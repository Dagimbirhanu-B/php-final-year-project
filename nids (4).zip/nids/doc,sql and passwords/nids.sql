-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2022 at 01:21 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nids`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(22) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `subject`, `description`, `date`) VALUES
(13, 'to all resident who register at 6/14/2022', 'Come and collect ur ID card', 'Sunday 29th  May 2022 09:30:35 AM');

-- --------------------------------------------------------

--
-- Table structure for table `issuedid`
--

CREATE TABLE `issuedid` (
  `id` varchar(20) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(67) NOT NULL,
  `issueddate` date NOT NULL,
  `expirydate` date NOT NULL,
  `uid` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issuedid`
--

INSERT INTO `issuedid` (`id`, `firstname`, `lastname`, `issueddate`, `expirydate`, `uid`) VALUES
('ET/427184214/22', 'ay', 'ff', '2022-06-19', '2023-06-19', 12);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `regstrationid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` int(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `bloodgroup` varchar(255) NOT NULL,
  `town` varchar(255) NOT NULL,
  `kebele` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `birth_day_card` varchar(255) NOT NULL,
  `important_file` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `dates` date DEFAULT current_timestamp(),
  `status` varchar(10) NOT NULL,
  `expiry_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`regstrationid`, `name`, `age`, `address`, `bloodgroup`, `town`, `kebele`, `state`, `nationality`, `occupation`, `gender`, `phonenumber`, `photo`, `birth_day_card`, `important_file`, `signature`, `dates`, `status`, `expiry_date`) VALUES
('ET/154207618/22', 'ss', 45, 'aaa', 'a', 's', '45', 'Adis Abeba', 'Ethiopian', 'student', 'Male', '899987745', 'photos/chali (2).jpg', 'photos/chali (2).jpg', 'photos/chali (2).jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/162618280/22', 'aaa', 19, 'dd', 'a', 'aa', '1', 'am', 'ethiopia', 'student', 'Male', '345677', 'photos/ayu.jpg', 'photos/ayu.jpg', 'photos/ayu.jpg', 'aa', '2022-06-20', 'Approved', '2023-06-20'),
('ET/168153724/22', 'aa', 44, 'aa', 'a', 'aa', '2', 'Benishangul-Gumuz', 'Ethiopian', 'qqq', 'Male', '912239819', 'photos/fk.jpg', 'photos/fk.jpg', 'photos/fk.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/244432255/22', 'aa', 20, 'dd', 'o', 'ss', '3', 'am', 'ethiopia', 'student', 'Male', '67788', 'photos/ayu.jpg', 'photos/ayu.jpg', 'photos/ayu.jpg', 'zed', '2022-06-20', 'Approved', '2023-06-20'),
('ET/299111982/22', 'hhh', 33, 'fff', 'b', 'aaa', '3', '', '', 'yyy', 'Male', '777777', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/324009454/22', 'fff', 52, 'dd', 'a', 'aaaa', '3', '', '', 'hhh', 'Male', '6890900', 'assets/ayu.jpg', 'assets/imgayu.jpg', 'assets/imgayu.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/422913040/22', 'aaa', 34, 'sagure', 'o', 'tep', '3', '', '', 'student', 'Male', '99887676', 'assets/fk.jpg', 'assets/imgfk.jpg', 'assets/imgfk.jpg', 'zed', '2022-06-20', 'pending', '2023-06-20'),
('ET/427184214/22', 'ff', 32, 'ff', 'a', 'ff', '45', 'oromia', 'ethiopia', 'student', 'Male', '7886437', 'photos/ayu.jpg', 'photos/ayu.jpg', 'photos/ayu.jpg', 'zed', '2022-06-19', 'Approved', '2023-06-19'),
('ET/467746327/22', 'ff', 54, 'aa', 'a', 'ss', 'aa', 'Adis Abeba', 'Ethiopian', 'ddd', 'Male', '98878676659', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/482568043/22', 'aa', 87, 'ad', 'o', 'tep', '4', 'Amharic ', 'ethiopia', 'student', 'Female', '6778865', 'assets/ayu.jpg', 'assets/imgayu.jpg', 'assets/imgayu.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/487844761/22', 'aa', 34, 'rr', 'a', 'ff', '4', 'eth', 'ethiopia', 's', 'Female', '6789945', 'assets/ayu.jpg', 'assets/imgayu.jpg', 'assets/imgayu.jpg', 'zed', '2022-06-20', 'pending', '2023-06-20'),
('ET/534525688/22', 'abebe', 23, 'Tepi', 'A', 'tepi', '45', 'amharic', 'ethiopia', 'student', 'Male', '234324343242343', 'assets/ayu.jpg', 'assets/ayu.jpg', 'assets/ayu.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20'),
('ET/751200372/22', 'ayalew', 78, 'Bale', 'O', 'Robe', '09', 'Oromia ', 'Ethiopia', 'Student', 'Male', '98776667', 'photos/chali (2).jpg', 'photos/chali (2).jpg', 'photos/chali (2).jpg', 'young', '2022-06-14', 'Approved', '2023-06-14'),
('ET/770130713/22', 'ayalew', 22, 'Bale', 'O', 'Robe', '09', 'Oromia ', 'Ethiopia', 'Student', 'Male', '46890088', 'photos/ayu.jpg', 'photos/ayu.jpg', 'photos/ayu.jpg', 'young', '2022-06-14', 'Approved', '2023-06-14'),
('ET/877931461/22', 'ayalew', 67, 'jj', 'O', 'jj', '09', 'Oromia ', 'Ethiopia', 'Student', 'Male', '77777777777777777', 'photos/fk.jpg', 'photos/fk.jpg', 'photos/fk.jpg', 'young', '2022-06-14', 'Approved', '2023-06-14'),
('ET/892728686/22', 'dd', 24, 'aaa', 'a', 'aa', 'aa', 'Adis Abeba', 'Ethiopian', 'aaa', 'Male', '09122398201', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'photos/12003167_10153695913717704_3502631914067017889_n.jpg', 'abebe', '2022-06-20', 'pending', '2023-06-20');

-- --------------------------------------------------------

--
-- Table structure for table `renewrequest`
--

CREATE TABLE `renewrequest` (
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `id` varchar(30) NOT NULL,
  `dates` date NOT NULL DEFAULT current_timestamp(),
  `email` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `renewrequest`
--

INSERT INTO `renewrequest` (`firstname`, `lastname`, `address`, `id`, `dates`, `email`) VALUES
('yakobe', 'shewa', '2345/87', 'bulen', '2021-09-21', ''),
('yihenew', 'mengist', '2334/09', 'der', '2021-09-21', ''),
('yihenew', 'mengist', '2334/09', 'der', '2021-09-21', ''),
('abadula', 'gemeda', '232323/09', 'bulen', '2021-09-21', ''),
('yihenew', 'mengist', 'abebe', '4534/767', '2021-09-21', 'yakobesewa@gmail.com'),
('Kebe', 'Beku', 'Nnj', 'ET/501774239', '2021-09-22', 'geti@gmail.com'),
('Jalele', 'Bb', 'Nnj', 'Yjd', '2021-09-22', 'geti@gmail.com'),
('gg', 'jhgjh', '3eeuig', 'ET/2313131434', '2021-09-23', '0946392947@gmail.com'),
('kidan', 'keda', 'ambo', 'ET/2313131434', '2021-09-24', 'kidukenenisa@gmail.com'),
('kidann', 'kedan', 'ambo', 'ET/2313131434', '2021-09-24', 'kidukenenisa@gmail.com'),
('kakilu', 'kakilu', 'kakilu', 'ET/2313131437', '2021-09-24', 'kidukenenisa@gmail.com'),
('kakilu', 'keda', 'amboa', '233333', '2021-09-24', 'kidukenenisa@gmail.com'),
('gg', 'h', 'h', 'h', '2021-09-25', 'chalachew@gmail.com'),
('gg', 'keda', 'dkdkd', 'ET/2313131434', '2021-09-25', 'jacob@gmail.com'),
('kakilu', 'jhgjh', 'dkdkd', 'ET/2313131434', '2021-09-25', 'yihenaw@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(22) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(55) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `fullname`, `gender`, `address`, `email`, `username`, `password`, `role`) VALUES
(12986, 'Chali', 'Male', 'Bedele', '0946392947@gmail.com', 'gov', 'e10adc3949ba59abbe56e057f20f883e', 'verified user'),
(12987, 'Misganu', 'Male', 'Bedele', 'chale@gmail.com', 'Misge', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(12989, 'Zinash', 'Male', 'Jima', 'yihenaw@gmail.com', 'Zed', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(12993, 'Adamu', 'Male   ', 'Injibara', '0946392947@gmail.com', 'Adx', 'e10adc3949ba59abbe56e057f20f883e', 'kebele officer'),
(12994, 'dddd', 'Male', 'Finotaselam', 'admin@admin.com', 'aa', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(12995, 'Ayu', 'Male', 'Bale', 'ayu', 'young', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(12996, 'ayu', 'Male', 'Bale', 'ayu@gmail.com', 'ayu', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(12997, 'www', 'Male', 'rr', 'admin@admin.com', 'hy', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(12998, 'rr', 'Male', 'rrrr', 'admin@admin.com', 'ju', 'c33367701511b4f6020ec61ded352059', 'resident user'),
(12999, 'Admin', 'Male', 'Assela', 'young@gmail.com', 'Admin', 'e10adc3949ba59abbe56e057f20f883e', 'Admin'),
(13000, 'Kebele_Officers ', 'Male', 'Finotaselam', 'hhh@hhhh.com', 'Kebele_Officers ', 'e10adc3949ba59abbe56e057f20f883e', 'kebele officer'),
(13001, 'ff', 'Female', 'ff', 'admin@admin.com', 'v', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(13002, 'dd', 'Male', 'Assela', 'admin@admin.com', 'ff', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(13003, 'ss', 'Male', 'ss', 'aaa', 'aa', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(13004, 'abebe', 'Male', 'Tepi', 'tegenumideksa@gmail.com', 'abebe', 'fdb122e7c906013a9bc0cb02c436fa8a', 'resident user'),
(13005, 'adane', 'Male', 'Addis', 'adnae@gmail.com', 'adane', '708349f9b982dd3feaaebf828ed5bb0f', 'resident user'),
(13006, 'fff', 'Male', 'fff', 'dddd', 'dd', '7fa8282ad93047a4d6fe6111c93b308a', 'resident user'),
(13007, 'fff', 'Male', 'fff', 'dddd', 'dd', '7fa8282ad93047a4d6fe6111c93b308a', 'resident user'),
(13008, 'fff', 'Male', 'fff', 'dddd', 'dd', '7fa8282ad93047a4d6fe6111c93b308a', 'resident user'),
(13009, 'fff', 'Male', 'fff', 'dddd', 'dd', '7fa8282ad93047a4d6fe6111c93b308a', 'resident user'),
(13010, 'fff', 'Male', 'ss', 'youngtag@gmail.com', 'aaaa', 'e10adc3949ba59abbe56e057f20f883e', 'resident user'),
(13011, '2222', 'Male', '222', 'youngtag@gmail.com', '22', '821fa74b50ba3f7cba1e6c53e8fa6845', 'resident user'),
(13012, '444', 'Female', 'ddd', 'youngtag@gmail.com', 'dd', '96e79218965eb72c92a549dd5a330112', 'resident user'),
(13013, '444', 'Female', 'ddd', 'youngtag@gmail.com', 'dd', '96e79218965eb72c92a549dd5a330112', 'resident user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issuedid`
--
ALTER TABLE `issuedid`
  ADD UNIQUE KEY `uid` (`uid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD UNIQUE KEY `regstrationid` (`regstrationid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `issuedid`
--
ALTER TABLE `issuedid`
  MODIFY `uid` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13014;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

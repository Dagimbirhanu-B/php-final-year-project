<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
   <title>Ethiopian National Citizen Identification System</title>
   <link rel="shortcut icon" type="image/x-icon" href="assets/img/logok.PNG">
   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
   <link rel="stylesheet" type="text/css" href="assets/plugins/fontawesome/css/all.min.css">
   <link rel="stylesheet" href="assets/css/feathericon.min.css">
   <link rel="stylesheet" href="assets/plugins/morris/morris.css">
   <link rel="stylesheet" href="assets/css/style.css"> </head>
   <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600&display=swap" rel="stylesheet">
   <link rel="stylehseet" href="https://cdn.oesmith.co.uk/morris-0.5.1.css">
<link rel="stylesheet" type="text/css" href="css/style8.css">
<link rel="stylesheet" type="text/css" href="css/style4.css">
<link rel="stylesheet" type="text/css" href="css/style5.css">
<link rel="stylesheet" type="text/css" href="css/style6.css">
   <link rel="stylesheet" href="style/w3.css">
   <link rel="stylesheet" href="style/bootstrap.min.css">
   <link rel="icon" href="images/icon.png">

   
</head>
<body>
<section class="contact">
	<div class="contact-form">
		<h1>Contact<span>Us</span></h1>
		<h4>We are available for free work . connect whith us via phone:0937850676
			or email:tegenumideksa@gmail.com
		</h4>
		<form action="">
			<input type="" placeholder="Your name" required>
			<input type="email" name="email" id="" placeholder="E-mail" required>
			<input type="" placeholder="White a subject" required>
			<textarea name="" id="" cols="30" rows="10" placeholder="Your message" required>
			</textarea>
			<input type="submit" name="" value="submit" class="btn">
			
		</form>
	</div>
	<div class="contact-img">
		<img src="assets/img/df.jpg">
		
	</div>

</section>


</body>
</html>
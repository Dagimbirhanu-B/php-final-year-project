<ul class="w3-navbar w3-light-grey">
    <li><a href="administrator.php">Registerd citizens</a></li>
    <li><a href="newuser.php">Register User</a></li>
    <li><a href="announcements.php">Announcements</a></li>
    <li><a href="announcements.php">Renewal request</a></li>
    <li><a href="myaccount.php">Account Update</a></li>
    <li><a href="users.php">issued id</a></li>
    <li><a href="users.php">Customize Users</a></li>
<li class="w3-right"><a class="w3-green" href="logout.php">Logout (<?php echo"$current"; ?>)</a></li>
  </ul>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
   <title>Ethiopian National Citizen Identification System</title>
   <link rel="shortcut icon" type="image/x-icon" href="assets/img/logok.PNG">
   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
   <link rel="stylesheet" type="text/css" href="assets/plugins/fontawesome/css/all.min.css">
   <link rel="stylesheet" href="assets/css/feathericon.min.css">
   <link rel="stylesheet" href="assets/plugins/morris/morris.css">
   <link rel="stylesheet" href="assets/css/style.css"> </head>
   <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600&display=swap" rel="stylesheet">
   <link rel="stylehseet" href="https://cdn.oesmith.co.uk/morris-0.5.1.css">
<link rel="stylesheet" type="text/css" href="css/style8.css">
<link rel="stylesheet" type="text/css" href="css/style4.css">
<link rel="stylesheet" type="text/css" href="css/style5.css">
   <link rel="stylesheet" href="style/w3.css">
   <link rel="stylesheet" href="style/bootstrap.min.css">
   <link rel="icon" href="images/icon.png">

   
</head>

<body>
   <section class="about">
      <div class="main">
         <img src="assets/img/df.jpg">
         <div class="about-text">
            <h1>Designer</h1>
            <h6>Developer<span>& Designer </span></h6>
               <p>We are front-end developer.We can provide clear code and pixel
                  perfect design.We also make the website more and more iteractive whith web animation.
                  We can provide Clear code and pixel perfect design.
                  A responsive design makes your website accessible to all users,regardles of our device
               </p>
               <button type="button">Let's Talk</button>
         </div>
      </div>
   </section>
</body>
</html>
<?php
include('include.php');
?>
<?php

include 'database_configuration.php';
$code = "ET/";
$prefix="ID:";
$dt=date('y');
$slash="/";
$r=rand(100000000,900000000);
$id = "$code$r$slash$dt";
$statu = "pending";
$file=$_FILES['image']['tmp_name'];
$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
$image_name= addslashes($_FILES['image']['name']);			
move_uploaded_file($_FILES["image"]["tmp_name"],"photos/" . $_FILES["image"]["name"]);
$important_file="photos/" . $_FILES["image"]["name"];
$birth_day_card="photos/" . $_FILES["image"]["name"];
$photo ="photos/" . $_FILES["image"]["name"];
$name = $_POST['name'];
$address = $_POST['address'];
$bloodgroup = $_POST['bloodgroup'];
$town = $_POST['town'];
$local = $_POST['kebele'];
$state= $_POST['state'];
$nationality = $_POST['nationality'];
$occupation = $_POST['occupation'];
$gender = $_POST['gender'];
$phone = $_POST['phonenumber'];
$age = $_POST['age'];
$date = date('Y/m/d');
$signature=$current;
$expiry_date=date('Y/m/d', strtotime('+1 years'));
$nameErr = $addreErr =$phonEr= $townErr = $kebelErr = "";
$name = $address = $town =$phone= $local ="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }

  if (empty($_POST["address"])) {
    $addreErr = "address is required";
  } else {
    $address = test_input($_POST["address"]);
    // check if e-mail address is well-formed
    if (!preg_match("/^[a-zA-Z-' ]*$/",$address)) {
      $addreErr = "Only letters and white space allowed";
    }
  }
   if (empty($_POST["phonenumber"])) {
    $phonEr = "phonenumber is required";
  } else {
    $phone = test_input($_POST["phonenumber"]);
    // check if phone address is well-formed
   if (!preg_match('/^[0-9]{10}+$/', $phone)) {
   $phonEr= "Only Phone Number";
}
}
  if (empty($_POST["town"])) {
    $townErr = "town is required";
  } else {
    $town = test_input($_POST["town"]);
    // check if town address is well-formed
    if (!preg_match("/^[a-zA-Z-' ]*$/",$town)) {
      $townErr = "Only letters and white space allowed";
    }
  }

  if (empty($_POST["kebele"])) {
    $kebelErr = "kebele is required";
  } else {
    $local = test_input($_POST["kebele"]);
    // check if kebele address is well-formed
    if (!preg_match("/^[a-zA-Z-' ]*$/",$town)) {
      $kebelErr = "Only letters and white space allowed";
    }
  }
  if($age>=18){
    $sql = "INSERT INTO registration (regstrationid,dates,age,expiry_date, name,address, bloodgroup, town,kebele, state,nationality,occupation,gender, phonenumber, photo,important_file,birth_day_card,status,signature)
    VALUES ('$id', '$date','$age', '$expiry_date', '$name','$address', '$bloodgroup', '$town','$local','$state','$nationality','$occupation','$gender','$phone','$photo','$important_file','$birth_day_card','$statu','$signature')";
    
    if ($conn->query($sql) === TRUE) {
        echo   "<script type = \"text/javascript\">
        alert(\"user request Successfully sent \");
        window.location = (\"residentexplore.php\")
        </script>";
    //header("location:explore.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }}
    else {
        echo   "<script type = \"text/javascript\">
        alert(\"age must be greater than 18 \");
        window.location = (\"residentrequest.php\")
        </script>";
    }
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
    $conn->close();
    ?>

   <footer class="w3-footer w3-amber">
<p style="text-align:center" Color:red> developed Young </p>
</footer>

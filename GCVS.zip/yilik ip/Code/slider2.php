 <!DOCTYPE html>
 <html lang="en">
 <head>
 <meta charset="UTF-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <style type="text/css">
   @keyframes fade {

0% {

opacity: 0;

}

100% {

opacity: 1;

}

}

* {

padding: 0;

border: 0;

box-sizing: border-box;
}

body {

height: auto;
overflow-x: hidden;

}
.slide-container {

display: flex;

justify-content: ;

align-items: ;
width: 100%;
position: relative;
margin-top: 1.5%;
}

.slide-container .slide {

display: none;

width: 100%;

}
.slide-container .slide.fade {

animation: fade 0.5s cubic-bezier(0.55, 0.085, 0.68, 0.53) both;
}

.slide-container .slide img {
       image-rendering: auto;
       image-rendering: crisp-edges;
       image-rendering: pixelated;
       image-rendering: -webkit-optimize-contrast;
       object-fit: cover;
       width: 1400px;
       height: 520px;
       opacity: 1;
}
.slide-container .prev,

.slide-container .next {

cursor: pointer;
position: absolute;
top: 50%;
width: auto;
margin-top: -32px;
padding: 16px;
color: white;

font-weight: bold;
font-size: 25px;
transition: all 0.6s ease;
user-select: none;
text-decoration: none;
background-color: #041E42;
}

.slide-container .prev:hover,

.slide-container .next:hover {
background-color: #ff4500;
}

.slide-container .prev {

left: 1px;

}

.slide-container .next {

right: -26px;

}

.dots-container {
position: absolute;
display: flex;
margin-top: 32%;
margin-left: 87%;
justify-content: center;

align-items: center;

padding: 10px;
}

.dots-container .dot {

cursor: pointer;
margin: 5px;
width: 20px;
height: 20px;
color: rgba(0, 0, 0, 0.8);
border-radius: 50%;
background-color: transparent;
border: 2px solid #c3c3c3;

}

.dots-container .dot.active {

background-color: white;

}
.slide-container .slide .content
{
  flex: 1 1 350px;
  animation: slidecontent .4s linear .6s backwards;
  margin-top: 10%;
  margin-left: 70%;
  position: absolute;
  animation-direction: normal;

}
@keyframes slidecontent
{
  0%
  {
    opacity: 0;
    transform: translateX(-50px);
  }
}
.slide-container .slide .content h2
{
  font-family: sans-serif;
  font-size: 30px;
  color: whitesmoke;
  margin-top: %;
  margin-left: 0%;
  
}
.slide-container .slide .content h3
{
  font-family: sans-serif;
  font-size: 30px;
  color: white;
  margin-top: %;
  margin-left: -2%;
  background-color: ;
}
.slide-container .slide .content .btn
{
  margin-top: 4%;
  margin-left: 13%;
  display: inline-block;
  border-top: 3px solid #90C0A8;
  color: white;
  font-size: 20px;
  font-family: sans-serif;
  padding: 9px 30px;
  width: 170px;
  height: 50px;
  text-align: center;
  text-decoration: none;
  border-radius: px;
  background-color: #48A860;
  font-weight: bold;
}
.slide-container .slide .content .btn:hover
{
  opacity: 0.8;
}
#b2
{
  margin-left: 60px;
  opacity: ;
}
#pause
{
  position: absolute;
  top: 80%;
  width: 75px;
  height: 50px;
  padding: 6px;
  margin-left: 5%;
  text-align: center;
  background-color: transparent;
  border-radius: 50px;
  border: 2px solid orange;
  font-size: 20px;
  font-family: Helvitica;
}
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .slide-container, .slide-container .slide img, h3, h2, .btn{
    width: 100%;
  }
}
 </style>
 </head>
 <body>
 <div class="slide-container">
  <div class="slide fade">
       <div class="content">
          <h2>ONLINE VERIFICATION</h2>
          <h3>For Higher Govornmental<br>Educational Institutes</h3>
          <a href="index.php?home slide.php" class="btn">Verify Now</a>
       </div>   
 <img src="iterfaceimage/new15.jpg" alt="">
 </div>
 <div class="slide fade">
        <div class="content">
            <h2 style="font-size: 30px; width: 700px; margin-left: -45%; margin-top: 15%;">MINISTRY OF SCIENCE & HIGHER EDUCATION</h2>
            <a href="aboutus.php" class="btn" id="b2">Find Us</a>
        </div>
 <img src="iterfaceimage/new2.jpg" style="opacity: 1;" alt="">
 </div>
 
 <!--<div class="slide fade">
      <div class="content">
          <h2>Graduation Day</h2>
          <h3>Graduates Attending!</h3>
      </div>
 <img src="iterfaceimage/gc.jpg" alt="">
 </div>-->
 <!--<div class="slide fade">
 <img src="iterfaceimage/gc.jpg" alt="">
 </div>-->
 <a href="#" class="prev" title="Previous">&#10094;</a>
 <a href="#" class="next" title="Next">&#10095;</a>
 <!--<button id="pause">&#10074;&#10074;</button>-->
 <div class="dots-container">
 <span class="dot"></span>
 <span class="dot"></span>
 <!--<span class="dot"></span>
 <span class="dot"></span>-->
 </div>
 </div>
 

 <script type="text/javascript">
   var currentSlide = 0;

const slides = document.querySelectorAll(".slide")

const dots = document.querySelectorAll('.dot')

const init = (n) => {

slides.forEach((slide) => {

slide.style.display = "none"

dots.forEach((dot) => {

dot.classList.remove("active")

})

})

slides[n].style.display = "block"

dots[n].classList.add("active")

}

document.addEventListener("DOMContentLoaded", init(currentSlide))
const next = () => {

currentSlide >= slides.length - 1 ? currentSlide = 0 : currentSlide++

init(currentSlide)

}

const prev = () => {

currentSlide <= 0 ? currentSlide = slides.length - 1 : currentSlide--

init(currentSlide)

}

document.querySelector(".next").addEventListener('click', next)

document.querySelector(".prev").addEventListener('click', prev)
setInterval(() => {

next()

}, 10000);
dots.forEach((dot, index) => {

dot.addEventListener("click", () => {

init(index)

currentSlide = i

})

})
 </script>
 </body>
 </html>
<?php
        session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:index.php");
		   }
		   else
		   {
		   ?>
<html>
<head><title> 
Registerar page
</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<style type="text/css">
body
{
  background-color: white;
  
}
img
{
  margin-top: 0%;
  height: 700px;
}
h1
{
    margin-top: -42%;
    margin-left: 31%;
    color: white;
    font-size: 60px;
}
</style>
</head>
<body>
<?php include "registerhead.php";?>
   	
<img src="iterfaceimage/reg.jpg" width="1580px" height="600px"/>
</div>
<h1>Registrar office</h1>
</body>
</html>
<?php
}
?>
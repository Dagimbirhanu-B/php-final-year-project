<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>adminhead</title>
 <style type="text/css">
 	#hub{
     
	width: 100%;
	height: 80px;
	background: #08457e;
	margin-top: 1%;
}
ul
{
	list-style: none;
	padding: 0;
	margin: 0;
	position: absolute;
	margin-top: 2%;
	margin-left: 10%;
}
#hub ul li
{
	
	float: left;
	margin-top: -4%;
}
#hub ul li a
{
	
	color: white;
	width: 130px;
	display: block;
	text-decoration: none;
	font-size: 20px;
	text-align: center;
	padding: 10px;
	font-family: Tahoma;

}
ul li ul{
	background: gray;
	width: 150px;
	margin-top: -0.5%;
	margin-left: 1%;
	
}
ul li ul{
	display: none;
	
}
ul li ul li
{
	
	float: none;
}
ul li:hover ul
{
	display: inline-block;
}
#hub ul li a:hover
{
	color: #3179a6;
	text-decoration: none;
}
#hub ul li ul li a:hover
{
	color: #08457e;
	background: orange;

}

 </style>

</head>
<body>
	<div id="hub">
         <ul>
	        <li><a href="AdminPage.php">HOME</a></li>
			<li><a href="#">MANAGE ACCOUNT</a>&nbsp;&nbsp;
						<ul>
							<li> <a href="create userpage.php">CREATE ACCOUNT<br></a></li>
			                <li> <a href="admindisplayuser.php">DISPLAY ACCOUNT<br></a></li>
			                <li> <a href="UserAccount.php">CHANGE PASSWORD<br></a></li>
				        </ul>
			       </li>
            <li><a href="Logout.php">LOGOUT</a></li>
        </ul>
   </div>
</body>
</html>
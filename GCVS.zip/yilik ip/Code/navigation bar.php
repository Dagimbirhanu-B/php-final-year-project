<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <style> 
 .nav {
	 display: inline-flex;
	 position: relative;
	 overflow: hidden;
	 max-width: 100%;
	 background-color: #fff;
	 padding: 0 20px;
	 border-radius: 40px;
	 box-shadow: 0 10px 40px rgba(159, 162, 177, .8);
}
 .nav-item {
	 color: #83818c;
	 padding: 20px;
	 text-decoration: none;
	 transition: 0.3s;
	 margin: 0 6px;
	 z-index: 1;
	 font-family: 'Roboto Condensed', sans-serif;
	 font-weight: 500;
	 position: relative;
}
 .nav-item:before {
	 content: "";
	 position: absolute;
	 bottom: -6px;
	 left: 0;
	 width: 100%;
	 height: 5px;
	 background-color: #dfe2ea;
	 border-radius: 8px 8px 0 0;
	 opacity: 0;
	 transition: 0.3s;
}
 .nav-item:not(.is-active):hover:before {
	 opacity: 1;
	 bottom: 0;
}
 .nav-item:not(.is-active):hover {
	 color: #333;
}
 .nav-indicator {
	 position: absolute;
	 left: 0;
	 bottom: 0;
	 height: 4px;
	 transition: 0.4s;
	 height: 5px;
	 z-index: 1;
	 border-radius: 8px 8px 0 0;
}

</style>
</head>
<body>
    <nav class="nav">
     
        <li><a class="nav-item is-active" href="index.php">Home</a></li>
	    <li><a class="nav-item" href="verify graduate2.php">Verification</a></li>
	    <li><a class="nav-item" href="aboutus.php">About Us</a></li>
	    <li><a class="nav-item" href="contact us.php">Contact Us</a></li>
	    <li><a class="nav-item" href="#">Help</a></li>
    
    </nav>
    <script src="snake.js">
      
    </script>
</body>
</html>
<?php
$gid=$_POST['id'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$q="delete from report where ID='$gid'";
mysqli_query($q);
?>
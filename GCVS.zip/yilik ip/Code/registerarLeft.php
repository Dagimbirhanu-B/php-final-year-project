<html>
<head>
	<meta charset="utf-8">
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
body
body
{
  background-color: white;
  width: 1600px;
}
#yuu
{
    width: 100%;
    padding: 0;
    margin: 0;
    background-color: #f5f5f5;
    position: absolute;
}
ul
{
  padding: 0;
  margin: 0;
  position: absolute;
  background-color: 1C6DD0;

}
ul li 
{
  display: flex;
  float: left;
  list-style: none;
  
}

ul li a
{
 
  background-color: whitesmoke;
  width: 130px;
  text-decoration: none;
  font-size: 20px;
  padding: 10px;
}

.active
{
  color: green;
  text-decoration: underline;
  text-underline-offset: 22px;
}
img
{
  margin-top: 4%;
  height: 700px;
}
</style>
</head>
<body>
    <div id="yuu">
     <ul>
            <li><a href="RegisterarPage.php">Home</a></li>
            <li><a href="insertregister.php">Insert data</a></li>
            <li><a href="select to view.php">Display data</a></li>
            <!--<li><a href="#viewreg.php">Search data</a></li>-->
            <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
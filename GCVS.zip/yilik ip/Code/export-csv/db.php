<?php
$conn = mysqli_connect('localhost', 'root', '') or die(mysqli_error());
$db=mysqli_select_db($conn,'gcvs_db_success') or die(mysqli_error($conn));
?>
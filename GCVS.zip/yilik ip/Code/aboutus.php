<html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<style type="text/css">
      *{
          box-sizing: border-box;
        }
      body
          {
          	 width: 100%;
             height: 100%;
             overflow-x: hidden;
    	       background: whitesmoke;
          
          }
            
       #h11 h1 
          {
             color: black;
             
	           font-size: 20px;
             margin-top: 2%;
             position: ;
          }
          #h11 h3{
            text-align: center;
            color: black;
            text-decoration: 3px white underline;
            text-underline-offset: 2px;
            opacity: 1;
          }
        #spa{
                padding: 16px;
                margin-top: 70px;
                background: #87CEEB;
                height: 600px;

              }
	   #spa p
	         {
               color: black;
	             font-size: 25px;
               justify-content: center;
               margin-top: -3%;
               margin-left: 15%;
          }
    #spa h3
   {
      margin-top: 2%;
      color: black;
      
   }
    #spa h2
   {
    
      color: whitesmoke;
      
   }
  #top1
  {
    margin-top: %;
  }

    #h11
        {
        
          height: 30%;
          margin-top: 0%;
 
        }
        #fooot
        {
            margin-top: 0%;
            padding-bottom: 0;
        }
        hr
        {
          background: #FFA500;
        }
        #with
        {
          margin-top: 20%;
        }
      #header ul li a
    {

      top: 4.5px;
      
   }

footer #bot
{
    margin-top: -2%;
}
footer .right-foot
  {
    margin-top: -14%;
  
  }
</style>
</head>
<body>
      <?php
		  include ('yheader.php');
		?>                
<div id="spa">
<div id="h11">
    <h3>welcome to</h3>
    <h1 align="center"><font size="6">MoSHE Verification</font></h1></div>
 <p>The Ministry of Science and Higher Education (MoSHE), established by proclamation number 1097/2018 in October 2018, is responsible to lead the development of science, higher education as well as the technical and vocational education and training (TVET) in Ethiopia.</p>
        


</div>
<div id="inn">
<h2 style="color: black; margin-left: 4%; font-family: sans-serif; text-decoration: underline; padding-top: 10px;">Moshe Ethiopia</h2>
<p style="font-size: 20px; color: #08457e; margin-left: 3%;">The Ministry of Science and Higher Education (MoSHE), established by proclamation number 1097/2018 in October 2018, is responsible to lead the development of science, higher education as well as the technical and vocational education and training (TVET) in Ethiopia.</p></div>
<div id="fooot">
   <?php
        include "Footer.php";
    ?>
        
</div>
</body>
</html>

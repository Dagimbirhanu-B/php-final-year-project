<html>
<head><title></title>
<style>
html
{
  overflow-x: hidden;
}
body{
  width: 100%;
  margin:0;
  font-family: sans-serif;
  overflow-x: hidden;
}
*{
  box-sizing: border-box;
}
.thumbnail-slider .item:hover {
  border: 1px solid #08457e;
}
h1
{
  text-align: center;
}
.thumbnail-slider{
  max-width: 1340px;
  float: left;
  overflow: hidden;
}

.thumbnail-slider .thumbnail-container{
  width: 100%;
  float: left;
  transition: margin 1s ease;
}

.thumbnail-slider .item{
  height: 240px;
  background-color: #fff;
  padding: 15px;
  line-height: 250px;
  text-align: center;
  font-size: 50px;
  color:#ffffff;
  float: left;
  border: 2px solid #EBEBEB;
  box-shadow: 0 4px 5px #cacaca;
}

.thumbnail-slider .controls{
  width: 100%;
  float: left;
  padding:15px;
}

.thumbnail-slider .controls ul{
  display: block;
  text-align: center;
  padding:0;
  margin:0;
  list-style: none;
  margin-top: -15px;
}
.thumbnail-slider .controls ul li{
  height: 35px;
  width: 35px;
  border:1px solid #c3c3c3;
  margin:4px;
  display: inline-block;
  line-height: 33px;
  cursor: pointer;
}
.thumbnail-slider .controls ul li.active{
  background-color: gray;
  color:#ffffff;

}
#f4
{
  margin-top: 30%;
  
}
#adi
{
  height: 100px;
}
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .thumbnail-slider, .thumbnail-slider.thumbnail-container.item, img{
    width: 100%;
  }
}
</style>
</head>
<body>
   <div class="thumbnail-slider">
    <div class ="thumbnail-container">
    <div class="item"><a href="Verification44.php"><img src="iterfaceimage/astu_addis.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification45.php"><img src="iterfaceimage/astu_adama.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification2.php"><img src="iterfaceimage/LOG.png" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification3.php"><img src="iterfaceimage/Addis.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification4.php"><img src="iterfaceimage/jima.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification5.php"><img src="iterfaceimage/hawasa.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification6.php"><img src="iterfaceimage/arsilogo.png" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification.php"><img src="iterfaceimage/MTU.JPG" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verfication8.php"><img src="iterfaceimage/bahirdar.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification9.php"><img src="iterfaceimage/haramaya.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification10.php"><img src="iterfaceimage/arbaminch.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification11.php"><img src="iterfaceimage/debremarkos.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification7.php"><img src="iterfaceimage/gonder.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification12.php"><img src="iterfaceimage/mekele.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification13.php"><img src="iterfaceimage/dire.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification14.php"><img src="iterfaceimage/injibara.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification15.php"><img id="bonga" src="iterfaceimage/bongauni.jpg" width="200" height="200" alt=""></a></div>


    <div class="item"><a href="Verification16.php"><img src="iterfaceimage/adigrat.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification17.php"><img src="iterfaceimage/ambo.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification19.php"><img src="iterfaceimage/assosa2.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification18.php"><img src="iterfaceimage/axum.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification20.php"><img src="iterfaceimage/borena.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification21.php"><img src="iterfaceimage/hulehora.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification22.php"><img src="iterfaceimage/debark.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification23.php"><img src="iterfaceimage/dembidolo.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification24.php"><img src="iterfaceimage/dilla.png" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification25.php"><img src="iterfaceimage/debrebiran.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification26.php"><img id="jij" src="iterfaceimage/jij.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification27.php"><img src="iterfaceimage/jinka.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification28.php"><img src="iterfaceimage/kebredar.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification29.php"><img src="iterfaceimage/kotebem.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification30.php"><img src="iterfaceimage/medawalabu.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification31.php"><img src="iterfaceimage/odabultum.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification32.php"><img src="iterfaceimage/raya.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification33.php"><img src="iterfaceimage/selale2.jpg" width="200" height="210" id="sel" alt=""></a></div>
    <div class="item"><a href="Verification34.php"><img src="iterfaceimage/semera.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification35.php"><img src="iterfaceimage/wachamo.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification36.php"><img src="iterfaceimage/wolkite.png" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification37.php"><img src="iterfaceimage/wolaita1.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification38.php"><img src="iterfaceimage/Wolleg1.png" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification39.php"><img src="iterfaceimage/wollo.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification40.php"><img src="iterfaceimage/metu.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification41.php"><img src="iterfaceimage/woldiya.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification42.php"><img src="iterfaceimage/worabe2.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification43.php"><img src="iterfaceimage/debretabor.jpg" width="200" height="200" alt=""></a></div>
    <div class="item"><a href="Verification46.php"><img src="iterfaceimage/mekidela.jpg" width="200" height="200" alt=""></a></div>
</div>
<!-- controls slides -->
  <div class="controls">
  </div>
</div>
<script>
  const controls=document.querySelector(".controls");
  const container=document.querySelector(".thumbnail-container");
  const allBox=container.children;
  const containerWidth=container.offsetWidth;
  const margin=30;
   var items=0;
   var totalItems=0;
   var jumpSlideWidth=0;


  // item setup per slide

 responsive=[
  {breakPoint:{width:0,item:1}}, //if width greater than 0 (1 item will show) 
  {breakPoint:{width:600,item:2}}, //if width greater than 600 (2  item will show) 
  {breakPoint:{width:1000,item:6}} //if width greater than 1000 (4 item will show) 
 ]
 function load(){
     for(let i=0; i<responsive.length;i++){
      if(window.innerWidth>responsive[i].breakPoint.width){
        items=responsive[i].breakPoint.item
      }
     }
     start();
 }
 
 function start(){
   var totalItemsWidth=0
  for(let i=0;i<allBox.length;i++){
     // width and margin setup of items
    allBox[i].style.width=(containerWidth/items)-margin + "px";
    allBox[i].style.margin=(margin/2)+ "px";
        totalItemsWidth+=containerWidth/items;
        totalItems++;
  }

  // thumbnail-container width set up
  container.style.width=totalItemsWidth + "px";

  // slides controls number set up
   const allSlides=Math.ceil(totalItems/items);
     const ul=document.createElement("ul");
        for(let i=1;i<=allSlides;i++){
          const li=document.createElement("li");
               li.id=i;
               li.innerHTML=i;
               li.setAttribute("onclick","controlSlides(this)");
               ul.appendChild(li);
               if(i==1){
                li.className="active";
               }
        }
        controls.appendChild(ul);
 }

    // when click on numbers slide to next slide
 function controlSlides(ele){
       // select controls children  'ul' element 
       const ul=controls.children;

       // select ul children 'li' elements;
      const li=ul[0].children
       var active;
       for(let i=0;i<li.length;i++){
        if(li[i].className=="active"){
          // find who is now active
          active=i;
          // remove active class from all 'li' elements
          li[i].className="";
        }
       }
       // add active class to current slide
       ele.className="active";

       var numb=(ele.id-1)-active;
          jumpSlideWidth=jumpSlideWidth+(containerWidth*numb);
       container.style.marginLeft=-jumpSlideWidth + "px";
 }

window.onload=load();
  
</script>
</body>
</html>
function validation()
{
employe_id==document.form1.Gid.value;
if(employe_id==" ")
window.alert("Employe ID can not left blank");
}
}
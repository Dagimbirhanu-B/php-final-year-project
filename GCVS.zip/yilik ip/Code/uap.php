<html>
<head>
<title>
ghc
<title>
</head>
<body>
o ya ya
<?php
$sel=$_POST['select0p'];
$uaccontName=$_POST['uaccount'];
echo "what did you insert";
echo $sel;
echo $uaccontName;  

?>
</body>  
</html>
<?php
 $gid=$_GET['ID'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$q = "select Photo,Photo_type from employe WHERE ID='$gid'";
$r=mysqli_query($con,$q);
if($r)
{
 $row= mysql_fetch_array($r);
 $type="content-type:".$row['Photo_type'];
 header($type);
echo $row['Photo'];
}
else
{
 echo mysqli_error();
 }
?>
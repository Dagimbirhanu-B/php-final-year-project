<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:index.php");
		   }
		   else
		   {
		   ?>
<html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
<link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
	#spacee
	{
		margin-top: 10%;
	}
</style>
</head>
<body id="contianer">
<div id="body">
<?php
		include "adminheader.php";
		?>
			
		</div>
<div id="spacee">
<br>
<h1 align="center"><font color="#08457e" size="10" >You are administrator of the system!</font></h1>
</div>
</body>
</html>
<?php
}
?>
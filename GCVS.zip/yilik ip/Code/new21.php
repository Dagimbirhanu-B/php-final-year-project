<html>
<head>
	<meta charset="utf-8">
	<title>MoSHE Degree Verification|Ethiopia</title>
    <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<p style="justify-content: center; color: #0053a5; font-size: 20px; font-family: sans-serif;">while hiring an employee, a recruiter tries to find out everything about the employee
 However, it is not possible to know whether the employee is worthy or not, therefore</p>
</body>
</html>
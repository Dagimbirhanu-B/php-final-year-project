<html>
<head>
     <title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript">
  function validationForm() 
      {
         var gid=document.forma.id.value
         var gdprt=document.forma.Department.value       
    if(gid=="")
      {
        window.alert("ID can not left blank");
        return false;
      }

      else if (gdprt=="")
      {
        window.alert(" you must Select Graduate department");
        return false;
      }
      }
</script>
 <style>
         body
          {
            background-color: whitesmoke;
          }
   input 
       {
          border: 1px #c4c4c4 solid;
          width: 40%;
          height: 5%;
          border-radius: 05px;
          padding: 8px 15px 8px 15px;
          margin: 10px 0px 15px 0px;
          box-shadow: 1px 1px 2px gray;
        }
#f 
		 {
        margin-top: 1%;
        background-color: white;
        height: 25%;
        border: 1px #3E98D0 solid;
        width: 960px; 
        margin-left: 18%;
        }
#s
	   {
        background-color: white;
        border: 1px #3E98D0 solid;
        box-sizing: border-box;
        height: 72%;
        width: 960px; 
        margin-left: 18%; 
        margin-top: 1%;   
       }
img 
    {
         margin-left: 1%;
         margin-top: 1%;
       }
h2
    {
        margin-top: -17%;
        margin-left: 6%;

    }
		
button 
      {
	     font-weight: 700;
	     color: white;
         background-color: #3e98d0;
         border: 2px #3e98d0 solid;
         height: 45px;
         width: 100px;
         border-radius: 13px;
     }
button:hover
   {
        background-color: #3179a6;
  

   }
input[type='submit'],text area
   {
       background-color: whitesmoke;
   }
input[type='text'],text area
   {
       background-color: whitesmoke;

   }
input[type=submit]:hover

   {
       background-color: whitesmoke;

   }
p
   {
      margin-top: -11%;
      margin-left: 50%;
      font-size: 18px;
      font-family: Open Sans;
  }
#s h1
  {
      margin-top: 0%;
     color: #3E98D0;
     background-color: #d8eaf5;

  }
h2
  {
    margin-left: 4%;
    margin-top: -16%;
  }
#tx
     {
    margin-left: 13%;
    margin-top: -8%;
     }
h3 
{
    margin-top: -2%;
    margin-left: 5%;
}
#f3
{
    margin-top: 20%;
}
</style>
</head>
   <body>
       <div id="container">
          <div id="f">
		  <img src="iterfaceimage/jima.jpg" style="width:15%">
      <div id="tx">
      <h2><font color="376FC6" size="5">Jimma University
      </font></h2><br>
      <h3><font color="green">Verify our Graduates Online</font></h3>
      <address> 
      <p><font>location: jimma town<br><br>
      Web: <a href="http://www.ju.edu.et/">www.ju.edu.et<a/></font>
     </address></p>
       </div>
       </div>
       <div id="s">
	     <center>
	 <h1>Fill the Information below to Verify</h1>
           <form action="verify page4.php" name="forma" method="POST">
               Graduate Id: <span id="sprytextfield1"><label><input type="text" name="id" placeholder="Enter ID" size="30"></label><br><span class="textfieldRequiredMsg">
               <b>Graduate Id Required</b><br></span></span>
               Department: <span id="sprytextfield2"><select name="Department" id="span9001">
<option>--Enter Department--</option>
<option>computer science</option>
<option>information system</option>
<option>information technology</option>
<option>Construction Technology Management Engineering</</option>
<option>Civil Engineering</option>
<option>Electrical Engineering</option>
<option>Mechanical Engineering</option>
<option>Survey Engineering</option>
<option>Water and Resource Irrigation Engineering</option>
<option>Plant Science</option>
<option>Animal Science</option>
<option>Agro_Economics</option>
<option>Forestry</option>
<option>Natural Resource Management</option>
<option>Eco Tourism</option>
<option>Health Officer (HO)</option>
<option>Nursing</option>
<option>Midwifery</option>
<option>Statistics</option>
<option>Medicine</option>
<option>Mathematics</option>
<option>Biology</option>
<option>Chemistry</option>
<option>Physics</option>
<option>Sport Science</option>
<option>Economics</option>
<option>Business and Management</option>
<option>Accounting and Finance</option>
<option>Management</option>
<option>Marketing Management</option>
<option>Tourism Management</option>
<option>Afaan Oromoo</option>
<option>English</option>
<option>Amharic</option>
<option>Journalism and Communication</option>
<option>History</option>
<option>Geography</option>
<option>Adult Education</option>
<option>Psychology</option>
<option>Sociology</option>
<option>Civics and Ethical Education</option>
<option>Law</option>
<option></option>
</select>

<br>
                <span class="textfieldRequiredMsg"><b>Department Required</b></span><br/>
               <!--<input type="submit" name="search" value="verify">-->
               <button class="btn btn-primary" name="search" onClick="validationForm()">&nbsp;VERIFY</button>
            </form>
          </div>
        </center>
      </div>
    <Script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
</Script>
   </body>
</html>
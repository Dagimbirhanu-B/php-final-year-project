<div id="mheader">
<img src="iterfaceimage/moe.jpg" width="1000" height="120" alt="logo image">
</div>
<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="RegisterarPage.php">Home</a></li>
			<li><a href="#">Manage Graduate Informtion</a>
				<ul>
	<li> <a href="insertregister.php">Insert Graduate Information<br></a></li>
	<li><a href="regupdate.php">Display Graduate Information<br></li></a>
	<li><a href="viewreg.php">Search Student File</a></li>
			</ul>
			</li>
				<li><a href="approveserreq2.php">Approve Request (<?php
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$result = mysqli_query($con,"SELECT * FROM company");
	$numberOfRows = MYSQLI_NUM_ROWS($result);	 
				if ($numberOfRows > 0 )
				  echo '<font size="3" color="#FF0000" bgcolor="#003366">' . $numberOfRows .'</font>' ;
				else
    			 echo " ";	
				?>)</li></a>
    <li><a href="verifygraduateInfo.php">Verify</a></li>
			<li><a href="sendmessearch.php">Generate Report</a>
			</li>
			
            <li><a href="logout.php">Log out</a></li>
		    </ul>
			</div>
 </hgroup>
</header>

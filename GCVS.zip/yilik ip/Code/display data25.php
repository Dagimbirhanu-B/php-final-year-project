<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:index.php");
		   }
		   else
		   {
		   ?><html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
 <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<style type="text/css">
   *
   {
   	padding: 0;
   	margin-top: 0;
   }
   body
   {
     width: 100%;
   }
	#select
	{
		margin-top: -10%;
		margin-left: 70%;
	}
#spaceesh
{
	margin-top: 1%;
	position: absolute;
}
h3
{
	color: green;
}
</style>
</head>
<body>
<div id="bod">
   
<div id="spaceesh">
	<h3>Graduate Information in Hawassa University</h3>
<form action="" method="post">
<table  border="1">
<tr bgcolor="#85A157"><th>ID:</th><th>F_Name</th><th>M_Name</th><th>L_Name</th><th>Year</th><th>Qualification</th><th>Gender</th><th>Department</th><th>University</th><th>Gpa</th><th>Delete</th></tr>
<?php
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$q = "select * from hawassa";
$r=mysqli_query($con,$q);
 while($row = mysqli_fetch_array($r))
{
$Id=$row['ID'];
$fn=$row['Frist_Name'];
$mn=$row['Midle_Name'];
$ln=$row['Last_Name'];
$cg=$row['GPA'];
$yog=$row['Year_of_Graduation'];
$q=$row['Qualification'];
$g=$row['Gender'];
$d=$row['Department'];
$uni=$row['University'];
?>
<tr bgcolor="#BADFE8" ><td><strong><?php echo $Id;?></strong></td><td><strong><?php echo $fn;?></strong></td><td><strong><?php echo $mn;?></strong></td><td><strong><?php echo $ln;?></strong></td><td><strong><?php echo $yog;?></strong></td><td><strong><?php echo $q;?></strong></td><td><strong><?php echo $g;?></strong></td><td><strong><?php echo $d;?></strong></td><td><strong><?php echo $uni;?></strong></td><td><strong><?php echo $cg;?></strong></td><!--<td><strong><img src="imagepro.php?ID=<?php echo $row['ID']?>" width="50" height="50"></td><td><strong><a href="regupdatepro.php?ID=<?php echo $Id;?>">Edit</a></strong></td>--><td><strong><a href="delete student25.php?ID=<?php echo $Id;?>">Delete</a></strong></td><!--<td></strong><img src="image/printer.jpg" width="50" height="50"onClick="javascript:window.print();"></td>--></tr>
                    <?php
}
?>
</table>
<!--<h2 align="center"><a href="export-csv/export.php">DOWNLOAD</a></h2>-->
<h1 align="center">There are <?php
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$result = mysqli_query($con,"SELECT * FROM hawassa");
	$numberOfRows = MYSQLI_NUM_ROWS($result);	 
				if ($numberOfRows > 0 )
				  echo '<font size="6" color="#FF0000" bgcolor="#003366">' . $numberOfRows .'</font>' ;
				else
    			 echo "No";	
				?> Graduated Students!</h1>
              <!--<input type="button" onClick="window.location.href='export-csv/export.php' " value="DOWNLOAD" style="background-color:#FF0000"/>-->

        </form>
      </div>
	</div>
</body>
</html>
<?php
}
?>

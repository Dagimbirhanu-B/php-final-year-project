<?php
        session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:RegisterarPage.php");
		   }
		   else
		   {
		   ?>
<html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<!--<link href="mycss.css" rel="stylesheet" type="text/css"/>-->
<style type="text/css">
body
{
  background-color: white;
  overflow-x: hidden;
}
*
{
   box-sizing: border-box;
}
#yuu
{
    width: 100%;
    padding: 0;
    
    background-color: #f5f5f5;
    position: absolute;
}
#yuu ul li 
{
 
  margin-top: -10px;
}
#d2
{
  background-color: #d8eaf5;
  position: absolute;
  height: 80px;
  width: 1600px;
  margin-top: -45.1%;
}
img
{
  margin-top: 4%;
  height: 700;
}
h2
{
   text-align: center;
}
#dl2
{
   margin-top: 2%;

}
#un
{
  margin-top: -41%;
  background-color: whitesmoke;
  position: absolute;
  width: 1600px;
  font-size: 20px;
  height: auto;
  text-decoration: none;


}
 a
{
  text-decoration: none;
  color: black;
  display: block;
}
a:hover
{
  color: green;
}
table {
  width: 1000px;
  margin-left: 5%;
  margin-top: 1%;
}


       .myTbl {
           text-align: center;
           border-collapse: collapse;
       }
 
           .myTbl td {
               border: 1px solid black;
               padding: 15px;
           }
   
</style>
</head>
<body>
   <?php include "registerhead.php";?>
   <div id="d12">
<img src="iterfaceimage/reg.jpg" width="1580px" height="600px"/>
    </div>
    <div id="d2">
       <h2><font color="#3E98D0">List of Universities</font></h2>
    </div>
    <div id="un">
      <table class="myTbl">
       <tbody>
        <tr>
           <td><b>S:No</b></td>
           <td><b>Institute Name</b></td>
       </tr>
         <tr>
            <td>1</td>
             <td>
              <a href="insert form42.php">Addis Ababa Science & technology university</a></td>
         </tr>
         <tr>
            <td>2</td>
             <td>
              <a href="insert form43.php">Adama Science & technology university</a></td>
         </tr>
            <tr>
            <td>3</td>
             <td>
              <a href="insert form44.php">Addis Ababa university</a></td>
         </tr>
            
            <tr>
            <td>4</td>
             <td>
              <a href="insert form14.php">Adigrat university</a></td>
         </tr>
         <tr>
            <td>5</td>
             <td>
              <a href="insert form15.php">Ambo university</a></td>
         </tr>
            <tr>
            <td>6</td>
             <td>
              <a href="insert form8.php">Arba minch university</a></td>
         </tr>
          
            <tr>
            <td>7</td>
             <td>
              <a href="insert form6.php">Arsi university</a></td>
         </tr>
            <tr>
            <td>8</td>
             <td>
              <a href="insert form17.php">Assosa university</a></td>
         </tr>
            <tr>
            <td>9</td>
             <td>
              <a href="insert form16.php">Aksum university</a></td>
         </tr>
            <tr>
            <td>10</td>
             <td>
              <a href="insert form2.php">Bahir Dar university</a></td>
         </tr><tr>
            <td>11</td>
             <td>
              <a href="insert form13.php">Bonga university</a></td>
         </tr><tr>
            <td>12</td>
             <td>
              <a href="insert form18.php">Borena university</a></td>
         </tr><tr>
            <td>13</td>
             <td>
              <a href="insert form19.php">Bule Hora university</a></td>
         </tr><tr>
            <td>14</td>
             <td>
              <a href="insert form23.php">Debre birhan university</a></td>
         </tr><tr>
            <td>15</td>
             <td>
              <a href="insert form20.php">Debark university</a></td>
         </tr><tr>
            <td>16</td>
             <td>
              <a href="insert form9.php">Debremarkos university</a></td>
         </tr><tr>
            <td>17</td>
             <td>
              <a href="insert form41.php">Debre Tabor university</a></td>
         </tr><tr>
            <td>18</td>
             <td>
              <a href="insert form21.php">Dembi Dolo university</a></td>
         </tr><tr>
            <td>19</td>
             <td>
              <a href="insert form22.php">Dilla university</a></td>
         </tr><tr>
            <td>20</td>
             <td>
              <a href="insert form11.php">Dire Dawa university</a></td>
         </tr><tr>
            <td>21</td>
             <td>
              <a href="insert form45.php">Gambella university</a></td>
         </tr>
         <tr>
            <td>22</td>
             <td>
              <a href="insert form17.php">Gonder university</a></td>
         </tr>
         <tr>
            <td>23</td>
             <td>
              <a href="inser form3.php">Haramaya university</a></td>
         </tr>
         <tr>
            <td>24</td>
             <td>
              <a href="insert form5.php">Hawassa university</a></td>
         </tr>
         <tr>
            <td>25</td>
             <td>
              <a href="insert form12.php">Injibara university</a></td>
         </tr>
         <tr>
            <td>26</td>
             <td>
              <a href="insert form24.php">Jijiga university</a></td>
         </tr>
         <tr>
            <td>27</td>
             <td>
              <a href="insert form4.php">Jimma university</a></td>
         </tr>
         
         <tr>
            <td>28</td>
             <td>
              <a href="insert form25.php">Jinka university</a></td>
         </tr><tr>
            <td>29</td>
             <td>
              <a href="insert form26.php">Kebri Dehar university</a></td>
         </tr><tr>
            <td>30</td>
             <td>
              <a href="insert form27.php">Kotebe Metropolitan university</a></td>
         </tr><tr>
            <td>31</td>
             <td>
              <a href="insert form28.php">Medawalabu university</a></td>
         </tr><tr>
            <td>32</td>
             <td>
              <a href="insert form46.php">Mekidela Amba university</a></td>
         </tr><tr>
            <td>33</td>
             <td>
              <a href="insert form10.php">Mekele university</a></td>
         </tr><tr>
            <td>34</td>
             <td>
              <a href="insert form38.php">Mettu university</a></td>
         </tr><tr>
            <td>35</td>
             <td>
              <a href="insert form.php">Mizan Tepi university</a></td>
         </tr><tr>
            <td>36</td>
             <td>
              <a href="insert form29.php">oda bultum university</a></td>
         </tr><tr>
            <td>37</td>
             <td>
              <a href="insert form30.php">Raya university</a></td>
         </tr><tr>
            <td>38</td>
             <td>
              <a href="insert form31.php">Selale university</a></td>
         </tr><tr>
            <td>39</td>
             <td>
              <a href="insert form32.php">Semera university</a></td>
         </tr><tr>
            <td>40</td>
             <td>
              <a href="insert form33.php">Wachamo university</a></td>
         </tr><tr>
            <td>41</td>
             <td>
              <a href="insert form34.php">Welkete university</a></td>
         </tr><tr>
            <td>42</td>
             <td>
              <a href="insert form40.php">Werabe university</a></td>
         </tr><tr>
            <td>43</td>
             <td>
              <a href="insert form35.php">Wolaita sodo university</a></td>
         </tr><tr>
            <td>44</td>
             <td>
              <a href="insert form39.php">Woldiya university</a></td>
         </tr><tr>
            <td>45</td>
             <td>
              <a href="insert form36.php">Wollega university</a></td>
         </tr>

         <tr>
            <td>46</td>
             <td>
              <a href="insert form37.php">Wollo university</a></td>
         </tr>
  </div>
</body>
</html>
<?php
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
	
<style type="text/css">
	body
	{
		overflow-x: hidden;
		overflow-y: hidden;
	}
	
*{

	padding: 0;
	margin: 0;
}

body{
	width: 100%;
	
}
.cnn
{
	width: 100%;
	background-color: ;
}
.cnn img{
width: 1600px;
height: 765px;

}
.sub-cnn
{
	width: 100%;
	position: relative;
	margin-top: -65%;
}
.sub-cnn h2{
	text-align: center;
	margin-top: 10%;
	color: white;
	
}
#righ
{
	margin-top: -0.7%;
	margin-left: 40%;
	width: 20.2%;
	border-radius: 25px;
}
</style>
</head>
<body>
<div class="cnn">
  <img src="iterfaceimage/real.jpg">
  <div class="sub-cnn">
  	 <h2>Login</h2>

  
  <div id="righ">
<?php
		include "yright.php";
		?>
		<?php 
if (isset($_POST['Login']))
			
			{
session_start();
$UserName=$_POST['uname'];
$Password=$_POST['pword'];
$UserType=$_POST['selectop'];
if($UserType==="--select one--")
{
?>
<div class="alert alert-error">
			  	 Please select your account type
				 and try again!!!
				</div>
<?php 
}
else
{
if($UserType==="Administrator")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}
else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:AdminPage.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="astu_addis@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form42.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="mtu@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="astu_adama@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form43.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="addis@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form44.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="adigrat@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form14.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="ambo@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form15.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="arbaminch@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form8.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="arsi@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form6.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="assosa@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form7.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="aksum@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form16.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="bahirdar@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form2.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="bonga@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form13.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="borena@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form18.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="bulehora@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form19.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="debrebiran@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form23.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="debark@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form20.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="debremarkos@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form9.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="debretabor@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form41.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="dembidolo@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form21.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="dilla@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form22.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="diredawa@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form11.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="gambella@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form45.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="gonder@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form17.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="haramaya@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:inser form3.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="hawassa@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form5.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="injibara@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form12.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="jijiga@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form24.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="jimma@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form4.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="jinka@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form25.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="kotebe_metro@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form27.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="kebridar@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form26.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="medawalabu@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form28.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="mekdela@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form46.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="mekele@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form10.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="mettu@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form38.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="odabultum@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form29.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="raya@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form30.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="selale@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form31.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="semera@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form32.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar" AND $UserName==="wachamo@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form33.php");
} 
mysqli_close($con);
}


else if($UserType==="Registerar" AND $UserName==="welkite@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}

else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form34.php");
} 
mysqli_close($con);
}


else if($UserType==="Registerar" AND $UserName==="werabe@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form40.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="wolaita@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form35.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="woldiya@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form39.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="wollega@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form36.php");
} 
mysqli_close($con);
}

else if($UserType==="Registerar" AND $UserName==="wollo@123")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}


else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:insert form37.php");
} 
mysqli_close($con);
}





}
}
?>

</div>
</div>
</div>
</body>
</html>
<html>
<head>
<title>EHEICVS</title>
</head>
<body>
<?php 
$gid=$_POST['Gid'];
$gfname=$_POST['Gfname'];
$gmname=$_POST['Gmname'];
$glname=$_POST['Glname'];
$gpa=$_POST['Gpa'];
$yog=$_POST['Yog'];
$gqul=$_POST['Gqul'];
$mgender=$_POST['mgender'];
$gdep=$_POST['gdep'];
$guniv=$_POST['guni'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "INSERT INTO assosa(ID,Frist_Name,Midle_Name,Last_Name,Year_of_Graduation,Qualification,Gender,Department,University,GPA) VALUES ('$gid','$gfname','$gmname','$glname','$yog','$gqul','$mgender','$gdep','$guniv','$gpa')";
if(!mysqli_query($con,$sql))
{
die('Error:'.mysql_error());
}
mysqli_close($con);
echo '<script type="text/javascript">alert("Student added success");window.location=\'insert form7.php\';</script>';
exit();
?>
</body>
<!--
$image_size=getimagesize($_FILES['image']['tmp_name']);
if ($image_size==FALSE)
{
echo '<script type="text/javascript">alert("Please select an student image!");window.location=\'insertregister.php\';</script>';
exit();
}
else
{
if ($_FILES['image']['size']<=60000)
{
$gphoto=addslashes(file_get_contents($_FILES['image']['tmp_name']));
$image_type=addslashes($_FILES['image']['type']);
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
if(move_uploaded_file ($_FILES['image']['tmp_name'],"image/".$_FILES['image']['name'])) 
,
,
,
else
{
echo '<script type="text/javascript">alert("The image is to big!");window.location=\'insertregister.php\';</script>';
exit();
}
-->
</html>

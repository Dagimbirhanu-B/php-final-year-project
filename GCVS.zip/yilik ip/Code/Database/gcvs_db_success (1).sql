-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2022 at 06:39 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gcvs_db_success`
--

-- --------------------------------------------------------

--
-- Table structure for table `addis`
--

CREATE TABLE `addis` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addis`
--

INSERT INTO `addis` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('SCIR/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Addis Ababa university', 3);

-- --------------------------------------------------------

--
-- Table structure for table `adigrat`
--

CREATE TABLE `adigrat` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adigrat`
--

INSERT INTO `adigrat` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Adigrat university', 2.7);

-- --------------------------------------------------------

--
-- Table structure for table `ambo`
--

CREATE TABLE `ambo` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ambo`
--

INSERT INTO `ambo` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Ambo university', 4);

-- --------------------------------------------------------

--
-- Table structure for table `arbaminch`
--

CREATE TABLE `arbaminch` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `arbaminch`
--

INSERT INTO `arbaminch` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Arba minch university', 3.4);

-- --------------------------------------------------------

--
-- Table structure for table `arsi`
--

CREATE TABLE `arsi` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `arsi`
--

INSERT INTO `arsi` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('SCIR/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Arsi university', 3.8);

-- --------------------------------------------------------

--
-- Table structure for table `assosa`
--

CREATE TABLE `assosa` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assosa`
--

INSERT INTO `assosa` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Ambo university', 3.4);

-- --------------------------------------------------------

--
-- Table structure for table `astu_adama`
--

CREATE TABLE `astu_adama` (
  `ID` varchar(40) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `astu_adama`
--

INSERT INTO `astu_adama` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('SCIR/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Adama Science & technology university', 3.4);

-- --------------------------------------------------------

--
-- Table structure for table `astu_addis`
--

CREATE TABLE `astu_addis` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `astu_addis`
--

INSERT INTO `astu_addis` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('SCIR/170/11', 'SISAY', 'FESYISA', 'SASXX', 2012, 'Bachelor of Degree', 'Male', 'Law', 'Addis Ababa Science & technology univers', 3.5);

-- --------------------------------------------------------

--
-- Table structure for table `axum`
--

CREATE TABLE `axum` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `axum`
--

INSERT INTO `axum` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2009, 'Bachelor of Degree', 'Male', 'information system', 'Axum university', 3);

-- --------------------------------------------------------

--
-- Table structure for table `bahirdar`
--

CREATE TABLE `bahirdar` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(11) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bahirdar`
--

INSERT INTO `bahirdar` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('224', 'abe', 'kebe', 'ke', 2003, 'Bachelor of Degree', 'Male', 'Law', 'Bahir Dar university', 3.14);

-- --------------------------------------------------------

--
-- Table structure for table `bonga`
--

CREATE TABLE `bonga` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bonga`
--

INSERT INTO `bonga` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Bonga university', 3);

-- --------------------------------------------------------

--
-- Table structure for table `borena`
--

CREATE TABLE `borena` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borena`
--

INSERT INTO `borena` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Borena university', 3.1);

-- --------------------------------------------------------

--
-- Table structure for table `bulehora`
--

CREATE TABLE `bulehora` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bulehora`
--

INSERT INTO `bulehora` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Bule Hora university', 3.5);

-- --------------------------------------------------------

--
-- Table structure for table `debark`
--

CREATE TABLE `debark` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `debark`
--

INSERT INTO `debark` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Debark university', 2.7);

-- --------------------------------------------------------

--
-- Table structure for table `debrebiran`
--

CREATE TABLE `debrebiran` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `debrebiran`
--

INSERT INTO `debrebiran` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2012, 'Bachelor of Degree', 'Male', 'information system', 'Debrebiran university', 3.9);

-- --------------------------------------------------------

--
-- Table structure for table `debremarkos`
--

CREATE TABLE `debremarkos` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `debremarkos`
--

INSERT INTO `debremarkos` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Debremarkos university', 3.6);

-- --------------------------------------------------------

--
-- Table structure for table `debretabor`
--

CREATE TABLE `debretabor` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `debretabor`
--

INSERT INTO `debretabor` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2007, 'Bachelor of Degree', 'Male', 'information system', 'Debre Tabor university', 3.7);

-- --------------------------------------------------------

--
-- Table structure for table `dembidolo`
--

CREATE TABLE `dembidolo` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dembidolo`
--

INSERT INTO `dembidolo` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Dembi Dolo university', 3.7);

-- --------------------------------------------------------

--
-- Table structure for table `dilla`
--

CREATE TABLE `dilla` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dilla`
--

INSERT INTO `dilla` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Dilla university', 3.8);

-- --------------------------------------------------------

--
-- Table structure for table `diredawa`
--

CREATE TABLE `diredawa` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `diredawa`
--

INSERT INTO `diredawa` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Dire Dawa university', 3.4);

-- --------------------------------------------------------

--
-- Table structure for table `employe`
--

CREATE TABLE `employe` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(30) NOT NULL,
  `Midle_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Year_of_Graduation` int(5) NOT NULL,
  `Qualification` varchar(30) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `University` varchar(40) NOT NULL,
  `GPA` double NOT NULL,
  `Photo` longblob NOT NULL,
  `Photo_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employe`
--

INSERT INTO `employe` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`, `Photo`, `Photo_type`) VALUES
('12', 'ayele', 'kebedw', 'feye', 1900, '--select one--', '', '--select one--', '--select one--', 3, '', ''),
('SCIR/024/11', 'Adino', 'Ageru', 'Yilima', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Mizan Tepi university', 3.4, '', ''),
('SCIR/177/11', 'Gutema', 'biruk', 'Faye', 2014, 'Bachlor of degree', 'M', 'information system', 'Mizan Tepi University', 3.5, '', ''),
('SCIR/234/11', 'AYELE', 'KINDE', 'EJIGU', 2013, 'Bachlor of degree', 'M', 'history', 'Mizan Tepi University', 3.5, '', ''),
('SCIR/277/11', 'Nebil', 'Sebsibe', 'Haji', 2014, 'Bachlor of degree', 'M', 'information system', 'Mizan Tepi University', 3.8, '', ''),
('SCIR/352/11', 'Yared', 'Tsegaye', 'kifle', 2014, 'Bachlor of degree', 'M', 'information system', 'Mizan Tepi University', 3.7, '', ''),
('SCIR/358/11', 'yilikal', 'mengedu', 'sido', 2014, 'Bachlor of degree', 'M', 'information system', 'Mizan Tepi University', 3.6, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `gambela`
--

CREATE TABLE `gambela` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gambela`
--

INSERT INTO `gambela` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Gambella university', 3.2);

-- --------------------------------------------------------

--
-- Table structure for table `gonder`
--

CREATE TABLE `gonder` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gonder`
--

INSERT INTO `gonder` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Gonder university', 2.6);

-- --------------------------------------------------------

--
-- Table structure for table `haramaya`
--

CREATE TABLE `haramaya` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `haramaya`
--

INSERT INTO `haramaya` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Haramaya university', 3.7);

-- --------------------------------------------------------

--
-- Table structure for table `hawassa`
--

CREATE TABLE `hawassa` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hawassa`
--

INSERT INTO `hawassa` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('Scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Hawassa university', 3.5);

-- --------------------------------------------------------

--
-- Table structure for table `injibara`
--

CREATE TABLE `injibara` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `injibara`
--

INSERT INTO `injibara` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Injibara university', 3);

-- --------------------------------------------------------

--
-- Table structure for table `jijiga`
--

CREATE TABLE `jijiga` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jijiga`
--

INSERT INTO `jijiga` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2009, 'Bachelor of Degree', 'Male', 'information system', 'Jijiga university', 3.2);

-- --------------------------------------------------------

--
-- Table structure for table `jimma`
--

CREATE TABLE `jimma` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jimma`
--

INSERT INTO `jimma` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('SCIR/024/11', 'adino ', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Jimma university', 3.7);

-- --------------------------------------------------------

--
-- Table structure for table `jinka`
--

CREATE TABLE `jinka` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jinka`
--

INSERT INTO `jinka` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2008, 'Bachelor of Degree', 'Male', 'information system', 'Jinka university', 3.2);

-- --------------------------------------------------------

--
-- Table structure for table `kebridar`
--

CREATE TABLE `kebridar` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kebridar`
--

INSERT INTO `kebridar` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2006, 'Bachelor of Degree', 'Male', 'information system', 'Kebri Dehar university', 2.8);

-- --------------------------------------------------------

--
-- Table structure for table `kotebe_metro`
--

CREATE TABLE `kotebe_metro` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kotebe_metro`
--

INSERT INTO `kotebe_metro` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2007, 'Bachelor of Degree', 'Male', 'information system', 'Kotebe Metropolitan university', 3);

-- --------------------------------------------------------

--
-- Table structure for table `medawalabu`
--

CREATE TABLE `medawalabu` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medawalabu`
--

INSERT INTO `medawalabu` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2009, 'Bachelor of Degree', 'Male', 'information system', 'Medawalabu university', 2.6);

-- --------------------------------------------------------

--
-- Table structure for table `mekele`
--

CREATE TABLE `mekele` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mekele`
--

INSERT INTO `mekele` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2014, 'Bachelor of Degree', 'Male', 'information system', 'Mekelle university', 3.6);

-- --------------------------------------------------------

--
-- Table structure for table `mekidela`
--

CREATE TABLE `mekidela` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mekidela`
--

INSERT INTO `mekidela` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2012, 'Bachelor of Degree', 'Male', 'information system', 'Mekidela Amba university', 3.1);

-- --------------------------------------------------------

--
-- Table structure for table `metu`
--

CREATE TABLE `metu` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `metu`
--

INSERT INTO `metu` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2009, 'Bachelor of Degree', 'Male', 'information system', 'Mettu university', 3.1);

-- --------------------------------------------------------

--
-- Table structure for table `odabultum`
--

CREATE TABLE `odabultum` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `odabultum`
--

INSERT INTO `odabultum` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2011, 'Bachelor of Degree', 'Male', 'information system', 'oda bultum university', 2.9);

-- --------------------------------------------------------

--
-- Table structure for table `raya`
--

CREATE TABLE `raya` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `raya`
--

INSERT INTO `raya` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2010, 'Bachelor of Degree', 'Male', 'information system', 'Raya university', 3.7);

-- --------------------------------------------------------

--
-- Table structure for table `selale`
--

CREATE TABLE `selale` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `selale`
--

INSERT INTO `selale` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2010, 'Bachelor of Degree', 'Male', 'information system', 'Selale university', 3.6);

-- --------------------------------------------------------

--
-- Table structure for table `semera`
--

CREATE TABLE `semera` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semera`
--

INSERT INTO `semera` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2009, 'Bachelor of Degree', 'Male', 'information system', 'Semera university', 3.5);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` varchar(30) NOT NULL,
  `Frist_Name` varchar(30) NOT NULL,
  `Midle_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Cumulative_Gpa` double NOT NULL,
  `Year_of_Graduation` varchar(12) NOT NULL,
  `Qualification` varchar(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Photo` longblob NOT NULL,
  `Photo_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Cumulative_Gpa`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `Photo`, `Photo_type`) VALUES
('22', 'wqe', 'wd', 'da', 4, '2002', 'Bachelors Degree', 'Male', 'Information Systems', 0xffd8ffe000104a46494600010100000100010000ffdb0084000a0708161615181615161918181a1a1e1c1a1c1a1c1e1c1f1a1f1e1e1c1c1c211c1e1c242e251c1e2b21181a2738262b2f313535351a243b403b333f2e343531010c0c0c100f101f12121f342b242c34343d3d34343634343434343436343434343434363434343434343434343434343434343434343434343434343434343434ffc000110800e100e103012200021101031101ffc4001b00010002030101000000000000000000000004050203060107ffc40038100001030204050204050402020300000001000211032104123141052251617181910632a1b11342c1d1f0145262e1728223f1151692ffc4001a010100030101010000000000000000000000010203040506ffc4002b11000202010303030401050000000000000001021103122131044151132271326181910542a1b1c1d1ffda000c03010002110311003f00f8ca222008888022220088880222200888802222008888022220088880222200888802222008888022220088880222200888802222008bd015b60780d5a972328efafb2949be086d2e4a85900baea5f0db5b775cff0097e807eb2af70fc2dad02181be00fd15fd3f2575f83e76cc1543a31decb67ff1757fb0fb8fdd7d14e07b2d75308009360a34a1a99f3d3c36a8fca7dc7eeb4bb0cf1f94fb2ef5f4d96beb61dd69ad820764d286a6706e691a85e2e93154832ce123bffebeca156c134dc08ee3f909a4b6a2a114cab8070bb79bc6beca242ab44d9e222280111100444401111004444011110044440111100561c3b85beb1b081b93a7fb2ac3817013539ea4b59b6d9bf60bb4c3d0681958d8360d81603b469fed6f0c57bb329e4ad9107847c38c60072e67757093e9d15e52c1168f947d07d96ce14d32644c037eb1dc6d65343dad8cee01c769fb7a2993d3b154af765757c2e68821a7dfd161428d42eca410d6c5ec011f73f44c4d463de1b9b2e633325a6de04edbab9a58369d89d398989f10a9ab62c95956fa0e66843a4ea741ecab4e2dce25b024187448d7417be9799fd9756fc2b3e58f1fcd8aa8c5e098dcee6cc804b8893062d9e3f9ee89a659a39dad41e1e1ed6ce81b2d0401e45c1fba93431198c3da01ea349f1b291c29d51cdb8e5b92e76fd22449fa050b8b615adbfe2b8c9f9072993791fdc3bab356e991f737e230a1c2e010b9dc770c2c25cc30352360baae1e0160871703fdda82aafe26616b040fcdaee3a2aa4ee897c59422811124dd6ac5e0daed45faa99fd746405a492d17881700cf75a71353fc627a5d438b26d14388c3169eca3abc7491a831d35502b6164666fa8e9e155a253212222a921111004444011110044440111100579c13858710fa9f2cf2b7fb88fd3eea170ac09aaf8fca2ee3dba792bb4a385e52ecb01bcad6f7d1a074017560c3abdd2e0c3364af6c792461c3aa6502c33468328681723c2b8ad5194f91a41738f3191ebbdb6b7521686e04b18d23416718de2f31a092a2e1b8717b8860e7025b330db89d4df50ba255f8328aa2ff000cf0ca61c199cbe600bd8103eff6f6f7fa47d47730870396379df9bdfd94cc33837245834961b0d1ae709bf61aae8286229ea61b27f4baf3324d36db66f18ead8a46705634b73105d0009893dd6fc7b053ca67d0f4eabde35880466a7399ba3ba5c1b7d6fdd50f1cc7bdf91849cc29b5c6d124e6998eb0ab19c657a7b132f6957f10f19a94de035ae0d700e6bf4907a761dc2d187e30e7bc32400e6177482038edb91d56fa643d8e63cc8232007a6bf36a082a0e2b859a2cf983a4434b9b0e683ca61c3c10baf0ce0e34d6ff00e4cdb7c92f84d069a4c2dccc71693e2e4b646fb7995857a8e79730b01c924db5bc48f3ad96be1d45f49a1b985893bd81d87553e9974e7cd6e8440fbace592a4fb974f6349c292d6e474489246f63ee6557f187bdd4887309b6b1b8de4595931e43e1b25ae22da44ebe9d8dd658ba3918f7bde4c66232fe5001fae96ea255a324dd92737846b0b72ecd88ccd3326e6276995a31f432e82e7acfd202c06383a93b339ad7b4481101fedbdf4f1e159ff4e2ad36b83a244c9bc755692a7b84ece5b29cf60645fc47fefeab6d5a8043bafef041f1aa91530391c1cd7c8d3afd945a8c0e7380dc48e92227f455924c9443c761a3987a8fd54056e1e4b8b7dbb74f455f5e9c1edf63b85934d164cd0888a09088880222200888802c8058abbf85f081f573384b597f5fcbfa9f457845ce4922252d29b6741c2b861635ac6fceebb8f43bfb68ba5c7e03261ac25c1cd224c1306481d4c2c383d300b9eed07f07f3ba9d8a0c2412333bf286ea0cc9bde0f85e93f6d45708e28abb6fb9368b3388194b0f35cdc489820ea27ac2b8e17c3a9b03b21beba5b41a0df6f55c3f17c5318d1469b5c1ef21adcdcc25c4024c72b8805755c3681a7c9261a00127fc44c7b91e8b83accbe9457dece9c51d4e89f88a148435af877cc65b98b85c1d3427ad9690e0e68200e84cc83fee67aaf7122c047cc0dc098131046ddad1758d1c3c372b76045b6defdd78b3c8e4b83a631a91b1b4e4e5899b2aee37820fc4b58d89735c2f313e9a0d07a2b7a0d70320de3dbbad58cc2c657dc16999eba0f0428c3974bdcae48da382c6517d3a818e21a5c600699bc8100f593e55b56e0b51f4b2d6665f9434075e24b8e61d4971b2b9e30c6ffe11458d0fce5e41ccd8106490c20b8193d41cabc7e3dc59519559665e49c921d05847f688cd727f2f75ea7b694a2ce651a39cc6618b440194b400379b0efac2814b893db6cb9c1fc83ef27e51e54dce0b8bc3e5b25a4021fa5ee41b112142ad8c6339896826e41be603681a9b4792a91b72a488b206378d96cb430b5e2d05d21bd3efb15af8cd2a8e6c924e85c0ddc48fb346c0752b5e32b61f3078673384964cb648302c600f126c1555521afe427404c1de2f706e2ff55e8431f0e3b7cf722c88f692bac75334b0c5dae50047a80efbfd173d82c5163816ef008ea0d88fafd02bcf895e5947269350ced3027daf30a722b69168f0d94eec4076600837fa40d27b8519ef01cc6f633da6dfcf451b0e79dbe44fdd4e7d2ce5e401686b49df28bc7d2ea928a459323bc16bb36bb1f4d47de3d12b61c3a63f30fadaeb6d5a80da35049dbc58f85861cf3017d0ebb755849772e8a57b48241d42c54fe294a1c1dd75f3fcfb280a85822220088880222203d0bb7f85f0d969b09d5c4933d341e9027d571749a49006a4c7bafa1536860000b35a1a3d2dfcf2bb3a385c9cbc1cdd4cb648e86ab7231ed644beed9d3b0f36fa291fd535cd194004b4176a0b645c1b795ee0199e8d3e4cfacdfa4fbdfeeb654a0184b8b6f1700d8ed707a4eb1b7a2de4d5d148ad8ace17c1df53122ac35ec6831cc22f2098eb136d2e6ebaf7d3e6ce34307e9fb00ab385e2a8d07963f91eeb6f95c018194f526d0bb0c370da4d0d666e60d0e2d0750e90246db81a7d179bfc841cda6bb23ab04945b39f7971122fd07698f0bdc1b207f36fe15371b866b4b836603ac23e93bdc2d74e9d8342f1e7b2a3a5ab6a47ad3b2c1f584c6606f102f07a763fbacb10c2c61790605845e493fa05a303822e25f50f34d80d44db9836635948616f7665296f48d9fd3b1cfce64bc003ef1f73eeb53783cd5fc4352a3db32199806367b340cf1fe53a29cdc334105cf117136b419d4ded22e6d2a49a82e0110226e09d3b6960177e2835cb28dd9cd71ee1ee6b4bd8c73e3664171336307cdcaf99f1aa0f0e0e7b0b2c045fadbd6fb2fb456c5b3364cc3374ebd87536365c9fc4d8863001933bdf229e58b1260124e8d985ddd3a517696e6738a67ccb09847d578632c7bda3b9e9e54bc4f0e6517b195641939cb4820b731822276dbfdae8bffacbc3439d880d90efc5ca040fee87685dcc04596bc17c24c6cbaa562e6b4f25b288718079891f31169fbaea9644fb9451673b43044bd80f2b1ce993fda2e0b80b34c103fec16cf8ab141cfc8d321923c19e699ee14ce298e652696527b9ee265a4105ad1f30325b2e7735a0c05cb9449b7a992dd6c7b4810410262fe237fa296fb31d3b9903703f4dbd96341c186e756ed79b8f6d0ac2ad47340d066e6b6b06c27d9564ac2230a8478fafbaf1954833befdd1ddb6d7f9eeb13bc0d964d1744fc6d3ccd3d6247a7f3eaa8974cf1a77fd573b59b0e23a12b951a7735a22290111100444404fe0b4f357a63fc81f6bfe8bb3afdbb7ebfed733f0733362e98ecf3ecc72e971601cdb4683b4991f55e9f44bd8fe4e2ea3eb5f075d84aeca14cb1af6e71cce9fcb619b2f5d09eea160388b6b3c87b5b2fe5e6b06c16b9d2664c8ce3cc2e6b118ecc2eee636222c632c177588dfa2cb82d721c743966a5e3568244797643e1a56cf1ecdf70a474fc76a7e0ff4f56bb1ef636a3da0f282f2d735ec2ee920b846f966caf307f1235d88655a721b88a259cf670a94ce7ca6f1f2d481d79571d88e32eab83c8e712e0f69ca4b5d3ac16348e589dba28583e2645365e2a52aa5f4cc0e60f1ce1d6db2363b3c8d8473e5c0e70aefbaff0085d4f4b3ea0caa5cc1e4fdede8b712761ffbdd43e0751af6676dd879803b0234e9214dc4566b03cbcc06b73ceb6bf4d745f31284af4f7b3bd4ee08ade2a5d0dccf631b3f9de1a2dd01d56ba9c4db876801cd03fbcbc10e71ee04137dd7cfb1f887bdc4bdc5e4ee4cdff65595aa3a08931e57bd8ff8c4a2937b9c0f2dbb48fa5d4c4b5f7fc517d48783989d034345879ecb99e29c71cc78a6c25a081704889defefe371b72987aa5a64120820823af557df15615a4b2ab1d2da8d306d7801c0dfb3fe88ba458f3252769dd7cfdc6b6d6c5961f83bf9b26269bc38fced7cbf9490e82446a4999bc7950788d1cafa6dfc40daedf947ccd6c905a73da62c7cae6595b2b8c9768458c5bcec160718ebc137dc99802f0bb3d377c8d4a8e97158f18660a42a7e287173de45839e63311698194341df31b74a4a9c65ef680f71700496b66037711d2febdd55d5a85c64993fcfdd608b1a5c93a999622b39ee2e71927f410206c00004765aa3f65947d96ea04734ea2e34f5dba23d81ed569cc06b03d046beca357749df7d775221d0e80609b3a2d6b44ec2ff006512a8bfd3d966cb1e35be617a74853f1187e561636416ea3aeff59fe050dc227c2c1bb2e8b361058dbcd87b8b1fb2a3e20d879ee0156580f908e87f495038afcc3fe23ee57355368bdf04144442422220088880baf84eae5c4b0f670f763975f8f0c7bf30e56bc6f10d75e663691ec570fc0aa65c4533fe51ef6fd5768f8bb4d9a75244e53b1b79d17a7d17d0fe4e2ea3eb5f06a7709aa4b8b40395e585d9844b5a5f69d8b74eb0a2e270e69b58e1763c1735f119a090eef00888ec55bd6c0b9b99c65ec34cb8398e367346504c683b9d9c7a151b04f7d5a670ef7e5a4dccf61736cd7c1b077e50e2413fc9e9d4f92a9103f09b9039e6e5a4b4348b9d25db47617bad8ca25ad6973480ee669d88923eed77b2d5f86d349ae2f21c33402d30472e582045e5d73fd8a6d1c4b5d4b2963a584c1cc728cdfe3a66e517b4803a2bd83bbf842b37f05a3369208e9724cf4b9faab0e38f268bc3742c0445e72925d7178cae3ecbe7f80c5ba9ba5a60ee3f433bfeebb5e1bc45b5a9c4017e6b6e398c89f948074eebe7faae9678b3facb75766f09dc74b38cc5d10180e6638bc9968bb981b119b600e6d3b76502a60cb9a3231ee3249cad2e6c18cb10267e607febdd77b8af8729bc0c9560388b06492e83f338c65173a0034e8acf03f0d3452bbe1e464602620e593aeaef9b49d3caf41f5b175a377faa29e9c9b3e3b87c31738c16803fb8c7b000b9c601b004ab3adc3ab656380156930921b4df9c341399c080039b31330b671ee02683dc5e5a199a1a585cecfd729020103ac2a7c2e25eca80d3719981789e9336f75bcb54bdd16bf24556cc8d5694e9afb4f9da5682c3171d9745c4df9ddcd4194df624e6680e1a926618f240f59d16cc470ca21ad77f52c27f2b5f0044dc4b492083627baa7ac955aa6ff24a89cc166bd3ee778fe7dd6a2ae307c21ef00e6a7cc61a3382e7eba345c0e5264c0d3aabba9f09536d16bcd5caf73a21cde506272cb660d88d75b2b3c89724a8b671ff00cfe4a90d70c9f2b499f98c489d2372bdc561cb1c5ae224120dbf51f3795ed4ab2d80c006821b727cf5bdd565b928cab97e41f34020b796046d3d9573185ce03a9ff67e8a5bdee75a649b01266ddbc13f55860df95e6458823dc1eab37b22c6cad55ce88f962201d00509d72624f9de06fd16ca96969317b8d8ff0021697bcd81e9efdd62cb9bf0b52096cebfcfd945e2bf38ff0088fb959d330737436f751f1cfcce27b058cd6f65911911150b044440111101b6854cae6b86a083ec657d05ee07987e6163e458f820fd17ce82edb81d6cf419b969ca7d3e5fa10bbba19d49c7c9cdd4c76522e7098d2323089631f2e044cc883ff5920f90b656c030d7652c3bf296b83cd4711929e53999941ef1b9f5baaeacc1072c9075d8f5f433faaf1bc62a31a18c63439aebb83412483ca0f7907cc9dd76b8be518c5f93ce2582afa54a61ae0621a001a6627a19cc0cdf5eea3e028905ee6bd90c682e971e604fca04735c0911b2b1c4717c4bde333f3864925ec6920169cf2e805a08241bda4c2d14f8632a8ffc767b9b998c6f359bf307173a64f616ca54a934b725af03155838b5c18d635c24064c6a418927488f485bb09c5dd4243434cff766f1a0236561c13e1fcec01c1d99e40032c43a621dbc001c7308d809547c6280a351cc69cc1a4c3a2038025b201d6635fba29464f4934d6e59f08f88cd17879692dcc7344ea44b48d2fada6fe8bafc371ea18b6b2993107306e8e0e68d87a993245d7cbce2a46525c1b325a2e2c08075b9bc5fa95618ac30a4ea55a93c73f335ad0e6e483f2cbc99b46fa3972f51d2c65ee8b69f95fecb464d7c1f46f8878752751735f50309772b9f25ae2e83a892232911e3d7e5b8ec1ba9b8b091237690e0411223f6f45f47e27c34e270d4dcd7f206e72d90f0f30013c864c1b6a08bdfaf1d8af86aa320e7664cb2f82e041dc65745c6f78b1f0b3e9e7a63527b969ab7c1cfd4659b2e91b0266dfa7fbd964dc388758103a189248026d717ea174980f865f5db2fa9940e58ca79a2f21ceb589e97bab6a5f0d502e734b0e56b5ad64820925a1c5c5c490f3723e500690ad3ea609d5fe828b6729c0f10d63cb5cd39c119034b441cd065da131a495d6d5c306d374b5ee06e672ce61a0ca0c6866c469dd570f859ec32d2ce96047e6104e6993964400d17f20ecc61c4d16e5654060f24c5a4c19b5e04ebdfa42c65961392d2cb2b4b72b2b32854971a8c611100b410075ef107d67b2e7b1258d76563f38137321b27a03eeb3c532a9739efe6330e71de3976f10b4bdac873cb23a06981311bc98d4ea0f85ba55dc8bb300d0640d409d43477d77ed0b2a187793f2b4cc004b85b61a1515b49cf2035a4ed61d7a957785c4330ed731f05f20bb28923fc67491fa9f2a9374b62628d188e1244b9c6f1a6b7b7b055788c3e5df9763f7f1247d558e338cc8302fa366e00de7a930aa2b621eef98cefeeb1f77734d8d4eb951ab3a492b74c02545594df6262111150b04444011110057df0be2a1e699d1e2dff0021a7b891eca89674de5a410608333dc2d31cdc24a4bb159c7545a3bf7bcb24e689027bdf43edaf95a99524da3390ef949e6d4dfa3c6c4ec02612b8acc6b845ece1b35df9878dfc15856a0009ee35907506c623a7baf6ad495aee79cad6cc9c38c96d373233c99cc5a089b4661fdd0eed16f4d25ed069d725f41d20921a72b85fe5736f260882b5606b339b346726d221a4122440b03a9b6b2b67e2547402f2c630c3ac4116004b742dd069f754aa364ece8f13c42ab0b05061acd7805b2039f940ccef9036e240133eaa3623174eab83abd36b45c383d8e0f31130eb3819e86c6563c370ae643f3e723e43a34b75370201d35efb9131b8ce12939c1e402088195e006ba4ce616209cc378e5b2c92575fdcb6f449c56070d908149accee003dce2f741112c2e240b3a4f703455d8af85807e4fea590d6b092e0e69cae2e24804904803e56eab7bf80550f963d80139c663981b98b8d2d97e68bf85b7138aaac73bf129bc886bb9592c1101d94ed62413e3aa6a7d98af28afabc3aa618b26b6561773657653674599671d27422fd8ab5c37e236bb1ef736ae66e5978cb9181d01ce2089796cdc85a69710a751af7383488e4044b81e62439d3b939af657bc238707b5af792f63980343f5001079e35168f52b0cd2515725f62d15e0b17d12e7b5ac7435a27fc6c00f31d94c31716cba6a401d21635e93b9b2dcc893006e3d237586522e6e6445a0011303af5eebc9d2d9aad8838aa845839c1a008311e6e5536287e3ba1a32c006e274106fe815de2e93ded2e73cb5ba902499bfa5beca03b8696c961f3169d0852e34b621db7f6283118110333649d4df9b6e6137d22eabf88610b98e0c1a5cb401cc6d336d84c4745678ac416970be63af413a4fa10a13dee6b7fe462768df45a4724a2d6e50e4eb020168983a8ebd27aa8eba77e058f9394037332476113ac28eee1d4c036327be8ba5f5517e4b462ce75cd3aaf2faffb533174c31d95b78ebaf5fd94727571dbf908e57b96aa23d73103d4fe8a32c9ce932562b16ed974a8222282422220088880222202e7e1fe2229bf2b8c31d627fb4ec7c75ecbb1a92c306fa6f622d11da34217cd9755c038c02c146a9b8b5374e9fe27a8e9edd176f4d9ebd92e0e7cd8ff00a9172cc1b1ff00988be9e605afaf6f0b5bf04f0408d04174df2c6e2fff00ebca9587c35a4bf2998fe7d14fc302d780ff00976362275ff5b2ed949a39e3b9b70784a6f6652fcaf8b1cae33725ae639ba3e09040b1e9d3556c1bcb4b79de621af209044c73130eee24189dd5bb5d4dc0810d37b88304ef636f3a2ab7d32d7f2547813711a1da6e3de2160a4ecd89fc370f5031a1e5ccbe90d3034e52c33adefeead8d178681f88d789b6664913fddac8f51aae73faa15580d5a90d0e232b09619d04983ec4ae8386500180444692f2f24752480b29df2cbc4895787512030b18c04c9686dccdb283617d069a0b2e93f0453a4d6080c000e5b408000f0aadf426408bd887f30f51bfbaace118bc4b09c3625b9d84102a033e2dac47d6161962e71b4f82cb6278e2833b9ae69681bdf5bc8f6df75ba8712a6f16b01d607d555f1e790d0e0d697130e205ec0826370418ecb962fda606f7fd375c4e4d147271747d02b546467cc0883a11a6ea8b17c6e9b07292f244da2dd24ecb9a6f29b131a69aff003bac6bd082329cc0ee3eb2a7593a9be0c7198b73de5ee024fb0f0b0a0dcc6e7d365eb99ca61b274f1d6cb263328efd951b118bbdcf312f007d956e3b14182ff31d07eaa5d5749f0a831f4cb9e48d2235d1698a09f2684671977cc49266ca2e26a7e51a0d7cacea54cb206a7a6c1445bc9f6252ee111150b044440111100444401111004444074bc278cc80caa6e3e571dfa077efeeba31fdcc7169ddbb1ee06f73a775f37575c278e3a910d77333a6e3c76edf65db87a9a5a65fb39b261df547f4752ec69b07b03a35205cf8b882a4d3e28c1f213036a83ad8c39a4387993a2d14f114ab82e6b81275d646dcc3506dade7bad2fc3e5bda0e87513dfa1fe42e9f6c96c649b5c931d8a6939dae8322083ccdf040b8ece1e4abac27180400ef198447a8996fd75d573749f481e767a8db79f1dd5bb28537004098d1d3063d2167348d22cbbfeadc3691e57aec5b5fcb9b29d8386fd8e8557b4f433d24cfbeeb4d578fcd1ef6faac28d2cb1c4634b4c556b63670b0ff005ba8d8ca4c7ddac683d743f4179ebf450ead7696c6ad3b1323eba7d96186a9166dafbde3b785cf931c5705d54b930a99c00c74346808bed6f5d542638b0c466d6f3fcb2b27d104cb9fe8140c4d368f95df5fd97338515a3c7bfba818bc535a39880b46331996c4c9e837e8b9fc4552492eb795a430deef82d65b1c7070e5d3beaaaf1f8b0395b73b9e9fed44a989b436c3aee5455a3a5c1297904a222a96088880222200888802222008888022220088880db46b398439a4823420c157b83f8948b546e6eae6d89f23477d173a8af19ca3c32ae0a5c9dad2c5d0a821ae689fca6c67b077e8a4d263da0863e0748fd4ae0548a38b7b7e57380e8098f65baea5f7464f0f867d12863aa3443db200d586fecb462aa079904c0d80b8fd571ace37587e69f216e1f10d5dc34f907f753eb4791a245e606b3f3c5b283cc4fb5bb9567fd4c4995c83be21a87f2b07fd4feea357e2d51da903c058e492932d18c923aec471160b66f417fb2a8c4f13899706f8bbbd84c2e75f59c75256a5454b85fb2da7c93eae36fcb3e5ca1bde499264ac111c9be4b249044455242222008888022220088880222200888802222008888022220088880222200888802222008888022220088880222200888802222008888022220088880222200888802222008888022220088880222200888802222008888022220088880fffd9, 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_type` varchar(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_type`, `Name`, `username`, `password`, `email`) VALUES
('Registerar', 'Addis ababa university', 'addis@123', 'addis@123', 'addis@gmail.com'),
('Registerar', 'adigrat', 'adigrat@123', 'adigrat@123', 'adigrat@gmail.com'),
('Registerar', 'aksum', 'aksum@123', 'aksum@123', 'aksum@gmail.com'),
('Registerar', 'ambo', 'ambo@123', 'ambo@123', 'ambo@gmail.com'),
('Registerar', 'arbaminch', 'arbaminch@123', 'arbaminch@123', 'arbaminch@gmail.com'),
('Registerar', 'arsi', 'arsi@123', 'arsi@123', 'arsi@gmail.com'),
('Registerar', 'assosa', 'assosa@123', 'assosa@123', 'assosa@gmail.com'),
('Registerar', 'astu_adama', 'astu_adama@123', 'astu_adama@123', 'astu_adama@gmail.com'),
('Registerar', 'astu-addis', 'astu_addis@123', 'astu_addis@123', 'astu_addis@gmail.com'),
('Registerar', 'bahirdar', 'bahirdar@123', 'bahirdar@123', 'bahirdar@mail.com'),
('Registerar', 'bonga', 'bonga@123', 'bonga@123', 'bonga@gmail.com'),
('Registerar', 'borena', 'borena@123', 'borena@123', 'borena@gmail.com'),
('Registerar', 'bulehora', 'bulehora@123', 'bulehora@123', 'bulehora@gmail.com'),
('Registerar', 'debark', 'debark@123', 'debark@123', 'debark@gmail.com'),
('Registerar', 'debrebiran', 'debrebiran@123', 'debrebiran@123', 'debrebiran@gmail.com'),
('Registerar', 'debremarkos', 'debremarkos@123', 'debremarkos@123', 'debremarkos@gmail.com'),
('Registerar', 'debretabor', 'debretabor@123', 'debretabor@123', 'debretabor@gmail.com'),
('Registerar', 'dembidolo', 'dembidolo@123', 'dembidolo@123', 'dembidolo@gmail.com'),
('Registerar', 'dilla', 'dilla@123', 'dilla@123', 'dilla@gmail.com'),
('Registerar', 'diredawa', 'diredawa@123', 'diredawa@123', 'diredawa@gmail.com'),
('Registerar', 'gambella', 'gambella@123', 'gambella@123', 'gambella@gmail.com'),
('Registerar', 'gonder', 'gonder@123', 'gonder@123', 'gonder@gmail.com'),
('Registerar', 'haramaya', 'haramaya@123', 'haramaya@123', 'haramaya@gmail.com'),
('Registerar', 'hawassa', 'hawassa@123', 'hawassa@123', 'hawassa@gmail.com'),
('Registerar', 'injibara', 'injibara@123', 'injibara@123', 'injibara@gmail.com'),
('Registerar', 'jijiga', 'jijiga@123', 'jijiga@123', 'jijiga@gmail.com'),
('Registerar', 'jimma', 'jimma@123', 'jimma@123', 'jimma@gmail.com'),
('Registerar', 'jinka', 'jinka@123', 'jinka@123', 'jinka@gmail.com'),
('Registerar', 'kebridar', 'kebridar@123', 'kebridar@123', 'kebridar@gmail.com'),
('Registerar', 'kotebe_metropolitan', 'kotebe_metro@123', 'kotebe_metro@123', 'kotebe_metro@gmail.com'),
('Registerar', 'medawalabu', 'medawalabu@123', 'medawalabu@123', 'medawalabu@gmail.com'),
('Registerar', 'mekdela', 'mekdela@123', 'mekdela@123', 'mekdela@gmail.com'),
('Registerar', 'mekele', 'mekele@123', 'mekele@123', 'mekele@gmail.com'),
('Registerar', 'mettu', 'mettu@123', 'mettu@123', 'mettu@gmail.com'),
('Registerar', 'MTU', 'mtu@123', 'mtu@124', 'mtu@gmail.com'),
('Registerar', 'odabultum', 'odabultum@123', 'odabultum@123', 'odabultum@gmail.com'),
('Registerar', 'raya', 'raya@123', 'raya@123', 'raya@gmail.com'),
('Registerar', 'selale', 'selale@123', 'selale@123', 'selale@gmail.com'),
('Registerar', 'semera', 'semera@123', 'semera@123', 'semera@gmail.com'),
('Registerar', 'wachamo', 'wachamo@123', 'wachamo@123', 'wachamo@gmail.com'),
('Registerar', 'welkite', 'welkite@123', 'welkite@123', 'welkite@gmail.com'),
('Registerar', 'werabe', 'werabe@123', 'werabe@123', 'werabe@gmail.com'),
('Registerar', 'wolaita', 'wolaita@123', 'wolaita@123', 'wolaita@gmail.com'),
('Registerar', 'woldiya', 'woldiya@123', 'woldiya@123', 'woldiya@gmail.com'),
('Registerar', 'wollega', 'wollega@123', 'wollega@123', 'wollega@gmail.com'),
('Registerar', 'wollo', 'wollo@123', 'wollo@123', 'wollo@gmail.com'),
('Administrator', 'yilikal', 'yilikal', 'yilik@123', 'yilikal@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `wachamo`
--

CREATE TABLE `wachamo` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wachamo`
--

INSERT INTO `wachamo` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Wachamo university', 3.9);

-- --------------------------------------------------------

--
-- Table structure for table `welkete`
--

CREATE TABLE `welkete` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `welkete`
--

INSERT INTO `welkete` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2006, 'Bachelor of Degree', 'Male', 'information system', 'Welkete university', 3.8);

-- --------------------------------------------------------

--
-- Table structure for table `werabe`
--

CREATE TABLE `werabe` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `werabe`
--

INSERT INTO `werabe` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Werabe university', 3.5);

-- --------------------------------------------------------

--
-- Table structure for table `wolaita`
--

CREATE TABLE `wolaita` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wolaita`
--

INSERT INTO `wolaita` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2013, 'Bachelor of Degree', 'Male', 'information system', 'Wolaita sodo university', 3.6);

-- --------------------------------------------------------

--
-- Table structure for table `woldiya`
--

CREATE TABLE `woldiya` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `woldiya`
--

INSERT INTO `woldiya` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2005, 'Bachelor of Degree', 'Male', 'information system', 'Woldiya university', 3.5);

-- --------------------------------------------------------

--
-- Table structure for table `wollega`
--

CREATE TABLE `wollega` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wollega`
--

INSERT INTO `wollega` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2012, 'Bachelor of Degree', 'Male', 'information system', 'Wollega university', 2.7);

-- --------------------------------------------------------

--
-- Table structure for table `wollo`
--

CREATE TABLE `wollo` (
  `ID` varchar(20) NOT NULL,
  `Frist_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Midle_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Last_Name` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Year_of_Graduation` int(10) NOT NULL,
  `Qualification` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Gender` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Department` varchar(40) CHARACTER SET latin1 NOT NULL,
  `University` varchar(40) CHARACTER SET latin1 NOT NULL,
  `GPA` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wollo`
--

INSERT INTO `wollo` (`ID`, `Frist_Name`, `Midle_Name`, `Last_Name`, `Year_of_Graduation`, `Qualification`, `Gender`, `Department`, `University`, `GPA`) VALUES
('scir/024/11', 'adino', 'ageru', 'yilma', 2010, 'Bachelor of Degree', 'Male', 'information system', 'Wollo university', 3.8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addis`
--
ALTER TABLE `addis`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `adigrat`
--
ALTER TABLE `adigrat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ambo`
--
ALTER TABLE `ambo`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `arbaminch`
--
ALTER TABLE `arbaminch`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `arsi`
--
ALTER TABLE `arsi`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `assosa`
--
ALTER TABLE `assosa`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `astu_adama`
--
ALTER TABLE `astu_adama`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `astu_addis`
--
ALTER TABLE `astu_addis`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `axum`
--
ALTER TABLE `axum`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bahirdar`
--
ALTER TABLE `bahirdar`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bonga`
--
ALTER TABLE `bonga`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `borena`
--
ALTER TABLE `borena`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bulehora`
--
ALTER TABLE `bulehora`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `debark`
--
ALTER TABLE `debark`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `debrebiran`
--
ALTER TABLE `debrebiran`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `debremarkos`
--
ALTER TABLE `debremarkos`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `debretabor`
--
ALTER TABLE `debretabor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `dembidolo`
--
ALTER TABLE `dembidolo`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `dilla`
--
ALTER TABLE `dilla`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `diredawa`
--
ALTER TABLE `diredawa`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gambela`
--
ALTER TABLE `gambela`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gonder`
--
ALTER TABLE `gonder`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `haramaya`
--
ALTER TABLE `haramaya`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `hawassa`
--
ALTER TABLE `hawassa`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `injibara`
--
ALTER TABLE `injibara`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `jijiga`
--
ALTER TABLE `jijiga`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `jimma`
--
ALTER TABLE `jimma`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `jinka`
--
ALTER TABLE `jinka`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `kebridar`
--
ALTER TABLE `kebridar`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `kotebe_metro`
--
ALTER TABLE `kotebe_metro`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `medawalabu`
--
ALTER TABLE `medawalabu`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mekele`
--
ALTER TABLE `mekele`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mekidela`
--
ALTER TABLE `mekidela`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `metu`
--
ALTER TABLE `metu`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `odabultum`
--
ALTER TABLE `odabultum`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `raya`
--
ALTER TABLE `raya`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `selale`
--
ALTER TABLE `selale`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `semera`
--
ALTER TABLE `semera`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`) USING BTREE;

--
-- Indexes for table `wachamo`
--
ALTER TABLE `wachamo`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `welkete`
--
ALTER TABLE `welkete`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `werabe`
--
ALTER TABLE `werabe`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wolaita`
--
ALTER TABLE `wolaita`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `woldiya`
--
ALTER TABLE `woldiya`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wollega`
--
ALTER TABLE `wollega`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wollo`
--
ALTER TABLE `wollo`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

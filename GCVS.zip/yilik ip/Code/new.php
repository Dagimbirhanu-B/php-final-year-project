<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
	<style type="text/css">
		body
		{
           overflow-x: hidden;
		}
		*
		{
			box-sizing: border-box;
		}
.main_centr
	{
		     background-color: #87CEEB;
		     display: grid;
             padding: 2rem;
             grid-template-columns: 300px 1fr;
             gap: 1rem;
            align-items: center;
            font: 500 100%/1.5 system-ui;
            height: 500px;
    }

	#mid
	{
		text-align: ;
		color: white;
		
		text-underline-offset: 3px;
		margin-top: 21%;
		margin-left: 9%;
		position: ;
		background-color: white;
		width: 132px;
		color: black;
	}
	#text1
	{
		margin-left: 40%;
		width: 49%;
		margin-top: -10%;
		

	}
#text1 h3
{
	color: black;
	text-align: center;
	position: absolute;
	margin-top: -2.2%;
	margin-left: 3%;
}
/*.main_centr img
{
	margin-top: 7%;
	position: absolute;
}*/
.main_centr img 
{    height:300px;
	   margin-left: 57%;
     width: 500px;
     opacity: 1;
     image-rendering: auto;
     image-rendering: crisp-edges;
     image-rendering: pixelated;
     image-rendering: -webkit-optimize-contrast;
     margin-top: 15%;
}	
#12
{
	
}
#pointer1
{
	font-size: 25px;
	margin-left: 3%;
	color: green;
	margin-top: 4.7%;
}
#pointer
{
	font-size: 40px;
	margin-left: 2.6%;
	color: black;
}
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .main_centr, #mid, .main_centr img, #text1 h3 {
    width: 100%;
  }
}
</style>
</head>
<body>
<div class="main_centr">
	<img src="iterfaceimage/mosheh.jpg">
      <div id="text1">
      	<h2 id="mid">Our Service</h2>
        <h3 style="font-family: sans-serif; margin-top: 1.5%;">Users Must Read The following Direction...</h3><br><br>
        <h3 id ="12" style="color: black; font-family: sans-serif; margin-top: 1.5%;" >This Application is used to provide:</h3><br>
        <div id="pointer1">&#x2713;</div><h3 style="font-family: sans-serif; color: green; font-size: 22px;">Degree Credentials/Certificate Verification:</h3><br>
        <p style="color: black; opacity: 1; justify-content: center; position: absolute; font-family: sans-serif; font-size: 20px; margin-top: -1%; margin-left: 3%;">This service is aimed to verify the reality of a certificate issued by the ethiopian higher educational institutes.</p><br>
        <div id="pointer">&#x261E;</div><p style="opacity: 1; color: black; font-family: sans-serif; justify-content: center; position: absolute; font-size: 20px; margin-left: 3.5%; margin-top: -3%;">This service is extended to verify the reality of certificates to Universities,<br>Organizations, and graduates for free. </p>
    </div>
    <div id="centr2">
    	

    </div>
</div>
</body>
</html>
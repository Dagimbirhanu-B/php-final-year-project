<html>
<head>
  <title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
</head>
<body>
<?php 
$gid=$_POST['Gid'];
$gfname=$_POST['Gfname'];
$gmname=$_POST['Gmname'];
$glname=$_POST['Glname'];
$gpa=$_POST['Gpa'];
$yog=$_POST['Yog'];
$gqul=$_POST['Gqul'];
$mgender=$_POST['mgender'];
$gdep=$_POST['gdep'];
$guniv=$_POST['guni'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "INSERT INTO hawassa (ID,Frist_Name,Midle_Name,Last_Name,Year_of_Graduation,Qualification,Gender,Department,University,GPA) VALUES ('$gid','$gfname','$gmname','$glname','$yog','$gqul','$mgender','$gdep','$guniv','$gpa')";
if(!mysqli_query($con,$sql))
{
die('Error:'.mysql_error());
}
mysqli_close($con);
echo '<script type="text/javascript">alert("Student added success");window.location=\'insert form5.php\';</script>';
exit();
?>
</body>
</html>

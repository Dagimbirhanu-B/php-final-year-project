<html>
<head>
<title>MWU GCVS</title>
</head>
<body>
<?php 
session_start();
$eid=$_POST['Gid'];
$rea=$_POST['regA'];
$gq=$_POST['gq'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "INSERT INTO info_verification (ID,Verification,Qualification) VALUES ('$eid','$rea','$gq')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo "record added success";
mysql_close($con);

?>
</body>
</html>

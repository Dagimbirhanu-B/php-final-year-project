<!DOCTYPE html>
<html lang="en">
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
<link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
html{
	scroll-behavior: smooth;
	overflow-x: hidden;
}
body
{
	 background-color: white;
   width: 100%;
   height: auto;
   overflow-x: hidden;
   font-family: sans-serif;
}
*{
    box-sizing: border-box;
    scroll-behavior: smooth;
}

.sldr
{
	margin-right: 0%;
	margin-left: -1.8%;
	margin-top: %;
	padding: 27px;
  margin-top: 30px;
  
}
	.sld
	{
		margin-top: -2%;
		margin-left: 0%;
		margin-right: 0%;
		
	}
	#myBtn
	{
		position: fixed;
		width: 40px;
		height: 40px;
		bottom: 13px;
		right: 10px;
		z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #121212;
    color: white;
    cursor: pointer;
    padding: 10px;
    
	}
	#myBtn:hover
	{
		background-color: #ff4500;
	}
	.foot1
	{
		margin-top: 4%;
		padding-bottom: 0;
	}
.mid
{
	margin-top: 20%;
	background: ;
	padding-bottom: 15px;

}
#nn3
{
	margin-top: 3%;
}
#than
{
	margin-top: 0%;
	position: absolute;
}
hr
{
	position: relative;
}
#header ul li a
    {

      top: 30.5px;
      
   }
footer #bot
{
    margin-top: -1.5%;
}
footer .right-foot
  {
    margin-top: -10%;
	
  }
  #header ul li ul li a
    {
    top: 5;

    }
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .head, .bod, .sldr, .sld, .foot1, .myBtn, .mid, button{
    width: 100%;
  }
}
</style>
</head>
<body>
<div class="bod">
<div class="head">
<?php
   include "yheader.php";
 ?>
 </div>    
<div class="sldr">
	<?php 
	include "slider2.php";
	 ?>
</div>
  <div class="sld">
	   <?php 
	     include "home slide.php";
	    ?>
  </div>
    <div class="mid">
    	<?php
    	include "new.php";
    	?>
    	
    </div>
    <div id="nn3">
    	<?php include "new2.php";?>
    </div>
    
 <div class="foot1">
    	<?php include "Footer.php"; ?>
 </div>
 </div> 
 <button onclick="topFunction()" id="myBtn" title="Go to top">&#708;</button>
 <script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>
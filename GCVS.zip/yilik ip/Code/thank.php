<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
	body
	{
		width: 1600px;
		overflow-x: hidden;
	}
		#Thank
		{
	background-color: #E1E1E1;
	height: 230px;
	margin-top: %;
	width: 1585px;
}
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  #Thank, h1{
    width: 100%;
  }
}
	</style>
</head>
<body>
  <div id="Thank">
    <!--<h1 style="color: gray; font-size: 46px; font-family: sans-serif; padding-top: 60px; margin-top: %;">MoSHE:</h1>-->
    <h1 style="color: gray; font-size: 55px; font-family: sans-serif; padding-top: 68px; text-align: center;">Thank you for Working With Us!</h1>
  </div>
</body>
</html>
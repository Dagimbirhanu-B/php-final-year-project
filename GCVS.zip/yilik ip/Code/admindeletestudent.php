<html>
<head>
<title>Delete Student</title>
</head>
<body>
<?php
$Id=$_GET['ID'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
	$sql = "delete from student where student.ID='".$Id."'";
	mysqli_query ($con,$sql);
	mysqli_close ($con);
	echo '<script type="text/javascript">alert("Student Deleted Succesfully");window.location=\'adminUpdate.php\';</script>';

?>
</body>
</html>

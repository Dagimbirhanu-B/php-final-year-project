<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
</head>
<style type="text/css">
     body
         {
  	         background-color: whitesmoke;
  	         width: 100%;
  	         overflow-x: hidden;
           }
    #on
	       {
		         margin-top: ;
		         margin-left: %;
             height: 500px;
             margin-top: 


	         }
	        #img1
	         {
	   	         height: 650px;
	   	         width: 900px;
	   	         margin-left: 10%;
	        }
	        #img2
	            {      
	      	     padding: 0;
	      	     margin: 0;
	   	         width: 100px;
	   	         height: 100px;
	   	         margin-top: 9%;
	   	         margin-left: -56%;
	   	         border-radius: 50%;
	   	         position: absolute;

	            }
	             #img3
	            {      
	      	     padding: 0;
	      	     margin: 0;
	   	         width: 100px;
	   	         height: 100px;
	   	         margin-top: 9%;
	   	         margin-left: -17%;
	   	         border-radius: 50%;
	   	         position: absolute;
	            }
	       #hed
	          {
               margin-left: %;
               padding: 0;
               margin: 0;
	          }
	      #h12
	           {
	   	        
               font-family: fantasy;
               margin-top: -38%;
               margin-left: 34%;
               position: absolute;
	   	        }
	   	   #h11
	          {
	          	position: absolute;
	   	        margin-top: -35%;
              font-family: sans-serif;
              margin-left: 33%;
              text-decoration: underline;
              text-underline-offset: 6px;
	   	      }
	   	   #l
	           {
	   	         margin-top: -30%;
	   	         margin-left: 20%;
               color: black;
               height: px;
               width: 600px;
               font-family: sans-serif;
               font-size: 20px;
               max-width: 700px;            
               text-align: justify;
	          }
	          h1
	          {
	          	text-align: center;
	          	font-size: 50;
	          	margin-top: 5%;
	          	
	          }
</style>
<body>
	<!--<a href="javascript:history.back()">Go Back</a>-->
	<div id="on">
<?php
   $con = mysqli_Connect("localhost","root") or die(mysqli_error());
   mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
 if(isset($_POST['search']))
 {
 if (isset($_POST['id'],$_POST['Department'])) 
 { 
   $id = $_POST['id']; 
	 $department = $_POST['Department'];
   $query="SELECT * FROM diredawa WHERE id='$id' AND Department = '$department'";
	 $_query_run = mysqli_query($con,$query);
	 if (mysqli_num_rows($_query_run)>0) 
  {
	 	
	 while($row = mysqli_fetch_array($_query_run))
  {
    ?>	
		
		 <div id="hed">
		 	<img id="img1" src="iterfaceimage/border1.jpg">
		 	<img id="img3" src="iterfaceimage/gonder.jpg">
		 	<h1 id="h12"><font size="43">certificate</font></h1>
		  <img id="img2" src="iterfaceimage/moelogo1.jpg">
		 	<div id="h11"><h1><?php echo $row['Frist_Name']?> <?php echo $row['Midle_Name']?>
		 <?php echo $row['Last_Name']?></h1></div><br>
		 <div id="l">
		 This is to certify that Student <?php echo $row['Frist_Name']?> <?php echo $row['Midle_Name']?>
		 <?php echo $row['Last_Name']?> registered with <?php echo $row['ID']?> ID no, has been awarded <?php echo $row['Qualification']?>
		 in <?php echo $row['Department']?> from <?php echo $row['University']?> with GPA <?php echo $row['GPA']?>
		 in <?php echo $row['Year_of_Graduation']?>.
		 <br><br><br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Notice!!</b><br><br><?php echo $row['University']?> is one of the Ethiopian higher govornmental educational institutes!
		 
		 <?php
		 
}
}
else{

	echo '<script type="text/javascript">alert("Student File Does not Exist");window.location=\'verification13.php\';
	</script>';
}
}
}
mysqli_close($con);
 ?>
                       </div>
                     </div>
                   </div>
</body>
</html>
<?php
$cem=$_POST['Gid'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$q = "select * from student WHERE ID='$cem'";
$r=mysqli_query($con,$q);
if(mysqli_num_rows($r)==0)
 {
 echo"No such record exists";
  exit();
 }
 while($row= mysqli_fetch_array($r))
{
 $a=$row['ID'];
 $b=$row['Frist_Name'];
 $c=$row['Midle_Name'];
 $d=$row['Last_Name'];
 $e=$row['Cumulative_Gpa'];
 $f=$row['Year_of_Graduation'];
 $g=$row['Qualification'];
 $h=$row['Gender'];
 $i=$row['Department'];
$sql = "INSERT INTO report (ID,Frist_Name,Midle_Name,Last_Name,Cumulative_Gpa,Year_of_Graduation,Qualification,Gender,Department) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h','$i')";
if(!mysqli_query($con,$sql))
{
die('Error:'.mysqli_error());
}
echo '<script type="text/javascript">alert("Report Generated  success");window.location=\'sendmessearch.php\';</script>';
}
?>
<?php
mysqli_close($con);
?>
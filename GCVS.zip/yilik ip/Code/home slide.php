<html>
<head><title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="js/slick.css"/>
<link rel="stylesheet" href ="js/slick-theme.css">
</head>
<style>
*
{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  outline: none;
}
body
{
  font-family: sans-serif;
  background-color: #f7f7f7;
  overflow-x: hidden;
 overflow-y: hidden;
}
 .logo-slider img
 {
  border-radius: 50%;
  width: 100%;
 }
 .container
 {
  margin: 0 auto;
  max-height: 20px;
  width: 1350px;
 }
 .logo-slider .item
 {
  background-color: #fff;
  box-shadow: 0 4px 6px #cacaca1
  padding: 10px;
  border: 2px solid #EBEBEB;
  height: 200px;
 }
.logo-slider .slick-slide
{
  margin: 10px;
  
}
.slick-dots
{
  margin-left: 2%;
  
}
.slick-prev:before
.slick-next:before
{
   color: green;
   font-size: 24px;
}
.slick-dots li.slick-active button:before
{
  
  color: #6495ED;
}
.slick-dots li button:before
{
  font-size: 50px;
}
.item:hover
{
  display: block;
}
.boo h1
{
  background-color: #d8eaf5;
  color: #3E98D0;
  height: 60px;
  margin-left: 0%;
  text-align: center;
}
.thumbnail-slider .item
{
  height: 140px;
  background-color: #fff;
  padding: 15px;
  line-height: 200px;
  text-align: center;
  font-size: 50px;
  color:#ffffff;
  float: left;
  border: 2px solid #EBEBEB;
  box-shadow: 0 4px 5px #cacaca;
  width: 200px;
}
.logo-slider .item:hover
{
  border: 1px solid #08457e;
}
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .container, .thumbnail-slider .item, .logo-slider .slick-slide, .logo-slider .item, .logo-slider .slick-slide
  {
    width: 100%;
  }
}
</style>
<body>
   <div class="container">
<div class ="logo-slider">
    <div class="item"><a href="Verification44.php"><img src="iterfaceimage/astu_addis.jpg" width="190" height="180" alt=""></a></div>
    <div class="item"><a href="Verification45.php"><img src="iterfaceimage/astu_adama.jpg" width="200" height="180" alt=""></a></div>
    
    <div class="item"><a href="Verification3.php"><img src="iterfaceimage/Addis.jpg" width="180" height="180" alt=""></a></div>
    <div class="item"><a href="Verification4.php"><img src="iterfaceimage/jima.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification5.php"><img src="iterfaceimage/hawasa.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification6.php"><img src="iterfaceimage/arsilogo.png" width="180" height="180" alt=""></a></div>
    <div class="item"><a href="Verification.php"><img src="iterfaceimage/MTU.JPG" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verfication8.php"><img src="iterfaceimage/bahirdar.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification9.php"><img src="iterfaceimage/haramaya.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification10.php"><img src="iterfaceimage/arbaminch.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification2.php"><img src="iterfaceimage/LOG.png" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification11.php"><img src="iterfaceimage/debremarkos.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification7.php"><img src="iterfaceimage/gonder.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification12.php"><img src="iterfaceimage/mekele.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification13.php"><img src="iterfaceimage/dire.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification14.php"><img src="iterfaceimage/injibara.jpg" width="200" height="180" alt=""></a></div>
    <div class="item"><a href="Verification15.php"><img id="bonga" src="iterfaceimage/bongauni.jpg" width="200" height="170" alt=""></a></div>


    <div class="item"><a href="Verification16.php"><img src="iterfaceimage/adigrat.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification17.php"><img src="iterfaceimage/ambo.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification19.php"><img src="iterfaceimage/assosa2.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification18.php"><img src="iterfaceimage/axum.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification20.php"><img src="iterfaceimage/borena.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification21.php"><img src="iterfaceimage/hulehora.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification22.php"><img src="iterfaceimage/debark.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification23.php"><img src="iterfaceimage/dembidolo.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification24.php"><img src="iterfaceimage/dilla.png" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification25.php"><img src="iterfaceimage/debrebiran.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification26.php"><img id="jij" src="iterfaceimage/jij.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification27.php"><img src="iterfaceimage/jinka.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification28.php"><img src="iterfaceimage/kebredar.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification29.php"><img src="iterfaceimage/kotebem.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification30.php"><img src="iterfaceimage/medawalabu.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification31.php"><img src="iterfaceimage/odabultum.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification32.php"><img src="iterfaceimage/raya.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification33.php"><img src="iterfaceimage/selale2.jpg" width="200" height="180" id="sel" alt=""></a></div>
    <div class="item"><a href="Verification34.php"><img src="iterfaceimage/semera.jpg" width="200" height="170" alt=""></a></div>


    <div class="item"><a href="Verification35.php"><img src="iterfaceimage/wachamo.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification36.php"><img src="iterfaceimage/wolkite.png" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification37.php"><img src="iterfaceimage/wolaita1.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification38.php"><img src="iterfaceimage/Wolleg1.png" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification39.php"><img src="iterfaceimage/wollo.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification40.php"><img src="iterfaceimage/metu.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification41.php"><img src="iterfaceimage/woldiya.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification42.php"><img src="iterfaceimage/worabe2.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification43.php"><img src="iterfaceimage/debretabor.jpg" width="200" height="170" alt=""></a></div>
    <div class="item"><a href="Verification46.php"><img src="iterfaceimage/mekidela.jpg" width="190" height="170" alt=""></a></div>
</div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/slick.min.js"></script>
<script>
$('.logo-slider').slick({
  slidesToShow: 7,
  slidesToScroll: 7,
  dots: true,
  arrows: true,
  autoplay: true,
  autoplayspeed: 2000,
  infinite: true
});

var filtered = false;

$('.js-filter').on('click', function(){
  if (filtered === false) {
    $('.logo-slider').slick('slickFilter',':even');
    $(this).text('Unfilter Slides');
    filtered = true;
  } else {
    $('.logo-slider').slick('slickUnfilter');
    $(this).text('Filter Slides');
    filtered = false;
  }
});
</script>
</body>
</html>
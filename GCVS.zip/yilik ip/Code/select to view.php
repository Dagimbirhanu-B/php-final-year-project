<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MoSHE Degree Verification|Ethiopia</title>
 <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
	<style type="text/css">
		body
		{
			background-color: whitesmoke;
		}

		#select1
		{
			border: 1px solid #d7d7d7;
			width: 25%;
			height: 63%;
			margin-left: 3%;
			background-color: white;
		}

		select
		{
			background: #ebebeb;
            font-size: 17px;
			width: 100%;
			height: 13%;
			margin-left: 0%;
			background-color: ;
	        border: none;
		}
		select:hover
{
	background-color: #dcdcdc;
	
}
  h1
  {
  	background-color: #d8eaf5;
  	text-align: center;
  }






	</style>
</head>
<body>
	<?php include "registerhead.php";?>
	<h1><font color="#3E98D0">Select University to view its data</font></h1>
<div id="select1">
	
    <select name="links" id="" size="1" onchange="window.location.href=this.value;">
		<option value="">--select university--</option>
		<option value="display data2.php">Addis Ababa Science & technology university</option>
		<option value="display data3.php">Adama Science & technology university</option>
		<option value="display data4.php">Addis Ababa university</option>
		<option value="display data5.php">Adigrat university</option>
		<option value="display data6.php">Ambo university</option>
		<option value="display data7.php">Arba minch university</option>
		<option value="display data8.php">Arsi university</option>
		<option value="display data9.php">Assosa university</option>
		<option value="display data10.php">Aksum university</option>
		<option value="display data11.php">Bahir Dar university</option>
		<option value="display data12.php">Bonga university</option>
		<option value="display data13.php">Borena university</option>
		<option value="display data14.php">Bule Hora university</option>
		<option value="display data15.php">Debre birhan university</option>
		<option value="display data16.php">Debark university</option>
		<option value="display data17.php">Debremarkos university</option>
		<option value="display data18.php">Debre Tabor university</option>
		<option value="display data19.php">Dembi Dolo university</option>
		<option value="display data20.php">Dilla university</option>
		<option value="display data21.php">Dire Dawa university</option>
		<option value="display data22.php">Gambella university</option>
		<option value="display data23.php">Gonder university</option>
		<option value="display data24.php">Haramaya university</option>
		<option value="display data25.php">Hawassa university</option>
		<option value="display data26.php">Injibara university</option>
		<option value="display data27.php">Jigjiga university</option>
		<option value="display data28.php">Jimma university</option>
		<option value="display data29.php">Jinka university</option>
		<option value="display data30.php">Kebri Dehar university</option>
		<option value="display data31.php">Kotebe Metropolitan university</option>
		<option value="display data32.php">Medawalabu university</option>
		<option value="display data33.php">Mekidela Amba university</option>
		<option value="display data34.php">Mekele university</option>
		<option value="display data35.php">Mettu university</option>
		<option value="regupdate.php">Mizan tepi university</option>
		<option value="display data36.php">oda bultum university</option>
		<option value="display data37.php">Raya university</option>
		<option value="display data38.php">Selale university</option>
		<option value="display data39.php">Semera university</option>
		<option value="display data40.php">Wachamo university</option>
		<option value="display data41.php">Welkete university</option>
		<option value="display data42.php">Werabe university</option>
		<option value="display data43.php">Wolaita sodo university</option>
		<option value="display data44.php">Woldiya university</option>
		<option value="display data45.php">Wollega university</option>
		<option value="display data46.php">Wollo university</option>
	</select></div>
</body>
</html>
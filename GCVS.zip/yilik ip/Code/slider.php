<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" type="text/css" href="slide styl.css">-->
</head>
<style type="text/css">
	
	body
	{
		background:#e6e6e6;
	}
	*
{
	  margin: 0;
    padding: 0;
    box-sizing: border-box;
    outline: none; border: none;
    text-decoration: none;
    text-transform: capitalize;
}

.container
{
	width: 1600px;
	height: 570px;
	margin:0 auto;
  position:relative;
  overflow:hidden;
  box-shadow:2px 5px 10px rgba(0,0,0,0.4);
}
.container.slide-container.slide
{
	min-height: 100vh;
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	grid-gap: : 15px;
	padding: 20px 9%;
	padding-bottom: 70px;
	width:80%;
  
}
.container .slide-container .slide .content
{
	flex: 1 1 350px;
	animation: slidecontent .4s linear .6s backwards;
	margin-top: 20%;
	margin-left: 17%;
	position: absolute;
	animation-direction: normal;

}
@keyframes slidecontent
{
	0%
	{
		opacity: 0;
		transform: translateX(-50px);
	}
}
.container .slide-container .slide .image
{
	flex: 1 1 500px;
  width: 1600px;

}

.container .slide-container .slide img
{
	     image-rendering: auto;
       image-rendering: crisp-edges;
       image-rendering: pixelated;
       image-rendering: -webkit-optimize-contrast;
	     animation: slideImage .4s linear;
       width: 100%;
       height: 700px;
}
@keyframes slideImage
{
	0%
	{
		opacity: 0;
		transform: translateX(-50px);
	}
}

.container .slide-container .slide .content h2
{
	font-family: Helvitica;
	font-size: 40px;
	color: white;
	margin-top: %;
	margin-left: -15%;
}
.container .slide-container .slide .content h3
{
	font-family: Helvitica;
	font-size: 30px;
	color: white;
	margin-top: %;
	margin-left: -7%;
}
.container .slide-container .slide .content p
{
	font-size: 18px;
	color: #666;
	padding: 10px 0;
}
.container .slide-container .slide .content .btn
{
	margin-top:12%;
	margin-left: -5%;
	display: inline-block;
	background-color: transparent;
	color: white;
	font-size: 23px;
	padding: 9px 30px;
	width: 210px;
	height: 50px;
	border: 1px solid white;
	text-align: center;
}
.container .slide-container .slide .content .btn:hover
{
	background: white;
	color: black;
	text-decoration: none;
}
.container .slide-container
{
	display: none;
}
.container .slide-container.active
{
  display: block;
}
                       /*.container .slide-container:nth-child(1) .slide
                      {
	                      background: linear-gradient(90deg, #f9f9f9 70%, #ffff99 30.1%);
                       }
                        .container .slide-container:nth-child(2) .slide
                       {
	                       background: linear-gradient(90deg, #f9f9f9 70%, #ff9090 30.1%);
                      }
                         .container .slide-container:nth-child(3) .slide
                      {
	                     background: linear-gradient(90deg, #f9f9f9 70%, #99bbff 30.1%);
                      }*/
.container #prev,
.container #next
{
position: absolute;
top: 50%;
transform: translateY(-50%);
color: #fff;
background: transparent;
height: 50px;
width: 53px;
line-height: 50px;
font-size: 40px;
text-align: center;
cursor: pointer;
font-weight: bolder;

}
.container #prev:hover,
.container #next:hover
{
	background:#3ca0e7;
  transition:0.3s;
}
.container #prev
{
	left: 0px;
}
.container #next
{
	right: 0px;
}
.slide-container, .slide, .content
{
	     animation-name: slide;
        animation-duration: 10s;
        animation-direction: normal;
        animation-timing-function: ease;
        animation-iteration-count: infinite;
}

/*@keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-moz-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-webkit-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-o-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}

@-ms-keyframes fadeIn {
  0% {opacity:0;}
  100% {opacity:1;}
}*/
@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .container.slide-container, .btn, h2, h3{
    width: 100%;
  }
}
</style>
<body>
	<div class="container">
		 <div class="slide-container active">
			  <div class="slide">
				 <div class="content">
					<h2>MINISTRY OF SCIENCE & HIGHER EDUCATION</h2>
					  <a href="aboutus.php" class="btn">find Us</a>
				    </div>
				   <div class="image">
					<img src="iterfaceimage/moshe2.jpg" alt="">
				</div>
			</div>
		</div>


		<div class="slide-container">
			<div class="slide">
				<div class="content">
					<h2>ONLINE VERIFICATION</h2>
					<h3>for higher govornmental educational Institutes</h3>
					<a href="verification slide.php" class="btn">verify now</a>
				</div>
				<div class="image">
					<img src="iterfaceimage/graduate.jpg" alt="">
				</div>
			</div>
		 </div>

		 <div class="slide-container">
			<div class="slide">
				<div class="content">
					<h2>Graduation Day</h2>
					<h3>Graduates attending!</h3>
				</div>
				<div class="image">
					<img src="iterfaceimage/gc.jpg" alt="">
				</div>
			</div>
		 </div>

      

		<!--<div class="slide-container">
			<div class="slide">
				<div class="content">
					<h2>verified by moe</h2>
					<a href="verify graduate2.php" class="btn">verify your employe</a>
				</div>
				<div class="image">
					<img src="iterfaceimage/log.jpg"alt="">
				</div>
			</div>
		</div>-->
		        <div id="prev" onclick="prev()"> ❮ </div>
		        <div id="next" onclick="next()"> ❯ </div>
 
	</div>
	<script type="text/javascript">
		let slides = document.querySelectorAll('.slide-container');
		let index = 0;
		// next function
		function next()
		{
			slides[index].classList.remove('active');
			index = (index + 1) % slides.length;
			slides[index].classList.add('active');
		}
		//previous function
		function prev()
		{
			slides[index].classList.remove('active');
			index = (index - 1 + slides.length) % slides.length;
			slides[index].classList.add('active');
		}
		//auto play
		setInterval(next, 7000); //slides change every 7 seconds
	</script>
</body>
</html>
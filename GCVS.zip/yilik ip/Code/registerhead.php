<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<style type="text/css">
body
{
	width: 1600px;
	overflow-x: hidden;
}
#yuu
{
    background-color: whitesmoke;
    margin-top: 0;
    width: 1580px;
     height: 50px;
  
}
ul
{
     
  list-style: none;
  padding: ;
  margin: ;
  position: absolute;
  margin-left: %;
  margin-top: %;
}
ul li 
{
  display: inline-block;
}
ul li a
{
 
  background-color: whitesmoke;
  text-decoration: none;
  font-size: 20px;
  padding: 10px;
  color: #08457e;
  padding: 10px;
}
ul li a:hover
{
  color: green;
}
</style>
<body>
<div id="yuu">
         <ul>
            <li><a href="RegisterarPage.php">Home</a></li>
            <li><a href="insertregister.php">Insert data</a></li>
            <li><a href="select to view.php">Display data</a></li>
            <!--<li><a href="#viewreg.php">Search data</a></li>-->
            <li><a href="logout.php">Logout</a></li>
        </ul> 
</div>
</body>
</html>
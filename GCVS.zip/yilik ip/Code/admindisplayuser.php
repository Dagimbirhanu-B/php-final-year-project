<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:index.php");
		   }
		   else
		   {
		   ?>
<html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
<link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body id="contianer">
<div id="bod">
<?php
include "adminheader.php";
		?>
				<div id="leftsh">
<div id="spaceesh">
<div id="aformsh">
<h3>User of The System:</h3>
<form action="delete user.php" method="post">
<table border="1"><tr><td>
<tr bgcolor="#85A157"><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;User_Type</th>
<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Username</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Password</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email</th>
<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Delete</th></tr>
<?php
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$q = "select * from user";
$r=mysqli_query($con,$q);
 while($row = mysqli_fetch_array($r))
{
$Id=$row['User_type'];
$ln=$row['Name'];
$cg=$row['username'];
$q=$row['password'];
$qe=$row['email'];
?>
<tr bgcolor="#BADFE8"><td><strong><?php echo $Id;?></strong></td><td><strong><?php echo $ln;?></strong></td><td><strong><?php echo $cg;?></strong></td><td><strong><?php echo $q;?></strong></td><td><strong><?php echo $qe;?></strong></td><td><strong><a href="delete user.php?username=<?php echo $cg;?>" onclick="return confirm('Are you sure you want to delete?')">Delete</a></strong></td></tr>
                   <?php
                  
}
?>
</table>
</form>
</div>
</div>
</div>
</div>
</body>
</html>
<?php
}
?>
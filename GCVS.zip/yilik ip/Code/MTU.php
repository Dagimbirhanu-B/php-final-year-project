if (isset($_POST['Login']))
			
			{
session_start();
$UserName=$_POST['uname'];
$Password=$_POST['pword'];
$UserType=$_POST['selectop'];
if($UserType==="--select one--")
{
?>
<div class="alert alert-error">
			  	 Please select your account type
				 and try again!!!
				</div>
<?php 
}
else
{
if($UserType==="Administrator")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}
else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:AdminPage.php");
} 
mysqli_close($con);
}
else if($UserType==="Registerar")
{
$con = mysqli_Connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($con,$sql);
$records = mysqli_num_rows($result);
$row = mysqli_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select your account type
				 and try again!!!
				</div>
<?php 
}
else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:RegisterarPage.php");
} 
mysqli_close($con);
}
}
}
?>

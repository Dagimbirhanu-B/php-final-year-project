<div id="mheader">
<img src="iterfaceimage/logoaaa.gif" width="1000" height="120" alt="logo image">
</div>
<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="AdminPage.php">HOME</a></li>
			<li><a href="#">MANAGE GRADUATE INFORMATION</a>
				<ul>
			<li> <a href="InsertAndupdate.php">INSERT GRADUATE INFORMATION<br></a></li>
	<li><a href="adminUpdate.php">DISPLAY GRADUATED INFORMATION<br></li></a>
				<li><a href="adminsearchrepdel.php">DISPLAY REPORT GENERATED<br></a></li>
			</ul>
			</li>&nbsp;&nbsp;
				<li><a href="#">MANAGE USER PROFILE</a>&nbsp;&nbsp;
						<ul>
				<li> <a href="admindisplayuser.php">DISPLAY ACCOUNT<br></a></li>
				<li> <a href="UserAccount.php">CHANGE PASSWORD<br></a></li>
				</ul>
				</li>
				<li><a href="#">DISPLAY</a>&nbsp;&nbsp;
								<ul>
				<li> <a href="admindeletecompany.php">REQUEST COMPANY<br></a></li>
				<li> <a href="admindisplayemploye.php">REQUEST EMPLOYE<br></a></li>
				<li> <a href="admindeleteapprovedreq.php">APPROVES REQUEST<br></a></li>
				<li> <a href="admindeleteverifiedreq.php">VERIFIED EMPLOYE INFORMATION<br></a></li>
				</ul></li>

    <li><a href="Logout.php">LOGOUT</a></li>&nbsp;&nbsp;</ul></div>
 </hgroup>
</header>
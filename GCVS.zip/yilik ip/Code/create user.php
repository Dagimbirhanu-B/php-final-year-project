<html>
<head>
<title>MTUGCVS</title>
</head>
<body>
<?php 
$so=$_POST['selectop'];
$un=$_POST['name'];
$uemail=$_POST['email'];
$nua=$_POST['nuaccount'];
$np=$_POST['npass'];
$cnp=$_POST['ncpass'];
if($np!=$cnp)
{
echo '<script type="text/javascript">alert("the password  is not confirmed!");window.location=\'UserAccount.php\';</script>';
exit();
}
else
{
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");

$sql = "INSERT INTO user (User_type, Name, email, username, password)
VALUES ('$so', '$un', '$uemail', '$nua', '$np')";
if(!mysqli_query($con,$sql))
{
die('Error:'.mysqli_error());
}
}
mysqli_close($con);
echo '<script type="text/javascript">alert("User added successfuly!");window.location=\'UserAccount.php\';</script>';
exit();
?>
</body>
</html>


<html>
<head>
<title>Untitled Document</title>
</head>
<body>
<?php
// Establish Connection with Database
$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"gcvs_db_success");
$result=mysqli_query("SELECT *FROM admin WHERE username='tesfish'");
$row=mysqli_fetch_array($result);
echo $row['Admin_Id'];
// Close the connection
mysqli_close($con);
?>

</body>
</html>

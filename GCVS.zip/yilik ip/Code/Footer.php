<!DOCTYPE html>
<html>
<head>
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/all.css">
	<link rel="stylesheet" href="css/fontawesome.min.css">
	<style type="text/css">
		html
		{
			scroll-behavior: smooth;
			overflow-x: hidden;
		}
		body
		{
			margin: 0;
			padding: 0;
			font-family: sans-serif;
			scroll-behavior: smooth;
			overflow-x: hidden;
		}
		.footer
		{
			margin: 0 auto;
			width: 1170px;
			position: absolute;
}
	.foot
{
      left: 0;
     bottom: 0;
     width: 100%;
     background-color: gray;
     text-align: center;
     height: 30px;
     padding-top: 14%;
     padding-bottom: 8%;
	}
	.foot h1
{
     font-size: 35px;
     text-transform: capitalize;
     font-family: sans-serif;
     color: black;
	}
	.foot p
{
	width: 50%;
	margin: auto;
	line-height: 1.6;
	font-family: sans-serif;
  color: black;

}
	.foot span
{
	width: 50px;
	height: 50px;
	display: inline-block;
	background-color: #fff;
}
		.mid1
{
      margin-left: -32%;
      margin-top: -12%;
 
}
.mid1 p
{
	text-align: justify;
  
}
.right-foot
  {
    margin-top: -10.6%;
	margin-right: -60%;
   }
  .social 
  {
  	padding-top: -3px;
  }
  .social span i
  {
  	color: #1b0c4f;
  	font-size: 20px;
  	line-height: 40px;
  	background-color: white;
  }
  .foot .mid1
  {
  	justify-content: center;
  }
.foot .mid1 p
{
	width: 25%;
	color: black;
	line-height: 22px;
	justify-content: center;
	text-align: center;
}
.foot .mid1 h1
{
	margin-left: -16%;
}
#bot
{
	background-color: black;
	height: 35px;
	color: white;
	margin-top: 11%;

}
#bot p
{
	   text-decoration: none;
	   color: white;
	   padding-top: 15px;
	   margin-left: 35%;
	   padding-top: 6px;
}
#bot a h4
{
	  margin-left: 550%;
    margin-top: 36%;
    text-decoration: none;
    color: white;
	
}
#bot h4:hover
{
	  background-color: green;
}
#bot a h3
{
	  margin-left: 850%;
    margin-top: 50%;
    text-decoration: none;
	  color: white;
}

.fa-brands:hover {
    opacity: 0.7;
}

.social .fa-facebook-f 
{
   background-color: #3b5998;
   color: white;
   width: 100%;
   height: 100%;
}
.social .fa-twitter 
{
   background: #55ACEE;
   color: white;
   width: 100%;
   height: 100%;
}
.social .fa-youtube 
{
   background-color: #bb0000;
   color: white;
   width: 100%;
   height: 100%;
}
.social .fa-instagram 
{
   background: #125688;
   color: white;
   width: 100%;
   height: 100%;
}

@media only screen and (max-width: 620px) {
  /* For mobile phones: */
  .foot, .mid1, .right-foot, #bot, h1, p{
    width: 100%;
  }
}
	</style>
</head>
<body>
	<footer>
    <div class="foot">
  <div class="mid1">
        	<h1>About us</h1>
    	<p>The Ministry of Science and Higher Education (MoSHE), established by proclamation number 1097/2018 in October 2018, is responsible to lead the development of science, higher education as well as the technical and vocational education and training (TVET) in Ethiopia.</p></div>
    	<div class="right-foot">
    		<h1>Follow us</h1>
    		<p class="social">
    			<span><a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f" style="font-size:28px"></i></a></span>
    			<span><i class="fa-brands fa-twitter" style="font-size:28px"></i></span>
    			<span><i class="fa-brands fa-instagram" style="font-size:28px"></i></span>
    			<span><i class="fa-brands fa-youtube" style="font-size:28px"></i></span>
    		</p>
    	</div>
    </div>
    <div id="bot">
    	<p>Copyright @ 2022 Moshe All Rights Reserved</p>
    </div>
</footer>
</body>
</html>
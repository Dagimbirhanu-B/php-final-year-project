<html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
 <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
</head>
<body>
<?php
$Id=$_GET['ID'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
	$sql = "delete from arbaminch where ID='".$Id."'";
	mysqli_query ($con,$sql);
	mysqli_close ($con);
	echo '<script type="text/javascript">alert("Student File Deleted Succesfully");window.location=\'display data7.php\';
	</script>';

?>
</body>
</html>
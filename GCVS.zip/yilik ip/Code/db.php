<?php
$con=mysqli_connect("localhost","root","") or die("Could not connect");
mysqli_select_db($con,"gcvs_db_success") or die("could not connect database");
?>
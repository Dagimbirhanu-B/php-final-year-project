<html>
<head>
<title>Delete Company</title>
</head>
<body>
<?php
$Id=$_GET['ID'];
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
	$sql = "delete from company where company.ID='".$Id."'";
	mysqli_query ($con,$sql);
	mysqli_close ($con);
	echo '<script type="text/javascript">alert("Company Deleted Succesfully");window.location=\'admindeletecompany.php\';</script>';

?>
</body>
</html>
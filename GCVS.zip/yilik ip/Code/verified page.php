<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>verify page</title>
</head>
<style type="text/css">
     body
         {
  	         background-color: whitesmoke;
           }
    #on
	       {
		         margin-top: ;
		         margin-left: 30%;
             font-weight: 300;	
		         font-family: Helvetica;


	         }
	   #for
	       {
              width: 500px;
              text-align: center;
              border: 2px #C3C3C3 solid;
              background-color: #E1E1E1;
              margin-top: 2%;
          
	        }
	 #mi
	     {
	   	        margin-top: -0.3%;
              color: black;
		          font-weight: bold;
		          background-color: #dcdcdc;
              margin-left: 40%;
	        }
	   #l
	     {
	   	         margin-top: 8%;
               color: black;
               height: 550px;
               width: 500px;
               background-color: #E1E1E1;
               font-family: Helvetica;
               font-size: 17px;
	          }
	   img
	      {
	   	         width: 120px;
	   	         height: 110px;
	   	         margin-left: -69%;
	   	         margin-top: 2%;
	   	         border-radius: 50%;
	        }
	    h3
	     {
	   	         margin-top: -21%;
	   	         margin-left: -1%;
	   	         color: whitesmoke;
	       }
	   h2 
	     {
	   	         margin-left: -15%;
	   	         color: whitesmoke;
	   	         font-size: bold;
	         }
	   #hed
	       {
	   	         background-color: #007acc;
	   	         width: 500px;
	   	         height: 130px;
	       }
</style>
<body>
	<!--<a href="javascript:history.back()">Go Back</a>-->
	<div id="on">
<?php
   $con = mysqli_Connect("localhost","root") or die(mysqli_error());
   mysqli_select_db($con,"gcvs_db_success") or die("Can not select Database");
 if(isset($_POST['search']))
 {
 if (isset($_POST['id'],$_POST['Department'])) 
 { 
   $id = $_POST['id']; 
	 $department = $_POST['Department'];
   $query="SELECT * FROM employe WHERE id='$id' AND Department = '$department'";
	 $_query_run = mysqli_query($con,$query);
	 if (mysqli_num_rows($_query_run)>0) 
  {
	 	
	 while($row = mysqli_fetch_array($_query_run))
  {
    ?>	
		 <div id="for">
		 <div id="hed">
		 <img src="iterfaceimage/moelogo1.jpg">
		 <h3>Ministry of Education</h3><h2>Ethiopia</h2>
		 </div>
		 <div id="l">
		 This&nbsp;is&nbsp;to&nbsp;certify&nbsp;that<br><br>Student&nbsp;<?php echo $row['Frist_Name']?>&nbsp;<?php echo $row['Midle_Name']?>
		 &nbsp;<?php echo $row['Last_Name']?>&nbsp;registered<br><br>with&nbsp;<?php echo $row['ID']?>&nbsp;ID no,&nbsp;<br><br>has&nbsp;been&nbsp;awarded&nbsp;<?php echo $row['Qualification']?>
		 <br><br>in <?php echo $row['Department']?><br><br>&nbsp;from&nbsp;<?php echo $row['University']?>&nbsp;with&nbsp;GPA&nbsp;<?php echo $row['GPA']?>
		 <br><br>in <?php echo $row['Year_of_Graduation']?>.
		 <br><br><br><br><br><br><br><br>Notice!!<br><br><?php echo $row['University']?>&nbsp;is one&nbsp;of&nbsp;<br><br>Ethiopian&nbsp;higher&nbsp;educational&nbsp;institutes!
		 <?php
		 
}
}
else{
	echo "<h1><font color='red'>No Such a Record Exists!!</font></h1>";
}
}
}
mysqli_close($con);
 ?>
                     </div>
                   </div>
                 </div>
               </div>
</body>
</html>
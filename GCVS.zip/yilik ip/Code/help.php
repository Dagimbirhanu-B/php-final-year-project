<html>
<head>
<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
<style type="text/css">
body
{
	  background-color: whitesmoke;
    overflow-x: hidden;
    scroll-behavior: smooth;
}
*{
  box-sizing: border-box;
}
#mainn
{
    position: absolute;
}
    #space h1{
        color: #08457e;
	    font-size: 40px;
	    margin-left: 5%;
        margin-top: 8%;
    }
	#help h2{
        color: #08457e;
	    font-size:23px;
	    margin: 20px 0px 20px 0px;
    }
    #fot
    {
    	margin-top: 0%;
    }
    #im1 img
    {
    	image-rendering: auto;
        image-rendering: crisp-edges;
        image-rendering: pixelated;
        image-rendering: -webkit-optimize-contrast;
        background-color: whitesmoke;
        margin-top: 5%;
        border-radius: 50%;
    }
    #help
    {
    	margin-top: 9%;
    	margin-left: 33%;
    }
    #help p
    {
        margin-left: -8%;
        color: rgba(234, 240, 246, 0.8);
    }
    #help ol li a
    {
        color: #32CD32;
    }
    #help ol li a:hover
    {
        color: green;
    }
      #header ul li a
    {

      top: 4.5px;
      
   }
    #myBtn
     {
          position: fixed;
          width: 50px;
          height: 45px;
          background: #00A86B;
          bottom: 13px;
          right: 18px;
          z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #FFA500;
    color: white;
    cursor: pointer;
    padding: 15px;
    border-radius: 50px;
    clip-path: circle();
     }
     #myBtn:hover
     {
          background-color: #ff4500;
     }
     footer #bot
     {
         margin-top: -2%;
      }
      footer .right-foot
  {
    margin-top: -14%;
  
  }
    @media only screen and (max-width: 620px) {
  /* For mobile phones: */
  #mainn, #space h1, #im1 img, #help{
    width: 100%;
  }
}
</style>
</head>
<body>
<div id="mainn">
<?php
		include "yheader.php";
		?>                   
<div id="space">
<div align="left" id="im1"><img style="float:left;" height="70%" width="30%" src="iterfaceimage/help3.jpg" alt="GCVS"/></div>
<h1 style="font-size: 30px; margin-left: 50%;">Welcome to:</h1><h1 style="font-size: 40px; margin-top: 2%;">ETHIOPIAN HIGHER EDUCATIONAL INSTITUES GRADUATE CREDENTIALS VERIFICATION SYSTEM</h1>
<div id="help"><h2>If you need any help, follow the direction below.</h2>
<ol><font size="5">
<li>first go to our <a href="index.php">site</a></li>
<li>then scroll down and find sliding university logos from the home page</li>
<li>thirdly, choose the university among the list, which the student claims to be graduated from</li>
<li>Fill the graduate ID number and department from the certificate presented by the student and finally click the verify button.</li>
<p>If the graduate information matches, it is assumed that the graduate is legal ,but if the serched data doesn't match the graduate must be having an illegal certificate.</p>
</font></ol></div>
</div>
<div id="fot">
<?php
include "Footer.php";
?>
</div>
</div>
<!--<button onclick="topFunction()" id="myBtn" title="Go to top">&#708;</button>-->
 <script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>

<?php
        session_start();
           if(!isset($_SESSION['username']))
       { 
       header("location:index.php");
       }
       else
       {
       ?>
<html>
<head>
  <title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript">
function validationForm() {
var gfn=document.forma.Gfname.value
var id=document.forma.Gid.value
var gmn=document.forma.Gmname.value
var gln=document.forma.Glname.value
var yog=document.forma.Yog.value
var gqu=document.forma.Gqul.value
var gdp=document.forma.gdep.value
var guniv=document.forma.guni.value
var gdpp=document.forma.image.value
var gdppr=document.forma.Gpa.value
if(id=="")
{
window.alert("ID can not left blank");
return false;
}
 else if (gfn=="")
{
window.alert("Graduate first name can not left blank");
return false;
}
else if (isNaN(gfn)==false)
{
window.alert("Graduate first name can not be number");
return false;
}
else if (gmn=="")
{
window.alert("Graduate Midle name can not left blank");
return false;
}
else if (isNaN(gmn)==false)
{
window.alert("Graduate Middle name can not be number");
return false;
}
else if (gln=="")
{
window.alert("Graduate Last name can not left blank");
return false;
}
else if (isNaN(gln)==false)
{
window.alert("Graduate Last name can not be number");
return false;
}
else if (yog=="--select one--")
{
window.alert("select year of garduation");
return false;
}
else if (gqu=="--select one--")
{
window.alert("Select Graduate qualification");
return false;
}
else if (!((document.forma.mgender[0].checked)||(document.forma.mgender[1].checked)))
{
window.alert("Select gender option");
return false;
}

else if (gdp=="--select one--")
{
window.alert("select Department");
return false;
}
else if (guni=="--select one--")
{
window.alert("select University");
return false;
}
 else if(gdppr=="")
{
window.alert("GPA can not left blank");
return false;
}
}
</script>
<style type="text/css">
     body
          {
          width: 100%;
          background-color: whitesmoke;
          overflow-x: ;
         }
  #formr
       {
            margin-top: 0.1%;
            margin-left: 10%;
         }
  #left
      {
          margin-top: -0.2%;
      }
  #hy
    {
          margin-top: 0%;
          background-color: #d8eaf5;
          position: relative;
          width: 1600px;
          text-align: center;
          height: 50px;
        }
  #inser
      {
         margin-top: 10%;
         margin-left: 90%;
         width: 100px;
       }
  button
     {
       font-weight: 700;
       color: white;
       background-color: #3e98d0;
       border: 2px #3e98d0 solid;
       height: 45px;
       width: 150px;
       border-radius: 13px;
     }
  button:hover
   {
     background-color: #3179a6;
   }
   input[type='button'],text area
   {
       color: white;
       background-color: #3e98d0;
       border: 2px #3e98d0 solid;
       height: 45px;
       width: 150px;
       border-radius: 13px;
   }
   input[type=button]:hover
   {
      background-color: #3179a6; 
   }
   #butt
   {
     margin-left: 44%;
     margin-top: 44%;
     position: absolute;
   }
   #butt2
   {
    margin-left: 85%;
    margin-top: -51.35%;
    font-size: 17px;
    position: absolute;
    background-color: darkred;
    border: none;
   }
   #butt2:hover
   {
    opacity: 0.8;
   }
</style>
</head>
<body>
  <div id="hy"><font color="#3E98D0"><h2>Haramaya university Registrar</font></h2></div>
  <h2 style="text-align: center;"><font color="#3E98D0">Insert Graduate Information/ import from excel</font></h2>
  <a href="display data24.php"><button id="butt">View Data</button></a>
  
<form action="insert data3.php" name="forma" id="formr" method="post" enctype="multipart/form-data">
<table cellspacing="15" cellpadding="10" bgcolor="#D7D7D7" id="tab">
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Graduate ID:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="sprytextfield1">
              <label><input type="text" name="Gid" class="user_name_hover" id="span9001" placeholder="Graduate Id" size="30" ></label><span class="textfieldRequiredMsg"><b>Graduate ID required</b></span></span></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;First Name:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="sprytextfield2">
              <label><input type="text" name="Gfname" id="span9001" placeholder="First Name" size="30" ></label><span class="textfieldRequiredMsg"><b>Frist Name required</b></span></span></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Middle Name:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="sprytextfield3">
              <label><input type="text" name="Gmname" id="span9001" placeholder="Middle Name" size="30" ><span class="textfieldRequiredMsg"><b>Middle Name required</b></span></span></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Last Name:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="sprytextfield4">
              <label><input type="text" name="Glname" id="span9001" placeholder="Last Name" size="30" ></label><span class="textfieldRequiredMsg"><b>Last Name required</b></span></span></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year of Graduation:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="Yog" id="span9001">
  <?php
  for($i = 1900; $i < date("Y")+1; $i++){
    echo '<option value="'.$i.'">'.$i.'</option>';
  }
  ?>
</select>
</td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quaification:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <select name="Gqul" id="select">
    <option>--select one--</option>
    <option>Associate Degree</option>
    <option>Bachelor of Degree</option>
    <option>Master's Degree</option>
    <option>Doctor of Medicine</option>
    <option>BSc</option>
    <option>Doctoral Degree</option>
  </select></td>
</tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gender:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="mgender" value="Male"> Male 
<input type="radio" name="mgender" value="Female"> Female </td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Department:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="gdep" id="span9001">
<option>--select one--</option>
<option>computer science</option>
<option>information system</option>
<option>information technology</option>
<option>Construction Technology Management Engineering</</option>
<option>Civil Engineering</option>
<option>Electrical Engineering</option>
<option>Mechanical Engineering</option>
<option>Survey Engineering</option>
<option>Water and Resource Irrigation Engineering</option>
<option>Plant Science</option>
<option>Animal Science</option>
<option>Agro_Economics</option>
<option>Forestry</option>
<option>Natural Resource Management</option>
<option>Eco Tourism</option>
<option>Health Officer (HO)</option>
<option>Nursing</option>
<option>Midwifery</option>
<option>Statistics</option>
<option>Medicine</option>
<option>Mathematics</option>
<option>Biology</option>
<option>Chemistry</option>
<option>Physics</option>
<option>Sport Science</option>
<option>Economics</option>
<option>Business and Management</option>
<option>Accounting and Finance</option>
<option>Management</option>
<option>Marketing Management</option>
<option>Tourism Management</option>
<option>Afaan Oromoo</option>
<option>English</option>
<option>Amharic</option>
<option>Journalism and Communication</option>
<option>History</option>
<option>Geography</option>
<option>Adult Education</option>
<option>Psychology</option>
<option>Sociology</option>
<option>Civics and Ethical Education</option>
<option>Law</option>
<option></option>
</select></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;University:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name="guni" id="span9001">
<option>--select one--</option>
<option>Addis Ababa Science & technology university</option>
<option>Adama Science & technology university</option>
<option>Addis Ababa university</option>
<option>Adigrat university</option>
<option>Ambo university</option>
<option>Arba minch university</option>
<option>Arsi university</option>
<option>Assosa university</option>
<option>Axum university</option>
<option>Bahir Dar university</option>
<option>Bonga university</option>
<option>Borena university</option>
<option>Bule Hora university</option>
<option>Debark university</option>
<option>Debrebiran university</option>
<option>Debremarkos university</option>
<option>Debre Tabor university</option>
<option>Dembi Dolo university</option>
<option>Dilla university</option>
<option>Dire Dawa university</option>
<option>Gambella university</option>
<option>Gonder university</option>
<option>Haramaya university</option>
<option>Hawassa university</option>
<option>Injibara university</option>
<option>Jijiga university</option>
<option>Jimma university</option>
<option>Jinka university</option>
<option>Kebri Dehar university</option>
<option>Kotebe Metropolitan university</option>
<option>Medawalabu university</option>
<option>Mekelle university</</option>
<option>Mekidela Amba university</option>
<option>Mettu university</option>
<option>Mizan Tepi university</option>
<option>oda bultum university</option>
<option>Raya university</option>
<option>Selale university</option>
<option>Semera university</option>
<option>Wachamo university</option>
<option>Welkete university</option>
<option>Werabe university</option>
<option>Wolaita sodo university</option>
<option>Woldiya university</option>
<option>Wollega university</option>
<option>Wollo university</option>
</select></td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GPA:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="sprytextfield5">
              <label><input type="text" name="Gpa"id="span9001" placeholder="GPA" size="30"></label><span class="textfieldRequiredMsg"><b>GPA required</b></span></span></td></tr>
<!--<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Upload Photo:</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="image" id="span9001"></td></tr>-->
<tr id="inser"><td><button class="btn btn-primary" name="submitb"onClick="validationForm()"><i class="icon-ok-sign icon-large"></i>&nbsp;INSERT</button></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><input type="button" value="IMORT FROM EXCEL"ONCLICK="window.location.href='excel/index.php' " class="btn btn-primary"/></td></tr>
</table>

                      

 <!--<button class="btn btn-primary" name="submitb" onClick="validationForm()"><i class="icon-ok-sign icon-large" ONCLICK="window.location.href='excel/index.php' "></i>&nbsp;IMPORT FROM EXCEL</button><br>
<--<div style="background-color:#CCCCFF"><h3>IF YOU WANT TO IMPORT FROM EXCEL</h3><a href="excel/index.php"><h1>CLICK HERE</h1></a></div>-->
</form>
<a href="logout.php"><button id="butt2">Logout</button></a>
    <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");
//-->
</script>
</body>
</html>
<?php
}
?>
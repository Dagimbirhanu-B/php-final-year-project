<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="bayisa.php">Home</a></li>&nbsp;&nbsp;
			<li><a href="#">Organization</a> 
			<ul><li> <a href="#">Verify Graduate<br></a><ul>
	                        

	                        <li><a href="rf.php">Register Organization<br></li></a>
				<li><a href="employeform.php">Register Employee<br></li></a></ul></li>
			        <li><a href="#"> View Credentials Verification Link<br></li></a>
				<li><a href="#">View Acknoweldgement Message<br></li></a></ul>
			        </li>&nbsp;&nbsp;
				<li><a href="Help.php">Help</a></li>&nbsp;&nbsp;
                        <li><a href="AboutUs.php">About Us</a></li>&nbsp;&nbsp;</ul></div>
 </hgroup>
</header> 
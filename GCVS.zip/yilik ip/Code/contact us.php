<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
	<style type="text/css">
body {
	
     overflow-x: hidden;
     scroll-behavior: smooth;
         }
	*{
             box-sizing: border-box;
         }
         #co
         {
         	background-color: #87CEEB;
         	margin-top: 5%;
         	position: ;
         	height: 350px;
         	
          
         }
          #co h3
          {
          	   color: black;
          	   padding-top: 0px;
               margin-left: 10%;
               font-family: sans-serif;
               font-size: 30px;
          }
         
     #f3
     {
     	margin-top: 0%;
     	padding-bottom: 0;
     }
     #co h4
     {
          color: black;
          margin-left: 10%;
          line-height: 2px;
     }
    #co h4 a
     {
          color: black;

     }
     #emplo
     {
          text-align: justify;
          width: 1000px;
          margin-left: 20%;
     }
     #with1
        {
          margin-top: 25%;
        }
        #myBtn
     {
          position: fixed;
          width: 50px;
          height: 45px;
          background: #00A86B;
          bottom: 13px;
          right: 25px;
          z-index: 99;
    font-size: 18px;
    border: none;
    outline: none;
    background-color: #FFA500;
    color: white;
    cursor: pointer;
    padding: 15px;
    border-radius: 50px;
    clip-path: circle();
     }
     #myBtn:hover
     {
          background-color: #ff4500;
     }
     footer #bot
{
    margin-top: -2%;
}
footer .right-foot
  {
    margin-top: -14%;
  
  }
     @media only screen and (max-width: 620px) {
  /* For mobile phones: */
  #co, h3, #myBtn, #f3, #with2, #emplo{
    width: 100%;
  }
}
	</style>
</head>
<body>
	<?php include "yheader.php"; ?>
        <div id="co">
          <h4 style="padding-top: 50px; color: black;">Contact Us</h4>
             <h3>Ministry of Science and Higher Education (MoSHE)</h3>
                   <h4>Phone: +251-111-55-31-33</h4><br> 
			    <h4>Email: <a href="mailto: moshe@ethernet.edu.et">moshe@ethernet.edu.et</a></h4><br>
			    <h4>Website: <a href="http://mosheservices.ethernet.edu.et/">View website</a></h4>
		</div>
          <div id="emplo">
          <h2 style="color: green; font-size: 31px; text-align: center; font-family: sans-serif;">An employer verification system must be implemented to ensure jobs are not given to illegal candidate</h2>
          <!--<h2 style="color: black; text-align: center; font-family: sans-serif; justify-content: center;">This fraud production of certificate has retarded our country from going forward because there was no such a system that actually could verify the reality of credentials.</h2>-->
          <h2 style="color: green; text-align: center;">We also believe in creating an enviroment where you will feel confident while hiring your employee.</h2>
            <h2 style="color: #08457e; text-align: center; font-size: 35px;">we help you get the right employee for your organization!</h2>
            </div>
            
		<div id="f3">
    <?php 
         include "Footer.php";
     ?>
</div>
<!--<button onclick="topFunction()" id="myBtn" title="Go to top">&#708;</button>-->
 <script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document,,,
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
</body>
</html>
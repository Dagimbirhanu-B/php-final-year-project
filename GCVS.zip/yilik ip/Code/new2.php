<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MoSHE Degree Verification|Ethiopia</title>
  <link rel="icon" type="image/x-icon" href="image/mortarboard.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style type="text/css">
		

		#mid2
		{
			width: 600px;
			justify-content: center;
			margin-left: 30%;

		}
		p a
		{
			text-decoration: none;
			color: #6495ED;
		}
		p a:hover
		{
			opacity: 0.7;
		}
		#more {display: none;}
		#myBt
		{
			background-color: #6495ED;
			width: 80px;
			margin-top: 1%;
			text-align: left;
			position: absolute;
			border: none;
		}
	</style>
</head>
<body>
<div id="mid2">
	<h1 style="color: black; font-size: 45PX; font-family: Roboto;">Why Degree Verification?</h1>
	<p style="justify-content: center; color: black; font-size: 20px; font-family: sans-serif;">while hiring an employee, a recruiter tries to find out everything about the employee
 However, it is not possible to know whether the empl<span id="dots">...</span><span id="more">oyee is worthy or not only through the interviews.
 	Interviews are more about testing the knowledge and competence of the graduate. But when you are hiring a graduate, it’s necessary to know more about them. This is where pre-employment degree Verification comes in.<br>
 	<b style="font-weight: bold;">The crucial advantage of degree verification is:</b><br>
 	
 		<b style="color: #6495ED;">Hire only qualified candidates-</b>
 		People often <a href="https://www.google.com/search?q=embellish+meaning&rlz=1C1NDCM_enET992ET992&oq=embellish&aqs=chrome.1.69i57j0i512l9.2127j0j7&sourceid=chrome&ie=UTF-8">embellish</a> their work history when they are trying to find a job. If you perform an employee degree check, you will know the correct work history or education and not end up hiring an unqualified candidate.
 	
 </span></p>
 <button onclick="myFunction()" id="myBt">Read more</button><br>
  <img src="iterfaceimage/graduate.jpg" style="margin-left: ; width: 600px; height: 70%; opacity: 1;">
  <h2 style="color: black">So what is the solution?</h2>
  <ul>
  	
  	<li style="color: #0053a5; font-size: 20px; margin-left: 4%;">you got to hire only a verified/qualified candidate.</li>
  </ul>
  <h3 style="color: #48A860">Here we provide you with an easy and fast verification service</h3>
  <h2 style="color: #0053a5;">We help you make the right dicision!</h2>
 </div>
 <script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBt");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "12@abcd@34";

// Create connection
$conn = mysqli_connect($servername, $username, $password,"test1");
// Check connection
?>
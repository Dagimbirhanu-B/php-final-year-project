This is my First Project as student.

I have work with MySQL/phpmyadmin as back-end for it and php/html as front-end,

I have added sql trigger in this project to work on two table as same time, It is 3 way system:-

USER can see which prisoner are in jail and there ID, and they can request for permission to see that prisoner.

ADMIN can add,update,delete a prisoner to the particular prison, also admin can add,update,delete staff member and assigned there work, he can also grant permission to User to there request.

STAFF can only add medical updates on prisoner in particular cases, and he can only view visitor,other staff members.

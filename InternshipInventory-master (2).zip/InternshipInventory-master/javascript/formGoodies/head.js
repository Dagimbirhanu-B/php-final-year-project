<script type="text/javascript" src="{source_http}mod/intern/javascript/formGoodies/copyAddress.js"></script>
<script type="text/javascript" src="{source_http}mod/intern/javascript/formGoodies/otherGoodies.js"></script>
<script type="text/javascript">
const approved = '{perm}';
const toGenId = '{id}';
    $(document).ready(function(){
        copyAddress();
        otherStuff();
    });
</script>

<?php
/*
 * @author Micah Carter
 */

$proper_name  = 'Internship Inventory';
$version      = '1.1.2';
$register     = false;
$unregister   = false;
$import_sql   = true;
$about        = true;
$priority     = 50;
$dependency   = true;
$image_dir    = false;
$file_dir     = false;

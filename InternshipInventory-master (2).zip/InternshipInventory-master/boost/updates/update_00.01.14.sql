alter table intern_internship alter start_date drop not null;
alter table intern_internship alter end_date drop not null;
alter table intern_internship alter background_check drop not null;
alter table intern_internship alter drug_check drop not null;

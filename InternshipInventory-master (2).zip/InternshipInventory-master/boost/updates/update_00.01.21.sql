INSERT INTO "intern_country" ("id", "name") VALUES ('US', 'United States of America');

ALTER TABLE intern_internship ADD COLUMN remote SMALLINT;
ALTER TABLE intern_internship ADD COLUMN remote_state VARCHAR;

ALTER TABLE intern_department ALTER COLUMN hidden DROP NOT NULL;

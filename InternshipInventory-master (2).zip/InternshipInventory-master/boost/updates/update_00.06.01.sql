ALTER TABLE intern_internship DROP COLUMN student_address;
ALTER TABLE intern_internship DROP COLUMN student_address2;
ALTER TABLE intern_internship DROP COLUMN student_city;
ALTER TABLE intern_internship DROP COLUMN student_state;
ALTER TABLE intern_internship DROP COLUMN student_zip;
ALTER TABLE intern_internship DROP COLUMN birth_date;

ALTER TABLE intern_local_student_data DROP COLUMN birth_date;
ALTER TABLE intern_local_student_data DROP COLUMN gender;
ALTER TABLE intern_local_student_data DROP COLUMN address;
ALTER TABLE intern_local_student_data DROP COLUMN address2;
ALTER TABLE intern_local_student_data DROP COLUMN city;
ALTER TABLE intern_local_student_data DROP COLUMN state;
ALTER TABLE intern_local_student_data DROP COLUMN zip;

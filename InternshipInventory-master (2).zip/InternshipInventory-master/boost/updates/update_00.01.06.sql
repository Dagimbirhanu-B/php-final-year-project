alter table intern_agency add column province character varying;
alter table intern_agency add column supervisor_province character varying;
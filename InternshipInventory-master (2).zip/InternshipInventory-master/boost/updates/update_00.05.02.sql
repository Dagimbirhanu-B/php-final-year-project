alter table intern_internship add column preferred_name varchar;
alter table intern_internship add column preferred_name_meta varchar;

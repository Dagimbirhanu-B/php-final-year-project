ALTER TABLE intern_internship ADD COLUMN internship SMALLINT NOT NULL;
ALTER TABLE intern_internship ADD COLUMN service_learn SMALLINT NOT NULL;
ALTER TABLE intern_internship ADD COLUMN independent_study SMALLINT NOT NULL;
ALTER TABLE intern_internship ADD COLUMN research_assist SMALLINT NOT NULL;
ALTER TABLE intern_internship ADD COLUMN other_type TEXT;
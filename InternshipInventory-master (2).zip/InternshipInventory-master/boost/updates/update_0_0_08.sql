BEGIN;

-- Four semesters per year! Adding extra one.
INSERT INTO intern_term values (10, 20114);
INSERT INTO intern_term values (11, 20124);
INSERT INTO intern_term values (12, 20134);

COMMIT;
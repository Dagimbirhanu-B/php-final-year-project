ALTER TABLE intern_internship ALTER COLUMN credits DROP NOT NULL;
ALTER TABLE intern_internship ALTER COLUMN avg_hours_week DROP NOT NULL;
alter table intern_internship add column experience_type varchar;

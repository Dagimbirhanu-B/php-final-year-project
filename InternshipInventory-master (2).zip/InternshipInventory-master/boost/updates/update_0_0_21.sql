ALTER TABLE intern_student ALTER COLUMN grad_prog DROP NOT NULL;
ALTER TABLE intern_student ALTER COLUMN ugrad_major DROP NOT NULL;
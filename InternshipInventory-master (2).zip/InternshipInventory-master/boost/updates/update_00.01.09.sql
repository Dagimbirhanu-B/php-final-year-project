alter table intern_internship add column student_address2 character varying;

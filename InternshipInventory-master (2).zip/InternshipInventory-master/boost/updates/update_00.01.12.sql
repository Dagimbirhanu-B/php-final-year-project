ALTER TABLE intern_internship ADD COLUMN background_check SMALLINT DEFAULT 0;
ALTER TABLE intern_internship ADD COLUMN drug_check SMALLINT DEFAULT 0;

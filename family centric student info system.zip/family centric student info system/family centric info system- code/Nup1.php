<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<?php
$con=mysql_connect("localhost","root","") or die('not connected');
$id=$_REQUEST['id'];
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
$phone=$_REQUEST['phone'];
$usertype=$_REQUEST['usertype'];
$gender=$_REQUEST['gender'];
mysql_select_db("fcis",$con) or die("can not select the database");
$query="UPDATE account SET username='".$username."',
 password='".$password."',phone='".$phone."',usertype='".$usertype."',gender='".$gender."' WHERE id='".$id."' ";
$a=mysql_query($query,$con);
if(!$a)
{
die('data can not be Update' . mysql_error());
}
else
{
echo '<script type="text/javascript">alert(" successfully updated!!");window.location=\'Nedit.php\';</script>';
}
?>
</body>
</html>

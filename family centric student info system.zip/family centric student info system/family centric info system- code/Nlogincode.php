<?php
session_start();
$usertype=$_POST['usertype'];
$id=$_POST['id'];
$password=$_POST['password'];
if($usertype=="Admin")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:admin.html");
} 
mysql_close($con);
}
else if($usertype=="Record officer")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis",$con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:NRecord officer.html");
} 
mysql_close($con);
}
else if($usertype=="student affair director")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:NsaffairD.html");
} 
mysql_close($con);
}
else if($usertype=="Doctor")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:Doctor.html");
} 
mysql_close($con);
}
else if($usertype=="card Room")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location: Nnurse.html");
} 
mysql_close($con);
}
else if($usertype=="Teacher")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:TECH.html");
} 
mysql_close($con);
}
else if($usertype=="Dep.Head")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis",$con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong userID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:departement.html");
}
mysql_close($con);
}
else if($usertype=="Nurse")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis",$con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong userID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:Nnurse.html");
}
mysql_close($con);
}  
else if($usertype=="Student")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis",$con);
$sql = "select * from account where id='".$id."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong userID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:Nstudent.html");
} 
mysql_close($con);
}
?>
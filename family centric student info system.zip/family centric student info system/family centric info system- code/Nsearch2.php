<html>
<head>
<title></title>
<link rel="stylesheet" href="style.css">
</head>
<body bgcolor="bluegreen">
<a href="Nsearch.html"> Go back </a>
<h1>  Search Results Are</h1>
<?php
$searchtype=$_POST['searchtype'];
$searchterm=$_POST['searchterm'];
$searchterm=trim($searchterm);
if(empty($searchtype) || empty($searchterm))
{
	echo'Please enter search details.'.mysql_error();
	exit;
}
@ $db= mysql_pconnect('localhost','root','');
if(!$db)
{
	echo 'Error connecting database'.mysql_error();
	exit;
}
mysql_select_db('fcis');
$query="select * from sinformation where ".$searchtype." like '%".$searchterm."%'";

$result=mysql_query($query);
$num_results=mysql_num_rows($result);
if($num_results)
echo '<p> Number of Student get order: '.$num_results.'</p>';


echo '<center><table bgcolor="white" border=1>';
echo'<TR>
<TD bgcolor="pink"  width="60"><B>sid</B>
<TD bgcolor="pink"  width="60"><B>smfname</B>
<TD bgcolor="pink"  width="60"><B>smmname</B>
<TD bgcolor="pink"  width="60"><B>smlname</B>
<TD  bgcolor="pink" width="60"><B>sphone</B>
<TD  bgcolor="pink" width="60"><B>departement</B>
<TD  bgcolor="pink" width="60"><B>gender</B>
<TD  bgcolor="pink" width="60"><B>sgradereport</B>
<TD bgcolor="pink"  width="60"><B>status</B>
<TD bgcolor="pink"  width="60"><B>accadamic_year</B>
<TD bgcolor="pink"  width="60"><B>semister</B>
<TD bgcolor="pink"  width="60"><B>shealthreport</B>
<TD bgcolor="pink"  width="60"><B>sdisciplinereport</B>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60">';
echo $row["sid"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["smfname"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["smmname"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["smlname"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["sphone"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["departement"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["gender"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["sgradereport"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["status"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["accadamic_year"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["shealthreport"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["sdisciplinereport"];
echo '</td>';
echo"</tr>";
}
echo "</TABLE>";

echo '<p>';

?>
</body>
</html>
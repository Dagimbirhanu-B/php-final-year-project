<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO famcomment(sid,sname,sex,faculity,accyear,sphone,smfname,smmname,smlname,smphone,remark) VALUES('$_POST[sid]','$_POST[sname]','$_POST[sex]','$_POST[faculity]','$_POST[accyear]','$_POST[sphone]','$_POST[smfname]','$_POST[smmname]','$_POST[smlname]','$_POST[smphone]','$_POST[remark]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully Registered!!");window.location=\'faco.html\';</script>';
    }
    else 
	header("location:faco.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}

return true;
}
</script></head>
 <body bgcolor="white">
<table align="center" background="pink" border="1" height="200" width="870" bgcolor="white">
<form action="viewhistory.php" method="POST" name="form1">
<tr><td>SId<input type="text" name="sid" id="sid"/>
 <br><input type="submit" name="select" value="view Previous Record"/></td>

</form>
</tr>
<tr>
<td>SID</td>
<td>age</td>
<td>ptseenby </td>
<td>ptseenat </td>
<td>diagnosis  </td>
<td>prescription </td>
<td>complication </td>
<td>sickleaveendingdate</td>
<td>remarks</td>
</tr>
<?php


$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
//if(isset($_POST['select'])){
//$sid=$_POST['sid'];
$sql="select * from shealthinfo where sid='$_POST[sid]'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$age=$row['age'];
$ptseenby=$row['ptseenby'];
$ptseenat=$row['ptseenat'];
$diagnosis=$row['diagnosis'];
$prescription=$row['prescription'];
$complication=$row['complication'];
$sickleaveendingdate=$row['sickleaveendingdate'];
$remarks=$row['remarks'];


?>

<tr height="10">

<td height="10"><?php echo $sid;?></td>
<td><?php echo $age;?></td>
<td><?php echo $ptseenby;?></td>
<td><?php echo $ptseenat;?></td>
<td> <?php echo $diagnosis;?></td>

<td><?php echo $prescription;?></td>

<td><?php echo $complication;?></td>

<td><?php echo $sickleaveendingdate;?></td>
<td><?php echo $remarks; }?></td>
</tr>
<?php

//}
?>

</table>

</body>
</html>

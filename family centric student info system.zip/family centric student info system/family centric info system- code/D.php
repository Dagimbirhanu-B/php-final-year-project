
<?php
if(isset($_POST['submit'])){
$sid=$_POST['sid'];
$age=$_POST['age'];
$ptseenat=date('y/m/d');
$ptseenby=$_POST['ptseenby'];
$dg=$_POST['diagnosis'];
$pc=$_POST['prescription'];
$cp=$_POST['complication'];
$sed=$_POST['sickleaveendingdate'];
$rm=$_POST['remark'];
mysql_connect('localhost','root','');
mysql_select_db('fcis');
$query=mysql_query("INSERT INTO shealthinfo (sid,age,ptseenat,ptseenby,diagnosis,prescription,complication,sickleaveendingdate,remarks)values('$sid','$age','$ptseenat','$ptseenby','$dg','$pc','$cp','$sed','$rm')");
		if(!$query)
		{
	die('data not insert'.mysql_error());
		
		}
		else
	    {
		echo '<script type="text/javascript">alert("patient successfully recorded!!");window.location=\'horecord.html\';</script>';
	    }
		}
?>
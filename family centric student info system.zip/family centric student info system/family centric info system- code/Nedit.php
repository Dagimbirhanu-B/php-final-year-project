<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Online family control information system</title>
</head>
<body>
<div id="wrapper">
  
  <div id="content">
    <h2><center><span style="color:#003300"> Account Players</span></center></h2>
   <center> <table width="40%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td height="20" bgcolor="#3399FF"><span class="style5"><strong>List of account users</strong></span></td>
      </tr>
      <?php
// Establish Connection with Database
$con = mysql_connect("localhost","root","");
// Select Database
mysql_select_db("fcis", $con);
// Specify the query to execute
$sql = "select * from account";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$id=$row['id'];
$username=$row['username'];
$password=$row['password'];
$phone=$row['phone'];
$usertype=$row['usertype'];
$gender=$row['gender'];
}
?>
      
        <td height="15"><form id="Nup1" name="Nup1" method="POST" action="Nup1.php" onSubmit="return validate(this) ;">
            <table width="45"  border="0" cellpadding="0" cellspacing="0">
			 <tr><td>id</td><td>username</td><td>password</td><td>phone</td><td>usertype</td><td>gender</td></tr>
              <tr>
                <td ><input type="text" name="id" value="<?php echo $id;?>" border="pink"</td>
                 <td><input type="text" name="username" value="<?php echo $username;?>"</td>
                  <td><input type="password" name="password" value="<?php echo $password;?>"</td>
                   <td><input type="text" name="phone" value="<?php echo $phone;?>"</td>
                 <td><input type="usertype" name="usertype" value="<?php echo $usertype;?>"</td>
                <td><input type="text" name="gender"value="<?php echo $gender;?>"</td>
                </tr>
                

 <td align="center"> <input type="submit"name="submit"value="update user" /></td><td align="justify"> <input type="reset"name="reset"vaelue="Reset" /></td>
</table>

        </form></td>
      </tr>
      <tr>
        <td height="15"width="20" bgcolor="3399FF"><span class="style4"><strong>User List</strong></span></td>
      </tr>
      <tr>
        <td><table width="50%" border="1" bordercolor="#FF6600" >
            <tr>
              <th height="20"width="50" bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>id</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>username</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9">password</div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9">phone</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9">usertype</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9">gender</div></th>
            </tr>
           
<?php
// Establish Connection with Database
$con = mysql_connect("localhost","root","");
// Select Database
mysql_select_db("fcis", $con);
// Specify the query to execute
$sql = "select * from account";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$id=$row['id'];
$username=$row['username'];
$password=$row['password'];
$phone=$row['phone'];
$usertype=$row['usertype'];
$gender=$row['gender'];

?>
            <tr>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $id;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $username;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $password;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $phone;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $usertype;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $gender;?></strong></div></td>
            </tr>
            <?php
}
// Retrieve Number of records returned
$records = mysql_num_rows($result);
?>
            <tr>
              <td colspan="0" class="style3"><div align="left" class="style12"><?php echo "Total ".$records." Records"; ?> </div></td>
            </tr>
            <?php
// Close the connection

?>

        </table></td>
      </tr>
     
    </table>
    <p>&nbsp;</p>
  </div>
   <div style="clear:both;"></div>
</div>
</body>
</html>


<?php
if(isset($_POST['submit'])){
$sid=$_POST['sid'];
$ptname=$_POST['ptname'];
$age=$_POST['age'];
$gender=$_POST['gender'];
mysql_connect('localhost','root','');
mysql_select_db('fcis');
$query=mysql_query("INSERT INTO cardkeeper(sid,ptname,age,gender,status)values('$sid','$ptname','$age','$gender','unseen')");
		if(!$query)
		{
	echo"data not inserted";
		
		}
		else
	    {
		echo '<script type="text/javascript">alert("patient successfully recorded!!");window.location=\'patientR.html\';</script>';
	    }
		}
?>
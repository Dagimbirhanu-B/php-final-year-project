<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['send'])){
$c="INSERT INTO contactas(id,name,email,comment) VALUES('$_POST[id]','$_POST[name]','$_POST[email]','$_POST[comment]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully comment sent!!");window.location=\'Ncontactas.html\';</script>';
 echo "data is inserted";
    }
    else 
	header("location:Ncontactas.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jun 15, 2015 at 11:24 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `fcis`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `account`
-- 

CREATE TABLE `account` (
  `id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `phone` int(15) NOT NULL,
  `usertype` varchar(30) NOT NULL,
  `gender` char(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `account`
-- 

INSERT INTO `account` (`id`, `username`, `password`, `phone`, `usertype`, `gender`) VALUES 
('kiot/1510/04', 'nuru', '77', 916467147, 'Admin', ''),
('kiot/001/04', 'adis', '111', 916468356, 'record officer', 'M'),
('kiot/1400/04', 'ee', '90', 2147483647, 'Doctor', 'M'),
('kiot/1500/04', 'cd', '80', 9555555, 'Card Room', 'F'),
('1433', 'nu', 'nn', 916467147, 'Student', 'M'),
('kiot/1111/04', 'nu', '10', 916467146, 'student affair director', 'M'),
('145', 'dd', '00', 916468887, 'Teacher', 'M');

-- --------------------------------------------------------

-- 
-- Table structure for table `cardkeeper`
-- 

CREATE TABLE `cardkeeper` (
  `sid` varchar(20) NOT NULL,
  `ptname` varchar(35) NOT NULL,
  `age` int(3) NOT NULL,
  `gender` char(1) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `cardkeeper`
-- 

INSERT INTO `cardkeeper` (`sid`, `ptname`, `age`, `gender`, `status`) VALUES 
('1475/04', 'arif', 23, 'M', 'seen'),
('1470/04', 'patient', 0, 'm', 'seen'),
('kiot/1410/04', 'nuru', 20, 'm', 'seen'),
('kiot/1546/04', '', 0, '', 'seen'),
('1475/04', '', 0, '', 'seen'),
('kiot/1510/04', '', 0, '', 'seen'),
('1600', 'dgh', 65, 'M', 'seen'),
('1298', 'zasd', 13, 'F', 'unseen');

-- --------------------------------------------------------

-- 
-- Table structure for table `comment`
-- 

CREATE TABLE `comment` (
  `name` varchar(20) NOT NULL,
  `comment` varchar(249) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `comment`
-- 

INSERT INTO `comment` (`name`, `comment`, `date`) VALUES 
('arif', 'we are surprised by this project! it is simply amazing. ', '2008-09-25 03:09:40'),
('ftytyugg', 'fhgfjhgkjg yrfyufhgyg yryfyugkjfyr hyrytruitut', '2008-09-25 03:09:00'),
('arif', 'sgfdghfhghbnvcvxfgsrtdygghvbcgdtdttfhhghvhfjh gfyfygn  ytyfyhg hgggh gfyfyfy guituigjh ghgug', '2008-09-25 04:09:54'),
('arif ', 'we are surprised by this project! it is simply amazing.', '2008-09-25 04:09:40'),
('arif', 'fhggjg! hyuefhdsh@ gfhsdjhedj$  %bjdhiklh. ', '2008-09-25 04:09:36'),
('arif', 'birhanu kibret abdularif nuru', '2008-09-25 04:09:22'),
('nure erebohale', 'aarabegnem ccgvgvgghb', '2015-06-10 01:06:08'),
('wawi', 'sgahahhaxggf  hgshhajzhghaazzazghgsfxhahgzhaghxgzggxxhagashgahhshsuhayu', '2015-06-13 01:06:47'),
('ygs', 'hhzhgzhgagYGZa', '2015-06-13 01:06:59');

-- --------------------------------------------------------

-- 
-- Table structure for table `contactas`
-- 

CREATE TABLE `contactas` (
  `id` varchar(30) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `comment` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `contactas`
-- 

INSERT INTO `contactas` (`id`, `name`, `email`, `comment`) VALUES 
('kiot/1510/04', 'nuru', 'nuru@gmail.com', 'vvvvvvadagauuq'),
('kiot/1546/04', 'Abgudo', 'abg@gmail.com', 'wow yameral');

-- --------------------------------------------------------

-- 
-- Table structure for table `famcomment`
-- 

CREATE TABLE `famcomment` (
  `sid` varchar(20) NOT NULL,
  `sname` varchar(20) NOT NULL,
  `sex` char(1) NOT NULL,
  `faculity` varchar(20) NOT NULL,
  `accyear` varchar(20) NOT NULL,
  `sphone` varchar(20) NOT NULL,
  `smfname` varchar(20) NOT NULL,
  `smmname` varchar(20) NOT NULL,
  `smlname` varchar(20) NOT NULL,
  `smphone` varchar(20) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `status` varchar(30) NOT NULL default 'unseen'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `famcomment`
-- 

INSERT INTO `famcomment` (`sid`, `sname`, `sex`, `faculity`, `accyear`, `sphone`, `smfname`, `smmname`, `smlname`, `smphone`, `remark`, `status`) VALUES 
('1', 'a', '9', 'i', '4th', '', 'a', 'm', 's', '9', 'r', 'seen'),
('1', 'w', 'M', 'r', 'r', '', 'a', 'm', 's', 'r', 'r', 'seen'),
('1', 'aa', 'd', '2', 'd', '', 'd', 'fghjj', 'fg', 'f', 'd', 'seen'),
('1475', 'arif', '0', 'informatics', '4th', '', 'afran', 'mohammed', 'siraj', '0917463584', 'i cant pass the authentication', 'seen'),
('3', 'h', 'h', 'h', 'h', '', 'h', 'h', 'h', 'h', 'h', 'unseen'),
('', '', '', '', '6', '', '', '', '', '', '', 'seen'),
('', '', '7', '', '', '', '', '', '', '', '', 'seen');

-- --------------------------------------------------------

-- 
-- Table structure for table `notice`
-- 

CREATE TABLE `notice` (
  `userid` varchar(30) NOT NULL,
  `title` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `position` varchar(30) NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `notice`
-- 

INSERT INTO `notice` (`userid`, `title`, `start_date`, `end_date`, `position`, `content`) VALUES 
('', 'for student', '0000-00-00', '0000-00-00', 'Record officer', 'all student must rigeseter in this day also day one class one start 23/1/2015');

-- --------------------------------------------------------

-- 
-- Table structure for table `saffair`
-- 

CREATE TABLE `saffair` (
  `sid` varchar(20) NOT NULL,
  `sfname` varchar(20) NOT NULL,
  `smname` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `sex` char(1) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `accyear` varchar(20) NOT NULL,
  `repon` date NOT NULL,
  `acon` varchar(20) NOT NULL,
  `discription` varchar(249) NOT NULL,
  `desicion` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL default 'new'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `saffair`
-- 

INSERT INTO `saffair` (`sid`, `sfname`, `smname`, `age`, `sex`, `dept`, `accyear`, `repon`, `acon`, `discription`, `desicion`, `status`) VALUES 
('1', 'arif', 'bad', 23, 'M', 'IT', '4th', '2008-09-24', '21/09/2007', 'ghhjhjfgfgvhjv', 'vvcvcffgfgfgh', 'seen'),
('2', 'a', 'b', 2, 'M', 'IT', '4th', '2015-06-08', '12', 'fvffg', 'regfdgd', 'seen'),
('7', 'arif', 'bad', 23, 'M', 'IT', '4th', '2015-06-09', '12', 'gtty', 'yyfyg', 'new');

-- --------------------------------------------------------

-- 
-- Table structure for table `sginfo`
-- 

CREATE TABLE `sginfo` (
  `sid` varchar(30) NOT NULL,
  `sname` varchar(40) NOT NULL,
  `departement` varchar(20) NOT NULL,
  `semister` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `sGPA` float NOT NULL,
  `cgpa` float NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `sginfo`
-- 

INSERT INTO `sginfo` (`sid`, `sname`, `departement`, `semister`, `date`, `sGPA`, `cgpa`, `status`) VALUES 
('1', 'nuw', '', '4thEAR 1st sem', '0000-00-00', 3.5, 0, 'pass'),
('1298', 'nuru', '', '4thYEAR 2nd sem', '0000-00-00', 4, 0, 'fail'),
('7', 'arif', '', '1stYEAR 1st sem', '0000-00-00', 3, 0, 'pass'),
('8', 'nu', '', '1stYEAR 1st sem', '0000-00-00', 3, 0, 'pass'),
('9', 't', 'IT', '1stYEAR 1st sem', '2015-06-09', 4, 0, 'pass');

-- --------------------------------------------------------

-- 
-- Table structure for table `shealthinfo`
-- 

CREATE TABLE `shealthinfo` (
  `sid` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `ptseenat` date NOT NULL,
  `ptseenby` varchar(30) NOT NULL,
  `diagnosis` varchar(249) NOT NULL,
  `prescription` varchar(200) NOT NULL,
  `complication` varchar(10) NOT NULL,
  `sickleaveendingdate` date NOT NULL,
  `remarks` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `shealthinfo`
-- 

INSERT INTO `shealthinfo` (`sid`, `age`, `ptseenat`, `ptseenby`, `diagnosis`, `prescription`, `complication`, `sickleaveendingdate`, `remarks`) VALUES 
('45', 11, '2008-09-19', 'dfgg', 'vvbnnv', 'bvcvcbmnmj', 'low', '0000-00-00', 'cdcgjkkljhvb'),
('kiot/1546/04', 11, '2008-09-19', 'hgcfgv', 'nbghvvgfcc', 'nhcfgvbhmj', 'Medium', '2008-03-03', 'fgfhjkjkj'),
('3445', 26, '2008-09-20', 'gghjj', 'gftgyyu', 'frfghhuu', 'low', '2008-03-03', 'gtghhtr'),
('1', 12, '2008-09-20', 'ddddd', 'dddddd', 'aaaaaa', 'low', '2008-03-03', 'dersaaaaaaa'),
('65', 56, '2008-09-20', 'gf', 'vgvgg', 'tgth', 'low', '2008-03-03', 'frggy6y'),
('1298', 13, '2008-09-20', 'arif', 'fhjhghdfcc', 'xdghvghbvbgx', 'Medium', '2008-03-03', 'hgffdzgfnvbxfxzfx'),
('kiot/123/12', 34, '2008-09-18', 'xcxffddd', 'ddddffd', 'ddssaa', 'low', '2008-03-03', 'eedfdfdd'),
('13', 34, '2008-09-18', 'cvbnn', 'vvnbn', 'bvbnn', 'Medium', '2008-03-03', 'vggvhjjghbvb'),
('kiot/1546/04', 0, '2008-09-18', '', '', '', 'low', '0000-00-00', ''),
('1475/04', 0, '2008-09-18', '', '', '', 'low', '0000-00-00', ''),
('kiot/1410/04', 0, '2008-09-18', '', '', '', 'low', '0000-00-00', ''),
('1298', 67, '2008-09-24', 'arif', 'jhbcdjskbkjsd', 'jhdskjj', 'low', '2007-09-24', 'this fdhsdjkj'),
('7', 23, '2015-06-09', 'me', 'fgggugu', 'fhgug', 'low', '2015-06-12', 'fygyhg');

-- --------------------------------------------------------

-- 
-- Table structure for table `sinformation`
-- 

CREATE TABLE `sinformation` (
  `sid` varchar(20) NOT NULL default '',
  `sfname` varchar(30) NOT NULL,
  `smname` varchar(30) NOT NULL,
  `slname` varchar(30) NOT NULL,
  `sex` char(1) NOT NULL,
  `sphone` int(20) NOT NULL,
  `accyear` varchar(20) NOT NULL,
  `faculity` varchar(30) NOT NULL,
  `smfname` varchar(39) NOT NULL,
  `smmname` varchar(30) NOT NULL,
  `smlname` varchar(30) NOT NULL,
  `mphone` int(20) NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `sinformation`
-- 

INSERT INTO `sinformation` (`sid`, `sfname`, `smname`, `slname`, `sex`, `sphone`, `accyear`, `faculity`, `smfname`, `smmname`, `smlname`, `mphone`) VALUES 
('', '', '', '', 'M', 0, '', 'Informatics', '', '', '', 0),
('1', 'a', 'b', 'c', 'M', 9, '2007', 'Informatics', 'a', 'm', 's', 9),
('34', 'bbghnh', 'bhnbg', 'vghjj', 'M', 87, '567', 'Informatics', 'frhj', 'vch', 'bjb', 68),
('45', 'df', 'ffff', 'fffgg', 'F', 9, '56', 'Informatics', '', '', '', 87),
('7', 'arif', 'bad', 'isa', 'M', 9, '1', 'Informatics', 'afran', 'mohammed', 'siraj', 9),
('kiot/1546/04', '', '', '', '', 0, '', '', 'loko', 'nati', 'zeben', 0);

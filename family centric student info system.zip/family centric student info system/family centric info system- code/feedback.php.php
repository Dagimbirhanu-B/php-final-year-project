<html>
<head>
<script type="text/javascript">
function validate(form)
{
var A=form.name.value;
var B=form.email.value;
var C=form.country.value;
var D=form.phone_number.value;
var E=form.comment.value;

 var check = /^[a-zA-Z\ \']+$/;
 var isNumeric = /^[0-9]+$/;
 var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

if(!check.test(A))
{
alert("please enter only letter for name");
form.name.focus();
form.name.value="";
return false;
}
var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
if(!emailExp.test(B))
{
 alert("Please Enter Valid Email Address ");
 form.email.value="";
 form.email.focus();
 return false;  
}

if(!check.test(C))
{
alert("please enter only letter for country.");
form.country.focus();
form.country.value="";
return false;
}
if(!isNumeric.test(D))
{
alert("please enter only number for phone.");
form.phone_number.focus();
form.phone_number.value="";
return false;
}
$a=form.phone_number.length;
if($a<10||$a>10)
{
alert("please enter only 10 digit for phone number.");
form.phone_number.focus();
//form.phone.value="";
return false;
}

if(E=="")
{
alert("please enter your comment.");
form.comment.focus();
form.comment.value="";
return false;
}

 return true;
}
</script>
</head>
<body>
 <p style="font-weight:bold;">Latest comments:</p>
		 <table border='0'>
		<?php
		 $name="";
		 $comment="";
		 $date="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('fcis');
		$results = mysql_query("SELECT * from comment order by date DESC LIMIT 10");
		while($row=mysql_fetch_array($results))
		{
			$name=$row['name'];
			$comment=$row['comment'];
			$date=$row['date'];
			echo"<tr>
			  <td><b>Name: </b>{$name}</td>
			     </tr>
				 ";
			echo"<tr>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;{$comment}&nbsp;&nbsp;{$date}</td>
			</tr>";
		}
		
		?>
		
		</table>
		<a href=feedbackmore.php>Older Comments:</a>
		 <p style="font-weight:bold;">Feedback:</p>
		 <form action="comment1.php" method="POST" name="comment1" onSubmit="return check1();">
		    Name: <input type="text" name="name"><br><br>
			<textarea name="comment" placeholder="Enter your comment here.."></textarea><br><br>
			<div id="error1" style="color:red"></div>
			<input class="groovybutton" type="submit" name="submit" value="submit"> <input class="groovybutton" type="reset">
		 </form>
	 </div>	
     </body>
</html>
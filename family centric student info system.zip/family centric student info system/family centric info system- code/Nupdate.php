<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Online family control information system</title>
<script type="text/javascript">
function validate(form)
{
var id=form.id.value;
var username=form.username.value;
var password=form.password.value;
var phone=form.phone.value;
var usertype=form.usertype.value;
var gender=form.gender.value;
var check = /^[a-zA-Z\ \']+$/;
 var isNumeric = /^[0-9]+$/;
 var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

if(id=="")
{
alert("please enter id?");
Naccount.id.value="";
Naccount.id.focus();
return false;
}
if(!check.test(username))
{
alert("please enter letter only for username?");
Naccount.username.value="";
Naccount.username.focus();
return false;
}
if(password=="")
{
alert("please enter password?");
Naccount.password.value="";
Naccount.password.focus();
return false;
}
if(phone=="")
{
alert("please enter valid phone number?");
Naccount.phone.value="";
Naccount.phone.focus();
return false;
}
if(usertype=="")
{
alert("please select usertype?");
Naccount.usertype.valure="";
Naccount.usertype.focus();
return false;
}
if(gender=="")
{
alert("please select your gender?");
Naccount.gender.value="";
Naccount.gender.focus();
return false;
}
 return true;
}
</script>
</head>
<body>
<div id="wrapper">
  
  <div id="content">
    <h2><center><span style="color:#003300"> Account Players</span></center></h2>
   <center> <table width="60%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td height="27" bgcolor="#3399FF"><span class="style10"><strong>List of account users</strong></span></td>
      </tr>
      </tr>
      <tr>
        <td height="26"><form id="Naccount" name="Naccount" method="POST" action="Naccount.php" onSubmit="return validate(this) ;">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
			 <tr>
              <td height="32" >id</td>
                <td><span id="sprytextfield3">
                  <label>
                  <input type="text" name="id" id="id" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
             </tr>
              <tr>
                <td height="32" >username</td>
                <td><span id="sprytextfield3">
                  <label>
                  <input type="text" name="username" id="username" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
			   </tr>
              <tr>
                <td height="20" >password</td>
                <td><span id="sprytextfield2">
                  <label>
                  <input type="text" name="password" id="password" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
			   </tr>
              <tr>
                <td height="32" >phone</td>
                <td><span id="sprytextfield2">
                  <label>
                  <input type="text" name="phone" id="phone" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
              <tr>
              <tr>
              <tr>
              <tr>
			 
               <tr>
                <td height="30" >usertype</td>
                <td><span id="sprytextfield2">
                  <label>
                 <select name="usertype"id="usertype"><option>Admin</option><option>Card Room</option><option>Doctor</option><option>Teacher</option><option>record officer</option><option>student affair director</option><option>Dep.Head</option><option>Student</option></select>
                  </label>
                  <span class="textfieldRequiredMsg">please select.</span></span></td>
              </tr>
			   </tr>
			  <tr>
                <td height="34">gender</td>
                <td><span id="sprytextfield1">
                  <label>
                  <select name="gender" id="gender">
				  <option>M</option>
                <option>F</option>
            </select>
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
 <td height="35" align="center"> <input type="submit"name="submit"value="Create Account"/></td><td height="40" align="justify"> <input type="reset"name="reset"vaelue="Reset" /></td>
</table>

        </form></td>
      </tr>
      <tr>
        <td height="25" bgcolor="3399FF"><span class="style10"><strong>User List</strong></span></td>
      </tr>
      <tr>
        <td><table width="100%" border="1" bordercolor="#FF6600" >
            <tr>
              <th height="32" bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>id</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>username</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">password</div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">phone</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">usertype</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">gender</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>Edit</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Delete</div></th>
            </tr>
           
  
		    <?php
// Establish Connection with Database
$con = mysql_connect("localhost","root","");
// Select Database
mysql_select_db("fcis", $con);
// Specify the query to execute
$sql = "select * from account";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$id=$row['id'];
$username=$row['username'];
$password=$row['password'];
$phone=$row['phone'];
$usertype=$row['usertype'];
$gender=$row['gender'];

?>
            <tr>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $id;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $username;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $password;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $phone;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $usertype;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $gender;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><a href="Nedit.php?$id=<?php echo '$_POST[id]';?>">Edit</a></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><a href="Ndel.php?id=<?php echo $id;?>">Delete</a></strong></div></td>
            </tr>
            <?php
}
// Retrieve Number of records returned
$records = mysql_num_rows($result);
?>
            <tr>
              <td colspan="4" class="style3"><div align="left" class="style12"><?php echo "Total ".$records." Records"; ?> </div></td>
            </tr>
            <?php
// Close the connection

?>

        </table></td>
      </tr>
     
    </table>
    <p>&nbsp;</p>
  </div>
   <div style="clear:both;"></div>
</div>
</body>
</html>

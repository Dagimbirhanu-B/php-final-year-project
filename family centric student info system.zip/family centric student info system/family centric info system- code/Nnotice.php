<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO notice(title,start_date,end_date,position,content) VALUES('$_POST[title]','$_POST[start_date]','$_POST[end_date]','$_POST[position]','$_POST[content]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully notice!!");window.location=\'Nnotice.html\';</script>';
 echo "data is inserted";
    }
    else 
	header("location:Nnotice.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
<?php
session_start();
$username=$_POST['username'];
$password=md5($_POST['password']);
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from enc where username='".$username."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'Nlog.html\';</script>'.mysql_error();
}
else
{
header("location:Adem.html");
} 
mysql_close($con);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}

return true;
}
</script></head>

<body bgcolor="white">
<table align="center" background="pink" border="1" height="300" width="870" bgcolor="white">
<form action="techsick.php" method="POST" name="form1">
<tr><td>SId<input type="text" name="sid" id="sid"/>
 <br><input type="submit" name="select" value="view sick leave"/></td>

</form>
</tr>
<tr>
<td>student ID </td>
<td>ptseenby </td>
<td>ptseenat </td>
<td>sickleaveendingdate</td>
<td>remarks</td>
</tr>
<?php


$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
if(isset($_POST['select'])){
$sid=$_POST['sid'];
$sql="select * from shealthinfo where sid='$_POST[sid]'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$ptseenby=$row['ptseenby'];
$ptseenat=$row['ptseenat'];
$sickleaveendingdate=$row['sickleaveendingdate'];
$remarks=$row['remarks'];


?>

<tr>

<td><?php echo $sid;?></td>
<td><?php echo $ptseenby;?></td>
<td><?php echo $ptseenat;?></td>
<td><?php echo $sickleaveendingdate;?></td>
<td><?php echo $remarks; }?></td>
</tr>
<?php

}
?>

</table>

</body>
</html>

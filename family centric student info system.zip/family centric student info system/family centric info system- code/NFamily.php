<html>
<head>
   <title>best home</title>
   <link rel="stylesheet"href="fa.css">
    <link rel="stylesheet"href="e.css">
</head>
<body>
<div id="wrapper">

<div id="banner"><img src="harma.jpg"height="150"width="220"><img src="27.jpg" height="150" width="892"><img src="harma.jpg"height="150"width="220" align="right" ></div>
<div id="inbar">
<ul id="menu">
<li><a href="#" >View student information</a>
<ul>
<li><a href="viewhistory.php"target="iframe8">View Health Condition</a></li>
<li><a href="fagradeview.php"target="iframe8">View Accadamic Report</a></li>
<li><a href="affprev.php" target="iframe8" >View Discipline Report</a></li></ul></li>
<li><a href="http://www.google.com/" target="_parent">social media center</a></li>
<li><a href="NHome.html" target="_parent">Sign Out</a></li></ul></div>
<div id="columnLeft"> &nbsp;<font color="yellow" >FAMILY PAGE!!</font>
<br><br><br><br><br><br><br><br><br><br><br><br><br><marquee align="bottom" behavior="alternate" direction="up" >KIOTofIT@GMAIL.com</font></marquee></div>

<div id="columnRight"></div>

<div id="content"><iframe src="NFamily.html"name="iframe8"height="595"width="885"></iframe></div>

<div id="footer"><center><font color="white">Developed by:IT 4TH Year<br>Copy Right&copy;NA2B2007 All Rights Reserved</font></center></div>

</div>




</body>
</html>
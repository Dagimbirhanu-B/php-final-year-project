<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}
if(A=="")
{
alert("please not leave username empty!!");
form.username.focus();
form.username.value="";
return false;
}
if(B=="")
{
alert("please enter password!!");
form.password.focus();
form.password.value="";
return false;
}
return true
}
</script></head>

<body bgcolor="#FFDF55">
<table align="center" background="pink" border="1" height="300" width="500" bgcolor="#FFBFFF">
<form action="viewhistory.php" method="post" name="ap">
<tr><td>SId<input type="text" name="sid" /></td>
</tr>
<tr>
<td>view patient list<a href="viewrecord.php"><input type="button" name="select" value="view patient list"/></a></td>
<td>view patient history<a href="viewhistory.php"><input type="button" name="searchterm" value="view patient history"/><a></td>
<td>record new history <a href="horecord.html"><input type="button" name="" value="record new history"/></a></td>
</tr>
</form>
<tr>
<td>student ID </td>
<td>patient name </td>
<td>age  </td>
<td>gender </td>
<td>status </td>
</tr>
<?php

if(isset($_POST['select'])){
$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
$sql="select * from cardkeeper where status='unseen'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$ptname=$row['ptname'];
$age=$row['age'];
$gender=$row['gender'];
$status=$row['status'];


?>

<tr>

<td><?php echo $sid;?></td>

<td> <?php echo $ptname;?></td>

<td><?php echo $age;?></td>

<td><?php echo $gender;?></td>

<td><?php echo $status;?></td>
</tr>
<?php
}
?>
<?php

}
?>

</table>
</body>
</html>

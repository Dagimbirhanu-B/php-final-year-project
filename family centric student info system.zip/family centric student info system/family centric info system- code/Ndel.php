<html>
<body>
<?php
//if(isset($_POST['userid'])){
//$userid=$_POST['userid'];
$a=mysql_connect("localhost","root","");
if(!$a){die('not connet'.mysql_error());}
mysql_select_db("fcis",$a);
if(isset($_GET['id'])){
$id=$_GET['id'];
$query="DELETE FROM account WHERE id='$id'";
mysql_query($query,$a);
if(!$query)
{
echo ('not deleted'.mysql_error());
//header 'window:location\update1.php';
}
else
echo '<script type="text/javascript">alert("delete Successfully");window.location=\'Nupdate.php\';</script>';
//include("search.php");
}
?>
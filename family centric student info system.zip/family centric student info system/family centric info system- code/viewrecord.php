<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}
if(A=="")
{
alert("please not leave username empty!!");
form.username.focus();
form.username.value="";
return false;
}
if(B=="")
{
alert("please enter password!!");
form.password.focus();
form.password.value="";
return false;
}
return true
}
</script></head>

<body bgcolor="white">
<table align="center" background="pink" border="1" height="300" width="870" bgcolor="white">
<tr> <td colspan="6" align="center"><h1> view patient list</h1></td></tr>
<tr>
<td>student ID </td>
<td>patient name </td>
<td>age  </td>
<td>gender </td>
<td>status </td>
<td><h3>seen</h3> </td>
</tr>
<?php


$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
$sql="select * from cardkeeper where status='unseen'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$ptname=$row['ptname'];
$age=$row['age'];
$gender=$row['gender'];
$status=$row['status'];


?>

<tr>

<td><?php echo $sid;?></td>

<td> <?php echo $ptname;?></td>

<td><?php echo $age;?></td>

<td><?php echo $gender;?></td>

<td><?php echo $status;?></td>
<td><a href="seen.php?sid=<?php echo $sid;?>"><h2>seen</h2></a></td>
</tr>

<?php

}
?>
</table>
</body>
</html>

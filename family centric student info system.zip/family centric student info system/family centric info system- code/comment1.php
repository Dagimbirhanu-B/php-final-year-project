<?php
if(isset($_POST['submit'])){
$name=$_POST['name'];
$comment=$_POST['comment'];
$date = date('Y-m-d H:m:s');
mysql_connect('localhost','root','');
mysql_select_db('fcis');
$query=mysql_query("insert into comment values('$name','$comment','$date')");
		if($query)
		{
			$url="Location:feedback.php";
			header($url);
		}
		}
		else
	    {
			$url="Location:feedbacke.php";
			header($url);
	    }
?>
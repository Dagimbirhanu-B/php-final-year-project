<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>view student information</title>
</head>

<body>

<?php
session_start();
$con = mysql_connect("localhost","root","");
mysql_select_db("fcis", $con);
$sql = "select * from sinformation where sid='$_POST[sid]'";
$result = mysql_query($sql,$con);
while ($row = mysql_fetch_array($result))
{
$sid=$row['sid'];
$sfname=$row['sfname'];
$sex=$row['sex'];
$smfname=$row['smfname'];
$smmname=$row['smmname'];
$smlname=$row['smlname'];
$mphone=$row['mphone'];

if ($_POST['sid']=!$sid &&
$_POST['sfname']=!$sfname &&
$_POST['sex']=!$sex &&
$_POST['smfname']=!$smfname &&
$_POST['smmname']=!$smmname &&
$_POST['smlname']=!$smlname &&
$_POST['mphone']=!$mphone)

echo '<script type="text/javascript">alert("Wrong student id and student mfname! ");window.location=\'studentau.html\';</script>';
else
echo '<script type="text/javascript">alert("welcome Student");window.location=\'Nstudhome.html\';</script>';
$_SESSION['sid']=$row['sid'];

 
}
?>
<?php

	/*
*	$sid=$_POST['sid'];
	$vno=$_POST['vno'];
	
	
    if (!$result) {
        echo "data not record".mysql_error();
		echo '<script type="text/javascript">alert("data not record");window.location=\'Register.php\';</script>'; 
    }
    else 
	{
	echo "data is inserted";
		echo '<script type="text/javascript">alert("Succesfully Registration");window.location=\'verfiy.php\';</script>';

    }
*/
?>
</body>
</html>

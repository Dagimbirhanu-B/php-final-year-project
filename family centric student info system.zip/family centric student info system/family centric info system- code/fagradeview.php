<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}
if(A=="")
{
alert("please not leave username empty!!");
form.username.focus();
form.username.value="";
return false;
}
if(B=="")
{
alert("please enter password!!");
form.password.focus();
form.password.value="";
return false;
}
return true
}
</script></head>
 <?php

if(!isset($_SESSION))
{
session_start();
}
?>

<body bgcolor="#FFDF55">
<?php
echo $_SESSION['sid'];
?>
<table align="center"background="pink" border="1" height="300" width="500" bgcolor="#FFBFFF" >
<tr> <td colspan="6" align="center"><h1> View Student Grade</h1></td></tr>
<tr>
<td>student ID </td>
<td>Student Name</td>
<td>Department</td>
<td>Semister </td>
<td>Grade submitted On </td>
<td>Semister GPA </td>
<td>Comulative GPA </td>
<td>Status </td>
</tr>
<?php


$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
$sql="select * from sginfo where sid='$_SESSION[sid]'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$sname=$row['sname'];
$department=$row['departement'];
$semister=$row['semister'];
$date=$row['date'];
$sgpa=$row['sGPA'];
$cgpa=$row['cgpa'];
$status=$row['status'];
?>

<tr>

<td><?php echo $sid;?></td>

<td> <?php echo $sname;?></td>

<td><?php echo $department;?></td>

<td><?php echo $semister;?></td>

<td><?php echo $date;?></td>

<td><?php echo $sgpa;?></td>

<td><?php echo $cgpa;?></td>

<td><?php echo $status;?></td>
</tr>

<?php

}
?>
</table>
</body>
</html>

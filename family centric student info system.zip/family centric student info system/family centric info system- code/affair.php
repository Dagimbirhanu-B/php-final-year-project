
<?php
if(isset($_POST['submit'])){
$sid=$_POST['sid'];
$sfname=$_POST['sfname'];
$smname=$_POST['smname'];
$age=$_POST['age'];
$sex=$_POST['sex'];
$dept=$_POST['dept'];
$accyear=$_POST['accyear'];
$repon=date('y/m/d');
$acon=$_POST['acon'];
$discription=$_POST['discription'];
$desicion=$_POST['desicion'];
mysql_connect('localhost','root','');
mysql_select_db('fcis');
$query=mysql_query("INSERT INTO saffair (sid,sfname,smname,age,sex,dept,accyear,repon,acon,discription,desicion)values('$sid','$sfname','$smname','$age','$sex','$dept','$accyear','$repon','$acon','$discription','$desicion')");
		if(!$query)
		{
	die('data not insert'.mysql_error());
		
		}
		else
	    {
		echo '<script type="text/javascript">alert("patient successfully recorded!!");window.location=\'horecord.html\';</script>';
	    }
		}
?>
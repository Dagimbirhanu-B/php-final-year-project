<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
 mysql_select_db("fcis",$a);
 if(isset($_POST['submit'])){
$c="INSERT INTO account(id,username,password,phone,usertype,gender) VALUES('$_POST[id]','$_POST[username]','$_POST[password]','$_POST[phone]','$_POST[usertype]','$_POST[gender]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully account created!!");window.location=\'Nupdate.php\';</script>';
    }
    else 
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
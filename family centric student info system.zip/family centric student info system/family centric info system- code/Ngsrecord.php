<HTML>
<body bgcolor="#999933">
<br>
<h2><center>STUDENT RECORDS:</center></h2>
<br>
<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("fcis",$a);
$result = mysql_query("SELECT * FROM sinformatoin",$a);
echo '<center><table bgcolor="#cccccc">';
echo'<TR><TD bgcolor="pink"  width="60"><B>sid</B><TD bgcolor="pink"  width="60"><B>sfname</B><TD bgcolor="pink"  width="120"><B>smname</B><TD  bgcolor="pink" width="60"><B>slname</B><TD bgcolor="pink"  width="60"><B>mfname</B><TD bgcolor="pink"  width="60"><B>mmname</B><TD bgcolor="pink"  width="60"><B>mlname</B><TD bgcolor="pink"  width="60"><B>sdepartement</B><TD bgcolor="pink"  width="60"><B>accadamic_year</B><TD bgcolor="pink"  width="60"><B>age</B><TD bgcolor="pink"  width="60"><B>gender</B><TD bgcolor="pink"  width="60"><B>sCGPA</B></TR>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60">';
echo $row["sid"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["sfname"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["smname"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["slname"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["mfname"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["mmname"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["mlname"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["sdepartement"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["accadamic_year"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["age"];
echo '</td>';
echo '<td bgcolor="white" width="70">';
echo $row["gender"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["sCGPA"];
echo '</td>';
echo'</tr>';
}
echo '</TABLE>';
?>
</body>
</HTML>
<HTML>
<body bgcolor="white">
<br>
<h2><center>posted notice:</center></h2>
<br>
<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("fcis",$a);
$result = mysql_query("SELECT * FROM notice",$a);
echo '<center><table bgcolor="#cccccc">';
echo'<TR><TD bgcolor="pink"  width="60"><B>title</B><TD bgcolor="pink"  width="60"><B>start_date</B><TD bgcolor="pink"  width="60"><B>end_date</B><TD  bgcolor="pink" width="60"><B>position</B><TD bgcolor="pink"  width="100"><B>content</B></TR>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60">';
echo $row["title"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["start_date"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["end_date"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["position"];
echo '</td>';
echo '<td bgcolor="white" width="200">';
echo $row["content"];
echo '</td>';
echo'</tr>';
}
echo '</TABLE>';
?>
</body>
</HTML>
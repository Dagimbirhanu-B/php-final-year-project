<HTML>
<body bgcolor="#999933">
<br>
<h2><center>Admin report:</center></h2>
<br>
<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("fcis",$a);
$result = mysql_query("SELECT * FROM account",$a);
echo '<center><table bgcolor="#cccccc">';
echo'<TR><TD bgcolor="pink"  width="60"><B>id</B><TD bgcolor="pink"  width="60"><B>username</B><TD bgcolor="pink"  width="120"><B>password</B><TD  bgcolor="pink" width="60"><B>phone</B><TD bgcolor="pink"  width="60"><B>usertype</B><TD bgcolor="pink"  width="60"><B>gender</B></TR>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60">';
echo $row["id"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["username"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["password"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["phone"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["usertype"];
echo '</td>';
echo '<td bgcolor="white" width="70">';
echo $row["gender"];
echo '</td>';
echo'</tr>';
}
echo '</TABLE>';
?>
</body>
</HTML>
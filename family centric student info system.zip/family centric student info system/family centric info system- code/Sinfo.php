<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO sinformation(sid,smfname,smmname,smlname,sphone,departement,gender,sgradereport,status,accadamic_year,semister) VALUES('$_POST[sid]','$_POST[smfname]','$_POST[smmname]','$_POST[smlname]','$_POST[sphone]','$_POST[departement]','$_POST[gender]','$_POST[sgradereport]','$_POST[status]','$_POST[accadamic_year]','$_POST[semister]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully submited!!");window.location=\'Rsinfo.html\';</script>';
 echo "data is inserted";
    }
    else 
	header("location:Rsinfo.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}

return true;
}
</script></head>

<body bgcolor="lightblue">
<table align="center" background="black" border="1" height="150" width="870" bgcolor="white" >
<form action="verec.php" method="POST" name="form1">
<td><b>SId<input type="text" name="sid" id="sid"/>
 <br><input type="submit" name="select" value="view student record"/></td>

</form>
</tr>
<tr width="8">
<td><b>SID</b></td>
<td><b>Student Name </td>
<td><b>Sex</td>
<td><b>Faculity</td>
<td><b>Accadamic Year</td>
<td><b>Student phone no</td>
<td><b>Mother first Name </td>
<td><b>Mother Middle Name</td>
<td><b>Mother Last Name</td>
<td><b>Mother Phone No</td>
<td><b>Remark</td>
</tr>
<?php


$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
if(isset($_POST['select'])){
$sid=$_POST['sid'];
$sql="select * from famcomment where sid='$_POST[sid]'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$sname=$row['sname'];
$sex=$row['sex'];
$faculity=$row['faculity'];
$accyear=$row['accyear'];
$sphone=$row['sphone'];
$smfname=$row['smfname'];
$smmname=$row['smmname'];
$smlname=$row['smlname'];
$smphone=$row['smphone'];
$remarks=$row['remarks'];


?>

<tr>

<td><?php echo $sid;?></td>
<td><?php echo $sname;?></td>
<td><?php echo $sex;?></td>
<td><?php echo $faculity;?></td>
<td><?php echo $accyear;?></td>
<td><?php echo $sphone;?></td>
<td><?php echo $smfname;?></td>
<td><?php echo $smmname;?></td>
<td><?php echo $smlname;?></td>
<td><?php echo $smphone;?></td>
<td><?php echo $remarks;?></td>
<td><?php echo $status; }?></td>
</tr>
<?php

}
?>

</table>

</body>
</html>

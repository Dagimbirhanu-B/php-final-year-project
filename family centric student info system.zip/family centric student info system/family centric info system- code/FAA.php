<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DBU Dormitory managent system</title>
<link rel="icon" type="image/png" href="img/dbuicon.png"/>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="slideshow/imageslider.css" rel="stylesheet" type="text/css" />
<script src="slideshow/imageslider.js" type="text/javascript"></script>
<link href="aa.css" rel="stylesheet" type="text/css" media="screen" />
<script src="aa.js" type="text/javascript"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>
</head>
<body>
<table  border="0" align="center" width="750px">
<!--Header-->
<tr>
<td width="500px"></td>
<td id="loginlink" align="center"><a href="Nlog.html" id="log">Login</a></td>
</tr>
<tr>
<td width="700px" colspan="3" height="120px">
<p><img src="harma.jpg" align="center" width="200px" height="120px"></a>
<img style="border-radius:55px;box-shadow:1px 1px 12px black" src="h2.GIF" align="center" width="800px" height="120px">
<img src="harma.jpg" align="center" width="200px" height="120px"></a></p>
</td>
</tr>
<!--End Of Header-->
<!--Main menus-->
<tr>
<td colspan="3" width="1000px">
<div id="sse2">
        <div id="sses2"  >
         <ul>
<li><a href=""target="_parent">Home</a></li>&nbsp;&nbsp;&nbsp;&nbsp;
<li><a href="FAA.php" target="">View Student Report</a></li>
<li><a href="faco.html" target="iframe1">Authentication Help</a></li>
<li><a href="Nrecord.html" target="iframe1" >New Students</a></li>
<li><a href="studentau.html" target="_parent" >Senior Students</a></li>
<li><a href="Ngrnotice.php" target="iframe1">View notice</a></li>
<li><a href=""target="_parent">About</a></li>
<li><a href="" target="_parent">Contact us</a></li>
 </ul>
         </div>
    </div>

</td>
</tr>
<!--End of main menus-->
<!--Slide shows-->

<!--End of Slide shows-->
<table align="center" id="insides" width="850px">
<tr>
<!--Sub menus-->
<td width="25%" height="500px" valign="top" id="insides">
<table  >
<tr>
<th align="center" width="250px" height="25px" bgcolor="#336699"><font face="arial" color="white" size="2">WU-FCIS</font></th>
</tr>
<tr>
<td><br><br><center><img src="slideshow/images/DSC01751.JPG" width="150px" height="100px"></center></td>
</tr>
</table>
<br>
<br>
<br>
<table border="0">
<tr>
<th width="250px" bgcolor="#336699" height="25px"><font face="arial" color="white" size="2">Related Links</font></th>
</tr>
<tr>
<td><img src="img/Picture2.png" width="10px">&nbsp;<a href="http://www.wu.edu.et">WU Site</a></td>
</tr>
<tr>
<td><img src="img/Picture2.png" width="10px">&nbsp;<a href="site.php">Site Map</a></td>
</tr>
<tr>
<td><img src="img/Picture2.png" width="10px">&nbsp;<a href="https://mail.google.com/a/dbu/edu.et">Web Mail</a></td>
</tr>
</table>


<td valign="top"height="500"width="880">
<div style="width:550px; height:350px; margin:0 auto; position:relative; border:2px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:25px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">
<br>
<br>
<div style="background-color:#336699;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;"> 
 
        
       <?php

if(!isset($_SESSION))
{
session_start();
}
?>
      <tr>
      
        <td bgcolor="#BCE0A8"><div align="center" class="style9">FAMILY AUTONTICATION FORM</div></td>
        
      </tr>
    </table>
    <p>&nbsp;</p>
	
    <h2><span style="color:#003300"></span></h2>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
       
      </tr>
      
        <td height="26"><form id="FA" name="FA" method="post" action="FA.php">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
			
           	<tr>
                  <td height="36"><span class="style8">ID No:</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield1">
                    <input name="sid" type="text" id="sid"> 
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>
			<tr>
                  <td height="36"><span class="style8">First Name</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield2">
                    <input name="sfname" type="text" id="sfname"> 
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>
            <tr>
                  <td height="36"><span class="style8">Gender</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield2">
                    <input name="sex" type="text" id="sex"> 
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>
<tr>
                  <td height="36"><span class="style8">Mother First Name</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield2">
                    <input name="smfname" type="text" id="smfname" >
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>
<tr>
                  <td height="36"><span class="style8">Mother Middle Name</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield2">
                    <input name="smmname" type="text" id="smmname"> 
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>
<tr>
                  <td height="36"><span class="style8">Mother Last Name</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield2">
                    <input name="smlname" type="text" id="smlname"> 
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>
<tr>
                  <td height="36"><span class="style8">Mothers' Phone No</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield2">
                    <input name="mphone" type="text" id="mphone"> 
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td>
                </tr>

              <tr>
                <td>&nbsp;</td>
                <td><label><b></b>
                  <input type="submit" name="search" id="button" value="Login" />
                </label></td>
              </tr>
			  <tr>
                  
                </tr>
		<tr>
                <td>&nbsp;</td>
                <td><label><b>  </b>
                 
                </label></td>
              </tr>	  
</table>
        </form></td>
      </tr>
	  
      
	
           
           
		              </ul>
         </div>
    </div>

</td>
</tr>
<!--End of main menus-->
<!--Slide shows-->

<!--End of Slide shows-->

</td>
<!--End Of Sub menus-->
<!--Body section-->
<td valign="top">
</td>
<td width="25%" height="500px" valign="top" id="insides">
<table  >
<tr>
<th align="center" width="250px" height="25px" bgcolor="#336699"><font face="arial" color="white" size="2">DBU-DMS</font></th>
</tr>
<tr>
<td><br><br><center><img src="slideshow/images/DSC01751.JPG" width="150px" height="100px"></center></td>
</tr>
</table>
<br>
<br>
<br>
<table border="0">
<tr>
<th width="250px" bgcolor="#336699" height="25px"><font face="arial" color="white" size="2">Related Links</font></th>
</tr>
<tr>
<td><img src="img/Picture2.png" width="10px">&nbsp;<a href="http://www.dbu.edu.et">DBU Site</a></td>
</tr>
<tr>
<td><img src="img/Picture2.png" width="10px">&nbsp;<a href="site.php">Site Map</a></td>
</tr>
<tr>
<td><img src="img/Picture2.png" width="10px">&nbsp;<a href="https://mail.google.com/a/dbu/edu.et">Web Mail</a></td>
</tr>
</table>
<br>
<br>
<br>


</td>


</tr>
</table>
<!--End Body of section-->
</table>
<!--Footer-->

<div id="sample">
      <footer>
	  <br>
	  <div align="right">
<a href="#top"><img src="img/arrow_up.png" width="40px" title="Scroll Back to Top"></a>
</div>
        <p align="center"><font face="Times New Roman" color="white" size="2">Developed by:IT 4TH Year<br>Copy Right&copy;NA2B2007 All Rights Reserved</font></p>
		<br><br>
		
      </footer>
</div>

<!--End of Footer-->
</body>
</html>

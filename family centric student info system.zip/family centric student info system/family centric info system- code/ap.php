<html>
<head>
<title></title>
<link rel="stylesheet" href="style.css">
</head>
<body bgcolor="bluegreen">
<a href="aprov.php"> Go back </a>
<h1>  Search Results Are</h1>
<?php
$searchtype=$_POST['searchtype'];
$searchterm=$_POST['searchterm'];
$searchterm=trim($searchterm);
if(empty($searchtype) || empty($searchterm))
{
	echo'Please enter search details.'.mysql_error();
	exit;
}
@ $db= mysql_pconnect('localhost','root','');
if(!$db)
{
	echo 'Error connecting database'.mysql_error();
	exit;
}
mysql_select_db('fcis');
$query="select * from shealthinfo where ".$searchtype." like '%".$searchterm."%'";

$result=mysql_query($query);
$num_results=mysql_num_rows($result);
if($num_results)
echo '<p> really property owner, they can leave!!: '.$num_results.'</p>';


echo '<center><table bgcolor="white" border=1>';
echo'<TR>
<TD bgcolor="pink"  width="60"><B>sid</B>
<TD bgcolor="pink"  width="60"><B>ptname</B>
<TD bgcolor="pink"  width="60"><B>age</B>
<TD bgcolor="pink"  width="60"><B>gender</B>
<TD  bgcolor="pink" width="60"><B>ptseenat</B>
<TD  bgcolor="pink" width="60"><B>ptseenby</B>
<TD bgcolor="pink"  width="60"><B>diagnosis</B>
<TD  bgcolor="pink" width="60"><B>prescription</B>
<TD  bgcolor="pink" width="60"><B>complication</B>
<TD  bgcolor="pink" width="60"><B>sickleavestartingdate</B>
<TD  bgcolor="pink" width="60"><B>sickleaveendingdate</B>
<TD  bgcolor="pink" width="60"><B>remark</B>';
while ($myrow = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60">';
echo $myrow["sid"];
echo '</td>';

echo '<td bgcolor="white" width="60">';
echo $myrow["ptname"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $myrow["age"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $myrow["gender"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $myrow["ptseenat"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $myrow["ptseenby"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $myrow["diagnosis"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $myrow["prescription"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $myrow["complication"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $myrow["sickleavestartingdate"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $myrow["sickleaveendingdate"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $myrow["remark"];
echo '</td>';
}
echo"</tr>";
echo "</TABLE>";
echo '<p>';

//mysql_close($con);

?>
</body>
</html>
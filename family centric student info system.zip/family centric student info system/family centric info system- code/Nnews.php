<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO news(id,news) VALUES('$_POST[id]','$_POST[news]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert("news successfully submitted!!");window.location=\'Nnews.html\';</script>';
 echo "data is inserted";
    }
    else 
	header("location:Nnews.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO report(report_type,total_no) VALUES('$_POST[report_type]','$_POST[total_no]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully reported!!");window.location=\'Nreport.html\';</script>';
 echo "data is inserted";
    }
    else 
	header("location:Nreport.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
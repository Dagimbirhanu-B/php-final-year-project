<?php
if(isset($_POST['submit'])){
$sid=$_POST['sid'];
$stname=$_POST['sname'];
$dept=$_POST['departement'];
$semr=$_POST['semister'];
$dat=date('y/m/d');
$sgpa=$_POST['sGPA'];
$scgpa=$_POST['cgpa'];
$stat=$_POST['status'];
mysql_connect('localhost','root','');
mysql_select_db('fcis');
$query=mysql_query("INSERT INTO sginfo (sid,sname,departement,semister,date,sGPA,cgpa,status) VALUES('$sid','$stname','$dept','$semr','$dat','$sgpa','$scgpa','$stat')");
if(!$query)
		{
	die('data not insert'.mysql_error());
		
		}
		else
	    {
		echo '<script type="text/javascript">alert("student grade information successfully recorded!!");window.location=\'rinsertion.html\';</script>';
	    }
		}
?>
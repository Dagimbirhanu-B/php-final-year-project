<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
 mysql_select_db("fcis",$a);
 $password=md5($_POST['password']);
 if(isset($_POST['submit'])){
$c="INSERT INTO enc(username,password) VALUES('$_POST[username]','$password')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully account created!!");window.location=\'e.html\';</script>';
    }
    else 
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
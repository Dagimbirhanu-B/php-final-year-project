<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>kiot certificate verification</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
<!--
.style9 {font-size: 95%; font-weight: bold; color: #003300; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style3 {font-weight: bold}
-->
</style>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style10 {color: #FFFFFF}
.style12 {font-weight: bold}
-->
</style>
</head>
<body>

<div id="wrapper">
  <div id="content">
    <p align="justify">&nbsp;</p>
    <p>&nbsp;</p>
	
    <h2><span style="color:#003300"></span></h2>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	  
      <tr>
        <td height="25" bgcolor="green"><span class="style10"><strong>view student accadamic record information</strong></span></td>
      </tr>
      <tr>
        <td><table width="100%" border="1" bordercolor="orange" >
		<tr>
	
            <tr>
              <th height="32" bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>sid</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>smfname</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">smmname</div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">smlname</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">sphone</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">department</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">gender</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">sgradereport</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">status</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">accadamic_year</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">semister</div></th>             
            </tr>
           
		   
		    <?php

$con = mysql_connect("localhost","root");

mysql_select_db("fcis", $con);
if (isset($_POST['search'])) {
$sid=$_POST['sid'];
$sql = "select * from sinformation where sid='$sid'";
$result = mysql_query($sql,$con);
while($row = mysql_fetch_array($result))
{
$sid=$row['sid'];
$smfname=$row['smfname'];
$smmname=$row['smmname'];
$smlname=$row['smlname'];
$sphone=$row['sphone'];
$department=$row['department'];
$gender=$row['gender'];
$sgradereport=$row['sgradereport'];
$status=$row['status'];
$accadamic_year=$row['accadamic_year'];
$semister=$row['semister'];
?>

          <tr>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $sid;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $smfname;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $smmname;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $smlname;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $sphone;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $department;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $gender;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $sgradereport;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $status;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $accadamic_year;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $semister;?></strong></div></td>             
            </tr>
            <?php
}

// Retrieve Number of records returned
$records = mysql_num_rows($result);


?>
           
            <?php
			
// Close the connection
//mysql_close($con);
}
?>

        </table></td>
      </tr>
     
    </table>
    <p align="justify">&nbsp;</p>
    <table width="100%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="26" bgcolor="#BCE0A8"><div align="center" class="style9">Welcome to</div></td>
        <td bgcolor="#BCE0A8"><div align="center" class="style9">student</div></td>
        <td bgcolor="#BCE0A8"><div align="center" class="style9">accadamic record informatio</div></td>
      </tr>
    </table>
</body>
</html>

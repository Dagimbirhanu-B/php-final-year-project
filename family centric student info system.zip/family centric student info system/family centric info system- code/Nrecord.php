<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
 //echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO sinformation(sid,sfname,smname,slname,sex,sphone,accyear,faculity,smfname,smmname,smlname,mphone) VALUES('$_POST[sid]','$_POST[sfname]','$_POST[smname]','$_POST[slname]','$_POST[sex]','$_POST[sphone]','$_POST[accyear]','$_POST[faculity]','$_POST[smfname]','$_POST[smmname]','$_POST[smlname]','$_POST[mphone]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully Registered!!");window.location=\'Nrecord.html\';</script>';
    }
    else 
	header("location:Nrecord.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
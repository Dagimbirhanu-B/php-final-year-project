<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
$sid=$_POST['sid'];
$usertype=$_POST['usertype'];
$date=date("y/m/d");
$description=$_POST['description'];
$d= mysql_select_db("fcis",$a) or die('not selected'.mysql_error());
// echo"db selected";
 if(isset($_POST['submit'])){
$c="INSERT INTO sginfo(sid,usertype,date,description)VALUES('$sid','$usertype','$date','$description')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully submited!!");window.location=\'NshealthR.html\';</script>';
 echo "data is inserted";
    }
    else 
	header("location:NshealthR.html");
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Online Family control information system</title>
<link href="../../../Users/arif/Desktop/style.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
<!--
.style9 {font-size: 95%; font-weight: bold; color: #003300; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style3 {font-weight: bold}
-->
</style>
<script src="../../../Users/arif/SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="../../../Users/arif/SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style10 {color: #FFFFFF}
.style12 {font-weight: bold}
-->
</style>
</head>
<body>

<div id="wrapper">
 
  <?php

if(!isset($_SESSION))
{
session_start();
}
?>
  <div id="content">
   </table></td>
      </tr>
     
    </table>
    <p align="justify">&nbsp;</p>
    <table width="100%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
        
      
      <tr>
      
        <td bgcolor="#BCE0A8"><div align="center" class="style9">click on search button and Vew student information</div></td>
        
      </tr>
    </table>
    <p>&nbsp;</p>
	
    <h2><span style="color:#003300"></span></h2>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
       
      </tr>
      <tr>
        <td height="26"><form  method="post" action="Acadamic.php">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
			 </tr>
           	<tr>
                  <td height="36"><span class="style8">student ID:</span></td>
                  <td><span id="sprytextfield7">
                    <label><span id="sprytextfield1">
                    <input name="sid" type="text" id="sid"  class="validate[required] text-input" readonly value=<?php echo $_SESSION['sid'];?> >
                    </span></label>
                    <span class="textfieldRequiredMsg"></span></span></td><td><select name="usertype"><option>view health condition</option><option>view discipline report</option><option>view student accadamic record</option><option>Sign Out</option></select></td>
                </tr>
            
              <tr>
                <td>&nbsp;</td>
                <td><label><b>verify student</b>
                  <input type="submit" name="search" id="button" value="verify student" />
                </label></td>
              </tr>
			  <tr>
                  
                </tr>
		<tr>
                <td>&nbsp;</td>
                <td><label><b>  </b>
                 
                </label></td>
              </tr>	  
</table>
        </form>
            <?php


// Retrieve Number of records returned
//$records = mysql_num_rows($result);


?>
            
            <?php
			
// Close the connection
//mysql_close($con);

?>

        </table></td>
      </tr>
     
    </table>
    <p align="justify">&nbsp;</p>
    <table width="100%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="26" bgcolor="#BCE0A8"><div align="center" class="style9">Wellcome to</div></td>
        <td bgcolor="#BCE0A8"><div align="center" class="style9">Student</div></td>
        <td bgcolor="#BCE0A8"><div align="center" class="style9">Information</div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
  </div>
 
</div>
<script type="text/javascript">
<!--

//-->
</script>
</body>
</html>

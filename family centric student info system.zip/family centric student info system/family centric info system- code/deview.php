<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
function validate(form)
{
var c=form.id.value;
var A=form.username.value;
var B=form.password.value;
if(c=="")
{
alert("please not leave id empty!!");
form.id.focus();
form.id.value="";
return false;
}
if(A=="")
{
alert("please not leave username empty!!");
form.username.focus();
form.username.value="";
return false;
}
if(B=="")
{
alert("please enter password!!");
form.password.focus();
form.password.value="";
return false;
}
return true
}
</script></head>

<body bgcolor="white">
<table align="center" background="pink" border="1" height="300" width="870" bgcolor="white">
<tr> <td colspan="6" align="center"><h1>New Discipline Record</h1></td></tr>
<tr>
<td>student ID </td>
<td>student Name </td>
<td>student Father Name </td>
<td>age  </td>
<td>Gender </td>
<td>Department </td>
<td>Accadamic Year  </td>
<td>Recorded On </td>
<td>Action Committed On </td>
<td>Description</td>
<td>Decision</td>
<td>record type</td>
</tr>
<?php



$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
//if(isset($_POST['select'])){
//$sid=$_POST['sid'];
$sql="select * from saffair where status='new'";
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
$sid=$row['sid'];
$sfname=$row['sfname'];
$smname=$row['smname'];
$age=$row['age'];
$sex=$row['sex'];
$dept=$row['dept'];
$accyear=$row['accyear'];
$repon=$row['repon'];
$acon=$row['acon'];
$discription=$row['discription'];
$desicion=$row['desicion'];
$status=$row['status'];
?>

<tr>

<td><?php echo $sid;?></td>
<td><?php echo $sfname;?></td>
<td><?php echo $smname;?></td>
<td><?php echo $age;?></td>
<td><?php echo $sex;?></td>
<td> <?php echo $dept;?></td>
<td><?php echo $accyear;?></td>
<td><?php echo $repon;?></td>
<td><?php echo $acon;?></td>
<td><?php echo $discription; ?></td>
<td><?php echo $desicion; }?></td>
<td><a href="new.php?sid=<?php echo $sid;?>"><h2></h2>Unseen</a></td>
</tr>
<?php

//}
?>

</table>

</body>
</html>

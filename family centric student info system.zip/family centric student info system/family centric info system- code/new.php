<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$sid=$_GET['sid'];
$con=mysql_connect('localhost','root','');
mysql_select_db('fcis',$con);
$query=mysql_query ("update saffair set status='seen' where  sid='$sid'");
if(!$query)
		{
	die('data not insert'.mysql_error());
		
		}
		else
	    {
		echo '<script type="text/javascript">alert("Record seen!!");window.location=\'deview.php\';</script>';
	    }
		
?>
</body>
</html>

function lgn(){
  var elem1 = document.querySelector(".l1");
  var elem2 = document.querySelector(".l2");
  var elem3 = document.querySelector(".l3");
  var e1 = document.querySelector(".s1");
  var e2 = document.querySelector(".s2");
  var e3 = document.querySelector(".s3");
  e1.style.background = "#2196f3";
  e2.style.background = "#1d1c19";
  e3.style.background = "#1d1c19";
  elem1.style.display = "block";
  elem2.style.display = "none";
  elem3.style.display = "none";
}
function reg(){
  var elem1 = document.querySelector(".l1");
  var elem2 = document.querySelector(".l2");
  var elem3 = document.querySelector(".l3");
  var e1 = document.querySelector(".s1");
  var e2 = document.querySelector(".s2");
  var e3 = document.querySelector(".s3");
  e1.style.background = "#1d1c19";
  e2.style.background = "#2196f3";
  e3.style.background = "#1d1c19";
  elem1.style.display = "none";
  elem2.style.display = "block";
  elem3.style.display = "none";
}
function fp(){
  var elem1 = document.querySelector(".l1");
  var elem2 = document.querySelector(".l2");
  var elem3 = document.querySelector(".l3");
  var e1 = document.querySelector(".s1");
  var e2 = document.querySelector(".s2");
  var e3 = document.querySelector(".s3");
  e1.style.background = "#1d1c19";
  e2.style.background = "#1d1c19";
  e3.style.background = "#2196f3";
  elem1.style.display = "none";
  elem2.style.display = "none";
  elem3.style.display = "block";
}
function reset(){
  alert("Contact to Admin");
}

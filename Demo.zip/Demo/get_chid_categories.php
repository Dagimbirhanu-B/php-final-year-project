<?php

include_once("db_config/dbcon.php");

if($_REQUEST)
{
	$id 	= $_REQUEST['parent_id'];
    
	$case_query  = mysqli_query($conn,"select * from departments where Fname ='$id'");
    while($row = mysqli_fetch_array($case_query))
	{
		echo "<option> ".$row['Dname']."</option>";
	
	}
	
}
?>
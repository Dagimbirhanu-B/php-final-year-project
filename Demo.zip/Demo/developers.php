<?php
	include_once("header.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutclearance.php" title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php" title="Calander View"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="viewpost.php"title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
<li><a href=""><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Login</a>
<ul>
<li><a href="login.php?action=login"  title="Login Offices"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Officess Login</a></li>
<li><a href="loginstudent.php" title="Login Student"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Students Login</a></li>
</ul>
</li>
<li class="current-menu-item"><a href="registerstudent.php?action=registerstudent"title="Create Account"><i class="glyphicon glyphicon-save" ></i>&nbsp;Create Account</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div class="menu">
<ul>
<li><a href="index.php" title="Home"><i class="glyphicon glyphicon-home"></i>&nbsp;Home</a></li>
<li><a href="aboutus.php" title="About Us"><i class="glyphicon glyphicon-user"></i>&nbsp;About Us</a></li>
<li><a href="crule.php"title="Clearance Rule and Regulation"><i class="glyphicon glyphicon-file"></i>&nbsp;Cl Rule &amp; Regulation</a></li>
<li><a href="notice.php"title="Notice to Student"><i class="glyphicon glyphicon-time"></i>&nbsp;Notice to Student</a></li>
<li><a href="contactus.php"title="Contact Us"><i class="glyphicon glyphicon-share"></i>&nbsp;Contact Us</a></li>
<li><a href="feedback.php"title="Feed Back"><i class="glyphicon glyphicon-plane"></i>&nbsp;Feed Back</a></li>
<li><a href="help.php?action=help"title="Help Menu"><i class="glyphicon glyphicon-book"></i>&nbsp;Help</a></li>
</ul>
</div>
<div id="panel">
<div id="panel">			
</div>
</br>
</br>
</br>
</div>
<div class="size2">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>			
<div class="container12">
<div class="panel">
<div class="hero-unit-bud11">
<ul class="nav nav-tabs"> 
  <li class="active"><a href="#developers" data-toggle="tab"><font color="white">
    <i class="icon-pc-sign icon-large"></i></font><font color="orange">Developers</font></a></li>
</ul>
<div class="hero-unit-y">
 <h2><u><center>Debre Tabor University Student's Online Clearance System  Developers</u></center></h2>
<table width="1053" border="0">

  <tr>
    <td width="361"><center><font face="time new romanse" color="orange" size="5" align="center"> Project members</font><br/>
      <br/>
     <img src="groupimage/abatneh.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">abatneh</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:abat2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593819</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td>
      <br/>
     <img src="groupimage/nati.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Natnael</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:nati2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593820</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td>
      <br/>
     <img src="groupimage/kal.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Kalkidan</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:kal2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593821</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td>
      <br/>
     <img src="groupimage/tsega.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Tsegereda</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:tsega2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593822</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td>
     <img src="groupimage/Zemenay.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Zemenay</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:zemu2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593823</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
</table>
</div>

</div>
</div>
</div>
<?php
	include_once("footer.php");
?> 
</body>
</html>
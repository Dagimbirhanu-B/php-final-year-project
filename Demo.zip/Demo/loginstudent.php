<?php
	//Start session
	session_start();
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Debre Tabor University Online Student's Clearance System</title>
<meta http-equiv='refresh' content='30'>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link rel="shortcut icon"href="images/dtu1.gif" />
<link type="text/css" rel="stylesheet" href="css/global.css">
<link rel="stylesheet"   href="css3/icon.css"  media="screen"/>
<link rel="stylesheet"   href="css3/styles.css"  media="screen"/>
<link rel="stylesheet"   href="css3/bootstrap.min.css"  media="screen"/>
<link rel="stylesheet"   href="css3/bootstrap-datetimepicker.min.css"  media="screen"/>
<link rel="stylesheet"   href="css3/font-awesome.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css3/google-code-prettify/prettify.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css/js-image-slider.css" type="text/css" media="screen"/>
<link rel="stylesheet"   href="css/formstyles.css" type="text/css" media="screen"/>
<link rel="stylesheet"   href="css2/topheadernavigation.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css2/logchild.css" media="screen"type="text/css"/>
<link href="js/qtip/jquery.qtip.min.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="js/qtip/jquery.qtip.min.js"></script>
    <script src="js/js-image-slider.js" language="javascript" type="text/javascript"></script>
	<script src="js2/imageslideshow.js" language="javascript" type="text/javascript"></script>
    <script src="js2/jquery.hoverdir.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap.min.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap.js" language="javascript" type="text/javascript"></script>
    <script src="js2/google-code-prettify/prettify.js" language="javascript" type="text/javascript"></script>
    <script src="js2/holder/holder.js" language="javascript" type="text/javascript"></script>
    <script src="js2/slideShow.dataTables.js" language="javascript" type="text/javascript"></script>
    <script src="js2/jquery.dataTables.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap-popover.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap-collapse.js" language="javascript" type="text/javascript"></script>
    <script src="js2/va.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap-datetimepicker.min.js" language="javascript" type="text/javascript"></script>
	<script src="js2/14207351623330" charset="UTF-8" type="text/javascript"></script>
</head>
<body></br>
<div class="logo">
<img src="images/dtu1.gif" alt="Debre Tabor University Logo" width="100" height="110"style="margin-top:19px; margin-left:3px;">
<img src="images/capture7.jpg" alt="Debre Tabor University Logo" width="1147" height="115"style="margin-top:18px; margin-left:-5px;">
<img src="images/ribbon.png" alt="Debre Tabor University Logo" width="100" height="115"style="margin-top:18px; margin-left:-10px;">
</div>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutclearance.php" title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php" title="Calander View"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="viewpost.php"title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
<li><a href=""><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Login</a>
<ul>
<li><a href="login.php?action=login"  title="Login Offices"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Officess Login</a></li>
<li><a href="loginstudent.php" title="Login Student" class="active"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Students Login</a></li>
</ul>
</li>
<li class="current-menu-item"><a href="registerstudent.php?action=registerstudent"title="Create Account"><i class="glyphicon glyphicon-save" ></i>&nbsp;Create Account</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div class="menu">
<ul>
<li><a href="index.php" title="Home"><i class="glyphicon glyphicon-home"></i>&nbsp;Home</a></li>
<li><a href="aboutus.php" title="About Us"><i class="glyphicon glyphicon-user"></i>&nbsp;About Us</a></li>
<li><a href="crule.php"title="Clearance Rule and Regulation"><i class="glyphicon glyphicon-file"></i>&nbsp;Cl Rule &amp; Regulation</a></li>
<li><a href="notice.php"title="Notice to Student"><i class="glyphicon glyphicon-time"></i>&nbsp;Notice to Student</a></li>
<li><a href="contactus.php"title="Contact Us"><i class="glyphicon glyphicon-share"></i>&nbsp;Contact Us</a></li>
<li><a href="feedback.php"title="Feed Back"><i class="glyphicon glyphicon-plane"></i>&nbsp;Feed Back</a></li>
<li><a href="help.php?action=help"title="Help Menu"><i class="glyphicon glyphicon-book"></i>&nbsp;Help</a></li>
</ul>
</div>
<div id="panel">
<div id="panel">			
</div>
</br>
</br>
</br>
</div>
<div class="size2">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div class="container">			
<div class="panel2">
<div class="navigation">
<font color="white"><b>YOU ARE HERE:</b></font>
<a class="active buttonnav" href="index.php"><b>Home</b></a><font color="white">>>
<a class="active buttonnav" href=""><b>Login</b></a> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>
<div class="container">
<div class="panel">
<hr class="hidden">
	    <div id="banner_">
            <div id="sliderFrame">
			<div id="ribbon">
			</div>
				<div id="slider">
					<img src="image/2.jpg"/>
					<img src="images/11.jpg"  />
					<img src="images/12.jpg"/>
					<img src="image/staff.jpg" />
					<img src="images/buld1.jpg" />
				</div>
            </div>
        </div>
</br>
<div class="col-md-2">
<img src="image/cpassword.jpg" width="210" height="300" />
</div>
<?php
if(isset($_POST["login"]))
{
   $password1=$_POST['password'];
	$sqllogin = mysqli_query($conn,"SELECT * FROM student WHERE  Idno='$password1'");
	if(mysqli_num_rows($sqllogin)>0)
	{
		$dt = date("Y-m-d h:i:s");
		$update=  mysqli_query($conn,"UPDATE  student SET lastlogin='$dt' WHERE  Idno='$password1'");
    }
}
?>
<div 
style="margin-left:20.2%;
margin-right:10px;
width:63%;
height:268px;
border:1px solid;
padding:0px;
border-top-left-radius: 7px;
border-top-right-radius: 7px;
border-bottom-left-radius:5px;
border-bottom-right-radius:5px;">
<form  class="contact_form"  action="logincodestudent.php" method="POST" onSubmit = "return validate()">
     <center>
	 <div class="navigation">
	 <div class="left"><strong><center><font color="white"><h2>Welcome To Debre Tabor University Student's Online Clearance System Login Page</h2></font></center></strong>
	 <br />
	 </div>
	 </div>
	 <table id="table3" class="tborder" height="250" background='image/login.jpg'>
	 <tbody><tr  class="trow2">
     <td class="thead" colspan="2">
	 
	 </td>
	 </tr>
	 <tr><td></td><td></td></tr>
	 <tr><td></td><td></td></tr>
	 <tr>
	 <td><b><font color="purble">Username:</font></b>
	 <font color='red'>:</font></td>
	 <td>
	 <label>
     <input type="text" name="username"  placeholder="ENTER USER NAME" required ""/><span id="username" class="form_hint" >Insert User Name</span></label></td>
	 </tr>
	<tr><td></td><td></td></tr>
	<tr><td></td><td></td></tr>
	 <tr>
	 <td><b><font color="purble">Password:</font></b>
	 <font color='red'>:</font></td>
	 <td>
	 <label>
     <input type="password" name="password"  placeholder="*******" required =""/><span id="password" class="form_hint" >Insert Password</span></label></td>
	 </tr>
	 <tr><td></td><td id="submit"><a href="forgotpasswordstudent/Forgot_Password.php" id="submit"><div class="submit">Lost your password</div></a></td>
	 </tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	<tr class="trow2"><td></td><td></td></tr>
	        <tr   class="trow2">
			<td></td>
			<td>
			<button class="submit" name="login" type="submit"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;LogIn</button>&nbsp;&nbsp;&nbsp;
			<button class="submit" type="reset"><i class="glyphicon glyphicon-remove" ></i>&nbsp;Reset</button></td></tr>
	</tbody></table>
</center>
</form> 
</div>    	
</div>
</div>
</div>
</div>
<?php
	include_once("footer.php");
?> 
</body>
</html>
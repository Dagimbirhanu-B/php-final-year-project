<?php 
include('header.php');
include('../db_config/dbcon.php'); 
?>
	<style>	
		#next
		{
			font-size:18px;
			height:35;
			width:80;
			padding:2;
			background-color:#69A74E; color:#FFFFFF;
			border-top:#29447E;
			border-right-color:#29447E;
			border-bottom-color:#1A356E;
			border-left-color:#29447E;
			font-size:15px;
			font-weight:bold;
			box-shadow:5px 0px 10px 1px rgb(0,0,0);
		}
	</style>
	<script type="text/javascript">
function formValidator(){
	// Make quick references to our fields
	var b = document.getElementById('fname');
	
	if(isAlphabet(b, "Please enter only letters for username")){
	if(lengthRestriction(b, 3, 15 ,"for for username")){
	       return true;
		   }
		   }
	return false;
}
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z ]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function lengthRestriction(elem, min, max, helperMsg ){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		return true;
	}else{
		alert("Please enter between " +min+ " and " +max+ " characters"   +helperMsg);
		elem.focus();
		return false;
	}
}
</script>
<div class="navbar navbar-fixed-top">
<div class="hero-unit-bud">	
<div class="navbar-inner">
		<a class="branded">
		<img src="../image/ambo1.jpg" width="100" height="90">
 	</a> 
	<a class="brand">
	 <h2></h2>
	 <div class="chmsc_nav"><font size="4" color="white">Ambo University</font></div>
 	</a>
<div class="time">	
<font color="orange">
  <?php
 $Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font>
<br>
	<a href="../loginstudent.php" class="btn btn-warning"><i></i>&nbsp;Back to Home</a>
	
</div>
</div>
</div>
</div>
<div class="container">
<div style="position:absolute;left:35%;top:25%; height:10%; width:7%; z-index:-1; background:#339900; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute;left:45%;top:25%; height:10%; width:7%; z-index:-1; background:#999999; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute;left:55%;top:25%; height:10%; width:7%; z-index:-1; background:#999999; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>

<div style="position:absolute; left:36%; top:25%;"> <h2> Step 1 </h2> </div>
<div style="position:absolute; left:46%; top:25%;"> <h2> Step 2 </h2> </div>
<div style="position:absolute; left:56%; top:25%;"> <h2> Step 3 </h2> </div>

<div style="position:absolute;left:26%; top:30.8%; height:1; width:46.85%; background-color:#000000; z-index:-2 "> </div>
<div style="position:absolute;left:26%; top:30.8%; height:44.3%; width:0.08%; background-color:#000000; "> </div>
<div style="position:absolute;left:26%; top:75%; height:1; width:46.85%; background-color:#000000; "> </div>
<div style="position:absolute;left:72.75%; top:30.8%; height:44.3%; width:0.10%; background-color:#000000; "> </div>
<div class="form-group">
<form action="Forgot_Password2.php"  method="post" onsubmit='return formValidator()'>
	<div style="position:absolute; left:32%; top:45.6%;"> <h4> Enter Your User Name: </h4> </div>
	<div style="position:absolute; left:46%; top:44.5%;"> <h4> <input type="text" name="user_name" id="fname" class="form-control" style="height:35; width:300; font-size:18px;"> </h4> </div>
	<div style="position:absolute; left:45%; top:60%;">  <input type="submit" name="Next" value="Next" id="next"> </div>
</form>
</div>
</div>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<?php 
include('footer.php');
?>
</body>
</html>
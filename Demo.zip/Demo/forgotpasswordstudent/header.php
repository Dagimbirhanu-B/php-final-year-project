<html>
<head><title>Ambo university student's online clearance system</title>
<link rel="shortcut icon"href="../image/ambo1.jpg" />
<link type="text/css" rel="stylesheet" href="css/global.css">
<link rel="stylesheet"   href="../css3/styles.css"  media="screen"/>
<link rel="stylesheet"   href="../css3/bootstrap.min.css"  media="screen"/>
<link rel="stylesheet"   href="../css3/bootstrap-datetimepicker.min.css"  media="screen"/>
<link rel="stylesheet"   href="../css3/formstyles.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css3/font-awesome.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css3/google-code-prettify/prettify.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css2/topheadernavigation.css" media="screen"type="text/css"/>


<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrap-transition.js"></script>
<script type="text/javascript" src="js/bootstrap-typeahead.js"></script>
<script type="text/javascript" src="js/application.js"></script>

<script type="text/javascript" src="js/bootstrap-tooltip.js"></script>
<script type="text/javascript" src="js/bootstrap-popover.js"></script>

</head>


-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2015 at 09:36 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
---Database: `clearance`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--
CREATE TABLE IF NOT EXISTS `account` (
  `Fname` varchar(30) NOT NULL,
  `Mname` varchar(30) NOT NULL,
  `Lname` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `Sex` enum('Male','Female') NOT NULL,
  `Role` varchar(15) NOT NULL,
  `status` int(1) NOT NULL,
  `SQ1` varchar(30) NOT NULL,
  `SQ2` varchar(30) NOT NULL,
  `SQ3` varchar(30) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--
INSERT INTO `account` (`Fname`, `Mname`, `Lname`, `Username`, `Email`, `Password`, `Sex`, `Role`, `status`) VALUES
('abel', 'yab', 'Tegegne', 'gech', 'getachewtemi17@gmail.com', 'gt123GT', 'Male', 'studentservice', 0),
('Gelana', 'Abdissa', 'gehry', 'gela', 'gelana@gmail.com', 'ga123', 'Male', 'library', 0),
('Genet', 'Seyfe', 'Alemu', 'geni', 'geni23@gmail.com', 'gs123', 'Female', 'bookstore', 0),
('Getnet', 'Melese', 'Embiale', 'get', 'getnetmelese@gmail.com', 'gm123', 'Male', 'proctor', 0),
('Gete', 'Berhanu', 'Ayele', 'gete', 'gete@gmail.com', 'gb123', 'Female', 'proctor', 0),
('Kebede', 'Maru', 'Fikadu', 'kebe', 'kebe23@gmail.com', 'km123', 'Male', 'registrar', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE IF NOT EXISTS `cases` (
  `case_id` int(11) NOT NULL AUTO_INCREMENT,
  `Idno` varchar(15) NOT NULL,
  `description` text NOT NULL,
  `staff` varchar(50) NOT NULL,
  `by_user` varchar(50) NOT NULL,
  `status` enum('MODIFY','NOT_MODIFY') NOT NULL,
  `date_added` varchar(100) NOT NULL,
  PRIMARY KEY (`case_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=129 ;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`case_id`, `Idno`, `description`, `staff`, `by_user`, `status`, `date_added`) VALUES
1,'R/01/10 ', 'you borow  java book', 'library', 'gela', 'MODIFY', 'Monday, 01/Jun/2015, 09:40:42pm'),
(2, 'R/02/10 ', 'hhhhhhhhh', 'library', 'gela', 'MODIFY', 'Tuesday, 02/Jun/2015, 11:18:37am');

-- --------------------------------------------------------

--
-- Table structure for table `clearance`
--

CREATE TABLE IF NOT EXISTS `clearance` (
  `stud_id` varchar(15) NOT NULL,
  `faculty` tinyint(1) NOT NULL DEFAULT '0',
  `department` tinyint(1) NOT NULL DEFAULT '0',
  `library` tinyint(1) NOT NULL DEFAULT '0',
  `bookstore` tinyint(1) NOT NULL DEFAULT '0',
  `cafeteria` tinyint(1) NOT NULL DEFAULT '0',
  `dormitory` tinyint(1) NOT NULL DEFAULT '0',
  `sport` tinyint(1) NOT NULL DEFAULT '0',
  `Clearance` tinyint(1) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clearance`
--

INSERT INTO `clearance` (`stud_id`, `faculty`, `department`, `library`, `bookstore`, `cafeteria`, `dormitory`, `sport`, `Clearance`) VALUES
('R/3319/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3350/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3371/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3374/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3375/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3376/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3377/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3379/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3389/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3410/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3422/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/37nnnn75/04', 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `msg_id_fk` int(11) NOT NULL,
  `intime` datetime NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`com_id`, `comment`, `msg_id_fk`, `intime`) VALUES
(3, 'GETNET MELESE IT IS GOOD BUT LESS MORE QUALIT', 3, '2014-09-15 03:00:00'),
(4, 'GETACHEW TEMI HI it is not sefiecient', 4, '2015-04-15 01:00:00'),


-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `DID` int(5) NOT NULL AUTO_INCREMENT,
  `FName` varchar(25) NOT NULL,
  `DName` varchar(25) NOT NULL,
  `PYear` int(2) NOT NULL,
  PRIMARY KEY (`DID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DID`, `FName`, `DName`, `PYear`) VALUES
(1, 'Institute of Technology', 'Computer Science', 4),
(2, 'Institute of Technology', 'IT', 4),
(3, 'Institute of Technology', 'Electrical Engineering', 5),
(7, 'FB', 'FP', 4),
(8, 'Institute of Technology', 'Cs', 4),
(10, 'Sport Science', 'HPE', 3);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `FID` int(5) NOT NULL AUTO_INCREMENT,
  `FName` varchar(25) NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`FID`, `FName`) VALUES
(1, 'FB'),
(2, 'Institute of Technology'),
(3, 'Faculity of Business'),
(25, 'HE'),
(26, 'LAW'),
(24, 'Ho'),
(15, 'Cooperative'),
(27, 'Sport Science');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `FID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Offices` varchar(50) NOT NULL,
  `Comment` varchar(5000) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FID`, `Name`, `Email`, `Offices`, `Comment`, `date`) VALUES
(16, 'GETACHEW', 'getachewtemi17@gmail.com', 'studentservice', 'why u are be silent igbnbbv vhgbbvghvbnnhnhbnhnbbghv hvhbnhjnhj vb fbfgg vfgbhgvffbhj hjfbjbhj', '2015-04-06 14:18:43'),
(17, 'GETNET', 'getachewtemi17@gmail.com', 'library', 'Debre Tabor University provides Dormitory services to its regular and summer students in its Dormitory Building.                                  ', '2015-04-06 14:19:06'),
(18, 'Geteberhanu', 'gte@gmail.com', 'sportscience', 'hjghgj', '2015-04-06 14:19:38'),
(15, 'fsdfdsf', 'gte@gmail.com', 'bookstore', 'ghhg', '2015-04-06 14:17:16'),
(19, 'Gelana', 'gte@gmail.com', 'proctor', 'what', '2015-04-06 14:20:08'),
(20, 'Kebede', 'kebedemaru@gmail.com', 'registrar', 'yes', '2015-04-06 14:20:47'),
(26, 'Gelana Abdias', 'gelana@gmail.com', 'proctor', 'i want paper.\r\n', '2015-06-01 09:51:43'),
(22, 'HFR', 'geza3381@gmail.com', 'library', 'HJGFHGHG', '2015-04-07 08:05:32'),
(23, 'GETACHEW', 'geza3381@gmail.com', 'registrar', 'TO U', '2015-04-07 08:08:05'),
(27, 'Gelana Abdias', 'gelana@gmail.com', 'bookstore', 'rygfrygfrhfhry', '2015-06-01 10:54:21');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastlogin` datetime NOT NULL,
  `user` varchar(50) NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `lastlogin`, `user`) VALUES
(1, '2014-05-14 15:14:51', 'geni');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `imgid` int(20) NOT NULL AUTO_INCREMENT,
  `Idno` varchar(30) NOT NULL,
  `imagepath` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`imgid`, `Idno`, `imagepath`, `date`) VALUES
(62, 'R/3350/04', '23027eyerusalem.jpg', '2015-06-01 09:32:41'),
(67, 'R/97/10', 'nati.JPG', '2015-06-01 11:39:28');

-- --------------------------------------------------------

--
-- Table structure for table `inboxstudent`
--

CREATE TABLE IF NOT EXISTS `inboxstudent` (
  `IID` int(11) NOT NULL AUTO_INCREMENT,
  `IDNO` varchar(15) NOT NULL,
  `Messages` text NOT NULL,
  `Date` varchar(100) NOT NULL,
  PRIMARY KEY (`IID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=567 ;

--
-- Dumping data for table `inboxstudent`
--

INSERT INTO `inboxstudent` (`IID`, `IDNO`, `Messages`, `Date`) VALUES
(559, 'R/3422/04', 'hdfhfhfd', 'Monday, 01/Jun/2015, 10:01:38pm'),
(560, 'R/3371/04', 'ggggggghjj', 'Monday, 01/Jun/2015, 10:22:02pm'),
(561, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:11am'),
(562, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:11am'),
(563, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:29am'),
(564, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:29am'),
(565, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:22:30am'),
(566, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:22:30am');

-- --------------------------------------------------------

--
-- Table structure for table `kewords`
--

CREATE TABLE IF NOT EXISTS `kewords` (
  `KID` int(11) NOT NULL AUTO_INCREMENT,
  `Keyword` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`KID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kewords`
--

INSERT INTO `kewords` (`KID`, `Keyword`, `Date`) VALUES
(1, '	Chapter One	\r\n1.1 Introduction\r\n        Clearance is a status granted to individuals typically students allowing them access to information. The term clearance is also sometimes used in private organizations that have a formal process to check the employee’s information. A clearance by itself is normally not sufficient to gain access the organization must determine the cleared individual has need to know the information.\r\n        Clearance is the process of determining and negotiating any permission that are needed to use of someone else’s intellectual property creative project. Part of that process includes:-\r\n?	Determining the owner(s) of the intellectual property.\r\n?	Contacting the owners and negotiating on agreement.\r\n?	Administering written contracts. \r\n?	Handling other issues related to the use and licensing of intellectual property.\r\n         No one is supposed to be granted access to classified information solely because of rank or position, but once a clearance is obtained access to certain information or gain of freedom will be granted., '2015-05-27 06:58:52');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `MID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `IDNo` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` int(20) NOT NULL,
  `Offices` varchar(30) NOT NULL,
  `messagess` text NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`MID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`MID`, `Name`, `IDNo`, `Email`, `phone`, `Offices`, `messagess`, `time`) VALUES
(56, 'Gelana Abdias', 'R/3371/04', 'gelana@gmail.com', 912782518, 'library', 'true life.', 'Tuesday, 07/Apr/2015, 01:49:25pm'),
(59, 'GETE BERHANU le', 'R/3377/04', 'geteberhanu@gmail.com', 923243148, 'bookstore', 'i want clearance', 'Thursday, 09/Apr/2015, 10:16:35am'),
(61, 'Gelana', 'R/3327/04', 'getachewtemi@gmail.com', 923243148, 'sportscience', 'jkhkjh', 'Thursday, 09/Apr/2015, 09:39:05pm'),
(84, 'DameÂ Tegegn', '1518/03', 'dagm@gmail.com', 923237751, 'proctor', 'yes i am', 'Tuesday, 12/May/2015, 03:25:25pm'),
(96, 'KebeÂ Maru', 'R/3422/04', 'kebe@gmail.com', 917782517, 'registrar', 'HH', 'Monday, 01/Jun/2015, 09:47:26pm');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE IF NOT EXISTS `notice` (
  `NID` int(11) NOT NULL AUTO_INCREMENT,
  `Notice` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`NID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `notice`
--


-- --------------------------------------------------------

--
-- Table structure for table `outcomment`
--

CREATE TABLE IF NOT EXISTS `outcomment` (
  `msg` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`msg`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `outcomment`
--

INSERT INTO `outcomment` (`msg`, `message`, `Date`) VALUES
(3, '<h2><b>Debre Tabor  University starts Clearance Processing System at The university give a service for Education </b></h2> \r\n\r\n\r\n<h4>Debre Tabor University starts teaching in masters program  in regular time of the university 30 students are learned in masters program in business administrative these indicates that time to time the capacity of learning /teaching process in Debre Tabor university is growth.</h4>', '2015-04-07 01:07:00'),
(4, '<h2><b>Debre Tabor  University Extend the STUDENT Debre Tabor CLEARANCE PROCESSING SYSSTEM  for the 2021 acadamic Year</b></h2>\r\n\r\n\r\n<h4>Debre Tabor  university change its schedule for the acadamic year 2015these schedules changed because of one student fight with one teacher and because of these are week teaching learning process stops that is why Debre Tabor university changes the graduation time 21 to 28 2015 .</h4>', '2015-04-07 10:01:02'),
-- --------------------------------------------------------

--
-- Table structure for table `readmore`
--

CREATE TABLE IF NOT EXISTS `readmore` (
  `RID` int(11) NOT NULL AUTO_INCREMENT,
  `readmessage` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`RID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `readmore`
--

INSERT INTO `readmore` (`RID`, `readmessage`, `date`) VALUES
(1, 'read message', '2015-06-01 13:05:25');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stud_id` varchar(15) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Department` varchar(40) NOT NULL,
  `Year` int(11) NOT NULL,
  `clearance_date` date NOT NULL,
  `clearance_reason` text NOT NULL,
  `print_status` enum('Printed','Not Printed','','') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `stud_id`, `Name`, `Department`, `Year`, `clearance_date`, `clearance_reason`, `print_status`) VALUES
(3, 'R/3422/04', 'Kebe Maru Mulatu', 'Computer Science', 4, '2015-06-01', 'JJJJJ', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `Fname` varchar(20) NOT NULL,
  `Mname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `PASSWORD2` varchar(30) NOT NULL,
  `Sex` enum('male','female','','') NOT NULL,
  `birth_date` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Idno` varchar(30) NOT NULL,
  `Phone` int(15) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Faculity` varchar(50) NOT NULL,
  `Year` int(11) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `security` varchar(30) NOT NULL,
  `lastlogin` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `imgid` int(20) NOT NULL,
  `PHOTO` varchar(100) NOT NULL,
  PRIMARY KEY (`Idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Fname`, `Mname`, `Lname`, `username`, `PASSWORD2`, `Sex`, `birth_date`, `Age`, `Idno`, `Phone`, `Email`, `Faculity`, `Year`, `Department`, `security`, `lastlogin`, `status`, `imgid`, `PHOTO`) VALUES
('Demiso', 'Damito', 'Lata', 'damto', '1233ASas', 'male', '1990/06/24 08:47', 26, 'R/3319/04', 912782517, 'demisodamito@gmail.com', 'Institute of Technology', 4, 'Computer Science', '123456789', '0000-00-00 00:00:00', 0, 66, ''),
('abbbb', 'cccc', 'dddd', 'eeee', '1233ASas', 'male', '1990/06/24 08:47', 26, 'R/3319/04', 912782517, 'abat@gmail.com', 'Institute of Technology', 4, 'Computer Science', '123456789', '0000-00-00 00:00:00', 0, 66, ''),
('Eyerusalem ', 'Abreham', 'Ayele', 'jerry', '1234ASas', 'female', '1996/02/22 08:43', 23, 'R/3350/04', 923237752, 'jerryabreham500@gmail.com', 'Institute of Technology', 4, 'Computer Science', '53eb5935a8631302c29074f16c15b1', '0000-00-00 00:00:00', 0, 62, ''),
('Gelana', 'Abdissa', 'Duressa', 'galaxi', '123ASas', 'male', '1980/06/10 08:48', 29, 'R/3371/04', 910598046, 'gelanaabdissa@gmail.com', 'Institute of Technology', 4, 'Computer Science', 'f0f22d0e3f615e72658ec7860402ba', '0000-00-00 00:00:00', 1, 65, ''),
('Genet', 'Seyfe', 'Haile', 'geni', '12ASas', 'female', '1983/06/12 08:51', 24, 'R/3374/04', 937237751, 'geni@gmail.com', 'Institute of Technology', 4, 'Computer Science', '448afed499fc5f21aab4b594234b9e', '0000-00-00 00:00:00', 0, 61, ''),


-- --------------------------------------------------------

--
-- Table structure for table `uploadfile`
--

CREATE TABLE IF NOT EXISTS `uploadfile` (
  `FID` int(11) NOT NULL AUTO_INCREMENT,
  `File` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `size` int(11) NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `uploadfile`
--

INSERT INTO `uploadfile` (`FID`, `File`, `type`, `size`, `Date`) VALUES
(12, '92858-c-#.docx', 'application/vnd', 14, '2015-05-13 16:41:41'),
(13, '95109-feedback_management_system.zip', 'application/oct', 1072, '2015-05-13 16:42:22'),
(14, '83529-meskerem-getu-new-vcd-song-2007-áˆ°áˆ‹áˆá‰³áˆ…-á‹ˆá‹°-á‰ á‰´-áœˆá‰£...---youtube[via-torchbro', 'video/mp4', 12435, '2015-05-14 08:45:55'),


--
-- Constraints for dumped tables
--

--
-- Constraints for table `clearance`
--
ALTER TABLE `clearance`
  ADD CONSTRAINT `clearance_ibfk_1` FOREIGN KEY (`stud_id`) REFERENCES `student` (`Idno`);

    <div class="modal fade " id="history" role= "dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <p>Debre Tabor University Online Student's Clearance System</p>
                </div>
                <div class="modal-body">
                    <p>ADDRESS OF THE UNIVERSITY<br/>

                        Debre Tabor ,Ethiopia<br/>
                        P.O.Box 272,<br/>
                        Phone +251581416290,+251581410495,<br/>
                        Fax +251584412260,<br/>
                        
                            <a href="www.dtu.edu.et" title="Debre Tabor University Website">Debre Tabor University</a><br/>
                    </p>
                </div>
				<div class="modal-footer"> 
                </div>
                <div id="copy"><center><p><h3>HISTORY</h3></p></center></br>
        <div class="modal-footer"> 
                </div>
		<p align="justify"><h2>Debre Tabor University was established in 2008. 
	  <br />It was attempted to construct a total of 134 buildings out of which in the first round 35 buildings, in the second round 32 and in the third round 32 were successfully planted while the final 35 are on construction in 2007 fiscal year. This enables the university to complete its construction a year ahead of the plan of action. With regard to the budget, around 10.5 million birr has been allotted.
	  </h2></p> 
	  </div>
				  <div class="modal-footer"> 
               <a class="btn btn-default" data-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade " id="mission" role= "dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <p>Debre Tabor University Online Student's Clearance System</p>
                </div>
                <div class="modal-body">
                    <p>ADDRESS OF THE UNIVERSITY<br/>

                        Debre Tabor ,Ethiopia<br/>
                        P.O.Box 272,<br/>
                        Phone +251581416290,+251581410495,<br/>
                        Fax +251584412260,<br/>
                        
                            <a href="www.dtu.edu.et" title="Debre Tabor University Website">Debre Tabor University</a><br/>
                    </p>
                </div>
				<div class="modal-footer"> 
                </div>
                <div id="copy"><center><p><h3> MISSION</h3></p></center></br>
        <div class="modal-footer"> 
                </div>
		<p align="justify"><h2>DTU aspires to generate self reliant, competent, problem solving, research-oriented and innovative transformation agents who can actively participation the teaching-learning, research doing and community services that basically enhance the technological advancement of the society as a whole.
	  </h2></p> 
	  </div>
				  <div class="modal-footer"> 
               <a class="btn btn-default" data-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>


	<div class="modal fade " id="vision" role= "dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                         <p>Debre Tabor University Online Student's Clearance System</p>
                </div>
                <div class="modal-body">
                    <p>ADDRESS OF THE UNIVERSITY<br/>

                        Debre Tabor ,Ethiopia<br/>
                        P.O.Box 272,<br/>
                        Phone +251581416290,+251581410495,<br/>
                        Fax +251584412260,<br/>
                        
                            <a href="www.dtu.edu.et" title="Debre Tabor University Website">Debre Tabor University</a><br/>
                    </p>
                </div>
				<div class="modal-footer"> 
                </div>
                <div id="copy"><center><p><h3> VISSION</h3></p></center></br>
        <div class="modal-footer"> 
                </div>
		<p align="justify"><h2>Debre Tabor University tries hard to become one of the icons of quality education and nationwide reputable universities of Ethiopia in 2020.</h2></p> 
	  </div>
				  <div class="modal-footer"> 
               <a class="btn btn-default" data-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>
	

	<div class="modal fade " id="mandate" role= "dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                   <p>Debre Tabor University Online Student's Clearance System</p>
                </div>
                <div class="modal-body">
                    <p>ADDRESS OF THE UNIVERSITY<br/>

                        Debre Tabor ,Ethiopia<br/>
                        P.O.Box 272,<br/>
                        Phone +251581416290,+251581410495,<br/>
                        Fax +251584412260,<br/>
                        
                            <a href="www.dtu.edu.et" title="Debre Tabor University Website">Debre Tabor University</a><br/>
                    </p>
                </div>
            </div>
        </div>
    </div>
	

<div class="modal fade " id="developer" role= "dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <p>Debre Tabor University Online Student's Clearance System</p>
                </div>
                <div class="modal-body">
                    <p>ADDRESS OF THE UNIVERSITY<br/>

                        Debre Tabor ,Ethiopia<br/>
                        P.O.Box 272,<br/>
                        Phone +251581416290,+251581410495,<br/>
                        Fax +251584412260,<br/>
                        
                            <a href="www.dtu.edu.et" title="Debre Tabor University Website">Debre Tabor University</a><br/>
                    </p>
                </div>
				<div class="modal-footer"> 
                </div>
                <div id="copy"><center><p>Copy Right Group Member &COPY;  2021</p></center></br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="green">NAME^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ID NO</font></br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1,Abatneh Nigusie ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^R/01/10</br></br>   
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2,Kalkidan Masresha ^^^^^^^^^^^^^^^^^^^^^^^^R/77/10</br></br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3,Natnael Zerihun^^^^^^^^^^^^^^^^^^^^^^^^^^^^^R/96/10</br></br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4,Tsegereda Moges ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^R/114/04</br></br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5,Zemenay Nigussie ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^R/121/04</br></br>		
				 </div>
				  <div class="modal-footer"> 
               <a class="btn btn-default" data-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>

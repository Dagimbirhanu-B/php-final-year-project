-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2015 at 09:36 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `clearance`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `Fname` varchar(30) NOT NULL,
  `Mname` varchar(30) NOT NULL,
  `Lname` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `Sex` enum('Male','Female') NOT NULL,
  `Role` varchar(15) NOT NULL,
  `status` int(1) NOT NULL,
  `SQ1` varchar(30) NOT NULL,
  `SQ2` varchar(30) NOT NULL,
  `SQ3` varchar(30) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Fname`, `Mname`, `Lname`, `Username`, `Email`, `Password`, `Sex`, `Role`, `status`, `SQ1`, `SQ2`, `SQ3`) VALUES
('Getachew', 'Temi', 'Tegegne', 'gech', 'getachewtemi17@gmail.com', 'gt123GT', 'Male', 'studentservice', 0, 'mekid', 'enjera', 'daboye'),
('Gelana', 'Abdissa', 'gehry', 'gela', 'gelana@gmail.com', 'ga123', 'Male', 'library', 0, 'gete', 'dulete', 'aberash'),
('Genet', 'Seyfe', 'Alemu', 'geni', 'geni23@gmail.com', 'gs123', 'Female', 'bookstore', 0, 'alemu', 'dorowet', 'abebech'),
('Getnet', 'Melese', 'Embiale', 'get', 'getnetmelese@gmail.com', 'gm123', 'Male', 'sportscience', 0, 'mekides', 'meat', 'ayelech'),
('Gete', 'Berhanu', 'Ayele', 'gete', 'gete@gmail.com', 'gb123', 'Female', 'proctor', 0, 'getu', 'dulete', 'aster'),
('Kebede', 'Maru', 'Fikadu', 'kebe', 'kebe23@gmail.com', 'km123', 'Male', 'registrar', 0, 'ayantu', 'gemen', 'snidu');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE IF NOT EXISTS `cases` (
  `case_id` int(11) NOT NULL AUTO_INCREMENT,
  `Idno` varchar(15) NOT NULL,
  `description` text NOT NULL,
  `staff` varchar(50) NOT NULL,
  `by_user` varchar(50) NOT NULL,
  `status` enum('MODIFY','NOT_MODIFY') NOT NULL,
  `date_added` varchar(100) NOT NULL,
  PRIMARY KEY (`case_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=129 ;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`case_id`, `Idno`, `description`, `staff`, `by_user`, `status`, `date_added`) VALUES
(127, 'R/3371/04 ', 'you borow  java book', 'library', 'gela', 'MODIFY', 'Monday, 01/Jun/2015, 09:40:42pm'),
(128, 'R/3371/04 ', 'hhhhhhhhh', 'library', 'gela', 'MODIFY', 'Tuesday, 02/Jun/2015, 11:18:37am');

-- --------------------------------------------------------

--
-- Table structure for table `clearance`
--

CREATE TABLE IF NOT EXISTS `clearance` (
  `stud_id` varchar(15) NOT NULL,
  `faculty` tinyint(1) NOT NULL DEFAULT '0',
  `department` tinyint(1) NOT NULL DEFAULT '0',
  `library` tinyint(1) NOT NULL DEFAULT '0',
  `bookstore` tinyint(1) NOT NULL DEFAULT '0',
  `cafeteria` tinyint(1) NOT NULL DEFAULT '0',
  `dormitory` tinyint(1) NOT NULL DEFAULT '0',
  `sport` tinyint(1) NOT NULL DEFAULT '0',
  `Clearance` tinyint(1) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clearance`
--

INSERT INTO `clearance` (`stud_id`, `faculty`, `department`, `library`, `bookstore`, `cafeteria`, `dormitory`, `sport`, `Clearance`) VALUES
('R/3319/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3350/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3371/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3374/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3375/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3376/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3377/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3379/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3389/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3410/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/3422/04', 0, 0, 0, 0, 0, 0, 0, 0),
('R/37nnnn75/04', 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `msg_id_fk` int(11) NOT NULL,
  `intime` datetime NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`com_id`, `comment`, `msg_id_fk`, `intime`) VALUES
(3, 'GETNET MELESE IT IS GOOD BUT LESS MORE QUALIT', 3, '2014-09-15 03:00:00'),
(4, 'GETACHEW TEMI HI it is not sefiecient', 4, '2015-04-15 01:00:00'),
(5, 'WHY U not develop fast', 5, '2015-04-15 05:06:00'),
(6, 'YOU need more result from us.', 6, '2015-04-16 08:00:00'),
(7, 'Debre Tabor UNIVERSITY is not begin education as fast as possible.', 7, '2015-04-15 02:00:00'),
(9, '<h4>Debre Tabor  university change its clearance for the acadamic year 2015. WHY?', 8, '2004-04-20 05:00:00'),
(27, 'the last posted comment from registrar', 1, '2015-04-15 04:00:00'),
(15, ' ETHIOPIA SAID it is good for development for the universty', 10, '2015-04-15 06:00:00'),
(68, 'hi this is good idea but u can''t apply it', 11, '2015-04-15 22:04:38'),
(67, 'yes', 11, '2015-04-15 21:26:05'),
(66, 'HHH', 11, '2015-04-15 20:35:26'),
(21, 'FGFG', 9, '2015-04-15 00:00:00'),
(28, 'test time', 11, '2015-04-15 04:00:00'),
(65, 'HHH', 11, '2015-04-15 20:35:06'),
(33, 'GETACHEW @time', 10, '2015-04-15 08:00:00'),
(63, 'shega is section 4 live in library ', 10, '2015-04-12 07:25:16'),
(38, 'GETACHEW @time test', 9, '2015-04-15 03:00:00'),
(62, 'IT IS ENOUGPH', 10, '2015-04-09 13:23:29'),
(40, 'time is display', 11, '2015-04-15 08:00:00'),
(64, 'melkam said that it is........', 11, '2015-04-15 15:37:33'),
(61, 'Debre Tabor UNIVERSITY', 1, '2015-04-09 13:16:03'),
(53, 'ijiun', 7, '2015-04-08 08:08:29'),
(70, 'jhhgs', 4, '2015-04-15 22:34:46'),
(57, 'hi this is good idea but u can''t apply it', 2, '2015-04-09 09:10:46'),
(59, 'luky idea continiue----------', 6, '2015-04-09 09:12:35'),
(69, 'test', 5, '2015-04-15 22:32:08'),
(71, 'bvc', 3, '2015-04-15 22:45:25'),
(72, 'HI IT IS GOOD IDEA', 11, '2015-04-16 13:40:35'),
(73, 'no ten years', 8, '2015-04-17 09:55:09'),
(74, 'fghj', 11, '2015-04-22 20:38:26'),
(75, 'fghj', 11, '2015-04-22 20:38:57'),
(76, 'cv', 1, '2015-05-01 11:13:55'),
(77, 'fghfghfghf', 5, '2015-05-09 20:03:52'),
(78, 'geni says.....................................', 11, '2015-05-31 10:24:01'),
(79, 'bbbbaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 10, '2015-05-31 10:24:23'),
(80, 'bbbbaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 10, '2015-05-31 10:24:53'),
(81, 'gelana abdissa mmmmmmmmmmmmmm', 1, '2015-06-01 10:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `DID` int(5) NOT NULL AUTO_INCREMENT,
  `FName` varchar(25) NOT NULL,
  `DName` varchar(25) NOT NULL,
  `PYear` int(2) NOT NULL,
  PRIMARY KEY (`DID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DID`, `FName`, `DName`, `PYear`) VALUES
(1, 'Institute of Technology', 'Computer Science', 4),
(2, 'Institute of Technology', 'IT', 4),
(3, 'Institute of Technology', 'Electrical Engineering', 5),
(7, 'FB', 'FP', 4),
(8, 'Institute of Technology', 'Cs', 4),
(10, 'Sport Science', 'HPE', 3);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `FID` int(5) NOT NULL AUTO_INCREMENT,
  `FName` varchar(25) NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`FID`, `FName`) VALUES
(1, 'FB'),
(2, 'Institute of Technology'),
(3, 'Faculity of Business'),
(25, 'HE'),
(26, 'LAW'),
(24, 'Ho'),
(15, 'Cooperative'),
(27, 'Sport Science');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `FID` int(5) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Offices` varchar(50) NOT NULL,
  `Comment` varchar(5000) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FID`, `Name`, `Email`, `Offices`, `Comment`, `date`) VALUES
(16, 'GETACHEW', 'getachewtemi17@gmail.com', 'studentservice', 'why u are be silent igbnbbv vhgbbvghvbnnhnhbnhnbbghv hvhbnhjnhj vb fbfgg vfgbhgvffbhj hjfbjbhj', '2015-04-06 14:18:43'),
(17, 'GETNET', 'getachewtemi17@gmail.com', 'library', 'Ambo University provides Dormitory services to its regular and summer students in its Dormitory Building.                                  ', '2015-04-06 14:19:06'),
(18, 'Geteberhanu', 'gte@gmail.com', 'sportscience', 'hjghgj', '2015-04-06 14:19:38'),
(15, 'fsdfdsf', 'gte@gmail.com', 'bookstore', 'ghhg', '2015-04-06 14:17:16'),
(19, 'Gelana', 'gte@gmail.com', 'proctor', 'what', '2015-04-06 14:20:08'),
(20, 'Kebede', 'kebedemaru@gmail.com', 'registrar', 'yes', '2015-04-06 14:20:47'),
(26, 'Gelana Abdias', 'gelana@gmail.com', 'proctor', 'i want paper.\r\n', '2015-06-01 09:51:43'),
(22, 'HFR', 'geza3381@gmail.com', 'library', 'HJGFHGHG', '2015-04-07 08:05:32'),
(23, 'GETACHEW', 'geza3381@gmail.com', 'registrar', 'TO U', '2015-04-07 08:08:05'),
(27, 'Gelana Abdias', 'gelana@gmail.com', 'bookstore', 'rygfrygfrhfhry', '2015-06-01 10:54:21');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastlogin` datetime NOT NULL,
  `user` varchar(50) NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `lastlogin`, `user`) VALUES
(1, '2014-05-14 15:14:51', 'geni');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `imgid` int(20) NOT NULL AUTO_INCREMENT,
  `Idno` varchar(30) NOT NULL,
  `imagepath` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`imgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`imgid`, `Idno`, `imagepath`, `date`) VALUES
(62, 'R/3350/04', '23027eyerusalem.jpg', '2015-06-01 09:32:41'),
(61, 'R/3374/04', '23186genet.JPG', '2015-06-01 09:31:15'),
(67, 'R/3375/04', '5683getachew.JPG', '2015-06-01 20:23:13'),
(63, 'R/3379/04', '16327getnet.JPG', '2015-06-01 09:33:43'),
(64, 'R/3377/04', '32481gete.jpg', '2015-06-01 09:34:19'),
(65, 'R/3371/04', '6509gelana.jpg', '2015-06-01 11:17:38'),
(66, 'R/3319/04', '1890demiso.JPG', '2015-06-01 11:19:28');

-- --------------------------------------------------------

--
-- Table structure for table `inboxstudent`
--

CREATE TABLE IF NOT EXISTS `inboxstudent` (
  `IID` int(11) NOT NULL AUTO_INCREMENT,
  `IDNO` varchar(15) NOT NULL,
  `Messages` text NOT NULL,
  `Date` varchar(100) NOT NULL,
  PRIMARY KEY (`IID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=567 ;

--
-- Dumping data for table `inboxstudent`
--

INSERT INTO `inboxstudent` (`IID`, `IDNO`, `Messages`, `Date`) VALUES
(559, 'R/3422/04', 'hdfhfhfd', 'Monday, 01/Jun/2015, 10:01:38pm'),
(560, 'R/3371/04', 'ggggggghjj', 'Monday, 01/Jun/2015, 10:22:02pm'),
(561, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:11am'),
(562, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:11am'),
(563, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:29am'),
(564, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:21:29am'),
(565, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:22:30am'),
(566, 'R/3371/04 ', 'You are cleared from LIBRARY', 'Tuesday, 02/Jun/2015, 11:22:30am');

-- --------------------------------------------------------

--
-- Table structure for table `kewords`
--

CREATE TABLE IF NOT EXISTS `kewords` (
  `KID` int(11) NOT NULL AUTO_INCREMENT,
  `Keyword` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`KID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kewords`
--

INSERT INTO `kewords` (`KID`, `Keyword`, `Date`) VALUES
(1, '	Chapter One	\r\n1.1 Introduction\r\n        Clearance is a status granted to individuals typically students allowing them access to information. The term clearance is also sometimes used in private organizations that have a formal process to check the employee’s information. A clearance by itself is normally not sufficient to gain access the organization must determine the cleared individual has need to know the information.\r\n        Clearance is the process of determining and negotiating any permission that are needed to use of someone else’s intellectual property creative project. Part of that process includes:-\r\n?	Determining the owner(s) of the intellectual property.\r\n?	Contacting the owners and negotiating on agreement.\r\n?	Administering written contracts. \r\n?	Handling other issues related to the use and licensing of intellectual property.\r\n         No one is supposed to be granted access to classified information solely because of rank or position, but once a clearance is obtained access to certain information or gain of freedom will be granted.\r\n         The proposed system over comes one problem done by manual system. To reduce misuse of manpower, avoiding errors, to save time, to provide comfort clearance process for the students and to provide insurance for the organization especially for workers who play role in the clearance processing system.\r\n         This system works for students of Ambo University. The online clearance processing system allows the students to register for the membership to access the service of the system. \r\n\r\n\r\n\r\n\r\n1.2 Background of the organization\r\n         Ambo University, established in 1939E.C, is one of the oldest higher learning institutions in Ethiopia. A new chapter in history of the institution was registered in 1995E.(2003) as this was the time when the institution started to offer undergraduate degree programs in the fields of Crop Production, Animal production, Applied Chemistry and Applied Biology. In the meantime, the college was affiliated of Jimma University by the name Jimma University Ambo College. In the following years, the College showed remarkable growth both in intake capacity and the number of programs it offers. Subsequently by 2006, the college opened 15 undergraduate and 2 postgraduate programs in various fields of natural and social sciences.                                                                                                                                                                                     \r\n         Presently the University runs nine graduate and twenty-eight undergraduate programs which are divided into eight colleges/institutes and thirty academic departments. Besides its main campus at Ambo, the University also has one faculty-Faculty of Business and Economics at Woliso. \r\n          In the years to come, the university has the vision of becoming one of the most prestigious universities in the country excelling in academics, research and community service giving its at most attention to quality education. Offering relevant, quality education and training, conducting demand driven research and rendering accessible community services.\r\n           Ambo University Awaro Campus also a branch beside a main campus. The campus begin in 2005 E.C, by Institute of Technology. The University show a great change in three years and the student numbers is increased.  \r\n1.2.1 Vision\r\n          Ambo University aspires to be a leading university in Ethiopia, a centre of excellence in the field of all departments in east Africa competitive in 2020.\r\n1.2.2 Mission\r\n          Ambo University has a mission of offering relevant and quality education and training, conducting demand driven research and rendering accessible community services.[ref1]	\r\n\r\n1.3 Background of the project\r\n          Ambo University student’s clearance processing system is one of the processes that will be done to be cleared the students from the campus. The manual clearance system starts the process as Ambo University was established in 1939E.C.\r\n          The system gives its function to many user of the University. The numbers of students grow from year to year in many numbers. Now a day, there are many users of the clearance processing system. But the project give a service only the students. The students get one copies of clearance sheet from department and get signature and stamp from around eight offices. These are Advisor, Bookstore, Library, Health and physical Education, Student’s Proctor, Student Service, and College/Institute Registrar. After they finished all necessary requirements, finally the students take copies of sheet that has all signature and stamp from all offices. This processing makes the students bulky because they go to about eight offices.\r\n1.4 Statement of the problem\r\n         The process of clearing students of a named institution AMBO UNIVERSITY after the end of academic year requires that the students must be cleared in their various departments. This clearance processing system service currently uses manual system which creates the following major problems.\r\n?	Data recording system is not centralized or not in the modern system which is difficult to search.\r\n?	It creates wastages of material & time.\r\n?	Data redundancy & loss of data.\r\n?	Consumes more resources to complete the process which is of high cost such as:- \r\n•	Stationary material.\r\n•	Printers and computers etc.\r\n?	Need more manpower to process the clearance in the respective offices.\r\n?	Error is happened during process the clearance System.\r\n?	The process is very offensive for students when there is a harsh atmosphere like rain. \r\n?	To process the clearance is lot of queue because of the number of users.\r\n?	Employees involved in the clearance process are not available 24 hours of the day.\r\n         Hence, it became imperative for computer software based online clearance system to eliminate the shortcoming of the manual system in place as above listed problem.\r\n1.5 Team compositions\r\n         We have organized our self (team member) in a decentralized way that every team member communicates to each other and diagrammatically. \r\n \r\nFig 1.1 Team composition\r\n\r\n\r\n\r\n       Work breakdown structure for the project\r\n\r\nAmbo University Student’s Online Clearance System\r\nWORKBREAK DOWN STRUCTURES	SN	Tasks	Duration	Predecessor	Responsible\r\n	1	Project initiation and Planning \r\n?	Gathering information	1 weak		All\r\n	2	Description of the project \r\nIntroduction:\r\n?	Back ground information\r\n?	Statement of the problem\r\n?	Objective of the problem\r\n?	Scope and limitation of the project\r\n?	Methodology\r\n?	Feasibility study	2 weak	1	?	Demiso Damito\r\n?	Gelana Abdissa\r\n?	Kebede Maru\r\n	3	Current system\r\n?	Description of current system\r\n?	Players in the existing system\r\n?	Business Rules\r\n?	Bottlenecks of the existing system	1 weak	1,2	?	Hawa Bati\r\n?	Iliham Sultan\r\n	4	Proposed System\r\n?	Functional Requirement\r\n?	Non Functional Requirements\r\n?	User interface\r\n?	Hardware or software requirements\r\n?	Security and safety procedure 	3 weak	1,2,3	?	Getnet Melese\r\n?	Eyerusalem Abreham\r\n	5	System  Modelling\r\n?	Use case diagram and there description\r\n?	Object Model\r\n?	Dynamic Model	1 weak	4	?	Genet Seyfe\r\n?	Getachew Temi\r\n?	Gete Berhanu\r\n	6	Implementation \r\n?	Design\r\n?	Coding \r\n?	Testing\r\n?	Documentation	12 weak	3,4	All\r\n  Advisor Dr Velmurgan   \r\n Submission Date Jan  28/2015                                                                                                                 \r\n                         Table 1.1 Work break down structure\r\n\r\n1.6 Objective of the project\r\n 1.6.1 General Objective\r\n         The main objective of this project is to change the manual clearance processing system to web based system and solve the above stated problems. \r\n1.6.2 Specific Object\r\n  The specific objective of this project includes:- \r\n?	Able to register students.\r\n?	Check students from the data base.\r\n?	Fast data processing.\r\n?	To  avoid the problems and stress of travelling and queuing up of student during clearance\r\n?	Efficient use of time.\r\n?	Designing friendly user interface.\r\n?	To develop reliable clearance system.\r\n?	To provide borderless access.\r\n?	To ensure prompt clearance.\r\n?	To develop transparent clearance system.\r\n?	To develop effective and efficient clearance system.\r\n?	To avoid redundancy, and inconsistency. \r\n?	To overcome problem of wastage of resources like pen, paper and human power.\r\n1.7 Feasibility Analysis\r\n         Feasibility analysis enables the system to determine ether or not the project can be developed, evaluates and identifies the newly developed system. Therefore, the feasibility analysis of proposed system involves the following feasibility:\r\n1.7.1 Operational Feasibility\r\n         The proposed system will solve the business and time problem for the organization.    Therefore the campus administration and other users providing effective processing system, which satisfies their needs.\r\n?	The proposed system offers greater level of user-friendliness.\r\n?	The proposed system produces best results and gives high  performance.\r\n?	The proposed system can be implemented easily.\r\n?	The proposed system can be solved the existing system problem and challenge.\r\n\r\n1.7.2 Technical Feasibility\r\n         The system developers understand the scope, objectives including specific objectives and limitations of the proposed system well and the users have technical capability/ability to use this system. As a result they develop the system for Ambo University successfully within proposed resources (budget, time, etc.). This also deals with the hardware as well as software requirements. We have to find out whether the necessary technology and the proposed equipment have the capacity to hold the data used in the project. The technical feasibility issues usually raised during the stage of fact finding includes the following:-\r\n?	This software is running in windows and Linux operating system.\r\n?	The system can be expanded in any system platforms.\r\n1.7.3 Economic Feasibility\r\n         When the team can be analyses the system by comparing the cost with the benefit (the enterprise can get by using the proposed system), surely the benefit out weight the cost. The cost of developing a full system, including software and hardware cost for the class of application being considered should be evaluated. So, the benefit that obtain by using the proposed system can be categorized as tangible and in tangible.\r\nTangible benefits are:\r\n?	Using less man power than the existing system.\r\n?	Increase speed of activities and competence.\r\n?	Reduce cost.\r\n Intangible benefits are: \r\n?	Knowledge required by project developer.\r\n?	Facilitating information processing.\r\n?	Updating information.\r\n?	Increasing the competitiveness of the individual. \r\n?	Improved productivity. \r\n?	Improving the morale of our team.\r\n?	Facilitating information processing of our team\r\nTherefore the team decided the proposed project is economically feasible.  \r\n1.7.4 Behavioural/Political Feasibility \r\n          Behavioural feasibility is the measure that how users use the system effectively. The proposed system should be easy to operate, convenient in maintenance and effective in its working. Thus behavioural feasibility is very important factor to be considered for effective working of the system. Behavioural feasibility is dependent on human resources available for the project and involves projecting whether the system will operate and be used when it is functionally operate. The system is behaviourally feasible because of the following:-\r\n?	The proposed system is easy to operate.\r\n?	Retrieval of information is easy, accurate and fast.\r\n         Since developing this new system will be solve the clearance system problems, the users will undoubtedly have positive attitude towards the system and the system is politically feasible and free from any legal claims.\r\n1.7.5 Schedule Feasibility\r\n          Schedule feasibility is concerned with analysing the expected completion date of the project and the constraints that may bring change to this date. We have so many fixed schedule to work together the project with all groups within each day and for the simplicity and fast developing purpose.\r\n                      Fig 1.2 Gantt chart.\r\n1)	Cost of the project\r\nA.	Hardware Requirements cost\r\nNo 	Materials Required	Amount	Price Per Unit	Total Cost\r\n1	Toshiba Computer	2	12000	24000\r\n2	Pen	10	4	40\r\n3	A4 Size Paper	1 Destin	110	110\r\n4	Print 	100	1	100\r\n5	Flash Disk	1(8G)	120	120\r\n6	CD-ROM	2	7	14\r\nTotal                                                                                                     24384\r\n               Table 1.2 Hardware Requirement Cost\r\nB.	Software Requirements Cost \r\nNo 	Materials Required	Price Per Unit\r\n1	Microsoft Word 2013	Free \r\n2	Notepad++	Free\r\n3	Microsoft Office Visio 2007	Free\r\n4	SQL Server	120\r\n5	Mozilla Firefox	Free \r\nTotal                                                                           120\r\n                  Table 1.3 Software Requirement Cost\r\n2)	Cost break down\r\nA.	One time cost: - are costs incurred at the time of developing our project.\r\nB.	Recurring costs:-are costs those incurred to maintain our project once developed.\r\n1.8 Scope of the project\r\n         This project is limited only for Ambo University students. Currently the university performs clearance system manually or paper based processing system. Generally the scope of this project includes:-\r\n?	Our system used for AU students only.\r\n?	The System contains all the recorded information that can be handled by the registrar and other offices.\r\n?	Registration for a membership.\r\n?	Administrator control the system.\r\n?	Users can view their profiles.\r\n?	The proposed system is accessed by English language.\r\n1.9 Significance of the project\r\n         The project work will help in a good ways to ease the queuing system in the university as the online clearance system will help students to achieve whatever they want without coming to the various offices for clearance personally such as dormitory, bookstore, registrar, sport, library and student service.\r\n         Online student clearance system allows the users to check their clearance status as whether they are in any way obligated to the university, fill and submit their clearance form, and obtain their clearance letter. There are many other advantage of student’s online clearance system. Some of them are listed below:-\r\n?	It save a time.\r\n?	It is very convenient to use it right from the dormitories, office or anywhere in the campus or in the world.\r\n?	Information processing is very fast and delays can be minimize.\r\n?	Help the University in reducing cost such as labour and stationary.\r\n?	Process clearance effectively and efficiently.\r\n?	Provides a reliable and transparent clearance processing system.\r\n?	It provide borderless access.\r\n?	It provide a reliable and transparent system devoid of person interest and inclination. \r\n?	The system removes the problems of stress, travelling to different office and queuing up of students during processing of the clearance.  \r\n1.10 Target beneficiaries of the system\r\n           This project provides many benefits for:-\r\n1.	Students: - by providing fast access to the clearance system by reducing time like waiting in the queue and going to different offices. The students access the system anywhere and anytime when they need the clearance. It improves the tiredness of student by avoiding to going to different offices to get the clearance system.\r\n2.	University: - in manual system there is loss of materials like time, paper, pen which is cost and more manpower, the system reduces loss of costly materials and manpower.\r\n3.	Developers of the project: - it increase our knowledge and we get moral satisfaction from the project we developed.\r\n1.11 Methodology for the project                                                                                       \r\n 1.11.1 Data source\r\n         Is the way or mechanism in which we gather information to develop the system. \r\nWe have used the following methods: -	\r\n?	By seeing the forms that the existing system uses how students clear and take out their property from the campus.\r\n?	Interviewing the heads of the office and the clerk (asking open and closed question)\r\n?	Observing different files and reporting documents.  \r\n?	Collecting information from different references, projects and web sites\r\n?	By discussing and analysing the problems with project team.\r\n1.11.2 Fact Finding Techniques\r\n Practical Observation: - we observed physically the current existing system which is done by manually. We referred different forms and documents in the department, registrar and some other offices.\r\nDocument Analysis: - For more information about the existing system we refer relevant documents, others reading materials and some forms in different offices.\r\nInterview: - To get the basic information and background information about the existing system structure, we ask different question from different persons who provide clearance system.\r\n1.12 System Analysis and Design\r\n         In this project the team used Object Oriented System Analysis and Development methodology (OOSAD). This has two phases.\r\nObject Oriented Analysis (OOA):- During this phase the team used to model the functions of the system (use case modelling), find and identify the business objects, organize the objects and identify the relationship between them and finally model the behaviour of the object.\r\nObject Oriented Design (OOD):- During this phase the team used to refine the use case model to reflect the implementation environment, model object interactions and behaviours that support the use case scenario, and finally update object model.\r\n\r\n1.13 Development Tools\r\nSoftware: - This project use the following system development tools for different activities.                              \r\nTools	Activities\r\nNotepad++	For editing code\r\nCSS	For attractive layout\r\nPHP 	 Back end (Server side coding)\r\nHTML	Client side coding\r\nMYSQL	Back end(data base)\r\nApache Server	As server\r\nMozilla Firefox, IE, Google Chrome, Opera	Browsers\r\nMs office word 2013	For Documentation\r\nMs office PowerPoint 2013	For Presentation\r\nMs office Visio 2007 	To draw UML Diagram and for designs\r\nAdobe Photo Shop CS5	To design back ground images\r\n                            Table 1.4 Development Tools\r\nHardware \r\n?	Hard Disk\r\n?	CD¬-ROM 700MB\r\n?	Flash Disk 8GB\r\n?	Printer\r\n1.14 Testing Procedures\r\n          We use the above listed software development tools to design or implement the proposed system, because the tools are compatible to develop the proposed system. We will also perform different testing for checking functionality of our proposed system.\r\n1.	Unit testing: - First we will test each unit at each system. So, if a problem is encountered it will immediately maintain at which the problem is occurred.\r\n2.	Integration Testing: - After we test each unit of the proposed system we will perform an integration test to check whether the system meets all the functional requirements. When a number of components are complete, it will test to ensure that they integrate well with each other like operating system, and other components.\r\n3.	System Testing: - After all of the above testing are checked we will test our system by other peoples and we will conduct some comments how they get our system.\r\n\r\n1.15 Implementation\r\n         The current student clearance processing system is still works. Since we cannot change it directly or partially we choose to develop the proposed system parallel to the existing system. We are going to change the manual clearance Processing system after the user is familiar with the proposed system, until that the users and the university uses parallel with the manual clearance processing system.\r\n1.16 Limitation of the project	\r\n        Defines what the proposed system is not going to perform or what is not including in the proposed system. This project covers some of the aspects of computer software based online clearance processing system using Ambo University as case study. However the following are the constraints:- \r\nTime constraints: - Due to time constrain the web page covers only clearance for various departments by the students.\r\nFinancial constraints: - Due financial constraints people cannot afford this kind of process online especially towards the cost of accessing the internet. Therefore, it would cost a lot to develop a full web based clearance processing system. Generally the limitation of this project includes: -\r\n?	This project done only for Ambo University students.\r\n?	The system couldn’t give service to academic staff and administrative staff i.e. limited only for students.\r\n?	If the students lost/damage the university property, he/she couldn’t gain clearance, until the students pay the cash personally to finance. \r\n?	The proposed system cannot accessed with their local language. \r\n1.17 Risks and Contingencies\r\n        Some risks and contingencies that may happen during the development of the system are includes absence of electrical power, absence of team members during working because of different problems are happened.\r\n1.18 Assumptions and Constraints\r\n        Assumptions: - The group members assume to finish the system according the given time.\r\n         Constraint: - The major constraints of the system are internet and electric power.\r\nChapter Two: Description of the Existing System\r\n2.1 Introduction of the Existing System\r\n         The current clearance processing system is the manual system that needs intensive human labour, resource, consume time, less security. Here, the student to visit all the clearance offices with a form for them to fill and get sign by the respected offices. Once these forms are signed, it proves that the users have been cleared. This process takes some days to be completed and possess a lot of stress to all the users and workers who provide clearance system. \r\n         In the manual system, the clearance forms are documented in a file cabinet. Each time the clearance form is needed, a search operation conducted on the file cabinets to locate a particular user’s clearance form. \r\n2.2 Players in the Existing System\r\n         The main players in the existing system includes the following: -\r\n?	Students: - Students will go to department to get the clearance form and fill the form then go to different offices to get sign.\r\n?	Registrar: - They sign in the form and give the form to the students.\r\n?	Proctors: - They check the dorm materials like bed, window, door, and the door key if all are not damage they sign in the students clearance form.\r\n?	Library: - They check either the borrowed books were returned or not.\r\n?	Sport Science: - This office check sport materials whether the student take from the office or not.\r\n?	Student Service: - Any student debit are defined in this office.\r\n?	Book Store: - They check if the students have borrowed a book and return the book or not, if they have not borrowed the students are cleared and they put sign in to the clearance form.\r\n?	Departments: - Distribute clearance paper form for the students in respected department.\r\n?	Security Guard: - They check the student properties are matched with their clearance paper. \r\n2.3 Major functions/activities in the existing system\r\n2.3.1 Input Analysis\r\n         Input to the system is the form which is fulfilled by the proper users. These forms are filled by student and submitted to the various offices for issuing of receipts.\r\n2.3.2 Process Analysis\r\n         The form is filling by the students then collected and signed by the respected offices to certify that the student has completed all the necessary things. Hence a certificate issued to show that the student have completed all the clearance processing.\r\n2.3.3 Output Analysis\r\n          The output from the system is the certificate or one form of clearance issued to the student stating that the student fulfilled all university obligation and is now free to pass out from the university.\r\n2.4 Business Rules\r\n?	Can only access authorized user.\r\n?	Unauthorized user cannot access the system for the reason of system security. \r\n?	Users must be registered to access the system to be authorized user by filling the necessary information in the registration form.\r\n?	Users must have username and password to login to the system.\r\n2.5 Report generated in the existing system\r\n         The forms generated in the existing system are in the forms of form and files.\r\nForms: - Forms are the reports generated in the existing system that contains all information filled by the university student.\r\nFiles: -Files are the collection of information about the students who involve in the clearance processing system.\r\n         These all reports kept in the offices of the university to store information about the university student.\r\n2.6 Forms and Other Documents of the Existing System\r\n \r\nFig 2.1 Students Clearance form\r\n\r\n2.7 Bottlenecks of the Existing System\r\n         Due to the manual means being used by the university, in keeping information about student’s clearance, a lot of problems are encountered which includes: -\r\n2.7.1 Performance (Response time)\r\n?	Wait in the queue while processing the clearance form.\r\n?	Unavailability of some key staff while processing the clearance form.\r\n?	Takes a lot of time to get back a particular clearance from the respected offices.\r\n2.7.2 Input (Inaccurate/redundant/flexible) and Output\r\n         During filling of the form the user may fill inaccurate or incorrect information and may miss necessary information, this show the system is inaccurate and the system is not flexible because if user wants to erase the form he/she must only change another form.\r\n2.7.3 Security and Controls\r\n?	Loose of vital documents as the filing system is manual.\r\n?	Damage of document due to fire or rain incident.\r\n?	Take a lot of time to retrieve a particular clearance form.\r\n?	Delay in processing clearance form.\r\n?	Illegal removal of forms by falsified staff leading to insecurity.\r\n2.7.4 Efficiency\r\n         Due to the manual operation most of the activities are easy to wastage of resources like stationary materials, manpower, time etc. to produce the corresponding outputs. This makes the current system inefficient while utilizing resources.\r\n2.8 Practices to the Preserved\r\n         Even if the existing system has a lot of problems, there are a number of activities that need to be preserved. The system uses files and forms to define operations and to perform business rules in the clearance system. Our team members preserve the following practices form the existing system. \r\n?	System procedures.\r\n?	The rule and regulation of the university.\r\n?	Formalities of the users of the system, offices concerned staffs and students.\r\n2.9 Proposed Solution for the new System that address problems of the Existing System\r\n          The new system is designed to solve problems affecting the manual system in use. It is design to be used online thereby relieving both the students and the offices workers from much stress as experienced in the manual system.\r\n         This system will do the analysing and storing of information either automatically or interactively. It will make use of online access to Internet. The proposed system will also have some other features like:-  \r\n?	Login system must be present and secured by password and logout after cover.\r\n?	Accuracy in the handling of data.\r\n?	Fast rate of operation and excellent response time.\r\n?	The system is flexible i.e. it can be accessed at any time.\r\n?	Easy way of back up or duplicating data in diskettes in case of data loss.\r\n?	Better storage and faster retrieval system.\r\n?	Accessibility from anywhere.\r\n2.10 Requirements of the Proposed System\r\n2.10.1 Functional requirements\r\n         Functional requirement defines a function of a system and its components. A function is described as a set of inputs, behaviour, outputs, data manipulation and processing and other specific functionality that define what the system is supposed to accomplish.\r\nPerformance requirements: - The system performance is one of the functional requirement in which they regularly and producing quality output. It is all time ready to perform all the functions, faster response time and use minimal space usage.\r\nProcess requirements: - The system performs the services for all inputs by functional components of the system based on the given inputs.\r\nInput related requirements: - After the system is implemented, to perform a process it needs inputs like student username, student ID No and other information which are necessary to in processing clearance are entered in clearing process.\r\nOutput related requirements: - The system takes in an input to perform or to process some function in order to produce an output based on the given input.\r\nStorage related requirements: - The system developed by using MySQL database server which used to store all the students information like cleared students and the current available students information to be cleared.\r\n2.10.2 Non-functional requirements\r\n Performance: -\r\n?	The system is very fast since it is automated. \r\n?	The software shall support use of multiple users at a time. \r\n?	It works very well with short response time, high throughput and high availability.\r\n?	Reduce costs and time waste by providing access to system in available place and time where Internet connection is available\r\nUser Interface: - The developed system provides web application user interfaces that are compatible browsers like Internet Explorer, Mozilla Firefox, Google chrome, etc. \r\nSecurity and Access Permissions: - The system provides or contains user name and password for each users based on their privilege. This performs the following activity: -\r\n?	Authenticated user with predefined access right will only enter to the information related to database.\r\n?	Every users should use strong passwords especially admin. \r\n?	User must enter valid user name and password to login to system. Without this, access to the system is denied. \r\n?	Data is encrypted for security. \r\n?	System allows only registered users to access clearance system and also allows the users’ to view their own profile not the other users’ profile.\r\nBackup and Recovery: - When team member standard to develop a system they must have to put use a backup mechanism by using removable flash disks, or CDs.\r\nUsability: - The system shall be very easy   to learn, needs a basic computer knowledge to use and have a help menu to guide the user.\r\nAvailability: - There is no delay in the availability of any information, whatever needed, can be captured very quickly and easily. The server should be always on to be available.\r\n\r\nChapter Three: System Analysis\r\n3.1 Introduction\r\n         This chapter deals with analysing the proposed system by using different UML analysis modelling techniques such as use case diagrams, the use case descriptions (scenarios), sequence diagrams, activity diagrams, analysis class diagram, and user interface prototype\r\n         After identifying the actors and use cases, the use cases are developed and textual descriptions (scenarios) are stated. The Sequence diagram id depicted based on the use cases which are developed for the proposed system. Activities will be represented by the activity diagrams.\r\n3.2 System Requirement Specification (SRS)\r\n3.2.1 Use case diagram\r\n\r\n\r\n                     \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n Figure 3.1 Use case diagram\r\nActors Description\r\nThe actors that interact with the system are the Proctors; Registrar, student service, sport science, bookstore, library, and students are users of the system. They are described here in brief:-\r\nName: Proctor \r\nDescription: A Proctor is a person who is responsible for Approve, Update, delete, and search the student’s information.\r\nName: Bookstore \r\nDescription: A Bookstore is a person who is responsible for Approve, Update, delete, and search the student’s information.\r\nName: Sport science \r\nDescription: A Sport science is a person who is responsible for Approve, Update, delete, and search the student’s information.\r\nName: Library\r\nDescription: A Library is a person who is responsible for Approve, Update, delete, and search the student’s information.\r\nName: Student service\r\nDescription: A Student service is a person who is responsible for Approve, Update, delete, and search the student’s information.\r\nName: Registrar Admin\r\nDescription: Registrar Admin is a person who is responsible for Approve and Generate Report.   \r\nName: Student\r\nDescription: Student is a person who is responsible for Update profile, Request, and view their own information.\r\nKey terms of Offices refers to \r\n 	Proctor\r\n 	Student service\r\n 	Bookstore\r\n 	Library\r\n 	Sport science\r\nFrom the above use case diagram. \r\n3.2.2 Use case descriptions\r\n1.	Use case description for Create Account.\r\nUCID-01	Use case name	Create Account\r\n	Actor(s)	Admin, Offices\r\n	Pre-condition	The Actors is not create account.\r\n	Post-condition	The Actors should be create account.\r\n	Description	When the Actors enter user name and password, it stores the input information in to the database. \r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: This use case is initiated when the actors clicks on the create account option\r\nStep3: The actor enter the required information.	Step2: The system displays the create account page.\r\nStep4: The systems checks the information is correct or not. \r\n	Alternative course of action:	Step5: If the actor does not fill the required information then the system display error message and return to step 2.\r\n                 Table 3.1 Use case description for Create Account.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n2.	Use case description for login.\r\nUCID-02	Use case name	Login\r\n	Actor	Student\r\n	Pre-condition	The Actor is  not   login the system\r\n	Post-condition	The Actor should be login in to the system\r\n	Description	When the students enter id and password, it checks the inputs from the database. If it is valid, it allows the user to access and if not it display authorization message.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: This use case is initiated when the actors clicks on the login option\r\nStep3: The actor enter the id and password	Step2: The system displays log in form\r\nStep4: The systems checks authorization. If she/he is authorized system displays the main page if not display unauthorized message.\r\n	Alternative course of action:	Step5: If the actor does not fill the id and password then the system display error message and return to step 2.\r\n                 Table 3.2 Use case description for Login.\r\n3.	Use case description for Registration.\r\nUCID-03	Use case name	Registration\r\n	Actors	Students\r\n	Pre-condition	The Actors not  to register\r\n	Post-condition	The users registers to the system\r\n	Description	This use case allows users to register in to the system\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The user wants to register in to the system.      \r\nStep3: The user enters the necessary information in to the form in registration page.	Step2: The system displays registration page                                                               Step4: The system validates whether the information submitted is correct or not.         Step5: The system register and displays registration confirmation page and leads to home page.                                                   Step6: The use case ends\r\n	Alternative course of action:	Step5: If the actor does not fill the id and password then the system display error message and return to step 2.\r\n	Alternative course of action	If the input information invalid or empty                                                      Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2: The use case continues Step2 of the basic course of action.\r\n                  Table 3.3 Use case description for Registration.\r\n\r\n4.	Use case description for Delete.\r\nUCID-04	Use case name	Delete\r\n	Actor(s)	Administrator, Offices\r\n	Pre-condition	The Actors are not authorized and login in to the system\r\n	Post-condition	The administrator delete the record from the database.\r\n	Description	The use case allows the administrator to delete record of students from database.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: This use case is initiated when the actor on delete option                                   \r\nStep3: The actors enter the id for delete data from the data base.	Step2: The system displays the delete form page.                                                Step4: The system verifies whether the existence of the data base.\r\nStep5: The system displays confirmation message.\r\n	Alternative course of action	If the input information invalid or empty                                                                                  Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2: The use case continues Step2 of the basic course of action.\r\n               Table 3.4 Use case description for Delete.\r\n5.	Use case description for Update.\r\nUCID-05	Use case name	Update profile\r\n	Actor(s)	 Students Admin, and Offices\r\n	Pre-condition	The Actors cannot be Update profile\r\n	Post-condition	The Actors will have update their account information\r\n	Description	This use case allows users to update the user account.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The actors can request to update his/her information. The system will display the current customer information to the users.                                               Step3: The user enters the necessary information to update.	Step2: The system displays user account update page.                               Step4: The system validates information is correct or not.                                                             Step5: The system displays confirmation page and save the update information of user.                                    \r\n	Alternative course of action	If the input information invalid or empty                                                      Step4.1: The system indicates the Actors information invalid.                                                                                                    Step4.2: The use case continues Step2 of the basic course of action.\r\n                Table 3.5 Use case description for Update.\r\n6.	Use case description for View Profile\r\nUCID-06	Use case name	View Profile\r\n	Actor(s)	Students\r\n	Pre-condition	The Actors not seen profile.\r\n	Post-condition	The Actors has been viewed his/her profile.\r\n	Description	This use case allows users request to view his/her profile.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The actors wants to View his/her profile.                   Step3: The actor selects the view profile option.\r\n	Step2: The system displays view option page.                                                    Step4: The system process selection.                            \r\nStep5: The system displays the actor profile.                                                 \r\nStep6: The use case ends.\r\n	Alternative course of action	If the input information invalid or empty                                                      Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2: The use case continues Step2.\r\n              Table 3.6 Use case description for view profile\r\n7.	Use case description for Search.\r\nUCID-07	Use case name	Search\r\n	Actor(s)	Administrator, and Offices\r\n	Pre-condition	The actors cannot search.\r\n	Post-condition	The Actors has been searched the selected record.\r\n	Description	This actors requests to search someone’s information.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The actors wants to search some record.               Step3: The user enters the information to search from database option.\r\n	Step2: The system displays user view option.                                                Step4: The system process the selection.                                            Step5: The system displays the selected record.                                                Step6: The use case ends.\r\n	Alternative course of action	If the input information invalid or empty                                                      Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2: The use case continues Step2 of the basic course of action.\r\n              Table 3.7 Use case description for Search\r\n\r\n\r\n\r\n8.	Use case description for Approve.\r\nUCID-08	Use case name	Approve\r\n	Actor(s)	 Offices and Admin \r\n	Pre-condition	The actors cannot Approve.\r\n	Post-condition	The actors should be approved the information.\r\n	Description	The actor to be approve if they get request some information from different corners.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The actor wants to submit.                                          Step3: The user selects the approve option.\r\n	Step2: The system displays the approve option.                                                   \r\nStep4: The system process the selections.                                        \r\nStep5: The system displays confirmation message to the user.                                      Step6: The use case ends.\r\n	Alternative course of action	If the input information invalid or empty                                                      Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2: The use case continues Step2 of the basic course of action.\r\n                Table 3.8 Use case description for Approve\r\n9.	Use case description for Generate Report.\r\nUCID-09	Use case name	Generate Report\r\n	Actor(s)	Admin\r\n	Pre-condition	The actor cannot be Generate Report.\r\n	Post-condition	The Actors should be generate the report.\r\n	Description	The actor wants to report how many students are clear from the university.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The actor wants to generate report.                                          \r\nStep3: The user selects the generate report option.	Step2: The system displays the generate report option.                                          Step4: The system process the selections.                           \r\nStep5: The system display the all information’s of the students.                              Step6: The use case ends.\r\n	Alternative course of action	If the input information invalid or empty                                                Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2: The use case continues Step2 of the basic course of action.\r\n               Table 3.9 Use case description for Generate Report.\r\n\r\n\r\n10.	Use case description for Request.\r\nUCID-10	Use case name	Request\r\n	Actor(s)	Student\r\n	Pre-condition	The actor cannot Request the information.\r\n	Post-condition	The Actors will be Request.\r\n	Description	The actor wants to request what they want.\r\n	Typical course of action:	Actor Action	System Response\r\n\r\n		Step1: The actor wants to request.                                          \r\nStep3: The user selects the request option.	Step2: The system displays the request option.                                          Step4: The system process the selections action.                           \r\nStep5: The system send information’s to the other page.                              Step6: The use case ends.\r\n	Alternative course of action	If the input information invalid or empty                                                Step4.1: The system indicates the user information invalid.                                                                                                    Step4.2 The use case continues Step2 of the basic course of action.\r\n               Table 3.10 Use case description for Request.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n3.2.3 Sequence Diagram\r\n         Sequence diagrams show the interaction between participating objects in a given use case. They are helpful to identify the missing objects that are not identified in the analysis object model.\r\n1)	Sequence Diagram for Create Account by Admin and Offices\r\n\r\n \r\n                     Fig 3.2 Sequence diagram for Create Account by Admin and Offices\r\n\r\n2)	Sequence diagram for Registration.\r\n       \r\n                                Fig 3.3 Sequence diagram for registration\r\n\r\n3)	Sequence diagram for Login.\r\n\r\nFig 3.4 Sequence diagram for login.\r\n\r\n4)	Sequence diagram for Update.\r\n Fig 3.5 Sequence diagram for Update\r\n\r\n\r\n\r\n5)	Sequence diagram for View.\r\n \r\n                                             Fig 3.6 Sequence diagram for View\r\n\r\n\r\n6)	Sequence diagram for Search.\r\n\r\n                                        Fig 3.7 Sequence diagram for Search\r\n\r\n7)	Sequence diagram for Delete.\r\n\r\n \r\n                                        Fig 3.8 Sequence diagram for Delete\r\n\r\n\r\n8)	Sequence diagram for Approve.\r\n\r\n \r\n      Fig 3.9 Sequence diagram for Approve\r\n \r\n9)	 Sequence diagram for Generate Report.\r\n \r\n                                                               Fig 3.10 Sequence diagram for Generate Report\r\n\r\n10)	Sequence diagram for Request.\r\n\r\n \r\n\r\n                         Fig 3.11 Sequence diagram for Request.\r\n\r\n\r\n\r\n3.2.4 Activity Diagram\r\n           Activity diagram used to emphasize the flow of control from activity to activity or to model the flow of an object as it moves from state at different points in the flow of control.\r\n1.	Activity Diagram for Registration\r\n  \r\n\r\nFig 3.12 Activity diagram for Registration\r\n2	Activity Diagram for Create Account\r\n \r\n\r\nFig 3.13 Activity diagram for Create Account.\r\n3	Activity Diagram for Login. \r\n  \r\nFig 3.14 Activity diagram for Login\r\n\r\n\r\n\r\n\r\n4	Activity Diagram for Delete\r\n \r\n\r\nFig 3.15 Activity diagram for Delete\r\n\r\n\r\n\r\n5	 Activity Diagram for Update Profile\r\n  \r\nFig 3.16 Activity diagram for Update profile.\r\n\r\n\r\n\r\n6	 Activity Diagram for View Profile\r\n \r\nFig 3.17 Activity diagram for View\r\n\r\n7	Activity Diagram for Search\r\n  \r\nFig 3.18 Activity diagram for Search \r\n\r\n8	Activity Diagram for Approve\r\n  \r\n\r\nFig 3.19 Activity diagram for Approve\r\n9	Activity Diagram for generate report\r\n \r\n            Fig 3.20 Activity diagram for Generate Report\r\n\r\n        \r\n                 \r\n\r\n\r\n10	Activity Diagram for Request.\r\n\r\n \r\nFig 3.21 Activity diagram for Request.\r\n3.2.5 Analysis Level Class Diagram\r\n?	It represents the properties of entities, their operations and relationships. Also it drives use case diagrams from use case. \r\n?	The class diagram is the main building block in our project modelling. \r\n?	It is used both for general conceptual modelling of the systematic of the application and for detailed modelling translating the models into programming code. \r\n?	The classes in a class diagram represent both the main objects and or interactions in the application and the objects to be programmed. \r\n?	Generally the project is including the following class in the class diagram the over view of the class diagram is:-\r\n \r\nFigure 3.22 Analysis level class diagram.\r\n3.2.6 User Interface Prototyping\r\n      The Proposed system has several user interfaces to communicate easily with the User. Our team attempt to illustrate this interface in general as follows:-\r\n?	The system user interface should be consistent with all other program.\r\n?	The caption and the test of user interface should be self-descriptive and clear to understand.\r\n?	The user interface should be easy to understand.\r\n?	The user interface should be customized.\r\n?	The user interface should be accompanied with help files that describe the usage of each user interface.\r\n?	The user interface should be designed in the way that they can be extended easily to support localization.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n \r\nFigure 3.23 user interface prototyping\r\n\r\n\r\nChapter Four: System Design Using Object-Oriented Paradigm\r\n4.1 Introduction\r\nThis is the second phase of our project entitled Ambo University Online students clearance System. In this phase we are going to verify brief aspect of  phase one, and describe the phase two parts; detail description of chapter four which focused on  Object-Oriented design and system containing class diagram, deployment diagram, state diagram, and relational persistence modeling diagrams, and chapter five which focuses on System implementation. In general, in this phase we will describe detail of our system design and implementation.\r\n              Review of phase one (I) \r\nIn the last phase, we have tried to describe the following: [1]\r\n?	Chapter one: Introduction\r\nIn this chapter we have discussed the background of the organization, statement of the problem, and objectives of the problem, scope and limitations of the, and feasibility of the project.\r\n?	Chapter two: description of the existing system.\r\nIn this chapter we have described about current system including its practices, players of the system, business rules, alternative solutions to the existing system, functional and nonfunctional requirements user interface hardware/software requirements, and security.\r\n?	Chapter three: system analysis\r\nIn this chapter we have discussed use case diagram and dynamic model which contain sequence and activity diagrams of the system.\r\nIn phase two (II) of the Ambo University Online students clearance System, the following points will be discussed. \r\n?	Chapter four: system design.\r\n?	Chapter five: System implementation.\r\n4.2 Class type Architecture\r\n4.2.1 User Interface Layer: - This layer is the in which users used to access your system. There are two categories of interface class-user interface (UI) classes that provide people access to external system to tour system.\r\n4.2.2 Domain Layer :- This Layer implements the concepts relevant to your business domain such as student focusing  on the data aspects of the business objects, plus behaviours specific to individual objects.\r\n 4.2.3 Process Layer: - This process layer implements business logic that involves collaborating with several domain classes or even other process classes.\r\n 4.2.4 Persistence Layer: - This layer encapsulates the capability to store, retrieve, and delete objects/data permantly without revealing details of the underlying storage technology.\r\n 4.2.5 System Layer: - System classes provide operating system specific functionality for your application, isolating your software from the operating system (OS) by wrapping OS specific feature, increasing the portability of your application. \r\n\r\n\r\n\r\n\r\n	\r\n\r\n\r\n\r\n\r\n\r\n\r\n	\r\n\r\n\r\n\r\n\r\n                                                       \r\n\r\n                 Figure 4-1 Class type architecture\r\n\r\n4.3 Class Modelling\r\nClass Modeling is design level that introduces changes to analysis class model based on implementation technologies. It focuses on the solution domain instead of the problem domain. It shows static nature of how the software is built.\r\n \r\n                      Figure Class modelling 4.2\r\n\r\n\r\n\r\n4.3.1 Class modelling Description \r\n\r\n4.4 State chart modelling\r\n', '2015-05-27 06:58:52');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `MID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `IDNo` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` int(20) NOT NULL,
  `Offices` varchar(30) NOT NULL,
  `messagess` text NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`MID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`MID`, `Name`, `IDNo`, `Email`, `phone`, `Offices`, `messagess`, `time`) VALUES
(56, 'Gelana Abdias', 'R/3371/04', 'gelana@gmail.com', 912782518, 'library', 'true life.', 'Tuesday, 07/Apr/2015, 01:49:25pm'),
(59, 'GETE BERHANU le', 'R/3377/04', 'geteberhanu@gmail.com', 923243148, 'bookstore', 'i want clearance', 'Thursday, 09/Apr/2015, 10:16:35am'),
(61, 'Gelana', 'R/3327/04', 'getachewtemi@gmail.com', 923243148, 'sportscience', 'jkhkjh', 'Thursday, 09/Apr/2015, 09:39:05pm'),
(84, 'DameÂ Tegegn', '1518/03', 'dagm@gmail.com', 923237751, 'proctor', 'yes i am', 'Tuesday, 12/May/2015, 03:25:25pm'),
(96, 'KebeÂ Maru', 'R/3422/04', 'kebe@gmail.com', 917782517, 'registrar', 'HH', 'Monday, 01/Jun/2015, 09:47:26pm');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE IF NOT EXISTS `notice` (
  `NID` int(11) NOT NULL AUTO_INCREMENT,
  `Notice` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`NID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `notice`
--


-- --------------------------------------------------------

--
-- Table structure for table `outcomment`
--

CREATE TABLE IF NOT EXISTS `outcomment` (
  `msg` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`msg`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `outcomment`
--

INSERT INTO `outcomment` (`msg`, `message`, `Date`) VALUES
(4, '<h2><b>Debre Tabor  University Extend the STUDENT CLEARANCE PROCESSING SYSSTEM  for the 2021 acadamic Year</b></h2>\r\n\r\n\r\n<h4>DTU</h4>', '2021-04-07 10:01:02'),
-- --------------------------------------------------------

--
-- Table structure for table `readmore`
--

CREATE TABLE IF NOT EXISTS `readmore` (
  `RID` int(11) NOT NULL AUTO_INCREMENT,
  `readmessage` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`RID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `readmore`
--

INSERT INTO `readmore` (`RID`, `readmessage`, `date`) VALUES
(1, '<hr><h3>Call for Scientific Articles for Publication </h3><p>The Research \r\nand Community Services V/President Office, AU is pleased to notify that\r\n the Ethiopian Journal of Science and Technology (EJST), Vol. VI, No. 1 \r\nis online now and ...</p><p><a rel="nofollow" target="_self" title="back" href="../index.php">back</a></p><hr>\r\n<h3>The 2nd Annual Science Conference (ASC 2014)</h3><p>The 2nd Annual Science Conference (ASC –2014) 2– 3, May 2014 College of Science, Ambo University</p><p><a rel="nofollow" target="_self" title="Read More back" href="../index.php">back</a></p><hr>', '2015-06-01 13:05:25');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stud_id` varchar(15) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Department` varchar(40) NOT NULL,
  `Year` int(11) NOT NULL,
  `clearance_date` date NOT NULL,
  `clearance_reason` text NOT NULL,
  `print_status` enum('Printed','Not Printed','','') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `stud_id`, `Name`, `Department`, `Year`, `clearance_date`, `clearance_reason`, `print_status`) VALUES
(3, 'R/3422/04', 'Kebe Maru Mulatu', 'Computer Science', 4, '2015-06-01', 'JJJJJ', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `Fname` varchar(20) NOT NULL,
  `Mname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `PASSWORD2` varchar(30) NOT NULL,
  `Sex` enum('male','female','','') NOT NULL,
  `birth_date` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Idno` varchar(30) NOT NULL,
  `Phone` int(15) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Faculity` varchar(50) NOT NULL,
  `Year` int(11) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `security` varchar(30) NOT NULL,
  `lastlogin` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `imgid` int(20) NOT NULL,
  `PHOTO` varchar(100) NOT NULL,
  PRIMARY KEY (`Idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Fname`, `Mname`, `Lname`, `username`, `PASSWORD2`, `Sex`, `birth_date`, `Age`, `Idno`, `Phone`, `Email`, `Faculity`, `Year`, `Department`, `security`, `lastlogin`, `status`, `imgid`, `PHOTO`) VALUES
('Demiso', 'Damito', 'Lata', 'damto', '1233ASas', 'male', '1990/06/24 08:47', 26, 'R/3319/04', 912782517, 'demisodamito@gmail.com', 'Institute of Technology', 4, 'Computer Science', '123456789', '0000-00-00 00:00:00', 0, 66, ''),
('Eyerusalem ', 'Abreham', 'Ayele', 'jerry', '1234ASas', 'female', '1996/02/22 08:43', 23, 'R/3350/04', 923237752, 'jerryabreham500@gmail.com', 'Institute of Technology', 4, 'Computer Science', '53eb5935a8631302c29074f16c15b1', '0000-00-00 00:00:00', 0, 62, ''),
('Gelana', 'Abdissa', 'Duressa', 'galaxi', '123ASas', 'male', '1980/06/10 08:48', 29, 'R/3371/04', 910598046, 'gelanaabdissa@gmail.com', 'Institute of Technology', 4, 'Computer Science', 'f0f22d0e3f615e72658ec7860402ba', '0000-00-00 00:00:00', 1, 65, ''),
('Genet', 'Seyfe', 'Haile', 'geni', '12ASas', 'female', '1983/06/12 08:51', 24, 'R/3374/04', 937237751, 'geni@gmail.com', 'Institute of Technology', 4, 'Computer Science', '448afed499fc5f21aab4b594234b9e', '0000-00-00 00:00:00', 0, 61, ''),
('Getachew', 'Temi', 'Tegegne', 'gech', '1234567ASas', 'male', '1983/06/11 08:52', 24, 'R/3375/04', 924782517, 'getachewtemi17@gmail.com', 'Institute of Technology', 4, 'Computer Science', 'ef32eeff5e21c07dab7eb9bb583c4f', '0000-00-00 00:00:00', 1, 67, ''),
('abdc', 'gech', 'halie', 'hello', '123ASDasd', 'male', '2015/06/11 09:26', 34, 'R/3376/04', 912345678, 'getnetmelese@rocketmail.com', 'Institute of Technology', 4, 'Computer Science', '12345', '0000-00-00 00:00:00', 0, 0, ''),
('Gete', 'Berhanu', 'Tulu', 'gete', '123456ASas', 'female', '1984/06/22 08:54', 23, 'R/3377/04', 912782518, 'gete@rocketmail.com', 'Institute of Technology', 4, 'Computer Science', '9b90f23cdd8b43991a4b2e1375a32d', '0000-00-00 00:00:00', 0, 64, ''),
('Getnet', 'Melese', 'Embiale', 'gechm', 'ASas123', 'male', '1982/06/24 08:55', 25, 'R/3379/04', 918694620, 'getnetmelese@rocketmail.com', 'Institute of Technology', 4, 'Computer Science', '3c524084620b2d8b72b20689e0a1c6', '0000-00-00 00:00:00', 0, 63, ''),
('Hawa', 'Bati', 'Mohammed', 'hawi', 'ASas1234', 'male', '1980/06/10 08:48', 29, 'R/3389/04', 910598046, 'hawibati@gmail.com', 'Institute of Technology', 4, 'Computer Science', '02fdea8c984a544a75aba58ba4c367', '0000-00-00 00:00:00', 0, 0, ''),
('Iliham', 'Sultan', 'Mohammed', 'ilu', 'ASas12345', 'female', '1981/06/11 08:59', 27, 'R/3410/04', 918232412, 'ilu@gmail.com', 'Institute of Technology', 4, 'Computer Science', 'ff1db90a1593314bcdac8e87520ca8', '0000-00-00 00:00:00', 0, 0, ''),
('Kebe', 'Maru', 'Mulatu', 'kebe', '12AAaa', 'male', '1983/06/17 09:00', 24, 'R/3422/04', 917782517, 'kebe@gmail.com', 'Institute of Technology', 4, 'Computer Science', '2fbe492e1dd48e652101cf316a5241', '0000-00-00 00:00:00', 1, 0, ''),
('Faculity of Business', 'Temi2', 'MOHAMMED', '', '', 'female', '2015/06/01 22:03', 29, 'R/37nnnn75/04', 910598046, 'hawibati@gmail.com', 'FB', 2, 'FP', 'ffdggggggggggggggggggggg', '0000-00-00 00:00:00', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `uploadfile`
--

CREATE TABLE IF NOT EXISTS `uploadfile` (
  `FID` int(11) NOT NULL AUTO_INCREMENT,
  `File` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `size` int(11) NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `uploadfile`
--

INSERT INTO `uploadfile` (`FID`, `File`, `type`, `size`, `Date`) VALUES
(12, '92858-c-#.docx', 'application/vnd', 14, '2015-05-13 16:41:41'),
(13, '95109-feedback_management_system.zip', 'application/oct', 1072, '2015-05-13 16:42:22'),
(14, '83529-meskerem-getu-new-vcd-song-2007-áˆ°áˆ‹áˆá‰³áˆ…-á‹ˆá‹°-á‰ á‰´-áœˆá‰£...---youtube[via-torchbro', 'video/mp4', 12435, '2015-05-14 08:45:55'),


--
-- Constraints for dumped tables
--

--
-- Constraints for table `clearance`
--
ALTER TABLE `clearance`
  ADD CONSTRAINT `clearance_ibfk_1` FOREIGN KEY (`stud_id`) REFERENCES `student` (`Idno`);

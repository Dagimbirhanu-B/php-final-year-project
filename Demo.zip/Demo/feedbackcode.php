<?php
if(isset($_POST['submit']))
{
$name=$_POST["Name"];
$email=$_POST["Email"];
$office=$_POST["Office"];
$comment=$_POST["Comment"];
$time = date("l, d/M/Y, h:i:sa");
if(is_numeric($name) || is_numeric($email) || is_numeric($comment))

{ 
?>
<script type="text/javascript">
alert('All information must be character strings');
history.back();
</script>
<?php
}
else{
$query="insert into feedback(Name,Email,Offices,Comment,Date)
values('$name','$email','$office','$comment',now())";
mysqli_query($conn,$query);
?>
<script type="text/javascript">
alert('Thank you for your feedback!!!!.');
window.location="feedback.php";
</script>
<?php 
}
}
?>

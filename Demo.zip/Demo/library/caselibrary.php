<?php
include_once("headeroffices.php");
?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php">About Us</a></li>
<li class="current-menu-item"><a href="">Projects list</a></li>
<li class="current-menu-item"><a href="">Project enquiry</a></li>
<li class="current-menu-item"><a href="contact.php">Contact Us</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="library.php" title="Home">Home</a></li>
<li class="leaf"><a href="" title="">Blog</a></li>
<li class="leaf"><a href="">Articles</a></li>
<li class="leaf"><a href="" title="">Tutorials</a></li>
<li class="collapsed"><a href="" title="">Forums</a></li>
<li class="leaf"><a href="" title="">Contact</a></li>
<li class="leaf"><a href="">FAQ</a></li>
<li class="leaf"><a href="" title="">Submit Code</a></li>
<li class="expanded"><a href="">Mobile</a>
<ul class="menu">
<li class="first leaf"><a href="">Android</a></li>
<li class="leaf"><a href="">iOS</a></li>
<li class="leaf"><a href="">Windows Phone</a></li>
<li class="last leaf"><a href="">Firefox OS</a></li>
</ul>
</li>
<li class="expanded"><a href="">Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="caselibrary.php" title="Add New Case"class="active1">Add New Case</a></li>
<li class="leaf"><a href="trashlibrary.php" title="View Archive File">View Case File</a></li>
<li class="leaf"><a href="" title="">ASP/ASP.NET</a></li>
<li class="leaf"><a href="" title="">C#</a></li>
<li class="leaf"><a href="" title="">C/C++</a></li>
<li class="leaf"><a href="">Delphi</a></li>
<li class="leaf"><a href="" title="">Java</a></li>
<li class="leaf"><a href="">JavaScript</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting">Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help">Help</a></li>
<li class="leaf"><a href="../login.php?logged=out" title="logout">Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<!--Case menu bar -->
<div class="container">
<div class="panel">
          <div class="panel panel-default1">          
            <div class="panel-group">
                      <div class="alert alert-info">
						<center class="title"><div class="h3">Student Case List</div></center>
						</div>
                       <?php if(isset($_GET['id'])) {       $idnoo=$_GET['id'];         ?>
                       
                           <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
    								<div class=""><p><a href="addcase.php" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i>&nbsp;Add Case</a></p></div>
    							
                                    <thead>
                                        <tr>
    									    <th>Case ID.</th>                                 
                                            <th>Case Description</th>                                 
                                            <th>Date added </th>
    										
    										<th>Idno</th>
    			                            <th>Recorded By</th>
    										<th class="action">Action</th>		
                                        </tr>
                                    </thead>
                                    <tbody>
    								 
                                      <?php 
    
    							
        								  $cas="SELECT * FROM `cases` where staff='$role'and Idno='$idnoo'";
                                          $case_query = mysqli_query($conn,$cas) OR die(mysqli_error());
                                          $count = mysqli_num_rows($case_query);
                                          if($count>0)
                                          {
        									while($row = mysqli_fetch_array($case_query))
                                            {
        									   
            									$des=$row["description"];
                                                $case_id=$row["case_id"];
                                                $date=$row["date_added"];
                                                $idn=$row["Idno"];
        									    $usr=$row["by_user"];
                                                 $sel=mysqli_query($conn,"select * from account where Username='$usr'");
                                                $rowu=mysqli_fetch_array($sel);
                                                $fnm=$rowu['Fname'];
                                                $mnm=$rowu['Mname'];
                                           
                                            
    									?>
                                        
                                       
    									<tr class="del<?php echo $idn; ?>">
                                        <td><?php echo $case_id; ?></td>
                                        <td><?php echo $des; ?></td>
    									<td><?php echo $date; ?> </td>
                                       
                                        <td class="action"><?php echo $idn;   ?> </td>
                                       <td><?php echo $fnm." ".$mnm; ?> </td>
                                        <td class="action">
                                            <a  href="#delete_case<?php echo $case_id; ?>"  data-toggle="modal"    class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
                                            <?php include('model/delete_modal.php'); 
                                            
                                                         include_once("controller/delete_controller.php");
                                            
                                            
                                            ?>
                                                      
    									
    										
                                        </td>
    									
                                        </tr>
    									<?php  } 
                                                 
                                                        
                                                    
                                        
                                         } 
                                         else{
                                            echo "<div style='color:red; margin-left:140px; margin-top:-30px; margin-bottom: 40px;'>No Results Found</div>";
                                         }
                                         
                                          ?>
                               
                                    </tbody>
                                </table>
                           
                           
                        
                       
                       
                       <?php  }  else{  ?>
                       
                       
                            <table cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
								
								<p><a href="addcase.php" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i>&nbsp;Add Case</a></p>
							
                                <thead>
                                    <tr>
									    <th>Case ID.</th>                                 
                                        <th>Case Description</th>                                 
                                        <th>Date added </th>
										
										<th>Idno</th>
			                            <th>Recorded By</th>
										<th class="action">Action</th>		
                                    </tr>
                                </thead>
                                <tbody>
								 
                                  <?php 

							
    								  $cas="SELECT * FROM `case` where staff='$role'";
                                      $case_query = mysqli_query($conn,$cas) OR die(mysqli_error());
                                      $count = mysqli_num_rows($case_query);
                                      if($count>0)
                                      {
    									while($row = mysqli_fetch_array($case_query))
                                        {
    									   
        									$des=$row["description"];
                                            $case_id=$row["case_id"];
                                            $date=$row["date_added"];
                                            $idn=$row["Idno"];
    									    $usr=$row["by_user"];
                                       
                                        
									?>
                                    
                                   
                                    
                                    
                                    
                                    
                                    
									<tr class="del<?php echo $idn; ?>">
                                    <td><?php echo $case_id; ?></td>
                                    <td><?php echo $des; ?></td>
									<td><?php echo $date; ?> </td>
                                   
                                    <td class="action"><?php echo $idn;   ?> </td>
                                    <td><?php echo $usr; ?> </td>
                                    <td class="action">
                                        <a  href="#delete_case<?php echo $case_id; ?>"  data-toggle="modal"    class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
                                        <?php include('model/delete_modal.php'); 
                                        
                                                     include_once("controller/delete_controller.php");
                                        
                                        
                                        ?>
                                                  
									
										
                                    </td>
									
                                    </tr>
									<?php  } 
                                             
                                                    
                                                
                                    
                                     } 
                                     else{
                                        echo "<div style='color:red; margin-left:140px; margin-top:-30px; margin-bottom: 40px;'>No Results Found</div>";
                                     }
                                     
                                      ?>
                           
                                </tbody>
                            </table>
							<?php  }  ?>
              </div>
        </div>
  </div>
</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

<?php

 class Delete {

     function delete_U($un) 
     {
          $sql=mysql_query("delete from account where Username='$un'");
                            if($sql)
                            {
                                echo "</br>Successfully deleted";
                            }
                            else
                            {
                                echo "coudn't delete the user";
                            }
        
    }
    function delete_S($sid) 
     {
        
          $sqli=mysql_query("delete from clearance where stud_id='$sid'");
          $sqli=mysql_query("delete from clearance where stud_id='$sid'");
          $sqli1=mysql_query("delete from student where Idno='$sid'");
                            if($sqli and $sqli1)
                            {
                                echo "</br>Successfully deleted";
                            }
                            else
                            {
                                echo "coudn't delete the student";
                            }
        
    }
	function disable($sid) 
     {
          $sqli=mysql_query("update student set status='0', password ='$sid' where Idno='$sid'");
                            if($sqli)
                            {
                                echo "</br>Successfully Disabled";
                            }
                            else
                            {
                                echo "coudn't Disable the student account";
                            }
        
    }
	function enable($sid) 
     {
          $sqli=mysql_query("update student set status='1' where Idno='$sid'");
                            if($sqli)
                            {
                                echo "</br>Successfully Enabled";
                            }
                            else
                            {
                                echo "coudn't Enable the student account";
                            }
        
    }
	
	function disableu($un) 
     {
          $sqli=mysql_query("update account set status='1' where Username='$un'");
                            if($sqli)
                            {
                                echo "</br>Successfully Disabled";
                            }
                            else
                            {
                                echo "coudn't Disable the User account";
                            }
        
    }
	function enableu($un) 
     {
          $sqli=mysql_query("update account set status='0' where Username='$un'");
                            if($sqli)
                            {
                                echo "</br>Successfully Enabled";
                            }
                            else
                            {
                                echo "coudn't Enable the User account";
                            }
        
    }
	
	
	
	
    function delete_C($id,$idn,$role) 
     {
        
         $cas="SELECT * FROM `cases` where case_id='$id'";
                                      $case_query = mysql_query($cas) OR die(mysql_error());
    									while($row = mysql_fetch_array($case_query))
                                        {
    									   
        									$des=$row["description"];
                                            
                                            $date=$row["date_added"];
                                           
    									    $usr=$row["by_user"];
                                        }
                                    
            
          $case_trash=  mysql_query("INSERT INTO `case_trash`(`case_id`, `Idno`, `description`, `staff`, `by_user`,`date_added`,`date_returned`) VALUES ('$id','$idn','$des','$role','$usr','$date',now());");
          $sqlia=mysql_query("DELETE FROM `clearance`.`cases` WHERE `cases`.`case_id` = $id");
          if($sqlia)
          {
           $clear_query=  mysql_query("select * from `cases` where Idno='$idn' and staff='library'");
                      $num=  mysql_num_rows($clear_query);
                      if($num<=0)
                      {
                           $up_sql=  mysql_query("update library set $role='0' where stud_id='$idn'");
                           
                       }

                        
                        
                    
          } 
          else {
                           echo 'Unable to delete';
               }
    }


}
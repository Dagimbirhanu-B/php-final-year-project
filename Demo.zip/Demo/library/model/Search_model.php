
<?php 

class Search {

    function __construct() {
        
    }
    function Search_R($stud_ID) 
    {
        $sql_S="select * from student where Idno='$stud_ID'";
                        $sr=mysql_query($sql_S);
                        $row = mysql_fetch_array($sr);
                        $result = mysql_num_rows($sr);
                        if($result > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                            return 0;
                            
                        }
    }
    function Search_U($usname) 
    {
        $sql_S="select * from account where Username='$usname'";
                        $sr=mysql_query($sql_S);
                        $row = mysql_fetch_array($sr);
                        $result = mysql_num_rows($sr);
                        if($result > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                            return 0;
                            
                        }
    }
        function Search_C($stud_ID) 
    {
        include "../db_config/dbcon.php";
        $sql_S="select * from clearance where stud_id='$stud_ID'";
                        $sr=mysql_query($sql_S);
                        $row = mysql_fetch_array($sr);
                        $result = mysql_num_rows($sr);
                        if($result > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                            return 0;
                            
                        }
    }
    function search_case($id) 
    {
        $sql_case=  mysql_query("SELECT * FROM `case` where case_id='$id'");
                        
                        $row = mysql_fetch_array($sql_case);
                       $r = mysql_num_rows($sql_case);
                       if($r > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                             return 0;
                            
                        } 
    }
}
?>
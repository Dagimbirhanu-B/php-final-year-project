<?php
include_once("headeroffices.php");
?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="library.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                         <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='library'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxlibrary.php" title="Inbox Message"><i class="glyphicon glyphicon-inbox" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><strong><?php echo $number; ?></strong></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="leaf"><a href="question.php"title="FAQ" class="active" ><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;FAQ</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case ">Add New Case</a></li>
<li class="leaf"><a href="trashlibrary.php" title="View Archive File">View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="../help.php" title="help"><i class="glyphicon glyphicon-book" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 

<?php
if(isset($_GET['res']))
{
    $stud_ID=$_GET['res'];
    $search= new Clearance();
   $clr_res= $search->clear($stud_ID);
                            $responce['stud_id']=$clr_res['stud_id']; 
                            $responce['faculty']=$clr_res['faculty'];
                            $responce['department']=$clr_res['department'];
                            $responce['library']=$clr_res['library'];
                            $responce['bookstore']=$clr_res['bookstore'];
                            $responce['cafeteria']=$clr_res['cafeteria'];
                            $responce['dormitory']=$clr_res['dormitory'];
                            $responce['sport']=$clr_res['sport'];
                   
   
}

//clearance model

class Clearance {

    function __construct() {
        
    }

    function clear($stud_ID)
    {
        include "db_config/dbcon.php";
        $sq="select * from clearance where stud_id='$stud_ID'";
                        $sr=mysql_query($sq);
                        $row = mysql_fetch_array($sr);
                        return $row;
        
    }
    
    
}

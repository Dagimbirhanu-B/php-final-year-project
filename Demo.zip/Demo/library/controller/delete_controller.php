<?php
include 'model/delete_model.php';
    if(isset($_POST['delete']))
    {
       $un=$_POST["usname"];
	   
        
		
        $op=$_POST["op"];
		
        
		if($op=='enable')
		{
			
			$del=new Delete();
			$deluser= $del->enableu($un);
		}
		elseif($op=='disable')
		{
			
			$del=new Delete();
            $deluser= $del->disableu($un);
		}
		elseif($op=='delete')
		{
			
			    $del=new Delete();
				$deluser= $del->delete_U($un);
		}
		else
		{
			echo "pleasse select the operation";
		}
		
		
    }
    if(isset($_POST['delete_S']))
    {
        $sid=$_POST["Stid"];
        $op=$_POST["op"];
		
        
		if($op=='enable')
		{
			
			$del=new Delete();
			$deluser= $del->enable($sid);
		}
		elseif($op=='disable')
		{
			
			$del=new Delete();
			$deluser= $del->disable($sid);
		}
		elseif($op=='delete')
		{
				
				$del=new Delete();
			$deluser= $del->delete_S($sid);
		}
		else
		{
			echo "pleasse select the operation";
		}
		
    }
    if(isset($_GET['ide']))
    {
        include 'model/Search_model.php';
        $id=$_GET['ide'];
        $ser=new Search();
        $del=new Delete();
        $serccas=$ser->search_case($id);
        $idn=$responce['Idno'] = $serccas['Idno'];
        
        $delcase= $del->delete_C($id,$idn,$role);
        
        
    }
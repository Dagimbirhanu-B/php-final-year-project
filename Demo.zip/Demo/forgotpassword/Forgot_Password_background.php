<html>
<head>
<LINK REL="SHORTCUT ICON" HREF="fb_files/fb_title_icon/c.jpg" />
	<style>
		#singup_button
		{
			background:#69A74E;
			color:#FFFFFF;
			border-top-color:#3B6E22;
			border-right-color:#2C5115;
			border-left-color:#3B6E22;
			font-size:15px;
			height:30;
			width:75;
			font-weight:bold;
			box-shadow:-5px 0px 10px 1px rgb(0,0,0);
		}
	</style>
     <link href="fb_files/fb_font/font.css" rel="stylesheet" type="text/css">
</head>
<body>

<div style="position:absolute;left:0%;top:0%; height:13.2%; width:100%; z-index:-1; background-image: -webkit-linear-gradient(top, #ff6600, #222222);">   </div>
</body>
</html>
	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container1">
		<a class="branded">
		<img src="../image2/dtu1.jpg" width="100" height="90">
 	</a> 
	<a class="brand">
	 <h2></h2>
	 <div class="chmsc_nav"><font size="4" color="white">Debre Tabor University</font></div>
 	</a>
<div class="time">	
<font color="orange">
  <?php
 $Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font>
<br>
	<a href="../login.php" class="btn btn-warning"><i></i>&nbsp;Back to Home</a>
</div>
</div>
</div>
</div>
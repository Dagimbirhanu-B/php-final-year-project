<?php
include('header.php');
include('../db_config/dbcon.php');
include("Forgot_Password_background.php");
 include('index-nav.php');
?>
<?php
if(isset($_POST['Next3'])){ 
	$user_name=$_POST['ans2'];
	$que0=mysqli_query($conn,"select Password from account where Email='$user_name'");
	$rec0=mysqli_fetch_array($que0);
	$userid=$rec0[0];	

?>

<div style="position:absolute;left:35%;top:25%; height:10%; width:7%; z-index:-1; background:#339900; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute;left:45%;top:25%; height:10%; width:7%; z-index:-1; background:#339900; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute;left:55%;top:25%; height:10%; width:7%; z-index:-1; background:#339900; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute; left:36%; top:25%;"> <h2> Step 1 </h2> </div>
<div style="position:absolute; left:46%; top:25%;"> <h2> Step 2 </h2> </div>
<div style="position:absolute; left:56%; top:25%;"> <h2> Step 3 </h2> </div>

<div style="position:absolute;left:26%; top:30.8%; height:1; width:46.85%; background-color:#000000; z-index:-2 "> </div>
<div style="position:absolute;left:26%; top:30.8%; height:44.3%; width:0.08%; background-color:#000000; "> </div>
<div style="position:absolute;left:26%; top:75%; height:1; width:46.85%; background-color:#000000; "> </div>
<div style="position:absolute;left:72.75%; top:30.8%; height:44.3%; width:0.10%; background-color:#000000; "> </div>
<?php
	}
	else
	{
		header("location:Forgot_Password.php");
	}
?>
</body>
</html>
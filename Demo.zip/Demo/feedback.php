<?php
	include_once("header.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutclearance.php" title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php" title="Calander View"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="viewpost.php"title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
<li><a href=""><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Login</a>
<ul>
<li><a href="login.php?action=login"  title="Login Offices"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Officess Login</a></li>
<li><a href="loginstudent.php" title="Login Student"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Students Login</a></li>
</ul>
</li>
<li class="current-menu-item"><a href="registerstudent.php?action=registerstudent"title="Create Account"><i class="glyphicon glyphicon-save" ></i>&nbsp;Create Account</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div class="menu">
<ul>
<li><a href="index.php" title="Home"><i class="glyphicon glyphicon-home"></i>&nbsp;Home</a></li>
<li><a href="aboutus.php" title="About Us"><i class="glyphicon glyphicon-user"></i>&nbsp;About Us</a></li>
<li><a href="crule.php"title="Clearance Rule and Regulation"><i class="glyphicon glyphicon-file"></i>&nbsp;Cl Rule &amp; Regulation</a></li>
<li><a href="notice.php"title="Notice to Student"><i class="glyphicon glyphicon-time"></i>&nbsp;Notice to Student</a></li>
<li><a href="contactus.php"title="Contact Us"><i class="glyphicon glyphicon-share"></i>&nbsp;Contact Us</a></li>
<li><a href="feedback.php"title="Feed Back"class="active"><i class="glyphicon glyphicon-plane"></i>&nbsp;Feed Back</a></li>
<li><a href="help.php?action=help"title="Help Menu"><i class="glyphicon glyphicon-book"></i>&nbsp;Help</a></li>
</ul>
</div>
<div id="panel">
<div id="panel">			
</div>
</br>
</br>
</br>
</div>
<div class="size2">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div id="container">
<div class="panel">
<div class="hero-unit-bud11">
<ul class="nav nav-tabs"> 
  <li class="active"><a href="#developers" data-toggle="tab"><font color="blue">
  <i class="icon-pc-sign icon-large"></i></font><font color="orange">Feed Back</font></a></li>
</ul>
<div class="hero-unit-y">
 <h2>Feedback</h2>
<hr>
  <fieldset>
  <legend align="left">Fill the fields and Write your Comment here</legend>
<?php 
include('feedbackcode.php'); 
?>
<br /><br />
	<form id="feedback" class="form-horizontal" method="POST" action="feedback.php" >	
    <table cellpadding='5' style=" margin: auto; margin-top: -100px;">
                 <tr>
                       <div class="form-group">
                     <td>
                            <label class=" control-label">Name:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="Name" placeholder="Name" required=""/>
                    </td>
                    </div>
                 </tr>
                
				<tr>
	            <div class="form-group">
                     <td>
                            <label class=" control-label">Email:</label>
                    </td>
				
              <td>
			  <input type="email" name="Email" class="form-control" placeholder="email@gmail.com" required="" required="required">
               </td>
			   </div>
			 </tr>
			 <tr>
                    <div class="form-group">
                    <td>
                    <label class=" control-label">Send To:</label>
                    </td>
                    <td>
                    <div id="show_sub_categories">
                              <select  class="form-control" required='' name="Office">
                              <option value="">--select one--</option>
                              <?php
                                include("dbcon.php");
											$sql=mysqli_query($conn,"select * from account");
											while($row=mysqli_fetch_array($sql))
											{
											$office=$row['Role'];
									//		$id=$row['id'];
											 echo '<option value="'.$office.'">'.$office.'</option>';
											} 
                              ?>
                            </select>
                    </div>
                   </td>
                   </div>
                 </tr>
	<tr>
	<div class="form-group">
    <td>
	<label class="control-label" for="input01">Comment:</label>
    </td>
	<td>
    <textarea rows="6" cols="40" input="" type="text" name="Comment" placeholder="Write your comment here"required="required"></textarea> 
    </td>
	</div>
	</tr>
	<tr>
	<div class="control-group">
 <td></td>
 <td>
	<button id="save_voter" class="btn btn-primary" name="submit"><i class="icon-email"></i>Submit</button>
	</td>
	<td>
	<button id="reset" class="btn btn-primary" name="reset" type="reset"><i class="icon-removei"></i>Clear</button>
    </td>
	</div>
	</tr>
	 </table>
	</form>
    </fieldset>
 </div>
</div>
</div>
</div>
<?php 
include('footer.php'); 
?>
</body>
</html>
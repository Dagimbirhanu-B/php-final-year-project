<?php
include 'db_config/dbcon.php'; 
if(isset($_POST['action']) && $_POST['action'] == 'username_availability'){ 
	$username 		= htmlentities($_POST['username']); 
	$check_query	= mysqli_query('SELECT username FROM student WHERE username = "'.$username.'" '); 
	echo mysqli_num_rows($check_query); 
}
?>
<?php
session_start();
if(!isset($_SESSION['SESS_MEMBER_ID'])){
?>
 <script>
  alert('YOU ARE NOT ALLOWED TO ACCESS!!Please Login to access the page');
  window.location='../loginstudent.php';
 </script>	
<?php
 }
 include_once("headeroffices.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar" ><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts" class="active"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="student.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                           <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM inboxstudent WHERE IDNO='$_SESSION[SESS_MEMBER_ID]'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxstudent.php"title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Recieved Inbox&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>                              
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Student Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="viewcase.php" title="View Case List"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Case List</a></li>
<li class="leaf"><a href="viewclearance.php" title="View Clearance"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Clearance</a></li>
<li class="leaf"><a href="sendmessage.php" title="Send Message"><i class="glyphicon glyphicon-send" ></i>&nbsp;Send Message</a></li>
<li class="leaf"><a href="clearance_paper.php" title="Take Clearance"><i class="glyphicon glyphicon-ok" ></i>&nbsp;Take Clearance</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Settings</a></li>
</ul>
</li>
                                      <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
                                            if(mysqli_num_rows($nomessages)){
											while($row=mysqli_fetch_array($nomessages))
											{
											$image2="<img src='uploads/$row[imagepath]' width=40 height=40";
											}
											}
											else
											{
											$image2="<img src='images/profilepic.jpg' width=40 height=40";																						}
											?>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-user" ></i>&nbsp;Profile&nbsp;<sup><?php echo $image2; ?></sup></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="profile.php" title="View Profile"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Profile</a></li>
<li class="leaf"><a href="changepassword.php" title="Update Profile"><i class="glyphicon glyphicon-edit" ></i>&nbsp;&nbsp;Update Profile</a></li>
</ul>
</li>
<li class="leaf"><a href="feedback.php" title="Feedback Menu"><i class="glyphicon glyphicon-plane" ></i>&nbsp;Feed Back</a></li>
<li class="leaf"><a href="help.php" title="Help Menu"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; 
?>
</font> 
</div>
<div class="container1">
<div class="panel">
<div class="panel panel-default">
<div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                 This is Debre Tabor University Registrar File Upload 
                                </a>
								</h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse in">
                              <div class="panel-body">
							  <img src="../helpimage/download1.jpg" style="margin-left:70px;" width=1100px height="170px">
 <?php
 if(@$_GET["view"] == "download")//remember put her download code
{  
}

$result = mysqli_query($conn,"SELECT * FROM uploadfile");
?>
  <form name="form2" method="post" action="">
  <table  class="table" align="center" border="0" width="100%" id="example">                               
  <tr class="danger">
                                   <th>UPLOAD ID</th>
								   <th>FILE NAME</th>
								   <th>FILE TYPE</th>
								   <th>FILE SIZE</th>
                                   <th>TIME UPLOAD</th>
								   <th>DOWNLOAD</th>
  </tr>
  <?php
  while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
		  echo "<td>&nbsp;" . $row['FID'] . "</td>";
		  echo "<td>&nbsp;" . $row['File'] . "</td>";
		  echo "<td>&nbsp;" . $row['type'] . "</td>";
		  echo "<td>&nbsp;" . $row['size'] . "</td>";
          echo "<td>&nbsp;" . $row['Date'] . "</td>";
		  ?>
		  <td class="action">
          <a href='../registrar/uploads/<?php echo $row['File']; ?>' target="_blank" class="download_demo"><img src='../image/download.png' width="80" height="50"/></a>
		  </td>
		  <?php
		  echo "</tr>&nbsp;";
  }
?>
</table>
</form>
 </div>
 </div>
 </div>                
 </div> 
</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

<?php
 include_once("headeroffices.php");
 include('../db_config/dbcon.php');
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="student.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                           <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM inboxstudent WHERE IDNO='$_SESSION[SESS_MEMBER_ID]'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxstudent.php"title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Recieved Inbox&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>                              
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Student Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="viewcase.php" title="View Case List"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Case List</a></li>
<li class="leaf"><a href="viewclearance.php" title="View Clearance"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Clearance</a></li>
<li class="leaf"><a href="sendmessage.php" title="Send Message"><i class="glyphicon glyphicon-send" ></i>&nbsp;Send Message</a></li>
<li class="leaf"><a href="clearance_paper.php" title="Take Clearance"><i class="glyphicon glyphicon-ok" ></i>&nbsp;Take Clearance</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Settings</a></li>
</ul>
</li>             
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
                                            if(mysqli_num_rows($nomessages)>0){
											while($row=mysqli_fetch_array($nomessages))
											{
											$image2="<img src='uploads/$row[imagepath]' width=40 height=40";
											}
											}
											else
											{
											$image2="<img src='images/profilepic.jpg' width=40 height=40";																						}
											?>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-user" ></i>&nbsp;Profile&nbsp;<sup><?php echo $image2; ?></sup></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="profile.php" title="View Profile" class="active1"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Profile</a></li>
<li class="leaf"><a href="changepassword.php" title="Update Profile"><i class="glyphicon glyphicon-edit" ></i>&nbsp;&nbsp;Update Profile</a></li>
</ul>
</li>
<li class="leaf"><a href="feedback.php" title="Feedback Menu"><i class="glyphicon glyphicon-plane" ></i>&nbsp;Feed Back</a></li>
<li class="leaf"><a href="help.php" title="Help Menu"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; 
?>
</font> 
</div> 			
<div id="container">
<div id="content">
<?php
if(@$_POST[setid]==@$_SESSION[SESS_MEMBER_ID])
{
	if (isset($_POST["updprofile"]))
	{
			

			$sql = "UPDATE student SET username='$_POST[username]',Age='$_POST[age]',PASSWORD2='$_POST[password]',Phone='$_POST[cnumber]',Year='$_POST[year]' WHERE Idno='$_SESSION[SESS_MEMBER_ID]'";
				if(!mysqli_query($conn,$sql))
				{
					die('Error:'.mysqli_error());
				}
				else
				{
					$msg="<strong><font color='red'><br>Profile Updated successfully.</font></strong>";
				}

	}
}

if(@$_POST[setid]==$_SESSION[@SESS_MEMBER_ID])
{
	if (isset($_POST["submitimg"]))
	{
				$imagename = $_FILES['profilepic']['name'];
				$imgname = rand().$_FILES['profilepic']['name'];
				move_uploaded_file($_FILES['profilepic']['tmp_name'],"uploads/". $imgname);
			    
				//upload profile image code
				$sql="INSERT INTO images(Idno,imagepath,date) VALUES('$_SESSION[SESS_MEMBER_ID]','$imgname',NOW())";	
				if(!mysqli_query($conn,$sql))
				{
					die('Error:'.mysqli_error());
				}
				else
				{
					$msg1="<strong><font color='green'><br>Profile Updated successfully,.</font></strong>";
				}
				@$imgid = mysqli_insert_id($dbcon);
			//update profile image code
			   $sql = "UPDATE student SET imgid='$imgid' WHERE Idno='$_SESSION[SESS_MEMBER_ID]'";
				if(!mysqli_query($conn,$sql))
				{
					die('Error:'.mysqli_error($dbcon));
				}
				else
				{
					$msg1="<strong><font color='green'><br>Profile Image successfully,.</font></strong>";
				}

	}
}
$sqlsel = mysqli_query($conn,"SELECT * FROM student WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
$rsrec = mysqli_fetch_array($sqlsel);
@$_SESSION[setid]  = rand();
?>
<div class="col-md-7">
                             <?php 
    								  $cas="SELECT * FROM `student` WHERE Idno='$_SESSION[SESS_MEMBER_ID]'";
                                      $case_query = mysqli_query($conn,$cas) OR die(mysqli_error());
                                      $count = mysqli_num_rows($case_query);
                                      if($count>0)
                                      {
    									while($rows = mysqli_fetch_array($case_query))
                                        {
										    $fn=$rows["Fname"];
        									$mn=$rows["Mname"];
                                            $ln=$rows["Lname"];
                                            $idn=$rows["Idno"];
    									    $usr=$rows["username"];
											$pass=$rows['PASSWORD2'];
											$bd=$rows["birth_date"];
                                            $age=$rows['Age'];
                                            $phone=$rows['Phone'];
                                            $fac=$rows['Faculity'];
                                            $dept=$rows['Department'];
                                            $year=$rows['Year'];											
                                        } 				
                                      } 
                                    else{
                                    echo "<div style='color:red; margin-left:500px;  margin-top:0px; margin-bottom: 40px; font-weight:bold;'>No Results Found</div>";
                                     }
                            ?>									
<form name=f5 action="" method=post>
<table width="510" background='../images/bg.png' border="2">
<input type="hidden" name="setid" value="<?php echo @$_SESSION[SESS_MEMBER_ID]; ?>">
<tr><td colspan="2" align="center"><div class="navigation"><strong><font color="white"><h3>Your Profile is as follow</h3></font></strong><?php echo@ $msg; ?></div></td></tr>
<tr><td>User Name</td><td><input name=username type=text size="30" value="<?php echo $usr ; ?>"> </td></tr>
<tr><td>IDNO</td><td><input type="text" name="idno" value="<?php echo $idn ; ?>"   /></td></tr>
<tr><td>First Name</td><td><input name=fname type=text size="30" value="<?php echo $fn ; ?>" /></td></tr>
<tr><td>Midle Name</td><td><input name=mname type=text size="30" value="<?php echo $mn ; ?>" /></td></tr>
<tr><td>Last Name</td><td><input name=lname type=text size="30" value="<?php echo $ln; ?>" /></td></tr>
<tr><td>Birth Date</td><td><input name=birth type=text size="30" value="<?php echo $bd; ?>" /></td></tr>
<tr><td>Age</td><td><input name=age type=text size="30" value="<?php echo $age; ?>" /></td></tr>
<tr><td>Password</td><td><input name=password type=text size="30"  value="<?php echo $pass; ?>"   /></td></tr>
<tr><td>Phone Number</td><td><input name=cnumber type=text size="30"value="<?php echo $phone; ?>"   /></td></tr>
<tr><td>Faculty</td><td><input name=fac type=text size="30" value="<?php echo $fac; ?>" /></td></tr>
<tr><td>Department</td><td><input name=dept type=text size="30" value="<?php echo $dept; ?>" /></td></tr>
<tr><td>Year</td><td><input name=year type=text size="30" value="<?php echo $year; ?>" /></td></tr>
<tr><td colspan="2" align="center"><button type="submit" name="updprofile" id="updprofile" class="btn btn-info btn pull-right">Update profile</button></td></tr>
</table>
</form>
</div>
<div class="col-md-3picture">
<div class="border">
<?php
$chaturl = basename($_SERVER['PHP_SELF']) . "?" . $_SERVER['QUERY_STRING'];;
if(isset($_SESSION['SESS_MEMBER_ID']))
{
	$sqllogin2 = mysqli_query($conn,"SELECT * FROM student LEFT JOIN images ON student.imgid=images.imgid WHERE  student.Idno='$_SESSION[SESS_MEMBER_ID]'");##remember
	
	while($row = mysqli_fetch_array($sqllogin2))
	{
		@$fnamesession = $row[Fname];
        @$mnamesession = $row[Mname];		
		@$lnamesession = $row[Lname];	
		@$imgpathsession=$row[imagepath];
	}
}
			 echo "<b><h3>Welcome: </h3>".$fnamesession. " ". $mnamesession ." ". $lnamesession ."</b><hr>";
    
            if($imgpathsession == "")
	{	   
		echo "<img src='images/profilepic.jpg' >";
	}
	else
	{
		echo "<img src='uploads/$row[imagepath] >";
	}
       ?>-->
     <?php
	$sqllogin2 = mysqli_query($conn,"SELECT * FROM student LEFT JOIN images ON student.imgid=images.imgid WHERE  student.Idno='$_SESSION[SESS_MEMBER_ID]'");##remember
	
	while($row = mysqli_fetch_array($sqllogin2))
	{
		@$fnamesession = $row[Fname];	
		@$lnamesession = $row[Lname];	
		@$imgpathsession=$row[imagepath];
		 echo "<b><h3>Welcome: </h3><u>".@$fnamesession. " ". @$mnamesession ." ". @$lnamesession ."</u></b>";
	}
	                                       $nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
                                            if(mysqli_num_rows($nomessages)>0)
                                             {                                           
										   while($row=mysqli_fetch_array($nomessages))
											{
											echo "<img src='uploads/$row[imagepath]' width=350 height=390";
											}
											}
											else
											{
											echo "<img src='images/profilepic.jpg' width=350 height=420";
											}
                                         ?>
       <hr> 
       <form method="post" action="" enctype="multipart/form-data">
       <input type="hidden" name="setid" value="<?php echo@ $_SESSION[SESS_MEMBER_ID]; ?>">
       <input type="file" name="profilepic" >
       <input type="submit" class="btn btn-info btn pull-right" name="submitimg" value="Change Your Profile Picture">
	   <hr>
       </form>
	   </div>
      </div>
	  <br /><br />
	  <font color="red"><u><h2>Note:</h2></u></font><b>Your profile update is include as follow</b><br /><br />
	              1, User Name<br />
				  2, Age<br />
				  3, Password<br />
				  4, Phone Number<br />
				  5, Year
    </div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
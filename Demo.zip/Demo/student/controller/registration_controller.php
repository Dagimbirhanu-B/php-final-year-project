<?php
include "model/registration_model.php";

    // register students

    if(isset($_POST['Import']))
    {
        
        	
        $string = randomString(rand(7,7));
        if(isset($_POST["Import"])){
		

		$filename=$_FILES["file"]["tmp_name"];
		

		 if($_FILES["file"]["size"] > 0)
		 {
            
		  	$file = fopen($filename, "r");
	         while (($import = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
	           $string = randomString(rand(7,7));
              
	           $register=mysqli_query($conn,"INSERT INTO student(Fname,Mname,Lname,Sex,Age,Idno,Year,Department,security,password,status) values('$import[0]','$import[1]','$import[2]','$import[3]','$import[4]','$import[5]','$import[6]','$import[7]','$string','$import[5]','')");
               
               $clear=  mysqli_query($conn,"INSERT INTO clearance(stud_id,faculty,department,library,bookstore,cafeteria,dormitory,sport,Clearance) VALUES('$import[5]','','','','','','','','')");
              
               
               }
                if($register and $clear)
                    {
                        echo "Successfully Registered";
                    }
                    else
                    {
                        echo"<div style='color:red'>Invalid File:Please Upload CSV File.</div>";
                    }
               fclose($file);
          }
               

        
        }
        
        
    }
    if(isset($_POST['register']))
    {   	
        $string = randomString(rand(7,7));


        $fname=$_POST['Fname'];
        $mname=$_POST['Mname'];
        $lname=$_POST['Lname'];
        $sex=$_POST['Sex'];
        $age=$_POST['Age'];
        $idno=$_POST['IDNO'];
		$facality=$_POST['Fac'];
        $year=$_POST['Year'];
        $department=$_POST['Dept'];
		$photo=$_POST['Photo'];
        $query="SELECT * FROM student WHERE Idno='$idno'";
        $sqlm=mysqli_query($conn,"select * from departments where DName='$department'");
            $rowm=mysqli_fetch_array($sqlm);
            $yrr=$rowm['PYear'];
			$row1=mysqli_fetch_array($query);
			$id1=$row1['Idno'];
            $res    =  mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This Student is Already Registered');</script>";
            
            }
            elseif($year>$yrr)
            {
                echo "<script lang='javascript'> alert('This Year is not available in this department');</script>";
            
			}
			else{
                    $pass=md5($idno);
					$security=md5($fname);
                    $register=mysqli_query($conn,"INSERT INTO student(Fname,Mname,Lname,Sex,Age,Idno,Faculity,Year,Department,security,password,status,Photo) VALUES('$fname','$mname','$lname','$sex','$age','$idno','$facality','$year','$department','$security','$pass','','$photo')");
                    $clear=  mysqli_query($conn,"INSERT INTO clearance(stud_id,faculty,department,library,bookstore,cafeteria,dormitory,sport,Clearance) VALUES('$idno','','','','','','','','')");
                $result=mysqli_query($conn,$register);
                if(!$result){
                    echo ("<script lang='javascript'>alert('You are registered sucssesfully!!!')</script>".mysqli_error());
                 
				   }
                else{
                   echo ("<script lang='javascript'>alert('You are Not registered sucssesfully!!!')</script>".mysqli_error());
                 }
            }    
    }
 //sendmessage
 if(isset($_POST['sendmessage']))
{
$name=$_POST["Name"];
$id=$_POST["IDNO"];
$email=$_POST["Email"];
$phone=$_POST["Phone"];
$office=$_POST["Offices"];
$comment = trim($_POST['Comment']);
$dttim = date("l, d/M/Y, h:i:sa");
if(is_numeric($name) || is_numeric($email) || is_numeric($comment))
{ 
?>
<script type="text/javascript">
alert('All information must be character strings');
history.back();
</script>
<?php
}
else{
$query="INSERT INTO messages(Name,IDNo,Email,phone,Offices,messagess,time)
value('$name','$id','$email','$phone','$office','$comment','$dttim')";
mysqli_query($conn,$query);
?>
<script type="text/javascript">
alert('Your Message have be succesfully sent!!!!.');
window.location="sendmessage.php";
</script>
<?php 
}
}
//send comment
if(isset($_POST['commentsave']))
{
$mcomment=$_POST['mcomment'];
$mesgid=$_POST['mesgid'];
$registercomment=mysqli_query($conn,"INSERT INTO comments(comment,msg_id_fk,intime) VALUES('$mcomment',$mesgid,NOW())");
}
// register user
    if(isset($_POST['AddAccount']))
    {
        $fname=$_POST['Fname'];
        $mname=$_POST['Mname'];
        $lname=$_POST['Lname'];
        $sex=$_POST['Sex'];
        $username=$_POST['username'];
        $password=$_POST['pass1'];
        $role=$_POST['role'];
        $query    =    "SELECT * FROM account WHERE Username='$username'";
            $res    =    mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This User is Already Registered');</script>";
            
            }
            else{
                    $register=mysqli_query($conn,"INSERT INTO account(Fname,Mname,Lname,Username,Password,Sex,Role,status) VALUES('$fname','$mname','$lname','$username','$password','$sex','$role','')");
                    if($register)
                    {
                        echo "Successfully Registered";
                    }
            }
    }    
function randomString($length){
                $chars = "abcdefghijkmnopqrstuvwxyz0123456789";
                srand((double)microtime()*1000000);
                $str = "";
                $i=0;

                        while($i <= $length){
                                $num = rand() % 33;
                                $tmp = substr($chars, $num, 1);
                                $str = $str . $tmp;
                                $i++;
                        }
                return $str;
        }
     if(isset($_POST["secu"]))
     {
         $string = randomString(rand(7,7));
     }
     if(isset($_POST["case_save"]))
     {
         $sc=$_POST["security"];
         $case_d=$_POST["case_d"];
         $idno= $_POST['idno'];
         $new_c=new Registration();
         $cas=$new_c->register_case($role,$idno,$sc,$case_d,$Dname);
         if($cas=='1')
         {
             echo "<span class='glyphicon glyphicon-ok'></span> Successfully added";
         }
            elseif ($cas=='5') {
             echo '<img src="images/invalid.png" > Invalid security code';
         }
        else {
                echo '<img src="images/invalid.png" > Unable to add the case';
        }
     }
	 if(isset($_POST["Add_dep"]))
     {
	   $fac= $_POST['fac'];
	   $yr= $_POST['yr'];
	   $dname= $_POST['Dname'];
        $query    =    "SELECT * FROM departments WHERE Dname='$dname'";
            $res    =    mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                echo "<script lang='javascript'> alert('This Department is Already Registered');</script>";
                
                }
                
                else{
            	   $new_d=new Registration();
                   $dep=$new_d->register_dept($fac,$yr,$dname);
            	    if($dep=='1')
                     {
                         echo "<span class='glyphicon glyphicon-ok'></span> Successfully added";
                     }
                      else {
                         echo '<img src="images/invalid.png" > Invalid security code';
                     }
                     
	       }
	 
	 
	 
	}
    	 if(isset($_POST["Add_fac"]))
     {
	   $fname= $_POST['Fname'];
        $query    =    "SELECT * FROM faculty WHERE Fname='$fname'";
            $res    =    mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                echo "<script lang='javascript'> alert('This Faculty is Already Registered');</script>";
                
                }
                else{
            	   $new_d=new Registration();
                   $fac=$new_d->register_fac($fname);
            	    if($fac=='1')
                     {
                         echo "<span class='glyphicon glyphicon-ok'></span> Successfully added";
                     }
                      else {
                         echo '<img src="images/invalid.png" > Invalid security code';
                     }
                     
	       }
	 
	 
	 
	}

?>

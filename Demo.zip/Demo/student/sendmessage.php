<?php
include_once("headeroffices.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="student.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
                                           <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM inboxstudent WHERE IDNO='$_SESSION[SESS_MEMBER_ID]'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxstudent.php"title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Recieved Inbox&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>                              
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Student Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="viewcase.php" title="View Case List"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Case List</a></li>
<li class="leaf"><a href="viewclearance.php" title="View Clearance"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Clearance</a></li>
<li class="leaf"><a href="sendmessage.php" title="Send Message" class="active1"><i class="glyphicon glyphicon-send" ></i>&nbsp;Send Message</a></li>
<li class="leaf"><a href="clearance_paper.php" title="Take Clearance"><i class="glyphicon glyphicon-ok" ></i>&nbsp;Take Clearance</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Settings</a></li>
</ul>
</li>
                                      <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
                                            if(mysqli_num_rows($nomessages)){
											while($row=mysqli_fetch_array($nomessages))
											{
											$image2="<img src='uploads/$row[imagepath]' width=40 height=40";
											}
											}
											else
											{
											$image2="<img src='images/profilepic.jpg' width=40 height=40";																						}
											?>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-user" ></i>&nbsp;Profile&nbsp;<sup><?php echo $image2; ?></sup></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="profile.php" title="View Profile"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Profile</a></li>
<li class="leaf"><a href="changepassword.php" title="Update Profile"><i class="glyphicon glyphicon-edit" ></i>&nbsp;&nbsp;Update Profile</a></li>
</ul>
</li>
<li class="leaf"><a href="feedback.php" title="Feedback Menu"><i class="glyphicon glyphicon-plane" ></i>&nbsp;Feed Back</a></li>
<li class="leaf"><a href="help.php" title="Help Menu"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; 
?>
</font> 
</div> 
<div class="container">
<div class="tab-pane" id="home">
<div class="hero-unit-y">
<div class="panel panel-default" >
<div class="panel-body">
<div id="mainform">
<?php
$cas="SELECT * FROM `student` WHERE Idno='$_SESSION[SESS_MEMBER_ID]'";
                                      $case_query = mysqli_query($conn,$cas) OR die(mysqli_error());
                                      $count = mysqli_num_rows($case_query);
                                      if($count>0)
                                      {
    									while($rows = mysqli_fetch_array($case_query))
                                        {
										    $fn=$rows["Fname"];
        									$mn=$rows["Mname"];
											$email=$rows["Email"];
                                            $phone=$rows['Phone'];											
                                        } 				
                                      } 
                                    else{
                                    echo "<div style='color:red; margin-left:500px;  margin-top:0px; margin-bottom: 40px; font-weight:bold;'>No Results Found</div>";
                                     }
?>
			<form id="form" class="form-horizontal" method="POST" action="sendmessage.php">
				<h3>Fill Your Information!</h3><br/><br/><br/>
				<table cellpadding='5' style=" margin: auto; margin-top: -100px;">
                <tr>
                <div class="form-group">
                <td>
				<label class="control-label">Name:</label>
				</td>
				<td>
				<input type="text" class="form-control" name="Name"  placeholder="Your Name"required="" required x-moz-errormessage="input must contain at least one digit/the first letter uppercase/ next one is good if it is lowercase letter not obligation and be at least 6 character long " pattern="(?=.*[A-Z]).{6,15}"/>
				</td>
				</div>
				</tr>
				<tr>
                <div class="form-group">
                <td>
				<label class="control-label">IDNO:</label>
				</td>
				<td>
				<input type="text" class="form-control" name="IDNO"  placeholder="Your IDNO"required="" />
				</td>
				</div>
				</tr>
				<tr>
	            <div class="form-group">
                <td>
                <label class=" control-label">Email:</label>
                </td>
                <td>
			    <input type="email" name="Email"  class="form-control" name="email" placeholder="email@gmail.com" required="" required="required">
                </td>
			    </div>
			   </tr>
				<tr>
	            <div class="form-group">
                <td>
                <label class=" control-label">Phone:</label>
                </td>
                <td>
			    <input type="text" name="Phone"  placeholder="Your Phone Number(0924782517)" required x-moz-errormessage="input must contain 10 digit Number from 0-9 "  pattern="[0-9][0-9].{8,12}"required="">
                </td>
			    </div>
			    </tr>
			   <tr>
                    <div class="form-group">
                    <td>
                    <label class=" control-label">Send To:</label>
                    </td>
                    <td>
                    <div id="show_sub_categories">
                              <select  class="form-control" required='' name="Offices">
                              <option value="">--select one--</option>
                              <?php
											$sql=mysqli_query($conn,"select * from account");
											while($row=mysqli_fetch_array($sql))
											{
											$office=$row['Role'];
											@$id=$row['id'];
											 echo '<option value="'.$office.'">'.$office.'</option>';
											} 
                              ?>
                            </select>
                    </div>
                   </td>
                   </div>
                 </tr>
	<tr>
	<div class="form-group">
    <td>
	<label class="control-label" for="input01">Messages:</label>
    </td>
	<td>
	<textarea rows="6" cols="40" input="" type="text" name="Comment" placeholder="Write your message here"required x-moz-errormessage="Fill the field.Your message usage is at least 160 Character no more allowed to write. " pattern="(?=.*[A-Z]).{160,180}"></textarea> 
    </td>
	</div>
	</tr>
	<tr>
	<div class="control-group">
    <td></td>
    <td>
	<button name="sendmessage" class="btn btn-primary" Value="submit"><i class="glyphicon glyphicon-send" ></i>&nbsp;Send</button>
	</td>
	<td>
	<button id="reset" class="btn btn-primary" Value="reset" type="reset"><i class="glyphicon glyphicon-remove" ></i>&nbsp;Clear</button>
    </td>
	</div>
	</tr>
			   </table>
			</form>
	<?php
       include_once('controller/registration_controller.php');
      ?>
		</div>
     
</div>
</div>
 
</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>




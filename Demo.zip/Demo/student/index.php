<?php
	include_once("header.php");
	include_once("hover.php");
?>
<link rel="stylesheet" type="text/css" href="time2/jquery.datetimepicker.css"/>
<style type="text/css">
.custom-date-style {
	background-color: red !important;
}
</style>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutclearance.php" title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php" title="Calander View"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="viewpost.php"title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View New Posts</a></li>
<li><a href=""><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Login</a>
<ul>
<li><a href="login.php?action=login"  title="Login Offices"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Officess Login</a></li>
<li><a href="loginstudent.php" title="Login Student"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Students Login</a></li>
</ul>
</li>
<li class="current-menu-item"><a href="registerstudent.php?action=registerstudent"title="Create Account"><i class="glyphicon glyphicon-save" ></i>&nbsp;Create Account</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div class="menu">
<ul>
<li><a href="index.php" title="Home"class="active"><i class="glyphicon glyphicon-home"></i>&nbsp;Home</a></li>
<li><a href="aboutus.php" title="About Us"><i class="glyphicon glyphicon-user"></i>&nbsp;About Us</a></li>
<li><a href="crule.php"title="Clearance Rule and Regulation"><i class="glyphicon glyphicon-file"></i>&nbsp;Cl Rule &amp; Regulation</a></li>
<li><a href="notice.php"title="Notice to Student"><i class="glyphicon glyphicon-time"></i>&nbsp;Notice to Student</a></li>
<li><a href="contactus.php"title="Contact Us"><i class="glyphicon glyphicon-share"></i>&nbsp;Contact Us</a></li>
<li><a href="feedback.php"title="Feed Back"><i class="glyphicon glyphicon-plane"></i>&nbsp;Feed Back</a></li>
<li><a href="help.php?action=help"title="Help Menu"><i class="glyphicon glyphicon-question-sign"></i>&nbsp;Help</a></li>
</ul>

</div>
<div id="panel">
<div id="panel">			
</div>
</br>
</br>
</br>
</div>
<div class="size2">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<!--
<span id="quick_login" class="button2">WELLCOME TO Debre Tabor UNIVERSITY ONLINE STUDENT CLEARANCE SYSTEM&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="login.php?action=login"><font color="de1234">Login</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="registerstudent.php?action=registerstudent"><font color="de1234">Register</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span> 
-->	
<div id="content">			
<div id="container">
<div class="navigation">
<a class="active buttonnav" href="rule/dtrule.pdf" target="_new"><b>DEBRE TABOR UNIVERSITY RULE &amp; REGULATION</b></a>|| 
&nbsp;&nbsp;<font color="white"><b>YOU ARE HERE:</b></font><a class="active buttonnav" href=""><b>Home</b></a>
    <div class="searchindex">
	<form action="searchview.php" class="navbar-search form-inline" method="POST">
	<input name="searchword" id="mod-search-searchword" maxlength="20" alt="Go" class="inputbox" type="text" size="40" placeholder="search Keyword...(like clearance,student,and so on.. )"  onblur="if(this.value=='') this.value='search...';" onfocus="if(this.value=='search...') this.value='';" />
	<button type="submit" name="sa" value=""><i class="glyphicon glyphicon-search"></i>&nbsp;Search</button>
    </form>
	</div>
</div>
<div class="container">
        <div class="col-md-2">
            <h4><a href="#"> About Clearance </a></h4>
            <p>Clearance System is the system which clears the Debre Tabor University students by ensuring that they return the properties pertaining to the University. </p>
        <div class="accordion" id="accordion2">    
          <div class="accordion-group">  
          <div id="collapseOne1" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				   This system is proposed to solve problems related with giving clearance to the students. The system will serve as a more reliable and effective means of undertaking students clearance remove all forms of delay and stress. In this project the implementation is carried out with PHP scripting,APACHE Server, MYSQL as the database. 
            		       <div class="accordion-heading">
                                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2"  href="#collapseOne1"><button type="button" class="btn btn-default">Roll Back</button> </a> <br /> <br /> <br />
                         </div>
                
                
                </div>
			  </div>
                        <div class="accordion-heading">
                      <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2"  href="#collapseOne1"><button type="button" class="btn btn-default">Read More </button> </a>
                       </div>
              </div>
     </div>
<div class="col-md-s2">
<div class="module">
        <div class="inner">
				<div class="h3c">
				<div class="h3r">
				<div class="h3l"><h3 class="module-title"><center><u><h4 id="a"><span style="background-color:#3B5998;">Upcoming Events</h4></span></u></center></h3>
				</div>
				</div>
				</div>
<div class="module-body">
	        <!-- NS-DHTML - Newsscroller Self DHTML for Joomla 1.7 by Kubik-Rubik.de - Viktor Vogel --><div class="nsdhtml">
<div id="marqueecontainer" onmouseover="copyspeed=pausespeed" onmouseout="copyspeed=marqueespeed">
<div style="top: -2598px;" id="vmarquee" >
<h3>Welcome to Debre Tabor University, It was established in 2008. </h3><p>Their Excellencies Addisu Legesse and Demeke Mekonen laid the foundation stone on the eastern part of the town about 4 Kms away from its center on 126 hectares of land.</p><p><a rel="nofollow" target="_self" title="Read More" href="readmore/readmorea.php">Read More</a></p><hr>
<h3>Debre Tabor University Library and Documentation Directorate's
Vision: </h3><p>To be the center of technologically organized sufficient information sources that guarantee the satisfaction of users.</p><p><a rel="nofollow" target="_blank" title="Read More" href="readmore/readmorec.php">Read More</a></p><hr>
<h3>Debre Tabor University Library and Documentation Directorate's 
Mission:</h3><p>DTU Library and Documentation Directorate is committed to making information sources available and accessible through collecting and organizing sources of information.</p><p><a rel="nofollow" target="_self" title="Read More" href="readmore/readmored.php">Read More</a></p><hr>
</div>
</div>
</div>
<script type="text/javascript">// <![CDATA[
			/**
			 * Cross browser Marquee II- Dynamic Drive (www.dynamicdrive.com)
			*/
			var delayb4scroll="2000"
			var marqueespeed="2"
			var pauseit="1"
			var copyspeed=marqueespeed
			var pausespeed=(pauseit==0)?copyspeed:0
			var actualheight=''
			function scrollmarquee(){if(parseInt(cross_marquee.style.top)>(actualheight*(-1)+8))
			cross_marquee.style.top=parseInt(cross_marquee.style.top)-copyspeed+"px"
			else
			cross_marquee.style.top=parseInt(marqueeheight)+8+"px"}
			function initializemarquee(){cross_marquee=document.getElementById("vmarquee")
			cross_marquee.style.top=0
			marqueeheight=document.getElementById("marqueecontainer").offsetHeight
			actualheight=cross_marquee.offsetHeight
			if(window.opera||navigator.userAgent.indexOf("Netscape/7")!=-1){cross_marquee.style.height=marqueeheight+"px"
			cross_marquee.style.overflow="scroll"
			return}
			setTimeout('lefttime=setInterval("scrollmarquee()",60)',delayb4scroll)}
			if(window.addEventListener)
			window.addEventListener("load",initializemarquee,false)
			else if(window.attachEvent)
			window.attachEvent("onload",initializemarquee)
			else if(document.getElementById)
			window.onload=initializemarquee
			// ]]></script>
	        </div>
        </div>
	</div>
    </div>
 </div> 
        <div class="col-md-7">
            <center><h2><a href="http://www.dtu.edu.et" title="http://www.dtu.edu.et" target="_blanck"> Debre Tabor University Official Website</a></h2>
            <div id="carousel-example-generic" class="carousel slide">
              <!-- Indicators -->
              <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
              </ol>
              <!-- Wrapper for slides -->
         <div class="carousel-inner">
                <div class="item active">
                  <img src="../images/slide1.png" alt="Debre Tabor University" style="min-height:250px; min-width:100%">
                  <div class="carousel-caption">
                            <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  </div>
                </div>
                 <div class="item">
            			<img src="../images/slide2.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				  <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
                      <div class="item">
            			<img src="../images/slide3.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide4.jpg" alt="Debre Tabor university view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide5.jpg" alt="Debre Tabor university view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide6.jpg" alt="Debre Tabor university view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
				
					  <div class="item">
            			<img src="../image/slide8.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image/slide9.jpg" alt="Debre Tabor university view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image/slide10.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image/slide11.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image/slide12.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide13.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide14.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide15.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image/slide16.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image/slide17.jpg" alt="ambo university view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide18.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../image2/slide19.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
					  <div class="item">
            			<img src="../images/slide20.jpg" alt="Debre Tabor University view" style="min-height:250px; min-width:100%"/>
            			<div class="carousel-caption">
            				 <h3><font color="green">Debre Tabor University</font></h3>
            				  <p><font color="yellow">Online student clearance System</font></p>
							  <p><font color="red">We are the building Basis for the Development!</font> </p>
                  	</div>
            		  </div>
              </div>
            
              <!-- Controls -->
              <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                <span class="icon-prev"></span>
              </a>
              <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                <span class="icon-next"></span>
              </a>
            </div>
           </center>
        </div>
        <div class="col-md-2">
                <ul>
				<center>
                    <table class="table">
                        <tr>
                            <td><a href="#" class="btn btn-primary dropdown-toggle"><font color="white"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;&nbsp;CALANDR &nbsp;VIEW</font></a></td>
                        </tr>
						
                    </table>
				</center>
                 <script src="js2/calander.js" language="javascript" type="text/javascript"></script>
                <h3 align="left">CalanderWithTime</h3>
	            <input type="text" value="Clik here USee Time & Date" size="18"id="datetimepicker_dark"/>
<script src="time2/jquery.js"></script>
<script src="time2/jquery.datetimepicker.js"></script>
<script>/*
window.onerror = function(errorMsg) {
	$('#console').html($('#console').html()+'<br>'+errorMsg)
}*/
$('#datetimepicker').datetimepicker({
dayOfWeekStart : 1,
lang:'en',
disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
startDate:	'1986/01/05'
});
$('#datetimepicker').datetimepicker({value:'2015/04/15 05:03',step:10});

$('.some_class').datetimepicker();

$('#default_datetimepicker').datetimepicker({
	formatTime:'H:i',
	formatDate:'d.m.Y',
	defaultDate:'8.12.1986', // it's my birthday
	defaultTime:'10:00',
	timepickerScrollbar:false
});

$('#datetimepicker10').datetimepicker({
	step:5,
	inline:true
});
$('#datetimepicker_mask').datetimepicker({
	mask:'9999/19/39 29:59'
});

$('#datetimepicker1').datetimepicker({
	datepicker:false,
	format:'H:i',
	step:5
});
$('#datetimepicker2').datetimepicker({
	yearOffset:222,
	lang:'ch',
	timepicker:false,
	format:'d/m/Y',
	formatDate:'Y/m/d',
	minDate:'-1970/01/02', // yesterday is minimum date
	maxDate:'+1970/01/02' // and tommorow is maximum date calendar
});
$('#datetimepicker3').datetimepicker({
	inline:true
});
$('#datetimepicker4').datetimepicker();
$('#open').click(function(){
	$('#datetimepicker4').datetimepicker('show');
});
$('#close').click(function(){
	$('#datetimepicker4').datetimepicker('hide');
});
$('#reset').click(function(){
	$('#datetimepicker4').datetimepicker('reset');
});
$('#datetimepicker5').datetimepicker({
	datepicker:false,
	allowTimes:['12:00','13:00','15:00','17:00','17:05','17:20','19:00','20:00'],
	step:5
});
$('#datetimepicker6').datetimepicker();
$('#destroy').click(function(){
	if( $('#datetimepicker6').data('xdsoft_datetimepicker') ){
		$('#datetimepicker6').datetimepicker('destroy');
		this.value = 'create';
	}else{
		$('#datetimepicker6').datetimepicker();
		this.value = 'destroy';
	}
});
var logic = function( currentDateTime ){
	if( currentDateTime.getDay()==6 ){
		this.setOptions({
			minTime:'11:00'
		});
	}else
		this.setOptions({
			minTime:'8:00'
		});
};
$('#datetimepicker7').datetimepicker({
	onChangeDateTime:logic,
	onShow:logic
});
$('#datetimepicker8').datetimepicker({
	onGenerate:function( ct ){
		$(this).find('.xdsoft_date')
			.toggleClass('xdsoft_disabled');
	},
	minDate:'-1970/01/2',
	maxDate:'+1970/01/2',
	timepicker:false
});
$('#datetimepicker9').datetimepicker({
	onGenerate:function( ct ){
		$(this).find('.xdsoft_date.xdsoft_weekend')
			.addClass('xdsoft_disabled');
	},
	weekends:['01.01.2014','02.01.2014','03.01.2014','04.01.2014','05.01.2014','06.01.2014'],
	timepicker:false
});
var dateToDisable = new Date();
	dateToDisable.setDate(dateToDisable.getDate() + 2);
$('#datetimepicker11').datetimepicker({
	beforeShowDay: function(date) {
		if (date.getMonth() == dateToDisable.getMonth() && date.getDate() == dateToDisable.getDate()) {
			return [false, ""]
		}

		return [true, ""];
	}
});
$('#datetimepicker12').datetimepicker({
	beforeShowDay: function(date) {
		if (date.getMonth() == dateToDisable.getMonth() && date.getDate() == dateToDisable.getDate()) {
			return [true, "custom-date-style"];
		}

		return [true, ""];
	}
});
$('#datetimepicker_dark').datetimepicker({theme:'dark'})
</script>
</ul>
        </div>   
    </div>	
</div>
</div>
<?php
	include_once("footer.php");
?> 
</body>
</html>
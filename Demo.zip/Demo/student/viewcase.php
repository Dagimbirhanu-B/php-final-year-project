<?php
include_once("headeroffices.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="student.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                           <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM inboxstudent WHERE IDNO='$_SESSION[SESS_MEMBER_ID]'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxstudent.php"title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Recieved Inbox&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>                              
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Student Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="viewcase.php" title="View Case List" class="active1"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Case List</a></li>
<li class="leaf"><a href="viewclearance.php" title="View Clearance"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Clearance</a></li>
<li class="leaf"><a href="sendmessage.php" title="Send Message"><i class="glyphicon glyphicon-send" ></i>&nbsp;Send Message</a></li>
<li class="leaf"><a href="clearance_paper.php" title="Take Clearance"><i class="glyphicon glyphicon-ok" ></i>&nbsp;Take Clearance</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Settings</a></li>
</ul>
</li>
                                      <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
                                            if(mysqli_num_rows($nomessages)){
											while($row=mysqli_fetch_array($nomessages))
											{
											$image2="<img src='uploads/$row[imagepath]' width=40 height=40";
											}
											}
											else
											{
											$image2="<img src='images/profilepic.jpg' width=40 height=40";																						}
											?>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-user" ></i>&nbsp;Profile&nbsp;<sup><?php echo $image2; ?></sup></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="profile.php" title="View Profile"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Profile</a></li>
<li class="leaf"><a href="changepassword.php" title="Update Profile"><i class="glyphicon glyphicon-edit" ></i>&nbsp;&nbsp;Update Profile</a></li>
</ul>
</li>
<li class="leaf"><a href="feedback.php" title="Feedback Menu"><i class="glyphicon glyphicon-plane" ></i>&nbsp;Feed Back</a></li>
<li class="leaf"><a href="help.php" title="Help Menu"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; 
?>
</font> 
</div> 
<div class="container">
<div class="panel">
 <div class="tab-pane active" id="profile">
  <div class="hero-unit-y">
  <div class="history_chmsc">
                  <?php
                        @$Sidno = ucfirst($_SESSION["Idno"]);
                        $sec_query=mysqli_query($conn,"select * from student where Idno='$Sidno'");
                        while($row_s=mysqli_fetch_array($sec_query))
                        {
                                $fna=$row_s['Fname'];
                                $mna=$row_s['Mname'];
                                $lna=$row_s['Lname'];
                                $dep=$row_s['Department'];
                                $yer=$row_s['Year'];
                                $age=$row_s['Age'];
                        }  
                  ?>              
  <div class="pbody">
    		 <div class="alert alert-info">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
               <form action="#" class="navbar-search form-inline" method="POST">
                         <table border="0">
						 <tr>
						 <div class="required">
						 <td> Enter Your IDNO:</td>
    		             <td><input type="text"  placeholder="Search" required x-moz-errormessage="Pls Enter Your ID" name="stud_ID"/></td>
						 <td><button class="btn btn-warning" style="height:38px;" name="search_R">&nbsp;&nbsp;<i class="glyphicon glyphicon-search" ></i>&nbsp;Search</button></td>	
                         </div>
						</tr>
					    </table>
                </form> 
			   </div>
			   <?php
							if(isset($_POST['search_R']))
                                     {
                                    @$d=$_SESSION[SESS_MEMBER_ID];
                                    $ins="select * from cases WHERE Idno='{$d}' AND status='NOT_MODIFY'";
                                    $query=mysqli_query($conn,$ins);
                                    if(!$query){
                                        die("data selection  is failed".mysqli_error());
                                        }
								   if(mysqli_num_rows($query)>0)
                                      {										
	                              ?>
                  <table  class="table" align="center" border="1" width="100%" id="example">						   
								   <tr class="danger">
								   <th>FROM OFFICE</th>
                                   <th>CASE DESCRIPTION</th>
                                   <th>RECORDED BY</th>
								   <th>DATE ADDED</th>
                                   </tr>
								   <?php
                                     while($row=mysqli_fetch_array($query))
                                      {
									  $usr=$row["by_user"];
									  $uid=$row["Idno"];
									  $sel=mysqli_query($conn,"select * from account where Username='$usr'");
                                                $rowu=mysqli_fetch_array($sel);
                                                $fnm=$rowu['Fname'];
                                                $mnm=$rowu['Mname'];
									 $sel2=mysqli_query($conn,"select * from student where Idno='$_SESSION[SESS_MEMBER_ID]'");
                                                $rowu=mysqli_fetch_array($sel2);
                                                $fnm1=$rowu['Fname'];
                                                $mnm1=$rowu['Mname'];
												$lnm1=$rowu['Lname'];
								   ?>
                                 <tr>
                               <td><p><?php echo $row['staff']; ?></p></td>
                               <td><p><?php echo $row['description']; ?></p></td>
                               <td><p><?php echo $fnm." ".$mnm; ?></p></td>
							   <td><p><?php echo $row['date_added']; ?></p></td>
							   </tr>
                                  <?php
                                 }
								 }
								 else{
                                     echo '<img src="../images/invalid.png" >&nbsp;&nbsp;<font color="red"><b>You have not any property from the universty</b></font><br />';
                                     }
								 }
								 echo "NAME:&nbsp;&nbsp;" .@$fnm1."&nbsp;&nbsp; ".@$mnm1."&nbsp;&nbsp;".@$lnm1;
                                  ?>
                               </table>  
							   </div>
   </div>
 </div>
 </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>




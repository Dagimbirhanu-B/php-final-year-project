<?php
session_start();
if(!isset($_SESSION['SESS_MEMBER_ID']))
{
?>
 <script>
  alert('YOU ARE NOT ALLOWED TO ACCESS!!Please Login to access the page');
  window.location='../loginstudent.php';
 </script>
<?php
}
 include_once("headeroffices.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Debre Tabor University Online Student Clearance System</title>
<meta http-equiv='refresh' content='120'>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="keywords" content="online clearance system for graduating students,students,graduating,for,system,clearance,online,">
<meta name="description" content="Are you looking for online clearance system for graduating students ? See details of online clearance system for graduating studentss .We discussing online clearance system for graduating students in hot topic area and see more about it... ">
<meta http-equiv="Content-Script-Type" content="text/javascript">

<link rel="shortcut icon" href="../image2/dtu1.jpg" />
<link rel="stylesheet"   href="../css/global.css"  media="screen"/>
<link rel="stylesheet"   href="../css3/styles.css"  media="screen"/>
<link rel="stylesheet"   href="../css3/bootstrap.min2.css"  media="screen"/>
<link rel="stylesheet"   href="../css3/formstyles.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css3/font-awesome.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css3/bootstrap-datetimepicker.min.css"  media="screen"/>
<link rel="stylesheet"   href="../css/container.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css2/topheadernavigation.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css2/mainmenunavigation.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css3/icon.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css3/font-awesomeicon.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="../css/refreshform.css" media="screen"type="text/css"/>


    <script src="../js2/jquery.dataTables.js" language="javascript" type="text/javascript"></script>
    <script src="../js2/bootstrap-popover.js" language="javascript" type="text/javascript"></script>
    <script src="../js2/bootstrap-collapse.js" language="javascript" type="text/javascript"></script>
    <script src="../js2/va.js" language="javascript" type="text/javascript"></script>
    <script src="../js2/bootstrap-datetimepicker.min.js" language="javascript" type="text/javascript"></script>
    <script src="../js/jquery.js" language="javascript" type="text/javascript" ></script>
    <script src="../js2/google-code-prettify/prettify.js" language="javascript" type="text/javascript"></script>
    <script src="../js2/holder/holder.js" language="javascript" type="text/javascript"></script>
    <script src="../js2/bootstrap.min.js" language="javascript" type="text/javascript"></script>
</head>
<?php 
include('../db_config/dbcon.php');
 ?>
<body></br>
<div class="logo">
<img src="../images/capture7.jpg" alt="Debre Tabor University Logo" width="1147" height="110"style="margin-top:23px; margin-left:-5px;">
<img src="../images/ribbon.png" alt="Debre Tabor University Logo" width="100" height="115"style="margin-top:20px; margin-left:-10px;">
</div>
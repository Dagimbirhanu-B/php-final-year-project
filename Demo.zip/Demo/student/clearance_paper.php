<?php
include_once("headeroffices.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="student.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>                                           
										   <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM inboxstudent WHERE IDNO='$_SESSION[SESS_MEMBER_ID]'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxstudent.php"title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Recieved Inbox&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>                              
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Student Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="viewcase.php" title="View Case List"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Case List</a></li>
<li class="leaf"><a href="viewclearance.php" title="View Clearance"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View Clearance</a></li>
<li class="leaf"><a href="sendmessage.php" title="Send Message"><i class="glyphicon glyphicon-send" ></i>&nbsp;Send Message</a></li>
<li class="leaf"><a href="clearance_paper.php" title="Take Clearance" class="active1"><i class="glyphicon glyphicon-ok" ></i>&nbsp;Take Clearance</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Settings</a></li>
</ul>
</li>
                                      <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$_SESSION[SESS_MEMBER_ID]'");
                                            if(mysqli_num_rows($nomessages)){
											while($row=mysqli_fetch_array($nomessages))
											{
											$image2="<img src='uploads/$row[imagepath]' width=40 height=40";
											}
											}
											else
											{
											$image2="<img src='images/profilepic.jpg' width=40 height=40";																						}
											?>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-user" ></i>&nbsp;Profile&nbsp;<sup><?php echo $image2; ?></sup></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="profile.php" title="View Profile"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Profile</a></li>
<li class="leaf"><a href="changepassword.php" title="Update Profile"><i class="glyphicon glyphicon-edit" ></i>&nbsp;&nbsp;Update Profile</a></li>
</ul>
</li>
<li class="leaf"><a href="feedback.php" title="Feedback Menu"><i class="glyphicon glyphicon-plane" ></i>&nbsp;Feed Back</a></li>
<li class="leaf"><a href="help.php" title="Help Menu"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; 
?>
</font> 
</div>
<div class="container">   
<div class="panel panel-default" >
<div class="container12">
<div class="alert alert-info">
                 <form action="#" class="navbar-search form-inline" method="POST">
                         <table border="0">
						 <tr>
						 <div class="required">
						 <td> Enter Your IDNO:</td>
    		             <td><input type="text" value="<?php echo @$_SESSION[SESS_MEMBER_ID];?>"  placeholder="Search" required x-moz-errormessage="Pls Enter Your ID" name="stud_ID"/></td>
						 <td><button class="btn btn-warning" style="height:38px;" name="search_R">&nbsp;&nbsp;<i class="glyphicon glyphicon-search" ></i>&nbsp;Search</button></td>	
                         </div>
						</tr>
						<button onclick="PrintDiv()" class="btn btn-info btn pull-right" name="Report" type="submit" title="Print"style="margin-top:13px;"><span class="glyphicon glyphicon-print "></span> Print</button> 
					    </table>
                </form> 
			   </div>
          </div> 
		  <?php
		  if(isset($_POST['Report']))
                               {
                                 @$idno=$_SESSION[SESS_MEMBER_ID];
                                $sqlq=mysqli_query($conn,"UPDATE report set print_status='1' WHERE stud_id='$idno'");
                               }
		  ?>
                          <?php
							if(isset($_POST['search_R']))
                                     {
                                    @$d=$_SESSION[SESS_MEMBER_ID];
                                    $ins="select * from report WHERE stud_id='{$d}'";
                                    $query=mysqli_query($conn,$ins);
                                    if(!$query){
                                        die("data selection  is failed".mysqli_error());
                                        }
									if(mysqli_num_rows($query)>0)
                                      {
                                     while($row=mysqli_fetch_array($query))
                                      {
									  $usr=$row["stud_id"];
									  $uid=$row["Name"];
									  $uid=$row["Department"];
									  $uid=$row["Year"];
									  $uid=$row["clearance_date"];
									  $uid=$row["clearance-reason"];
                       ?>
	<h3 class="panel-title">Print View Status of the Student</h3>
<div class="panel-body" style="font-family: times new roman;" >
  <div id="divToPrint" style=" width: 600px; margin-left: 300px;">
  <div style="border: dashed;background: silver;">
    <center>****************************************************<br />
    <img src="../image2/dtu1.jpg" title="Debre Tabor University Logo"width="200" height="200" class="img-circle"/><br /><br />
<div class="sizeprint">
<font color="white"> DATE:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<div class="sizeprint2">
       <h3><font color="green"><b><p>Debre Tabor UNIVERSITY</p></b></font></h3>
        <h4><font color="yellow"><b><p>Student Termination Clearance/Withdrawal Forms/</p></b></font></h4>
        <h4><font color="red"><b><p>For Regular Undergraduate Only</p></b></font></h4>****************************************************<br />
		<u>This student is sertified from university property.</u>
        </center>
        <table cellpadding='7' style="margin-left: 30px;" >
                                            <tr>
                                            	<td> Student Name: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['search_R']))
                                                             {
                                                                echo $row["Name"];
                                                              }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>IDNo:</td>
                                            	<td><?php                        
                                                             if(isset($_POST['search_R']))
                                                             {
                                                                echo $row["stud_id"];
                                                              }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Year: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['search_R']))
                                                             {
                                                                echo $row["Year"];
                                                              }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Department: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['search_R']))
                                                             {
                                                                echo $row["Department"];
                                                              }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Clearance Date: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['search_R']))
                                                             {
                                                                echo $row["clearance_date"];
                                                              }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Clearance Reason: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['search_R']))
                                                             {
                                                                echo $row["clearance_reason"];
                                                              }
                                                    ?>
												</td>
                                            </tr>

                                   </table> 
                                   
                                   <br />
        
    
  <center>****************************************************<br /></center> 
    <?php
	}
	}
	else{
          echo '<img src="../images/invalid.png" >&nbsp;&nbsp;Your Clearance is not send form the registrar <br />Please contact the registrar again.';
         }
	}?>
    </div>
    </div>
   </div>
   
    <script type="text/javascript">     
                                                function PrintDiv() {    
                                                   var divToPrint = document.getElementById('divToPrint');
                                                   var popupWin = window.open('', '_blank', 'width=600,height=600');
                                                   popupWin.document.open();
                                                   popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
                                                    popupWin.document.close();
                                                  }
   </script>
    
  </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
<?php
if(isset($_POST['register']))
    {   
	    $secure=$_POST['secure'];
        $username=$_POST['username'];
        $password=$_POST['password'];
        $query="SELECT * FROM student WHERE security='$secure'";
            $row1=mysqli_fetch_array($query);
			$id1=$row1['Idno'];
            $res=mysqli_query($conn, $query);
			$query2="SELECT * FROM student WHERE username='$username'";
            $res2=mysqli_query($conn, $query2);
			$query3="SELECT * FROM student WHERE PASSWORD2='$password'";
            $res3=mysqli_query($conn, $query3);
            if(mysqli_num_rows($res2)>0)
            {
                 echo "<script lang='javascript'> alert('This User Name is Already Registered');</script>";
            }
			elseif(mysqli_num_rows($res3)>0)
            {
               echo "<script lang='javascript'> alert('This Password is Already Registered');</script>";
            }
        else
		{
            if(mysqli_num_rows($res)>0)
            {  
               $register=mysqli_query($conn,"UPDATE student SET username='$username',PASSWORD2='$password' WHERE security='$secure'");
               echo ("<script lang='javascript'>alert('Create Account is sucssesfully!!!')</script>".mysqli_error());
			}
            else
            {
			echo "<script lang='javascript'> alert('You must Register before create your account');</script>";  
			}
        }			
    }
?>
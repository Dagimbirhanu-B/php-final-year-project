<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Post Comments"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" class="active1"><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="deletepost.php" title="Register Student">Register Studen</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Students</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<!--post comment menu bar -->
<div class="container">
<div class="panel">
<ul class="nav nav-tabs"> 
  <li class="active"><a href="#" data-toggle="tab"><font color="blue"></font><font color="orange"><h2>Post Comment Idea</h2></font></a></li>
</ul>
<div class="hero-unit-y">
 <h2>Write your Comment here to Post Comment</h2>
<hr class="hr">

<br /><br /><br /><br /><br /><br /><br /><br />
<div class="col-md-3l">
<?php 
//include('commentpost.php'); 
?>
	<form  class="form-horizontal" method="POST" action="postcomment.php" >	
    <table cellpadding='5' style=" margin: auto; margin-top: -100px;">            
	<tr>
	<div class="form-group">
    <td>
	<label class="control-label" for="input01">Comments:</label>
    </td>
	<td>
    <textarea rows="10" cols="80" input="" type="text" name="Comment" placeholder="Write your post comment here(it can be also possible to write more paragraph)"required="required"></textarea> 
    </td>
	</div>
	</tr>
	<tr>
	<div class="control-group">
   <td></td>
   <td>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<button id="save_voter" class="btn btn-primary" name="submit"><i class="glyphicon glyphicon-upload" ></i>&nbsp;Post</button>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<button id="reset" class="btn btn-primary" name="reset" type="reset"><i class="glyphicon glyphicon-remove" ></i>&nbsp;Clear</button>
	</div>
	</tr>
	 </table>
	</form>
	</div>
    <div class="col-md-3li">
	<form action="upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file" />
   <div class="control-group">
   <button type="submit" name="btn-upload" class="btn btn-primary" style="margin-top:-20px; margin-left:315px"><i class="glyphicon glyphicon-upload" ></i>&nbsp;upload</button><br />
   </div>
 </form>
 <?php
 if(isset($_GET['success']))
 {
  ?>
        <br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
        <label>File Uploaded Successfully...&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view.php" class="btn btn-primary" style="margin-top:-20px; margin-left:225px"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;click here to view file.</a></label>
        <?php
 }
 else if(isset($_GET['fail']))
 {
  ?>
  <br /><br />
        <label><h4><b>Problem While File Uploading !!!</b></h4></label>
        <?php
	}
 else
 {
  ?>
  <br /><br />
        <label><h4><b>Try to upload any files(PDF, DOC,TXT,PPT,ACC EXE, VIDEO, MP3, ZIP,etc...)</b></h4></label>
        <?php
 }
 ?>
	</div>
 </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

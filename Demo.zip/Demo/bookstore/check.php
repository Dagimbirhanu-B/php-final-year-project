<?php
include_once("headeroffices.php");
?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="bookestore.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                         <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='bookstore'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxbookstore.php" title="Inbox Message" class="active"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><strong><?php echo $number; ?></strong></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="casebookstore.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashbookstore.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<!--Library menu bar -->
<div class="container">
<div class="panel">
          <div class="panel panel-default">          
            <div class="panel-group">	
			   <div class="alert alert-info">
                        <form action="single.php" class="navbar-search form-inline" method="POST">
                         <table border="0">
						 <tr>
						 <?php
						 @$id3=$_GET[slid];
						 ?>
						 <div class="required">
						 <td> Enter Your IDNO:</td>
    		             <td><input type="text" value="<?php echo $id3;?>" name="stud_ID"/></td>
						 <td><button class="btn btn-warning" style="height:38px;" name="search_R">&nbsp;&nbsp;<i class="glyphicon glyphicon-search" ></i>&nbsp;Search</button></td>	
                         </div>
						</tr>
						</table>
						<a href='inboxbookstore.php#'class="btn btn-info btn pull-right" style="float: right; margin-right: -13px; margin-top:-25px;"><span class="glyphicon glyphicon-hand-left"></span> Back</a>  			
                </form> 
				</div>
                            <table class="table"cellpadding="0" cellspacing="0" border="1" class="table  table-bordered" id="example">
                                <thead>
                                    <tr class="danger">
									    <th>SNO.</th>										
                                        <th>IDNO</th>
										<th>Student Name</th>
										<th>Department</th>										
                                        <th>Case Description</th>                                 
                                        <th>Date Added </th>
			                            <th>Recorded By</th>
										<th>Status</th>
                                        <th>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Action</th>										
                                    </tr>
                                </thead>
                                <tbody>
								 <?php
								       $i=1;
									   $cas="SELECT * FROM `cases` WHERE staff='bookstore'";
                                      $case_query = mysqli_query($conn,$cas) OR die(mysql_error());
                                      $count = mysqli_num_rows($case_query);
                                      if($count>0)
                                      {
    									while($row = mysqli_fetch_array($case_query))
                                        {
										    $des=$row["case_id"];
        									$case=$row["description"];
                                            $date=$row["date_added"];
                                            $idn=$row["Idno"];
    									    $usr=$row["by_user"];
											$status=$row["status"];
                                        $sel=mysqli_query($conn,"select * from account where Username='$usr'");
                                                $rowu=mysqli_fetch_array($sel);
                                                $fnm=$rowu['Fname'];
                                                $mnm=$rowu['Mname'];
										$clearance=mysqli_query($conn,"select * from account where Username='$usr'");
                                                $role2=mysqli_fetch_array($clearance);
                                        $student=mysqli_query($conn,"select * from student where Idno='$idn'");
                                                $rows=mysqli_fetch_array($student);
                                                $sfnm=$rows['Fname'];
                                                $smnm=$rows['Mname'];
                                                $dept=$rows['Department'];
										$clearance1=mysqli_query($conn,"select * from clearance WHERE stud_id='$idn'");
                                                $rows=mysqli_fetch_array($clearance1);
                                                $id1=$rows['stud_id'];		
										
									?>
									<tr class="del<?php echo $idn; ?>">
                                    <td><?php echo $i; ?></td>
									<td class="action"><?php echo $idn;?> </td>
									<td><?php echo $sfnm." ".$smnm; ?> </td>
									<td><?php echo $dept; ?> </td>
									<td><?php echo $case; ?></td>
                                    <td><?php echo $date; ?></td>
                                    <td><?php echo $fnm." ".$mnm; ?> </td>
									<?php
									if($_GET["delete"] == "modify")
                                    {
                                  $message="You are cleared from BOOK STORE";
								  $dttim = date("l, d/M/Y, h:i:sa");
								  $query=mysqli_query($conn,"INSERT INTO inboxstudent(IDNO,Messages,Date) VALUES('$_GET[slid1]','$message','$dttim')"); 									
                                  
								  $sql=mysqli_query($conn,"UPDATE  cases set status='MODIFY' WHERE staff='bookstore' AND Idno='$_GET[slid1]'");
								  $sql1=mysqli_query($conn,"UPDATE clearance set bookstore='0' WHERE stud_id ='$_GET[slid1]'");
								  $sql2=mysqli_query($conn,"UPDATE clearance set Clearance='0' WHERE stud_id ='$_GET[slid1]'");  
								 }
									?>	
									<td><?php echo $status;?></td>
                                    <td class="action">
                                            <a href='check.php?slid1=<?php echo $row["Idno"]; ?>&delete=modify' class="btn btn-success" onclick="return confirm('Are you sure you want to modify data?? IDNO <?php echo $idn; ?>')"><span class="glyphicon glyphicon-pencil"></span></a>
											<a href='check.php?slid=<?php echo $row["Idno"]; ?>&view=delete'  class="btn btn-danger" onclick="return confirm('Are you sure you want to delete data?? IDNO <?php echo $idn; ?>')"><span class="glyphicon glyphicon-trash"></span></a>
											<?php 
											$i++;
											include('model/delete_modal.php'); 
                                            include_once("controller/delete_controller.php");
											include_once("controller/update_controller.php");
                                            ?>
                                        </td>
									</tr>
									<?php  
									} 				
                                     } 
                                     else{
                                        echo "<div style='color:red; margin-left:140px;  margin-top:0px; margin-bottom: 40px; font-weight:bold;'><h2>No Case Results Found in the database.<br />This means the student haven't any property from the library.</h2> </div>";
                                     }
                                      ?>
                           
                                </tbody>
                            </table>
					             <?php
									if(@$_GET["view"] == "delete")
                                    {
								  $message="You are cleared from BOOK STORE";
								  $dttim = date("l, d/M/Y, h:i:sa");
								  $query=mysqli_query($conn,"INSERT INTO inboxstudent(IDNO,Messages,Date) VALUES('$_GET[slid]','$message','$dttim')"); 									
                                  
									
                                  $sql=mysqli_query($conn,"DELETE FROM cases WHERE staff='bookstore' AND Idno ='$_GET[slid]'");
								  $sql1=mysqli_query($conn,"UPDATE clearance set bookstore='0' WHERE stud_id ='$_GET[slid]'");
								  $sql2=mysqli_query($conn,"UPDATE clearance set Clearance='0' WHERE stud_id ='$_GET[slid]'");
								  }
									?>						
		 </div>
        </div>
  </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?>
</body>
</html>

<?php

class Registration {

    function register_case($role,$idno,$sc,$case_d,$userNameD) {
        $sql0=  mysqli_query($conn,"Select * from student where Idno='$idno'");
        while($rowk=  mysqli_fetch_array($sql0))
        {
            $key=$rowk["security"];
        }
        if($sc!=$key)
        {
            return 3;
            
        }
        else {
              $sql1=  mysqli_query($conn,"INSERT INTO `cases`(`case_id`, `Idno`, `description`, `staff`, `by_user`,`date_added`) VALUES ('','$idno','$case_d','$role','$userNameD',now());");
              $sql2=  mysqli_query($conn,"UPDATE `clearance` SET `$role`='1' WHERE stud_id='$idno'");
              if($sql1 and $sql2)
              {
                  return 1;
              }
              else
              {
                  return 0;
              }
        }
    }
    function register_dept($fac,$yr,$dname)
    {
        $sql1=  mysqli_query($conn,"INSERT INTO `departments`(`id`, `Dname`, `Fname`, `Program_year`) VALUES ('','$dname','$fac','$yr')");
        if($sql1)
              {
                  return 1;
              }
              else
              {
                  return 0;
              }
    }
    function register_fac($fname)
    {
        $sql1=  mysqli_query($conn,"INSERT INTO `faculty`(`id`, `Fname`) VALUES ('','$fname')");
        if($sql1)
              {
                  return 1;
              }
              else
              {
                  return 0;
              }
    }

}


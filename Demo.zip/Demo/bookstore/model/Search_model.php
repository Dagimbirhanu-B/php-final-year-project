
<?php 

class Search {

    function __construct() {
        
    }
    function Search_R($stud_ID) 
    {
        $sql_S="select * from student where Idno='$stud_ID'";
                        @$sr=mysqli_query($conn,$sql_S);
                        @$row = mysqli_fetch_array($sr);
                        @$result = mysqli_num_rows($sr);
                        if($result > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                            return 0;
                            
                        }
    }
    function Search_U($usname) 
    {
        $sql_S="select * from account where Username='$usname'";
                        $sr=mysqli_query($sql_S);
                        $row = mysqli_fetch_array($sr);
                        $result = mysqli_num_rows($sr);
                        if($result > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                            return 0;
                            
                        }
    }
        function Search_C($stud_ID) 
    {
        include "../db_config/dbcon.php";
        $sql_S="select * from clearance where stud_id='$stud_ID'";
                        @$sr=mysqli_query($sql_S);
                        @$row = mysqli_fetch_array($sr);
                        @$result = mysqli_num_rows($sr);
                        if($result > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                            return 0;
                            
                        }
    }
    function search_case($id) 
    {
        $sql_case=  mysqli_query($conn,"SELECT * FROM `case` where case_id='$id'");
                        
                        $row = mysqli_fetch_array($sql_case);
                       $r = mysqli_num_rows($sql_case);
                       if($r > 0)
                        {
                            return $row;
                        }
                        else 
                        {
                             return 0;
                            
                        } 
    }
}
?>
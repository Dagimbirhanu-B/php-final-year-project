<?php
class Info {

    function case_list($idno,$role)
    {
        $case_n=  mysqli_query($conn,"select * from `cases` where Idno='$idno' and staff='$role'");
                      $num=  mysqli_num_rows($case_n);
                      return $num;
        
    }

}
?>

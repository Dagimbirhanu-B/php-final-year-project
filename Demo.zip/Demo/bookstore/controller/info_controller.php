<?php
        include 'model/info_model.php';
        $info = new Info();
  
        $num_of_case = $info->case_list($idno,$role);
        echo $num_of_case;
        
?>
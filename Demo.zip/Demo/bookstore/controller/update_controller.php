<?php
include '../model/update_model.php';
if (isset($_POST['save']))
{
    $secu=$_POST['sec'];
    $ups=new Update();
        $save_sec= $ups->update_Sec($secu,$Sidno);
        if($save_sec=='1')
        {
            
            header ("Location: security.php");
        }
 else {
        $save_sec="Unable to Save";
 }
    

}
if (isset($_POST['ok']))
{
    $oldp=$_POST['opass'];
    
    $pas=$_POST['pass1'];
    $id=  ucfirst($_SESSION["Idno"]);
    $upp=new Update();
        $save_pas= $upp->update_Pass($oldp,$pas,$id);
        if($save_pas=='1')
        {
            
            header ("Location: security.php");
        }
 else {
        $save_pas="Unable to Change Your password";
 }
    

}

   if(isset($_GET['sfn']))
   {
        $fna=$_GET['fname'];
		 $una=$_GET['unme'];
        $ups=new Update();
		$save_sec= $ups->settingf($fna,$una);
		if($save_sec==1)
		{
			
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
			
		}
		else
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
   }
   if(isset($_GET['sun']))
   {
        $fna=$_GET['mname'];
		$una=$_GET['unme'];
        $ups=new Update();
		$save_sec= $ups->settingu($fna,$una);
		if($save_sec==1)
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
		else
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
   }
   if(isset($_GET['sln']))
   {
        $fna=$_GET['lname'];
		 $una=$_GET['unme'];
        $ups=new Update();
		$save_sec= $ups->settingl($fna,$una);
		if($save_sec==1)
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
		else
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
   }
   if(isset($_GET['sap']))
   {
        $fna=$_GET['pass1'];
		 $una=$_GET['unme'];
        $ups=new Update();
		$save_sec= $ups->settingp($fna,$una);
		if($save_sec==1)
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
		else
		{
			echo"
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
   }
    if(isset($_GET['ssap']))
   {
        $fna=$_GET['pass1'];
		 $una=$_GET['unme'];
        $ups=new Update();
		$save_sec= $ups->settingsp($fna,$una);
		if($save_sec==1)
		{
		      
			echo" <div style='color:green;'><span class='glyphicon glyphicon-ok'></span> Successfully Changed</div>
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
		else
		{
			echo"<div style='color:red;'><span class='glyphicon glyphicon-remove'></span> Unable to Change</div>
			<head>
				<meta http-equiv='refresh' content='0.5'>
				
			</head>
			";
		}
   }
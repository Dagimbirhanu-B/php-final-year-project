<?php
include_once("headeroffices.php");
?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar" class="active"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="bookestore.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                         <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='bookstore'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxbookstore.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><strong><?php echo $number; ?></strong></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="casebookstore.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashbookstore.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div class="container">
<div class="panel">
             <div class="panel panel-default">
              <div class="panel-heading">
			  <h3 class="panel-title"> 
                          <div class="required"><center><u><i class="glyphicon glyphicon-calendar" ></i>&nbsp;CALANDER VIEW</u></center></div>	
               </h3>
              </div>
	<div align="center">
<?php
if (isset($_GET['year'])) {
    $year = $_GET['year'];
} else {
    $year = '';
} // if
?>
<br>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="GET">
<p><b>Enter Year:&nbsp;</b><input type="text" name="year" size="40" value="Enter the year(like 2000) display one year"" />
<button type="submit" class="submit" /><i class="glyphicon glyphicon-hand-right" ></i>&nbsp;GO</button></p>
<br />
<?php
// validate year
if (isset($_GET['year'])) {
    $valid = TRUE;
    if (!ereg('^[[:digit:]]+$', $year)) {
        echo "Year must be an integer";
        $valid = FALSE;
    } // if
    if ($year < 1970) {
        echo "Year cannot be less than 1970";
        $valid = FALSE;
    } // if
    if ($year > 2037) {
        echo "Year cannot be greater than 2037";
        $valid = FALSE;
    } // if
} // if
?>
</form>
<?php
if (isset($_GET['year']) and ($valid)) {
    // start at 1st day of 1st month in this year
    $dd = 1;
    $mm = 1;
    $ccyy = $year;
    // convert components into date format
    $date = strtotime("$ccyy-$mm-$dd");
    // create array of date information
    $today = getdate($date);
    // build array of dates until the year changes
    $date_array = array();
    do {
        build_array($ccyy, $mm, $dd);
    } while($ccyy == $year);

    // transfer contents of $date-array into an HTML table
    print_array($date_array);
} // if
?>
</div>
<?php
function build_array(&$ccyy, &$mm, &$dd)
// build an array containing every date for the selected year
{
global $date;
global $today;
global $date_array;
static $month_no;
static $week_no;

// at change of month reset to week 1 of 6
if ($mm > $month_no) {
    $month_no = $mm;
    $week_no  = 1;
} // if

$dow = $today['wday'];  // get day of week (0 = Sunday, 6 = Saturday)
if ($dow == 0) {
    $dow = 7;                // convert Sunday to day 7
} // if

// add to array
$date_array[$month_no][$week_no][$dow] = $dd;

// after day 7 increment to next week
if ($dow == 7) {
    $week_no = $week_no + 1;
} // if

// increment date to next day
$date = strtotime("+1 day", $date);

// create array of date information
$today = getdate($date);

// extract ccyy, mm, dd
$ccyy = $today['year'];
$mm   = $today['mon'];
$dd   = $today['mday'];

return;

} // build_array

function print_array($date_array) {

// set of array for day-of-week
$day_names = array(1 => '<b>MON</b>','<b>TUE</b>','<b>WED</b>','<b>THU</b>','<b>FRI</b>','<b>SAT</b>','<b>SUN</b>');
// set up array of month names
$month_names = array(1 => '<u><b>J A N U A R Y</b></u>',
                          '<u><b>F E B R U A R Y</b></u>',
                          '<u><b>M A R C H</b></u>',
                          '<u><b>A P R I L</b></u>',
                          '<u><b>M A Y</b></u>',
                          '<u><b>J U N E</b></u>',
                          '<u><b>J U L Y</b></u>',
                          '<u><b>A U G U S T</b></u>',
                          '<u><b>S E P T E M B E R</b></u>',
                          '<u><b>O C T O B E R</b></u>',
                          '<u><b>N O V E M B E R</b></u>',
                          '<u><b>D E C E M B E R</b></u>');

echo "<table border='0'>\n";
echo '<colgroup width="50">';
echo '<colgroup span="6" width="20">';
echo '<colgroup width="20">';
echo '<colgroup span="6" width="20">';
echo '<colgroup width="20">';
echo '<colgroup span="6" width="20">';
echo '<colgroup width="20">';
echo "<colgroup span='6' width='20'>\n";

// print the array in 3 rows with 4 months in each row
for ($row = 1; $row <= 3; $row++) {
   // identify the starting month in current row
   $first = set_start_month($row);
   // process one row at a time (the 1st line contains the month names)
   echo "<tr class='month'>\n";
   for ($m = $first; $m <= $first+3; $m++) {
      echo "<td>&nbsp;</td><td colspan='6'>" .$month_names[$m] ."</td>\n";
   } // for
   echo "</tr>\n";
   // output a line for each of the 7 days of the week
   for ($dow = 1; $dow <= 7; $dow++) {
      echo "<tr class='$day_names[$dow]'>\n";
      // step through each of the 4 months in this row
      for ($m = $first; $m <= $first+3; $m++) {
         // output the details for 4 consecutive months
         // 1st cell identifies the day of week (first month of the 4)
         if ($m == $first) {
            echo "<td class='dayname'>" .$day_names[$dow] ."</td>";
         } else {
            echo "<td>&nbsp;</td>"; // not first month, so cell is empty
         } // if
         // the next 6 cells are for the dates that fall on that day
         for ($week = 1; $week <= 6; $week++) {
            if (isset($date_array[$m][$week][$dow])) {
               echo "<td>" .$date_array[$m][$week][$dow] ."</td>";
            } else {
               echo "<td>&nbsp;</td>";
            } // if
         } // for
      } // for
      echo "\n</tr>\n";
   } // for
   // output a blank line at the end of each row of months
   echo "<tr><td colspan='28'>&nbsp;</td></tr>\n";
} // for

echo "</table>\n";

return;

} // print_array

function set_start_month($row) {
// identify the first month in each of the three rows
    if ($row == 1) {
        $first = 1;
    } elseif ($row == 2) {
        $first = 5;
    } else {
        $first = 9;
    } // if
    return $first;

} // set_start_month
?> 
<link rel="stylesheet" href="../time2/time3/css/pickmeup.css" type="text/css" />
<script type="text/javascript" src="../time2/time3/js/jquery.js"></script>
<script type="text/javascript" src="../time2/time3/js/jquery.pickmeup.js"></script>
<script type="text/javascript" src="../time2/time3/js/demo.js"></script>
<section>
	<h2><u><i class="glyphicon glyphicon-calendar" ></i>&nbsp;ALL CALANDER SHOW</u></h2>
	<article>
		<div class="3-calendars"></div>
	</article>
</section>	   
  </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

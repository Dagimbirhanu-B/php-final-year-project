<?php
session_start();
unset($_SESSION['SESS_MEMBER_ID']);
header('Location:../login.php');
?>
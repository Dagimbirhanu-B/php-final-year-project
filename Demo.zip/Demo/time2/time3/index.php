<link rel="stylesheet" href="css/pickmeup.css" type="text/css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.pickmeup.js"></script>
<script type="text/javascript" src="js/demo.js"></script>
<section>
	<h2>3 calendars + range</h2>
	<article>
		<div class="3-calendars"></div>
	</article>
</section>

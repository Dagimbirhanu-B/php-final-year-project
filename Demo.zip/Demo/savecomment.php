<?php
 include('session.php');
$logout_query=mysqli_query($conn,"select * from account where Username=$id_session");
$row=mysqli_fetch_array($logout_query);
$type=$row['Username'];
mysqli_query($conn,"INSERT INTO history (date,action,data,user) VALUES(NOW(),'Comment on Notification','$mcomment','$type')") or die(mysqli_error());
header("location: aboutus.php");
?>
<?php
	//Start session
	session_start();
	
	//Connect to mysql server
	require "db_config/dbcon.php";
	$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clearance";


$conn = mysqli_connect($servername, $username, $password, $dbname);
if($conn){
	// echo "Connection Established";
}

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	//Function to sanitize values received from the form. Prevents SQL injection
	// function clean($str) {
	// 	$str = trim($str);
	// 	if(get_magic_quotes_gpc()) {
	// 		$str = stripslashes($conn,$str);
	// 	}
	// 	return mysqli_real_escape_string($conn,$str);
	// }
	
	//Sanitize the POST values
	$username = $_POST['username'];
	$password = $_POST['password'];
	//Create query
	$qry="SELECT * FROM student WHERE username='$username' AND PASSWORD2='$password'";
	$result=mysqli_query($conn,$qry);
	if($result) 
	{
		if(mysqli_num_rows($result) > 0) 
		{
			//Login Successful
			session_regenerate_id();
			$member = mysqli_fetch_assoc($result);
			$_SESSION['SESS_MEMBER_ID'] = $member['Idno'];
			$_SESSION['SESS_FIRST_NAME'] = $member['username'];
			 session_write_close();
			//if ($level="admin"){
			header("location: student/student.php");
			exit();
		}
		else 
		{
			?>
	         <script>
              alert('YOUR USER NAME AND PASSWORD IS NOT MATCH PLEASE TRY AGAIN');
              window.location='loginstudent.php';
              </script>
              <?php
			exit();
		}
	}
	else 
	{
	?>
	<script>
    alert('DATA NOT FOUND IN THE DATA BASE Please REGISTER and  Tray again');
    window.location='loginstudent.php';
    </script>
    <?php
	}
?>
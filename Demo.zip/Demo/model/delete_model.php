<?php

 class Delete {

     function delete_U($un) 
     {
          $sql=mysqli_query($conn,"delete from account where Username='$un'");
                            if($sql)
                            {
                                echo "</br>Successfully deleted";
                            }
                            else
                            {
                                echo "coudn't delete the user";
                            }
        
    }
    function delete_S($sid) 
     {
        
          $sqli=mysqli_query($conn,"delete from clearance where stud_id='$sid'");
          $sqli=mysqli_query($conn,"delete from clearance where stud_id='$sid'");
          $sqli1=mysqli_query($conn,"delete from student where Idno='$sid'");
                            if($sqli and $sqli1)
                            {
                                echo "</br>Successfully deleted";
                            }
                            else
                            {
                                echo "coudn't delete the student";
                            }
        
    }
	function disable($sid) 
     {
          $sqli=mysqli_query($conn,"update student set status='0', password ='$sid' where Idno='$sid'");
                            if($sqli)
                            {
                                echo "</br>Successfully Disabled";
                            }
                            else
                            {
                                echo "coudn't Disable the student account";
                            }
        
    }
	function enable($sid) 
     {
          $sqli=mysqli_query($conn,"update student set status='1' where Idno='$sid'");
                            if($sqli)
                            {
                                echo "</br>Successfully Enabled";
                            }
                            else
                            {
                                echo "coudn't Enable the student account";
                            }
        
    }
	
	function disableu($un) 
     {
          $sqli=mysqli_query($conn,"update account set status='1' where Username='$un'");
                            if($sqli)
                            {
                                echo "</br>Successfully Disabled";
                            }
                            else
                            {
                                echo "coudn't Disable the User account";
                            }
        
    }
	function enableu($un) 
     {
          $sqli=mysqli_query($conn,"update account set status='0' where Username='$un'");
                            if($sqli)
                            {
                                echo "</br>Successfully Enabled";
                            }
                            else
                            {
                                echo "coudn't Enable the User account";
                            }
        
    }
	
	
	
	
    function delete_C($id,$idn,$role) 
     {
        
         $cas="SELECT * FROM `case` where case_id='$id'";
                                      $case_query = mysqli_query($conn,$cas) OR die(mysqli_error());
    									while($row = mysqli_fetch_array($case_query))
                                        {
    									   
        									$des=$row["description"];
                                            
                                            $date=$row["date_added"];
                                           
    									    $usr=$row["by_user"];
                                        }
                                    
            
          $case_trash=  mysqli_query($conn,"INSERT INTO `case_trash`(`case_id`, `Idno`, `description`, `staff`, `by_user`,`date_added`,`date_returned`) VALUES ('$id','$idn','$des','$role','$usr','$date',now());");
          $sqlia=mysqli_query($conn,"DELETE FROM `clearance`.`case` WHERE `case`.`case_id` = $id");
          if($sqlia)
          {
           $clear_query=  mysqli_query($conn,"select * from `case` where Idno='$idn' and staff='$role'");
                      $num=  mysqli_num_rows($clear_query);
                      if($num<=0)
                      {
                           $up_sql=  mysqli_query($conn,"update clearance set $role='0' where stud_id='$idn'");
                           
                       }
                        header("Location: case.php");
                        
                        
                    
          } 
          else {
                           echo 'Unable to delete';
               }
    }


}
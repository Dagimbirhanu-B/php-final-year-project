
    <div class="modal fade " id="delete_case<?php  echo $case_id; ?>" role= "dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                
                <div class="modal-body">
                    <div class="alert alert-danger">Are you Sure you want to Delete this Data?</div>
                    
                </div>
                <div class="modal-footer"> 
                <a class="btn btn-danger" href="case.php<?php echo '?ide='.$case_id; ?>">Yes</a>
               
		          	<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
                </div>
            </div>
        </div>
    </div>
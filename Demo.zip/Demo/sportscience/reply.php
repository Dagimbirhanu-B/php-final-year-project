<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="sportscience.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="Abot Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
<?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='sportscience'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxsportscience.php" title="Inbox Message" class="active"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashsportscience.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<div class="container">
<div class="panel">
<div class="panel panel-default">          
<div class="panel-group">	
<div class="alert alert-info">
<div class="required">
<center><font color="black"><b>Write your reply message here and send to the student</b></font></center>
<a href='inboxsportscience.php#'class="btn btn-info btn pull-right" style="float: right; margin-right: -10px; margin-top:-20px;"><span class="glyphicon glyphicon-hand-left"></span> Back</a>  			
</div>
</div>
<?php
if($_GET["reply"] == "to")
   { 
    $id2=$_GET[slid1];
	$sql="SELECT  * FROM messages WHERE IDNo='$id2'";
	$result=mysql_query($sql) OR die("Unable to execute Queary");
	while($rows=mysql_fetch_assoc($result))
	{   
	    $idnum=$rows["Idno"];
		$fname=$rows["Name"];
	}
}
?>
<form id="feedback" class="form-horizontal" method="POST" action="" >	
    <table cellpadding='5' style=" margin: auto; margin-top: 0px;">
     <tr>
                <div class="form-group">
                <td>
				<label class="control-label">IDNO:</label>
				</td>
				<td>
				<input type="text" class="form-control" name="idnumber" id="idnumber" value="<?php echo $id2;?>"/>
				</td>
				</div>
				</tr>          
	<tr>
	<div class="form-group">
    <td>
	<label class="control-label" for="input01">Comment:</label>
    </td>
	<td>
    <textarea rows="6" cols="40" input="" type="text" name="Comment" placeholder="Write your comment here"required="required"></textarea> 
    </td>
	</div>
	</tr>
	<tr>
	<div class="control-group">
 <td></td>
 <td>
	<button id="save_voter" class="btn btn-primary" name="submit"><span class="glyphicon glyphicon-send"></span>&nbsp;Send</button>
	</td>
	<td>
	<button id="reset" class="btn btn-primary" name="reset" type="reset"><span class="glyphicon glyphicon-remove"></span>&nbsp;Clear</button>
    </td>
	</div>
	</tr>
	 </table>
	</form>
	<?php
	 if(isset($_POST['submit']))
    {
        $idnumber=$_POST['idnumber'];
        $comment=$_POST['Comment'];
		$role=date("l, d/M/Y, h:i:sa");
        $query="SELECT * FROM inboxstudent WHERE IDNO='$idnumber'";
            $res=mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('Reply mesage is allready sent before');</script>";
            
            }
            else{
                    $register=mysqli_query($conn,"INSERT INTO inboxstudent(IDNO,Messages,Date) VALUES('$idnumber','$comment','$role')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('Reply message is seccesfully sent to the student');</script>";
                    }
               }
    }
	?>
</div>
</div>
</div>
</div>
<?php
include_once("footeroffices.php");
?>
</body>
</html>
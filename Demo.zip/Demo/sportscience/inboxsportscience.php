<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="sportscience.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="Abot Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
<?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='sportscience'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxsportscience.php" title="Inbox Message" class="active"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashsportscience.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<!--Library menu bar -->
<div class="container1">
<div class="panel">
 <div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                  Debre Tabor University Sport Science Inbox Message 
                                </a>
                              </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                              <div class="panel-body">
                              <p><b>Here Is the Message from the User</b></p>
                                 <?php
if($_GET["view"] == "delete")
{
mysqli_query($conn,"DELETE FROM messages WHERE MID ='$_GET[slid]'");
}
$result = mysqli_query($conn,"SELECT * FROM messages WHERE Offices='sportscience' ORDER BY time DESC");
?>
  <form name="form2" method="post" action="">
  <table  class="table" align="center" border="1" width="100%" id="example">                               
  <tr class="danger">
                                   <th>ACTION</th>
								   <th>IDNO</th>
                                   <th>NAME</th>
								   <th>EMAIL ADDRESS</th>
                                   <th>PHONE</th>
                                   <th>MESSAGE</th>
                                   <th>TIME</th>
								   <th>CHECK</th>
								   <th>REPLY</th>
  </tr>
  <?php
	  $i =1;
  while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>&nbsp";
  ?>
  <a href='inboxsportscience.php?slid=<?php echo $row[MID]; ?>&view=delete'><img src='../images/delete.png'  onclick="return confirm('Are you sure??')"/></a>
  <?php
  $Reply='REPLY';
          echo  $i . " </td>";
          echo "<td>&nbsp;" . $row['IDNo'] . "</td>";
     	  echo "<td>&nbsp;" . $row['Name'] . "</td>";
		  echo "<td>&nbsp;" . $row['Email'] . "</td>";
	      echo "<td>&nbsp;" . $row['phone'] . "</td>";
		  echo "<td>&nbsp;" . $row['messagess'] . "</td>";
          echo "<td>&nbsp;" . $row['time'] . "</td>";
		  ?>
		  <td>&nbsp;<a href='check.php?slid=<?php echo $row["IDNo"]; ?>&chech=status' class="btn btn-success"><span class="glyphicon glyphicon-check"></span>&nbsp;&nbsp;CHECK</a></td>
		  <td>&nbsp;<a href='reply.php?slid1=<?php echo $row["IDNo"]; ?>&reply=to' class="btn btn-success"><span class="glyphicon glyphicon-send"></span>&nbsp;&nbsp;REPLY</a></td>
		  <?php
		  echo "</tr>&nbsp;";
  $i++;
  }
  
?>
</table>
</form>
 </div>
 </div>
 </div>                
 </div>
<div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
							  <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM feedback WHERE Offices='sportscience'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                  Debre Tabor University Sport Science Offices Feedback Message 
                                </a><font color="blue">You have&nbsp;</font><font color="red"><?php echo $number;?></font>&nbsp;feed back messages 
                              </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse">
                              <div class="panel-body">
                              <p><b>Here Is the Feedback Message from the User</b></p>
                                 <?php
if($_GET["view"] == "delete")
{
mysql_query("DELETE FROM feedback WHERE FID ='$_GET[slid]'");
}
$result = mysql_query("SELECT * FROM feedback WHERE Offices='sportscience'");
?>
  <form name="form2" method="post" action="">
  <table  class="table" align="center" border="1" width="100%" id="example">                               
  <tr class="danger">
                                   <th>ACTION</th>
								   <th>EMAIL ADDRESS</th>
                                   <th>MESSAGE</th>
                                   <th>TIME</th>
  </tr>
  <?php
	  $i =1;
  while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>&nbsp";
  ?>
  <a href='inboxregistrar.php?slid=<?php echo $row[FID]; ?>&view=delete'><img src='../images/delete.png'  onclick="return confirm('Are you sure??')"/></a>
  <?php
          echo  $i . " </td>";
		  echo "<td>&nbsp;" . $row['Email'] . "</td>";
		  echo "<td>&nbsp;" . $row['Comment'] . "</td>";
          echo "<td>&nbsp;" . $row['date'] . "</td>";
		  echo "</tr>&nbsp;";
  $i++;
  }
  
?>
</table>
</form>
 </div>
 </div>
 </div>                
 </div> 
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

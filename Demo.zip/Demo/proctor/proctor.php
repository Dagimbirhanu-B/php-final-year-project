<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="proctor.php" title="Home" class="active" ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                            <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='proctor'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxproctor.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashproctor.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<div class="container">
<div class="panel">           
          <div class="panel panel-default">
         <div class="panel-heading">
             <h3 class="panel-title"> 
                    <form action="#" class="navbar-search form-inline" style="margin-top:6px" method="POST">
                         <div class="required"> Enter Student IDNO: &nbsp; &nbsp;
    		                  <input type="text" placeholder="Search" required x-moz-errormessage="Please Enter Student ID" name="stud_ID"/><button class="btn btn-warning" style="height: 35px;" name="search_R"><i class="glyphicon glyphicon-search" ></i>Search</button>	
                           </div>
                           <?php  include("controller/search_controller.php") ;  
                           
                             ?>
                   	</form> 
    
             </h3>
         </div>
    <div class="panel-body">
    <?php  
                  if(isset($_POST["search_R"])and $Reg_res!='0')
                    { 
                        if($statu=='1')
                              {
    
    
    
    
    ?>
	</div>
       <div class="pbody">
<!-- Student Information -->  
             <div class="row">
                <div class="col-md-5">
                   <table cellpadding='10' cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
                            <tr>
                            	<td> Full name: </td>
                                <?php  $idno= $responce['Idno']; ?>
                            	<td>    <?php
                            	if(isset($_POST["search_R"]))
                               { 
                                    echo "<div class='res'>". $responce['Fname'] ." ". $responce['Mname']. " ". $responce['Lname']. "</div>";
                               }
                            ?></td>
                            </tr>
                            <tr>
                            	<td>IDNo:</td>
                            	<td>  
                             <?php
                            	if(isset($_POST["search_R"]))
                               { 
                                    echo  "<div class='res'>". $responce['Idno']."</div>";
                               }
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Sex:</td>
                            	<td><?php
                            	if(isset($_POST["search_R"]))
                               { 
                                    echo   "<div class='res'>".$responce['Sex']."</div>";
                               }
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Department:</td>
                            	<td><?php
                            	if(isset($_POST["search_R"]))
                               { 
                                    echo   "<div class='res'>".$responce['Department']. "</div>";
                               }
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Year: </td>
                            	<td><?php
                            	if(isset($_POST["search_R"]))
                               { 
                                    echo   "<div class='res'>". $responce['Year']. "</div>";
                               }
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Clearance Status: </td>
                            	<td><?php
                            	if(isset($_POST["search_R"]))
                               { 
                                    if($dormClr=='0')
                                    {
                                        echo "<h4><span class='label label-success'>Clear</span></h4>";
                                    }
                                    else
                                    { ?>
                                        <a rel='tooltip' href='trashproctor.php?slid=<?php echo $idno;?>' data-toggle='modal'><h4><span class='label label-danger'>Not Clear <span class='badge'><?php include 'controller/info_controller.php'; ?></span></span></h4></a>
                                <?php    }           
                               }
                            ?></td>
                            </tr>
                     </table>
                   </div>
                          <div class="col-md-4">
                                            
                                                   
                          </div> 

                        <div class='col-md-3' >
                                     <h3>Calendar</h3>
                                   <script src="../js2/calander.js" language="javascript" type="text/javascript"></script> 
                            
                        </div>

                     </div>
                
                    </div>
        <?php    
                }   }
                   if(!isset($_POST["search_R"]))
                {  ?>
                    <div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                  Debre Tabor University Dormitory 
                                </a>
                              </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                              <div class="panel-body">
                                    Debre Tabor University provides Dormitory services to its regular and summer students in its Dormitory Building.   
                              </div>
                            </div>
                          </div>
                          <div  class="head"  >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                  Student Clearance Report From Dormitory Property
                                </a>
                              </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse">
                              <div class="panel-body">
                                  <?php
                                        	$noclear=mysqli_query($conn,"select * from clearance where dormitory='0'");
                                            $notclear=mysqli_query($conn,"select * from clearance where dormitory='1'");
                                           $numofclr = mysqli_num_rows($noclear);
                                           $numofnotclr = mysqli_num_rows($notclear);
                                        
                                                ?>
                                  <div class="table table-striped">
                                      <table class="table" id="example">
                                        <tr class="active">
                                                <th>No.</th>
                                                <th>Title</th>
                                                <th>Quantity</th>
                                        </tr>
                                        <tr>
                                                <td>1. </td>
                                                <td>Number of Cleared Student From Dormitory</td>
                                                <td><?php  echo $numofclr;  ?></td>
                                        </tr>
                                        <tr>
                                                <td>2. </td>
                                                <td>Number of UnCleared Student From Dormitory</td>
                                                <td><?php  echo $numofnotclr;  ?></td>
                                        </tr>
                                        <tr class="danger">
                                                <td>#. </td>
                                                <td>Total number of Student</td>
                                                <td><?php  echo $numofnotclr+$numofclr;  ?></td>
                                        </tr>
                                      </table>
                                    </div>
                                  
                                  
                            </div>
                          </div>
                          
                        
                        </div>

                   <div  class="head"  >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                                  View  UnCleared Student List Report From Proctor/Dormitory Property
                                </a>
                              </h4>
                            </div>
							<script type="text/javascript">     
                                                function PrintDiv() {    
                                                   var divToPrint = document.getElementById('divToPrint');
                                                   var popupWin = window.open('', '_blank', 'width=600,height=600');
                                                   popupWin.document.open();
                                                   popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
                                                    popupWin.document.close();
                                                  }
                          </script>
                            <div id="collapseThree" class="panel-collapse collapse">
                              <div class="panel-body">
                              <div class="table table-striped">
                                <form action="#" method="post">
        	                       <button onclick="PrintDiv()" class="btn btn-info btn pull-right" name="report" type="submit" title="Print"style="margin-top:13px;">Print List</button>       
                                  </form>
                              <div class="panel-body" style="font-family: times new roman;" >
                                 <div id="divToPrint">
								<div>
								 <b>Un Cleared Student List from proctor is as follows</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <font color="white"> DATE:</font>
                                <font color="orange">
                                    <?php
                                     $Today=date('y:m:d');
                                      $new=date('l, F d, Y',strtotime($Today));
                                          echo $new; ?>
                                 </font> 
                                  </div>
								   <table class="table" align="center" border="1" width="100%" id="example">
                                    <tr class="danger">
								   <th>SNO</th>
                                   <th>IDNO</th>
                                   <th>FNAME</th>
                                   <th>LNAME</th>
								   <th>MNAME</th>
                                   <th>DEPARTMENT</th>
                                   <th>CASE</th>
                                   <th>CASE DATE ADDED</th>
                                   </tr>
                                       <?php
									   $i=1;
                                mysqli_connect("localhost","root");
                                mysqli_select_db($conn,"clearance");
                                $res=mysqli_query($conn,"SELECT clearance1.* ,
 								                  student1.* , 
												  case1.*   
										      FROM clearance clearance1,
											       student student1,
											       cases case1 
											  WHERE clearance1.stud_id=student1.Idno AND 
											        clearance1.stud_id=case1.Idno AND 
													clearance1.dormitory='1' AND
													case1.staff='proctor'");
                                 while($row=mysqli_fetch_array($res))
                                  {
	                              ?>
                                 <tr>
							   <td class="danger"><p><?php echo $i; ?></p></td>
                               <td><p><?php echo $row['stud_id']; ?></p></td>
                               <td><p><?php echo $row['Fname']; ?></p></td>
                               <td><p><?php echo $row['Mname']; ?></p></td>
							   <td><p><?php echo $row['Lname']; ?></p></td>
							   <td><p><?php echo $row['Department']; ?></p></td>
							   <td><p><?php echo $row['description']; ?></p></td>
							   <td><p><?php echo $row['date_added']; ?></p></td>
                                </tr>
                                  <?php
								  $i++;
                                 }
                                  ?>
                               </table>  
                                    </div>  
                            </div>
                          </div>
                    
                          
                        </div>
                    
              <?php  }
                ?>
              </div>
        </div> 
           </div>
          </div>
        </div>
      </div>
     </div>
   </div>
  </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
				
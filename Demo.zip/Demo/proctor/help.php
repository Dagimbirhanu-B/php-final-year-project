<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="proctor.php" title="Home" class="active" ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                            <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='proctor'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxproctor.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashproctor.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help" class="active"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div id="container">
<div class="hero-unit-bud11">
<ul class="nav nav-tabs"> 
  <li class="active"><a href="#home" data-toggle="tab"><font color="white"><i class="icon-question-sign icon-large"></i></font><font color="orange">Frequently Asked Questions (FAQ)</font></a></li>
</ul>

<div class="tab-content">
  <div class="tab-pane active" id="home">
  <div class="hero-unit-y">
<hr>
  <div class="tab-pane active" id="profile">
<ul class="nav nav-tabs">
  <li class="active"><a href="#"><font color="white"></font><font color="orange">1. How to search Student Case?</font></a></li>
  <li><a  href="#2"><font color="white"></font><font color="orange">2. How to Print Clearance?</font></a></li>
  <li><a  href="#3"><font color="white"></i></font><font color="orange">3. How to dowload clearance?</font></a></li>
  <li><a  href="#4"><font color="white"></font><font color="orange">4. How to Use System?</font></a></li>
  <li><a  href="#5"><font color="white"></font><font color="orange">5. How to Send message to the respected office?</font></a></li>
  <li><a  href="#6"><font color="white"></font><font color="orange">6. How to Write Feedback?</font></a></li>
  <li><a  href="#7"><font color="white"></font><font color="orange">7. How to Email for the respected office?</font></a></li>
  <li><a  href="#8"><font color="white"></font><font color="orange">8. How to Email for the respected office?</font></a></li>
  <li><a  href="#9"><font color="white"></font><font color="orange">9. How to Email for the respected office?</font></a></li>
  <li><a  href="#10"><font color="white"></font><font color="orange">10. How to Email for the respected office?</font></a></li>
  </ul>
</div>
<hr>
  <div class="mm" id="1">
  <h2 align="left">1. How to search Student Case?</h2>
  <hr>
  <img src="../helpimage/message.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="2">
  <h2 align="left">2. How to Print Clearance?</h2>
  <hr>
  <img src="../helpimage/feedback.jpg"style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
    <div class="mm" id="3">
  <h2 align="left">3. How to dowload clearance?</h2>
  <hr>
  <img src="../helpimage/download.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
    <div class="mm" id="4">
  <h2 align="left">4. How to Use System?</h2>
  <hr>
  <img src="../helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="5">
  <h2 align="left">5. How to Send message to the respected office?</h2>
  <hr>
  <img  src="../helpimage/message.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="6">
  <h2 align="left">6. How to Write Feedback?</h2>
  <hr>
  <img src="../helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="7">
  <h2 align="left">7. How to Email for the respected office?</h2>
  <hr>
  <img src="../helpimage/message.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="8">
  <h2 align="left">8. How to Email for the respected office?</h2>
  <hr>
  <img src="../helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="9">
  <h2 align="left">9. How to Email for the respected office?</h2>
  <hr>
  <img src="../helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="10">
  <h2 align="left">10. How to Email for the respected office?</h2>
  <hr>
  <img src="../helpimage/download.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
 </div>
 </div>
  </div>
</div>
</div>
<?php 
include('footeroffices.php'); 
?>
</body>
</html>


<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="proctor.php" title="Home" ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                            <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='proctor'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxproctor.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashproctor.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>			
<div id="container21">
<div class="panel">
<div class="hero-unit-bud11">
<ul class="nav nav-tabs"> 
  <li class="active"><a href="#developers" data-toggle="tab"><font color="white">
  <i class="icon-pc-sign icon-large"></i></font><font color="orange">Developers</font></a></li>
</ul>
<div class="hero-unit-y">
 <h2><u><center>Debre Tabor University Student's Online Clearance System  Developers</u></center></h2>
<table width="1053" border="0">

 <tr>
    <td width="361"><center><font face="time new romanse" color="orange" size="5" align="center"> Project members</font><br/>
      <br/>
     <img src="../groupimage/abatneh.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">abatneh</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:abat2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593819</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td width="361"><center><font face="time new romanse" color="orange" size="5" align="center"> Project members</font><br/>
      <br/>
     <img src="../groupimage/nati.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Natnael</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:nati2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593820</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td width="361"><center><font face="time new romanse" color="orange" size="5" align="center"> Project members</font><br/>
      <br/>
     <img src="../groupimage/kal.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Kalkidan</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:kal2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593821</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td width="361"><center><font face="time new romanse" color="orange" size="5" align="center"> Project members</font><br/>
      <br/>
     <img src="../groupimage/tsega.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Tsegereda</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:tsega2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593822</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
    <tr>
    <td width="361"><center><font face="time new romanse" color="orange" size="5" align="center"> Project members</font><br/>
      <br/>
     <img src="../groupimage/Zemenay.jpg" width="200" height="200" border="0">
     
      <blockquote>
          <p><font face="Arial" color="#337c33" size="3">Zemenay</font><br/>
            <font face="Arial" color="#337c33" size="3">Email:zemu2019@Gmail.com</font><br/>
      <font face="Arial" color="#337c33" size="3">Mob: +2519 47593823</font></p>
            <font face="Arial" color="#337c33" size="3">IT 4<sup>th</sup> Year </font></p>
      </center></blockquote></td>
    </tr>
</table>
</div>

</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
<div class="panel panel-default1">
<div class="panel-body">
			  <div style="width: 600px; height: 400px; margin-left: 250px;">
               <?php                    
              if(isset($_POST["search_R"])and $Reg_res!='0')
                    { 
                        if($statu=='1')
                              {
                                   ?>
                               <form  action="" class="navbar-search form-inline" style="margin-top:6px" method="POST" >
                               <table cellpadding="10" class="table">
                                <input type="hidden" name="idno" value="<?php  echo $responce['Idno'];?> "/>
                                 <center><u></ul><?php echo $responce['Fname']. " ". $responce['Mname']." ". $responce['Lname']   ?></u></center> 
                                   <?php   
								   } 
								   }  
								   ?>                 
                                        <tr>
                                              <div class="form-group">
                                                <td><label for="exampleInputEmail1">Student ID Code</label></td>
                                              <td>  <input type="text" class="form-control" name="security" id="exampleInputEmail1" value="<?php  echo @$responce['Idno'];?> " placeholder="Enter the student security code" size="2" maxlength="8" required x-moz-errormessage="Please insert the student's security code "/></td>
                                              </div>
                                        </tr>
                                        <tr>
                                            <div class="form-group">
                                                <td><b>Student Case</b></td>
                                               <td> <textarea class="form-control" rows="5" name="description" placeholder="Type the record to the student..." required x-moz-errormessage="Please add a case here"></textarea> </td>
                                               </div>     
                                        </tr>
                                        <tr>
                                            <div class="form-group">

                                                <td>
												    <?php   
                                                      include("controller/registration_controller.php");             
                                                      ?>
												</td>
                                               <td> <input type="submit" value="Submit" name="caseproctor" class="btn btn-primary btn-lg"/></td>
											   <td> <input type="reset" value="Clear" name="clear" class="btn btn-primary btn-lg"/></td>                                              											   
                                               </div>
                                        </tr>
                                        <tr>
                                               <div class="form-group">
                                                <td></td>
                                                <td></td>
                                               </div>       
                                        </tr>
                                        </table>
                                        </form>
					</div>
           </div>
</div>
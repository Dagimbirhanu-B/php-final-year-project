<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="proctor.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"title="About Us"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                            <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='proctor'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxproctor.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="leaf"><a href="contactus.php" title="Contact Us"><i class="glyphicon glyphicon-share" ></i>&nbsp;Contact Us</a></li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operation</a>
<ul class="menu" id="nav nav-pills">
<li class="first leaf"><a href="addcase.php" title="Add New Case "><i class="glyphicon glyphicon-save" ></i>&nbsp;Add New Case</a></li>
<li class="leaf"><a href="trashproctor.php" title="View Archive File"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;&nbsp;View Case File</a></li>
<li class="leaf"><a href="setting.php" title="Profile Setting" class="active1"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div class="container" >
<div class="panel" >
    	<div class="panel panel-default">
             <fieldset style="width: 600px; height=500px; margin-left: 300px; background: #D0F2E4 ; border-radius: 20px;">
              <div class="alert alert-info">
                                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                                   <legend> <center><?php echo "<i>".$firstname." ". $midname." ".$lastname."</i>"; ?> Profile Setting</center></legend>
                                   
                </div>
                
                <form action="" method="GET">
                <table class="table">
                   
                    <tr><?php   include"../controller/update_controller.php";      ?>
                        <td>First name</td> 
                        <td><?php if(isset($_GET['chf'])){ echo "<input type='text' name='fname' value='$firstname' class='form-control' />";  }  else{ echo $firstname; }  ?></td>  
                       <td><a href="setting.php?chf=<?php echo $firstname; ?>" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Change</a></td>
                       <?php if(isset($_GET['chf'])){ ?><td><td><button name="sfn" class="btn btn-default" onclick="history.go(0)"><span class="glyphicon glyphicon-save"></span> Save</button></td>  </td> <?php } ?>
                     <?php if(isset($_GET['sfn'])){    if($save_sec==1){ ?> <td style="color: green; font-family: Times new roman; font-size: 14px;"><span class="glyphicon glyphicon-ok"></span></td><?php } else{ ?>  <td style="color: red; font-family: Times new roman; font-size: 14px;"><span class="glyphicon glyphicon-remove"></span></td> <?php }  }?>
                    </tr>
                     <tr><input type='hidden' name='unme' value='<?php echo $userNameD; ?>'/>
                        <td>Middle name</td>    
                        <td><?php if(isset($_GET['chu'])){ echo "<input type='text' name='mname' value='$midname' class='form-control' />";  }  else{ echo $midname;  } ?></td>
                        <td><a href="setting.php?chu=<?php echo $midname; ?>" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Change</a></td>    
                        <?php if(isset($_GET['chu'])){ ?><td><td><button class="btn btn-default" name="sun"><span class="glyphicon glyphicon-save"></span> Save</button></td>  </td> <?php } ?>
                       <?php if(isset($_GET['sun'])){    if($save_sec==1){ ?> <td style="color: green; font-family: Times new roman; font-size: 14px;"><span class="glyphicon glyphicon-ok"></span></td><?php } else{ ?>  <td style="color: red; font-family: Times new roman; font-size: 14px;"><span class="glyphicon glyphicon-remove"></span></td> <?php }  }?>
                        
                    </tr>
                    <tr>
                        <td>Last name</td> 
                        <td><?php if(isset($_GET['chl'])){ echo "<input type='text' name='lname' value='$lastname' class='form-control' />";  }  else{ echo $lastname; }  ?></td> 
                        <td><a href="setting.php?chl=<?php echo $lastname; ?>" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Change</a></td>
                        <?php if(isset($_GET['chl'])){ ?><td><td><button name="sln" class="btn btn-default"><span class="glyphicon glyphicon-save"></span> Save</button></td>  </td> <?php } ?>
                         <?php if(isset($_GET['sln'])){    if($save_sec==1){ ?> <td style="color: green; font-family: Times new roman; font-size: 14px;"><span class="glyphicon glyphicon-ok"></span></td><?php } else{ ?>  <td style="color: red; font-family: Times new roman; font-size: 14px;"><span class="glyphicon glyphicon-remove"></span></td> <?php }  }?>
                    </tr>
                     <tr>
                        <td>Password</td> 
                        <td><?php if(isset($_GET['pas'])){ echo "<input type='password' placeholder='*********' name='pass1' id='pass1' placeholder='*********' required x-moz-errormessage='input must contain at least one digit/lowercase/uppercase letter and be at least 6 character long' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}'  onchange='form.pwd2.pattern = this.value;' required='' class='form-control'/>";  }  else{ echo "*********"; }  ?></td>    
                        <td><a href="setting.php?pas" class="btn btn-success"><span class="glyphicon glyphicon-pencil"></span> Change</a></td>
                        <?php if(isset($_GET['pas'])){ ?><td><td><button class="btn btn-default" name="sap"><span class="glyphicon glyphicon-save"></span> Save</button></td>  </td> <?php } ?>
                    </tr>
                  <?php if(isset($_GET['pas'])){  ?><tr>
                  <div class="controls">
                        <td>Confirm Password</td> 
                        <td><input class='form-control' type="password" name="confirm" id="pwd2" placeholder="*********" required="" required x-moz-errormessage="The password should be match" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" /></td>    
                        </div>
                        <td></td>
                    </tr> <?php  } ?>
                
                </table>
                </form>
                
           </fieldset>
</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
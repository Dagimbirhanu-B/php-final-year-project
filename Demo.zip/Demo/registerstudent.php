<?php
	include_once("header.php");
	include_once("header3.php");
  include_once("db_config/dbcon.php");
?>
<link rel="stylesheet" type="text/css" href="time2/jquery.datetimepicker.css"/>
<style type="text/css">
.custom-date-style {
	background-color: red !important;
}
</style>
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutclearance.php" title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php" title="Calander View"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="viewpost.php"title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
<li><a href=""><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Login</a>
<ul>
<li><a href="login.php?action=login"  title="Login Offices"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Officess Login</a></li>
<li><a href="loginstudent.php" title="Login Student"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Students Login</a></li>
</ul>
</li>
<li class="current-menu-item"><a href="registerstudent.php?action=registerstudent"title="Create Account" class="active"><i class="glyphicon glyphicon-save" ></i>&nbsp;Create Account</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>

<div class="menu">
<ul>
<li><a href="index.php" title="Home"><i class="glyphicon glyphicon-home"></i>&nbsp;Home</a></li>
<li><a href="aboutus.php" title="About Us"><i class="glyphicon glyphicon-user"></i>&nbsp;About Us</a></li>
<li><a href="crule.php"title="Clearance Rule and Regulation"><i class="glyphicon glyphicon-file"></i>&nbsp;Cl Rule &amp; Regulation</a></li>
<li><a href="notice.php"title="Notice to Student"><i class="glyphicon glyphicon-time"></i>&nbsp;Notice to Student</a></li>
<li><a href="contactus.php"title="Contact Us"><i class="glyphicon glyphicon-share"></i>&nbsp;Contact Us</a></li>
<li><a href="feedback.php"title="Feed Back"><i class="glyphicon glyphicon-plane"></i>&nbsp;Feed Back</a></li>
<li><a href="help.php?action=help"title="Help Menu"><i class="glyphicon glyphicon-book"></i>&nbsp;Help</a></li>
</ul>
</div>
<div id="panel">
<div id="panel">			
</div>
</br>
</br>
</br>
</div>
<div class="size2">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>				
<div class="container">
<div class="panel">
<div class="navigation">
<font color="white"><b>YOU ARE HERE:</b></font>
<a class="active buttonnav" href="index.php"><b>Home</b></a><font color="white">>>
<a class="active buttonnav" href=""><b>Create Account</b></a> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>
<div class="panel panel-primary">
               <div class="panel-body">
              <center><h3><font color="black">Debre Tabor University Student Create Account Form</font></h3></center>
          <br /><br /><br /><br />
				<form class="form-horizontal" role="form" action="#"  method="post" onchange='form.pwd2.pattern = this.value;'>
                 <table cellpadding='5' style=" margin: auto; margin-top: -150px;">
    
                 <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">User Name:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="username" id="username" placeholder="Enter User Name" required=""/>
                    </td>
                          </div>
						  <td>
									 <div class="username_avail_result" id="username_avail_result">&nbsp;</div>
						  </td>
                 </tr>
                <tr>
				    <div class="form-group">
                        <td>Password</td> 
                        <td><input type='password' placeholder='*********' name='password' id='pass1' placeholder='*********' required x-moz-errormessage='input must contain at least one digit/lowercase/uppercase letter and be at least 6 character long' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}'  onchange='form.pwd2.pattern = this.value;' required='' class='form-control'/></td>    
                        <td>
							<div class="password_strength" id="password_strength">&nbsp;</div>
						</td>
					</div>
				</tr>
                  <tr>
                  <div class="controls">
                        <td>Confirm Password</td> 
                        <td><input class='form-control' type="password" name="confirm" id="pwd2" placeholder="*********" required="" required x-moz-errormessage="The password should be match" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" /></td>    
                        </div>
                        <td></td>
                    </tr>
                
                            
                          </div>
                   <tr>
				   <td></td> 
                          <div class="form-group">
                          <td>
                            <div class="col-lg-offset-6">
                              <button class="submit" type="submit" class="btn btn-success"  name="register">Register</button>
							  <button class="submit" type="reset" class="btn btn-primary">Reset</button>
                            </div>
                          </td>
                          <td></td>
                          </div>
                   </tr>
              </table>
      </form>
      <?php
       include_once('createaccount.php');
      ?>
 </div>
</div>    	
</div>
</div>    	
</div>
<?php
	include_once("footer.php");
?> 
</body>
</html>
<?php
include "model/registration_model.php";

    // register students

    if(isset($_POST['Import']))
    {
        
        	
        $string = randomString(rand(7,7));
        if(isset($_POST["Import"])){
		

		$filename=$_FILES["file"]["tmp_name"];
		

		 if($_FILES["file"]["size"] > 0)
		 {
            
		  	$file = fopen($filename, "r");
	         while (($import = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
	           $string = randomString(rand(7,7));
              
	           $register=mysql_query("INSERT INTO student(Fname,Mname,Lname,Sex,Age,Idno,Year,Department,security,password,status) values('$import[0]','$import[1]','$import[2]','$import[3]','$import[4]','$import[5]','$import[6]','$import[7]','$string','$import[5]','')");
               
               $clear=  mysql_query("INSERT INTO clearance(stud_id,faculty,department,library,bookstore,cafeteria,dormitory,sport,Clearance) VALUES('$import[5]','','','','','','','','')");
              
               
               }
                if($register and $clear)
                    {
                        echo "Successfully Registered";
                    }
                    else
                    {
                        echo"<div style='color:red'>Invalid File:Please Upload CSV File.</div>";
                    }
               fclose($file);
          }
               

        
        }
        
        
    }
    if(isset($_POST['register']))
    {   	
        $string = randomString(rand(7,7));


        $fname=$_POST['Fname'];
        $mname=$_POST['Mname'];
        $lname=$_POST['Lname'];
        $sex=$_POST['Sex'];
        $age=$_POST['Age'];
        $idno=$_POST['Idno'];
		$facality=$_POST['Fac'];
        $year=$_POST['Year'];
        $department=$_POST['Dept'];
		$photo=$_POST['Photo'];
        $query    =    "SELECT * FROM student WHERE Idno='$idno'";
        $sqlm=mysql_query("select * from departments where DName='$department'");
            $rowm=mysql_fetch_array($sqlm);
            $yrr=$rowm['Program_year'];
            $res = mysql_query($query);
            if(mysql_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This Student is Already Registered');</script>";
            break;
            }
			
            elseif($year<$yrr)
            {
                echo "<script lang='javascript'> alert('This Year is not available in this department');</script>";
            break;
			}
                    $pass=md5($idno);
					$security=md5($fname);
                    $register=mysql_query("INSERT INTO student(Fname,Mname,Lname,Sex,Age,Idno,Faculity,Year,Department,security,password,status,Photo) VALUES('$fname','$mname','$lname','$sex','$age','$idno','$facality','$year','$department','$security','$pass','','$photo')");
                    $clear=  mysql_query("INSERT INTO clearance(stud_id,faculty,department,library,bookstore,cafeteria,dormitory,sport,Clearance) VALUES('$idno','','','','','','','','')");
					
				
					$result=mysql_query($register);
                if(!$result){
                echo ("<script lang='javascript'>alert('You are registered sucssesfully!!!')</script>".mysql_error());
                  }
             else{
              echo"<h4><blink><font color='red'>You are not registered sucssesfully!!!</blink></h4>";
           }
                
    }
    
// register user
    if(isset($_POST['AddAccount']))
    {
        $fname=$_POST['Fname'];
        $mname=$_POST['Mname'];
        $lname=$_POST['Lname'];
        $sex=$_POST['Sex'];
        $username=$_POST['username'];
        $password=$_POST['pass1'];
        $role=$_POST['role'];
        $query="SELECT * FROM account WHERE Username='$username'";
            $res=mysql_query($query);
            if(mysql_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This User is Already Registered');</script>";
            
            }
            else{
                    $register=mysql_query("INSERT INTO account(Fname,Mname,Lname,Username,Password,Sex,Role) VALUES('$fname','$mname','$lname','$username','$password','$sex','$role')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('The User is Successfully Registered');</script>";
                    }
               }
    }
// send message
    if(isset($_POST['sendmessage']))
    {
        $fname=$_POST['Name'];
        $mname=$_POST['IDNo'];
        $lname=$_POST['Email'];
        $sex=$_POST['phone'];
        $username=$_POST['Offices'];
        $password=$_POST['messagess'];
        $role2=date("l, d/M/Y, h:i:sa");
        $query="SELECT * FROM account WHERE Username='$username'";
            $res=mysql_query($query);
            if(mysql_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This User is Already Registered');</script>";
            
            }
            else{
                    $register=mysql_query("INSERT INTO messages(Name,IDNo,Email,phone,Offices,messagess,Time) VALUES('$fname','$mname','$lname','$username','$password','$sex','$role2')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('The User is Successfully Registered');</script>";
                    }
               }
    }      
function randomString($length){
                $chars = "abcdefghijkmnopqrstuvwxyz0123456789";
                srand((double)microtime()*1000000);
                $str = "";
                $i=0;

                        while($i <= $length){
                                $num = rand() % 33;
                                $tmp = substr($chars, $num, 1);
                                $str = $str . $tmp;
                                $i++;
                        }
                return $str;
        }
     if(isset($_POST["secu"]))
     {
         $string = randomString(rand(7,7));
     }
//addcase for student service
if(isset($_POST['casestudentservice']))
{
$id=$_POST["security"];
$comment = trim($_POST['description']);
$dttim = date("l, d/M/Y, h:i:sa");
$office="studentservice";//remember after login is done
$user="gech";//remember after login is done
$status="NOT_MODIFY";
if(is_numeric($name) || is_numeric($email) || is_numeric($comment))
{ 
?>
<script type="text/javascript">
alert('All information must be character strings');
history.back();
</script>
<?php
}
else{
$query="INSERT INTO cases(Idno,description,staff,by_user,status,date_added) VALUES('$id','$comment','$office','$user','$status','$dttim')";
mysql_query($query);
$sql_up=mysql_query("UPDATE clearance set cafeteria='1' WHERE stud_id='$id'");
$sql_up1=mysql_query("UPDATE clearance set Clearance='1' WHERE stud_id='$id'");
if(!$query and !$sql_up and !$sql_up1 ){
                    echo ("<script lang='javascript'>alert('You are Not  sucssesfully Add case!!!')</script>".mysql_error());
				   }
                else{
                   echo ("<script lang='javascript'>alert('You are sucssesfully Add case!!!')</script>".mysql_error());
				 }
				 ?>
<script type="text/javascript">
window.location="addcase.php";
</script> 
<?php
}
}   
if(isset($_POST["Add_dep"])){
	   $fac= $_POST['fac'];
	   $yr= $_POST['yr'];
	   $dname= $_POST['Dname'];
        $query="SELECT * FROM departments WHERE Dname='$dname'";
        $res=mysql_query($query);
            if(mysql_num_rows($res)>0)
			  {
                echo "<script lang='javascript'> alert('This Department is Already Registered');</script>";
              }
                else{
            	   $register=mysql_query("INSERT INTO departments(Fname,DName,PYear) VALUES('$fac','$dname','$yr')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('Successfully Add Department');</script>";
                    }
	               }
	}
    	 if(isset($_POST["Add_fac"]))
     {
	   $fname= $_POST['Fname'];
        $query="SELECT * FROM faculty WHERE Fname='$fname'";
         $res=mysql_query($query);
            if(mysql_num_rows($res)>0)
            {
                echo "<script lang='javascript'> alert('This Faculty is Already Registered');</script>";
            }
                else{
            	   $register=mysql_query("INSERT INTO faculty(Fname) VALUES('$fname')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('Successfully Add Faculty');</script>";
                    }
	               }
	}

?>

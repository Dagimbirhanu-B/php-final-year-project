﻿/*
    File Name: tpcrn_scripts.js
    by ThemePacific
 */

jQuery(document).load(function() {
 
/*Fit Video*/
jQuery(".post-content").fitVids();
	
});
jQuery(document).ready(function() {
		jQuery('.tpcrn_share_l').click(function() {
     var NWin = window.open(jQuery(this).data('href'), '', 'height=600,width=600');
     if (window.focus) {NWin.focus();}return false;}); 

	var sidebar = jQuery('#sideslidemenu');
	
 
	jQuery('#catnav').children().clone().removeAttr('id').removeClass().appendTo(sidebar);
	jQuery('#topnav').children().clone().removeAttr('id').removeClass().appendTo(sidebar);
	sidebar.children().nextUntil().wrap('<div class="block" />');

	jQuery('.blog-thumb,.magbig-thumb,.sb-post-thumbnail,.cat_box-post-thumbnail,.tpcrn_r_p_thumb').on('inview', function(event, isInView) {
		if (isInView) {
			jQuery(this).addClass('inview');
		}
	});
	
	
		if (jQuery('#rating_container')[0]) {

		jQuery('#rating_container').on('inview', function(event, isInView, visiblePartX, visiblePartY) {
			if (isInView) {
				if (visiblePartY == 'top') {
				} else {
					jQuery(this).addClass('inview');
				}
			}
		});
	
	}
	
	
 
		 
jQuery(".tpcrn-follow-menu").hover(function(event) { if(event.type == "mouseenter") { jQuery("#tpcrn-followers-listpop").slideDown(); jQuery("#tpcrn-followers-pop-trigger").addClass("active"); } else { jQuery("#tpcrn-followers-listpop").slideUp(); jQuery("#tpcrn-followers-pop-trigger").removeClass("active"); }});
				 
 
 var stickyHeader = jQuery('#topnav').offset().top+288;
jQuery(window).scroll(function(){
if( jQuery(window).scrollTop() > stickyHeader ) {
jQuery('#magatopnav').addClass('fixedtop');
} else {
jQuery('#magatopnav').removeClass('fixedtop');
} 
});  
 jQuery(window).scroll(function () {
     if (jQuery(this).scrollTop() > 200) {
         jQuery('#gotop').css({
             bottom: "15px"
         });
     } else {
         jQuery('#gotop').css({
             bottom: "-100px"
         });
     }
 });
   jQuery('#gotop').click(function () {
            jQuery('html, body').animate({
                scrollTop: '0px'
            }, 800);
            return false;
        }); 
jQuery('.icon-list').click(function() {
jQuery(this).addClass('active');
jQuery('.icon-th').removeClass('active');
		jQuery('.blog-lists-blog.clearfix').fadeOut(300, function() {
			jQuery(this).addClass('lists').fadeIn(300);
			 
		});
		return false;
	});
	
	jQuery('.icon-th').click(function() {
	jQuery(this).addClass('active');
	jQuery('.icon-list').removeClass('active');

		jQuery('.blog-lists-blog').fadeOut(300, function() {
			jQuery(this).removeClass('lists').fadeIn(300);
			 
		});
		return false;
	});

});
 
jQuery(document).ready(function(){
 
 
	  jQuery('.tabs_container2 .tab_content2:first').show();
        jQuery('.tabs2 li:first').addClass('active');
        jQuery.each(jQuery('.tabs2 li'),function(i,el){
            jQuery(el).click(function(){
                jQuery('.tabs_container2 .tab_content2').slideUp();
                jQuery('.tabs_container2 .tab_content2').eq(i).slideDown();
                jQuery('.tabs2 li').removeClass('active');
                jQuery(this).addClass('active');
                 return false;
            });
         }); 

 
});

jQuery(document).ready(function () {

 

/*cat nav menu*/
 
jQuery("#catnav ul li:has(ul),#maganav ul li:has(ul)").addClass("parent"); 
 jQuery(".catnav li").hover(function () {
 jQuery(this).has('ul').addClass("dropme");
 jQuery(this).find('ul:first').css({display: "none"}).stop(true, true).slideDown(500);},
 function () {
 jQuery(this).removeClass("dropme");
 jQuery(this).find('ul:first').css({display: "block"}).stop(true, true).slideUp(1000);
 });
});
 
 /*Flex slider + Carousel*/

jQuery(window).load(function() {
 
  jQuery('.flexcarousel').flexslider({
    animation: "slide",easing: "easeInOutCirc",
    animationLoop: false,
    itemWidth: 240,
    itemMargin: 0,
    minItems: 2,
    maxItems: 4
  });
 
   jQuery('.blogflexcarousel').flexslider({
    animation: "slide",easing: "easeInOutCirc",
    animationLoop: true,
    itemWidth: 236,
    itemMargin: 10,
    minItems: 2,
    maxItems: 4
  });
 
  jQuery('.flexslider').flexslider({
    animation: "slide",easing: "easeInOutCirc",
	slideshowSpeed: 10000,
	animationSpeed: 2000,
	touch: true,
	video: true,
	randomize: false,
	pauseOnHover: true,

    start: function(slider) {
     jQuery('.fluid_container').show(); 
    }
  });
  }); 
 

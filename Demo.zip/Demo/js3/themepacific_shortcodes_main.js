/*
Plugin Name: ThemePacific Shortcodes Pro
Plugin URI: http://themepacific.com/wp-plugins/themepacific-shortcode-pro/
Description: A Pro Shortcode Plugin from ThemePacific
Author: Raja CRN, ThemePacific
Author URI: http://themepacific.com
Version: 1.0
Copyright 2013, ThemePacific.
Text Domain: themepacific
@package ThemePacific Shortcodes
@category Core
@author ThemePacific
*/
(function($) {
$(".themepacific_sh_accordion").accordion({autoHeight: false});
	$( ".themepacific_sh_tabs" ).tabs();	
	$("h3.themepacific_sh_toggle-title").click(function(){
	$(this).toggleClass("active").next().slideToggle("fast");return false;
	});

 })(jQuery);
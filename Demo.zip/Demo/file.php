
<?php
 if(isset($_POST['Import']))
 { 
   mysqli_connect('localhost','root','');
   mysqli_select_db('clearance');
   $name=$_FILES['file']['name'];
   $type=$_FILES['file']['type'];
   if($type=='image/jpeg' || $type=='image/png' || $type=='image/gif' || $type=='image/pjpeg')
   {
if(file_exists(dirname($_SERVER['DOCUMENT_ROOT']).'/oops/upload/image/'.$name))
     {
      echo'file is already present';
     }
     else
     {
      $up=move_uploaded_file($_FILES['file']['tmp_name'],dirname($_SERVER['DOCUMENT_ROOT']).'/oops/upload/image/'.$name);
      $q=mysqli_query($conn,"insert into image values('','".$name."')");
  if($up && $q)
  {
   echo'image uploaded and stored';
  }
  elseif(!$up) 
  {
   echo'image not uploaded';
  }
  elseif(!$q)
  {
   echo'image not stored';
  }
 }
   }
   else
   {
    echo'Invalid file type';
   }
 }
?>

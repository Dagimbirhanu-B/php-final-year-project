

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.pic2').qtip({
			content: 'Click to View Larger Image',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.news').qtip({
			content: 'News and Events',
			position: {
            my: 'top left',
            target: 'fixed',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.about').qtip({
			content: 'Click here to view About SU',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.MB').qtip({
			content: 'it Means Hamid Mebri (Abdul hamid Nesru)',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	

			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.site').qtip({
			content: 'Click here to View Class Map',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	

		
		
						<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#read').qtip({
			content: 'Click here to read more about. . . ',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
					<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.login').qtip({
			content: 'click here to login as Admin or Scheduler Or to Submit Sleep',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.admin_login').qtip({
			content: 'click here to login as Admin',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.scheduler_login').qtip({
			content: 'click here to login as Scheduler',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.user_login').qtip({
			content: 'click here to login as User to Submit Sleep',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		</script>	
					<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.feedback').qtip({
			content: 'click here to send feedback.',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
					
					
					
					
					
					
						<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.today').qtip({
			content: 'Today is <?php $Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.faq').qtip({
			content: 'Click Here to View FAQ',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		</script>	
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.class_schedule').qtip({
			content: 'Click Here to search Class Schedul',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.year_section').qtip({
			content: 'Click Here to search year section Schedul',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.instractor').qtip({
			content: 'Click Here to search instractor Schedul',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.room').qtip({
			content: 'Click Here to search Room Schedul',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.language').qtip({
			content: 'Click Here to change Language',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Amharic').qtip({
			content: 'Click Here to change Language to Amharic',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.English').qtip({
			content: 'Click Here to change Language to English',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Tegringa').qtip({
			content: 'Click Here to change Languag Tegringae',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Oromifa').qtip({
			content: 'Click Here to change Language',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Qafari').qtip({
			content: 'Click Here to change Language To Qafari',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Hindu').qtip({
			content: 'Click Here to change Language To Hindu',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
		
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Philipino').qtip({
			content: 'Click Here to change Language to Philipino',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
<?php 
include('header.php');
?> 
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutclearance.php" title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php" title="Calander View"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="viewpost.php"title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
<li><a href=""><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Login</a>
<ul>
<li><a href="login.php?action=login"  title="Login Offices"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Officess Login</a></li>
<li><a href="loginstudent.php" title="Login Student"><i class="glyphicon glyphicon-log-in" ></i>&nbsp;Students Login</a></li>
</ul>
</li>
<li class="current-menu-item"><a href="registerstudent.php?action=registerstudent"title="Create Account"><i class="glyphicon glyphicon-save" ></i>&nbsp;Create Account</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div class="menu">
<ul>
<li><a href="index.php" title="Home"><i class="glyphicon glyphicon-home"></i>&nbsp;Home</a></li>
<li><a href="aboutus.php" title="About Us"><i class="glyphicon glyphicon-user"></i>&nbsp;About Us</a></li>
<li><a href="crule.php"title="Clearance Rule and Regulation"><i class="glyphicon glyphicon-file"></i>&nbsp;Cl Rule &amp; Regulation</a></li>
<li><a href="notice.php"title="Notice to Student"><i class="glyphicon glyphicon-time"></i>&nbsp;Notice to Student</a></li>
<li><a href="contactus.php"title="Contact Us"><i class="glyphicon glyphicon-share"></i>&nbsp;Contact Us</a></li>
<li><a href="feedback.php"title="Feed Back"><i class="glyphicon glyphicon-plane"></i>&nbsp;Feed Back</a></li>
<li><a href="help.php?action=help"title="Help Menu"class="active"><i class="glyphicon glyphicon-book"></i>&nbsp;Help</a></li>
</ul>
</div>
<div id="panel">
<div id="panel">			
</div>
</br>
</br>
</br>
</div>
<div class="size2">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div id="container">
<div class="hero-unit-bud11">
<ul class="nav nav-tabs"> 
  <li class="active"><a href="#home" data-toggle="tab"><i class="glyphicon glyphicon-question-sign"></i>&nbsp;<font color="orange">Frequently Asked Questions (FAQ)</font></a></li>
</ul>

<div class="tab-content">
  <div class="tab-pane active" id="home">
  <div class="hero-unit-y">
<hr>
  <div class="tab-pane active" id="profile">
<ul class="nav nav-tabs">
  <li><a href="#"><font color="white"></font><font color="orange">1.<i class="glyphicon glyphicon-search"></i>&nbsp; How to search Student Case?</font></a></li>
  <li><a  href="#2"><font color="white"></font><font color="orange">2.<i class="glyphicon glyphicon-print"></i>&nbsp; How to Print Clearance?</font></a></li>
  <li><a  href="#3"><font color="white"></i></font><font color="orange">3.<i class="glyphicon glyphicon-download"></i>&nbsp; How to dowload clearance?</font></a></li>
  <li><a  href="#4"><font color="white"></font><font color="orange">4.<i class="glyphicon glyphicon-check"></i>&nbsp; How to Use System?</font></a></li>
  <li><a  href="#5"><font color="white"></font><font color="orange">5.<i class="glyphicon glyphicon-send"></i>&nbsp; How to Send message to the respected office?</font></a></li>
  <li><a  href="#6"><font color="white"></font><font color="orange">6.<i class="glyphicon glyphicon-comment"></i>&nbsp; How to Write Feedback?</font></a></li>
  <li><a  href="#7"><font color="white"></font><font color="orange">7.<i class="glyphicon glyphicon-link"></i>&nbsp; How to Email for the respected office?</font></a></li>
  <li><a  href="#8"><font color="white"></font><font color="orange">8. How to Email for the respected office?</font></a></li>
  <li><a  href="#9"><font color="white"></font><font color="orange">9. How to Email for the respected office?</font></a></li>
  <li><a  href="#10"><font color="white"></font><font color="orange">10. How to Email for the respected office?</font></a></li>
  </ul>
</div>
  <hr>
  <div class="mm" id="1">
  <h2 align="left">1. How to search Student Case?</h2>
  <hr>
  <img src="helpimage/message.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="2">
  <h2 align="left">2. How to Print Clearance?</h2>
  <hr>
  <img src="helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="3">
  <h2 align="left">3. How to dowload clearance?</h2>
  <hr>
  <img src="helpimage/download.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="4">
  <h2 align="left">4. How to Use System?</h2>
  <hr>
  <img src="helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="5">
  <h2 align="left">5. How to Send message to the respected office?</h2>
  <hr>
  <img  src="helpimage/message.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="6">
  <h2 align="left">6. How to Write Feedback?</h2>
  <hr>
  <img src="helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <div class="mm" id="7">
  <hr>
  <h2 align="left">7. How to Email for the respected office?</h2>
  <hr>
  <img src="helpimage/message.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="8">
  <h2 align="left">8. How to Email for the respected office?</h2>
  <hr>
  <img src="helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="9">
  <h2 align="left">9. How to Email for the respected office?</h2>
  <hr>
  <img src="helpimage/feedback.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
  <div class="mm" id="10">
  <h2 align="left">10. How to Email for the respected office?</h2>
  <hr>
  <img src="helpimage/download.jpg" style="margin-left:50px;" width=1000px;>
  </div>
  <hr>
 </div>
 </div>
  </div>
</div>
</div>
<?php 
include('footer.php'); 
?>
</body>
</html>


<?php 
session_start();
        if(isset($_POST['login']))
        {
            include_once("db_config/dbcon.php");
            $username=$_POST["Username"];
            $password=$_POST["Password"];
            
            $sql = "SELECT * FROM account WHERE username = '$username' AND password='$password'";
            $qr = mysqli_query($conn,$sql);  
            $result = mysqli_num_rows($qr);
        	 if($result>0)
                {
                 while($row = mysqli_fetch_array($qr))
                        {
                          $user_role= $row['Role'];
                        }
										if($user_role!='0')
										{
											if($user_role=='library')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location: library/library.php");
											exit();
											}
											elseif($user_role=='registrar')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location:registrar/registrar.php");
											exit();
											}
											elseif($user_role=='library')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location: library/library.php");
											exit();
											}
											elseif($user_role=='bookstore')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location: bookstore/bookestore.php");
											exit();
											}
											elseif($user_role=='proctor')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location: proctor/proctor.php");
											exit();
											}
											elseif($user_role=='sportscience')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location: sportscience/sportscience.php");
											exit();
											}
											elseif($user_role=='studentservice')
											{
											$_SESSION['SESS_MEMBER_ID'] = $user_role['Password'];
			                                $_SESSION['SESS_FIRST_NAME'] = $user_role['Username'];
											session_write_close();
											header("Location: studentservice/studentservice.php");
											exit(); 
											}
											else
											{
	                                             ?>
									            <script>
                                                 alert('YOUR USER NAME AND PASSWORD IS NOT MATCH WITH YOUR ROLE Tray again');
                                                 window.location='login.php';
                                                </script>
								                <?php
											}
                                        }
										else
										{  
										?>
										  <script>
                                           alert('Your account is disabled Please Contact the Administrator!!! and Try again');
                                           window.location='login.php';
                                           </script>
									    <?php	
									    }
								}
                                else
                                { 
                                ?>
									<script>
                                    alert('Incorrect USER NAME or PASSWORD Pls match and Try again ');
                                    window.location='login.php';
                                    </script>
								<?php								   
    							}
           }
        ?>
                                
      
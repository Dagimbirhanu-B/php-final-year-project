<?php
session_start();
if(!isset($_SESSION['SESS_MEMBER_ID']))
{
?>
 <script>
  alert('YOU ARE NOT ALLOWED TO ACCESS!!Please Login to access the page');
  window.location='../login.php';
 
 </script>
<?php
}
 include_once("headeroffices.php");
include_once("header2.php");
?>
<!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home" ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Post Comments"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices" class="active1">Register Offices</a></li>
<li class="leaf"><a href="registerstudent.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div class="container">
<div class="panel">    
              <div class="panel panel-default">
                  <div class="panel-heading">
                        <center><h3 class="panel-title">Debre Tabor University User Registration Form</h3></center>
                  </div>
				  <form class="form-horizontal" action="index.php" method="post">
				<div class="control-group">
						<table border="0" cellpadding="10">
							
						</table>
						
					
			</form>
			
                  <div class="panel-body">
         <form class="form-horizontal" role="form" action="" method="post">
                 <table cellpadding='5' style=" margin: auto; margin-top: -100px;">
                 <tr>
                       <div class="form-group">
                     <td>
                            <label class=" control-label">First Name</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="Fname" placeholder="First name" required=""/>
                    </td>
                          </div>
                 <td></td>
				 </tr>
                 <tr>
                          <div class="form-group">
                     <td>
                            <label class=" control-label">Middle Name</label>
                     </td>
                     <td>
                              <input type="text" class="form-control" name="Mname" placeholder="Middle name" required=""/>
                     </td>
                          </div>
                 <td></td>
				 </tr>
                 <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">Last Name</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="Lname" placeholder="Last name" required=""/>
                    </td>
                          </div>
                 <td></td>
				 </tr>
                 <tr>
                     <div class="form-group">
                    <td>             
                            <label class="control-label">Sex</label>
                    </td>
                            
                            <td>
                               <div class="radio">
                                  <label>
                                    <input type="radio" name="Sex" id="optionsRadios1" value="male" required=""/>
                                    Male
                                  </label>
                                </div>
                            </td>
                 </tr>
                 <tr>
                 <td></td>
                 <td>
                                <div class="radio">
                                  <label>
                                    <input type="radio" name="Sex" id="optionsRadios2" value="female" required=""/>
                                    Female
                                  </label>
                                </div>
                             </td>       
                            </tr> 
                          </div>
						  <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">Email</label>
                    </td>
                    <td>
                              <input type="email" class="form-control" name="email" placeholder="Email(examlpe@gmail.com)" required=""/>
                    </td>
                          </div>
                 <td></td>
                            <tr>
							  <div class="form-group">
								<td>
									<label class="control-label" >Username</label>
								</td>
								<td>
								<div class="controls">
									  <input type="text" name="username" id="username" class="form-control" placeholder="Username" style="height: 30px;">
									</div>
								</td>
								<td>
									 <div class="username_avail_result" id="username_avail_result">&nbsp;</div>
								</td>
								</div>
							</tr>
							<tr>
							  <div class="form-group">
								<td>
									<label class="control-label" >Password</label>
								</td>
								<td>
								<div class="controls">
									  <input type="password" name="pass1" id="pwd1" class="form-control" style="height: 30px;" placeholder="Password" required="" required x-moz-errormessage='input must contain at least one digit/lowercase/uppercase letter and be at least 6 character long' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}'  onchange='form.pwd2.pattern = this.value;'>
									</div>
								</td>
								<td>
									  <div class="password_strength" id="password_strength">&nbsp;</div>
								</td>
								</div>
							</tr>
                   <tr>
                   <div class="form-group">
                      <td>
                            <label class="control-label">Confirm Password</label>
                      </td>
                      <td>
                              <input type="password" class="form-control" name="pass2"  id="pwd2" placeholder="Confirm Password"required x-moz-errormessage="The password should be match" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required="" />
                       </td>
                   </div>
                  
                   </tr> 
                    <div class="form-group">
                      <td>
                            <label class="control-label">Select Role</label>
                      </td>
                      <td>
                          
                              <select class="form-control" name="role" >
                                    <option value="">--Select Role--</option>
                                    <?php
											$sql=mysqli_query($conn,"select * from account");
											while($row=mysqli_fetch_array($sql))
											{
											$office=$row['Role'];
											@$id=$row['id'];
											 echo '<option value="'.$office.'">'.$office.'</option>';
											} 
                              ?>
							  </select>
                           
                       </td>
                   </div>
                   <tr> 
                          <div class="form-group">
                          <td>
                            <div class="col-lg-offset-6">
                              <button type="submit" class="btn btn-primary" name="AddAccount"><i class="glyphicon glyphicon-save" ></i>&nbsp;Add Account</button>
                            </div>
                          </td>
						  <td>
                            <div class="col-lg-offset-6">
                              <button type="reset" class="btn btn-primary"  name="clear"><i class="glyphicon glyphicon-remove" ></i>&nbsp;Clear</button>
                            </div>
                          </td>
                          <td></td>
                          </div>
                   </tr>
              </table>
      </form>
      <?php
        
            include_once('controller/registration_controller.php');
      
      
      
      ?>
                  </div>
             </div>        
    </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" class="active1"><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="deletepost.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-book" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
 <!--Library menu bar -->
<div class="container1">
<div class="panel">
<div class="panel panel-default">
<div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                  Debre Tabor University Registrar File Upload 
                                </a>
								</h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse in">
                              <div class="panel-body">
                              <p><b>Here is your File Uploaded</b></p>
                                 <?php
$result = mysqli_query($conn,"SELECT * FROM uploadfile");
?>
  <form name="form2" method="post" action="">
  <table  class="table" align="center" border="0" width="100%" id="example">                               
  <tr class="danger">
                                   <th>Uplod Id</th>
								   <th>FILE Name</th>
								   <th>FILE TYPE</th>
								   <th>FILE SIZE</th>
                                   <th>TIME UPLOAD</th>
  </tr>
  <?php
  while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
		  echo "<td>&nbsp;" . $row['FID'] . "</td>";
		  echo "<td>&nbsp;" . $row['File'] . "</td>";
		  echo "<td>&nbsp;" . $row['type'] . "</td>";
		  echo "<td>&nbsp;" . $row['size'] . "</td>";
          echo "<td>&nbsp;" . $row['Date'] . "</td>";
		  echo "</tr>&nbsp;";
  }
?>
</table>
</form>
 </div>
 </div>
 </div>                
 </div> 
</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

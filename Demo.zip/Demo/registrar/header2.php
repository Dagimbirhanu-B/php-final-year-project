<html>
	<head>
	<!-- js -->	
			
		 <script src="js/jquery_1.9.js"></script>
		
		<style type="text/css">
		.success {color: green; font-weight: bold; font-size: 25px;}
		.error {color: red; font-weight: bold; font-size: 25px;}
		.password_strength {display:block;width:180px;padding:3px;text-align:center;color:#333;font-size:12px;backface-visibility:#FFF;font-weight:bold;}
		/* Password strength indicator classes veryweek weak, normal, strong, verystrong*/
		.password_strength.veryweek{background:#e84c3d;}
		.password_strength.weak{background:#e84c3d;}
		.password_strength.normal{background:#f1c40f;}
		.password_strength.strong{background:#27ae61;}
		.password_strength.verystrong{background:#2dcc70;color:#FFF;}
    </style>

    <script type="text/javascript">
		$(document).ready(function(){
			$('#username').keyup(function(){ 
				var Username = $(this).val();
				var UsernameAvailResult = $('#username_avail_result');
				if(Username.length > 2) { 
					UsernameAvailResult.html('Loading..');
					var UrlToPass = 'action=username_availability&username='+Username;
					$.ajax({ 
					type : 'POST',
					data : UrlToPass,
					url  : 'checker.php',
					success: function(responseText){ 
						if(responseText == 0){
							UsernameAvailResult.html('<span class="success">&check;</span>');
						}
						else if(responseText > 0){
							UsernameAvailResult.html('<span class="error">&times;</span>');
						}
						else{
							alert('Problem with sql query');
						}
					}
					});
				}else{
					UsernameAvailResult.html('Enter atleast 3 characters');
				}
				if(Username.length == 0) {
					UsernameAvailResult.html('');
				}
			});
			
			$('#pwd1, #username').keydown(function(e) { 
				if (e.which == 32) {
					return false;
				}
			});
			
			$('#pwd1').keyup(function() { // As same using keyup function for get user action in input
				var PasswordLength = $(this).val().length; // Get the password input using $(this)
				var PasswordStrength = $('#password_strength'); // Get the id of the password indicator display area
				
				if(PasswordLength <= 0) { // Check is less than 0
					PasswordStrength.html(''); // Empty the HTML
					PasswordStrength.removeClass('normal weak strong verystrong'); //Remove all the indicator classes
				}
				if(PasswordLength <3) { // If string length less than 4 add 'weak' class
					PasswordStrength.html('very week');
					PasswordStrength.removeClass('normal strong verystrong').addClass('Very weak');
				}
				if(PasswordLength > 3 && PasswordLength < 6) { // If string length less than 4 add 'weak' class
					PasswordStrength.html('weak');
					PasswordStrength.removeClass('normal strong verystrong').addClass('weak');
				}
				if(PasswordLength > 6 && PasswordLength < 10) { // If string length greater than 4 and less than 8 add 'normal' class
					PasswordStrength.html('Normal');
					PasswordStrength.removeClass('weak strong verystrong').addClass('normal');			
				}	
				if(PasswordLength >= 10 && PasswordLength < 15) { // If string length greater than 8 and less than 12 add 'strong' class
					PasswordStrength.html('Strong');
					PasswordStrength.removeClass('weak normal verystrong').addClass('strong');
				}
				if(PasswordLength >= 15) { // If string length greater than 12 add 'verystrong' class
					PasswordStrength.html('Very Strong');
					PasswordStrength.removeClass('weak normal strong').addClass('verystrong');
				}
			});
	
		});
	</script>
	</head>
	<body>	
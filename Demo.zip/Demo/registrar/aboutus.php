<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calander</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home" ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php" title="About Us"class="active" ><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><span class="glyphicon glyphicon-envelope" ></span>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="registerstudent.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Students</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div id="container">
<div class="hero-unit-bud11">
<ul class="nav nav-tabs"> 
  <li class="active"><a class="about" href="#profile" data-toggle="tab"><font color="white"></font><font color="orange"><i class="glyphicon glyphicon-user"></i>&nbsp;About Debre Tabor University</a></font></li>
   <li><a class="site" href="#settings" data-toggle="tab"><font color="white"></font><font color="orange"><i class="glyphicon glyphicon-flag"></i>&nbsp;University Environment</a></font></li>
   <li ><a class="news" href="#home" data-toggle="tab"><font color="white"></font><font color="orange"><i class="glyphicon glyphicon-headphones"></i>&nbsp;Announcement</font></a></li>
</ul>
<?php
// Function to calculate Years, Monts,Days, hours, minutes, seconds
function secondsToWords($seconds)
{
    $ret = "";
    /*** get the months ***/
    $years = intval(intval($seconds) / (365*60*60*24));
	    /*** get the months ***/
    $months = intval(intval($seconds) / (30*60*60*24));
    /*** get the days ***/
    $days = intval(intval($seconds) / (3600*24));
    /*** get the hours ***/
    $hours = (intval($seconds) / 3600) % 24;	
    /*** get the minutes ***/
    $minutes = (intval($seconds) / 60) % 60;
    /*** get the seconds ***/
    $seconds = intval($seconds) % 60;
	
	if($years> 0)
    {
        $ret = "$years years ago";
    }
	else if($months> 0)
    {
        $ret = "$months months ago";
    }
    else if($days> 0)
    {
        $ret = "$days days ago";
    }
    else if($hours > 0)
    {
        $ret = "$hours hours ago";
    }
    else if($minutes > 0)
    {
        $ret = "$minutes minutes ago";
    }
    else if ($seconds > 0) {
      $ret = "$seconds seconds ago";
    }
    else
	{
        $ret = "2 seconds ago";
    }
    return $ret;
}
?>
<link rel="stylesheet" href="../css/commentstyle.css" type="text/css"/>
<div class="tab-content">
<div class="tab-pane" id="home">
<div class="hero-unit-y">
<hr class="hr"/>
<div class="index-text"> 
<ol>
<?php
$msql=mysqli_query($conn,"select * from outcomment order by msg desc");
while($messagecount=mysqli_fetch_array($msql))
{
$id=$messagecount['msg'];
$msgcontent=$messagecount['message'];
?>
<?php
$list=mysqli_query($conn,"select * from comments where msg_id_fk='$id' order by com_id");
while($rowsmall=mysqli_fetch_array($list))
{ 
$date1=$rowsmall['intime'];
$date2 = date("Y-m-d h:i:s");
$ts1 = strtotime($date1);
$ts2 = strtotime($date2);
$seconds_diff = $ts2 - $ts1;
$timesago = floor($seconds_diff/3600/24);
$hdmago =secondsToWords($seconds_diff);
}
?>
<hr class="hr"/>
<li class="egg">
<div class="egg_Body">
<h3 class="egg_Message" >
<img src="../image2/profile.jpg" /><span><?php echo $msgcontent; ?></span>
<div style="margin-top:10px; margin-left: 58px;">
<?php 
$sql=mysqli_query($conn,"select * from comments where msg_id_fk='$id' order by com_id");
$comment_count=mysqli_num_rows($sql);

if($comment_count>9)
{
$second_count=$comment_count-9;
?>
<div class="comment_ui" id="view<?php echo $id; ?>">
<div>
<a href="#" class="view_comments" id="<?php echo $id; ?>">View all <?php echo $comment_count; ?> comments</a>
</div>
</div>
<?php 
} 
else 
{
$second_count=0;
}
?>
<div id="view_comments<?php echo $id; ?>"></div>
<div id="two_comments<?php echo $id; ?>">
<?php
$listsql=mysqli_query($conn,"select * from comments where msg_id_fk='$id' order by com_id limit $second_count,9 ");
while($rowsmall=mysqli_fetch_array($listsql))
{ 
$c_id=$rowsmall['com_id'];
$comment=$rowsmall['comment'];
$list=mysqli_query($conn,"select * from comments ");
while($rowsmall=mysqli_fetch_array($list))
{ 
$time=$rowsmall['intime'];
}
?>
<div class="comment_ui">
<div class="comment_text">
<div  class="comment_actual_text"><img src="../image2/profile.jpg" width="32" height="32" />
<div id="sssss"><?php echo $comment.'&nbsp;&nbsp;&nbsp;@&nbsp;'.$hdmago;?></div></div>
</div>
</div>
<?php 
}
?>
<div class="dddd">
<div>
<img src="../image2/profile.jpg" width="32" height="32" />
<form action="" method="post">
<input name="mesgid" type="hidden" value="<?php echo $id ?>" />
<i class="glyphicon glyphicon-user"></i>&nbsp;<input name="mcomment" type="text" placeholder="Write a comment..." style="height: 24px; border:1px solid #BDC7D8; padding:3px; border-width: 1px 0px 1px 1px; width:302px;" required="required"/>
<input id="buts" name="commentsave" type="submit" value="comment" />
    <?php
       include_once('../controller/registration_controller.php');
      ?>
</form>
</div>
</div>
</div>
</div>
</div>
</li>
<?php
}
?>
</ol>
</div>
</div>
</div>
<!--next-->
  <div class="tab-pane active" id="profile">
  <div class="hero-unit-y">
  <div class="hero-unit-y">
  <div class="hero-unit-bud1">
<div class="about_nav">
<ul class="nav nav-tabs nav-stacked">
  <li><a data-toggle="modal" href="#history"><font color="orange"><i class="glyphicon glyphicon-book"></i>&nbsp;History</font></a></li>
  <li><a data-toggle="modal" href="#mission"></font><font color="orange"><i class="glyphicon glyphicon-tag"></i>&nbsp;Mission</font></a></li>
  <li><a data-toggle="modal" href="#vision"></font><font color="orange"><i class="glyphicon glyphicon-tags"></i>&nbsp;Vission</font></a></li>
  <li><a data-toggle="modal" href="#developer"></font><font color="orange"><i class="glyphicon glyphicon-user"></i>&nbsp;Developer</font></a></li>
</ul> 
</div>
</div>
<div class="history_chmsc">
<p><h2 align="left">About Debre Tabor University</h2></p>
<hr/>
  <p align="justify">Debre Tabor University  is one among the public universities established by the Federal Democratic Republic  of Ethiopia to provide the higher education in the country through teaching  reaserch and community survice. &#4720;o and the university has six  faculities namely </p>
  <p align="justify">Faculty of Technology,</p>
  <p align="justify">College of medicine and health-science</p>
  <p align="justify">Faculty of natural and computational science</p>
  <p align="justify">Faculty of social science and humanities</p>
  <p align="justify">Faculty of business and economics and </p>
  <p align="justify">Faculty of agriculture and environmental science</p>
  <p align="justify">  The University is dedicated to the supply of highly qualified and innovative human resource by providing societal needs-tailored quality education. Debre Tabor University tries hard to become one of the top universities in the country in quality education in 2020 (2012 E.C).</p>
  </div>
 </div>
 </div>
 </div>
 <br /><br />
<div class="tab-pane" id="settings">
<div class="hero-unit">
<div id="myCarousel2" class="carousel slide">
  <!-- Carousel items -->
  <div class="carousel-inner">
     <div class="active item"><img src="../image/2.jpg" width="1090" height="500"></div>
        <div class="item"><img src="../image/3.jpg" width="1090" height="500"></div>
    <div class="item"><img src="../image/4.jpg" width="1090" height="500"></div>
    <div class="item"><img src="../images/5.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../images/buld1.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../images/7.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../images/8.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image2/9.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../images/10.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../images/11.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image/slide8.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image/slide9.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image/slide10.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image/slide11.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image/slide12.jpg" width="1090" height="500"></div>
  <div class="item"><img src="../image/staff.jpg" width="1090" height="500"></div>
  </div>
  <!-- Carousel nav -->
  <a class="carousel-control left" href="#myCarousel2" data-slide="prev">&lsaquo;</a>
  <a class="carousel-control right" href="#myCarousel2" data-slide="next">&rsaquo;</a>
</div>
</div>
</div>  
</div>
</div>
</div>
<br />
<?php 
include('footeroffices.php'); 
?>
</body>
</html>
<?php
	include_once("../missionvisionhistory.php");
?>




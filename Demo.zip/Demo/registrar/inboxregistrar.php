<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message" class="active" ><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="deletepost.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="help.php" title="help"><i class="glyphicon glyphicon-question-sign" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
 <!--Library menu bar -->
<div class="container1">
<div class="panel">
<div class="panel panel-default">
 <div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                  Debre Tabor University Registrar Offices Inbox Message 
                                </a>
                              </h4>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse in">
                              <div class="panel-body">
                              <p><b>Here Is the Message from the User</b></p>
                                 <?php
if(@$_GET["view"] == "delete")
{
mysqli_query($conn,"DELETE FROM messages WHERE MID ='$_GET[slid]'");
}
$result = mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar' ORDER BY time DESC");
?>
  <form name="form2" method="post" action="">
  <table  class="table" align="center" border="1" width="100%" id="example">                               
  <tr class="danger">
                                   <th>ACTION</th>
								   <th>IDNO</th>
                                   <th>NAME</th>
								   <th>EMAIL ADDRESS</th>
                                   <th>PHONE</th>
                                   <th>MESSAGE</th>
                                   <th>TIME</th>
								   <th>CLEARANCE</th>
								   <th>REPLY</th>
  </tr>
  <?php
	  $i =1;
  while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>&nbsp";
  ?>
  <a href='inboxregistrar.php?slid=<?php echo @$row[MID]; ?>&view=delete'><img src='../images/delete.png'  onclick="return confirm('Are you sure??')"/></a>
  <?php
          echo  $i . " </td>";
          echo "<td>&nbsp;" . $row['IDNo'] . "</td>";
     	  echo "<td>&nbsp;" . $row['Name'] . "</td>";
		  echo "<td>&nbsp;" . $row['Email'] . "</td>";
	      echo "<td>&nbsp;" . $row['phone'] . "</td>";
		  echo "<td>&nbsp;" . $row['messagess'] . "</td>";
          echo "<td>&nbsp;" . $row['time'] . "</td>";
		  ?>
		  <td>&nbsp;<a href='check.php?slid=<?php echo $row["IDNo"]; ?>&chech=status' class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;&nbsp;GIVE</a></td>
		  <td>&nbsp;<a href='reply.php?slid1=<?php echo $row["IDNo"]; ?>&reply=to' class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>&nbsp;&nbsp;REPLY</a></td>
		  <?php
		  echo "</tr>&nbsp;";
  $i++;
  }
  
?>
</table>
</form>
 </div>
 </div>
 </div>                
 </div>
<div class="panel-group" id="accordion">
                          <div class="head" >
                            <div class="ptitle">
                              <h4 class="panel-title">
							  <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM feedback WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                  Debre Tabor University Registrar Offices Feedback Message 
                                </a><font color="blue">You have&nbsp;</font><font color="red"><?php echo $number;?></font>&nbsp;feed back messages 
                              </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse">
                              <div class="panel-body">
                              <p><b>Here Is the Feedback Message from the User</b></p>
                                 <?php
if(@$_GET["view"] == "delete")
{
mysqli_query($conn,"DELETE FROM feedback WHERE FID ='$_GET[slid]'");
}
@$result = mysqli_query($conn,"SELECT * FROM feedback WHERE Offices='registrar'");
?>
  <form name="form2" method="post" action="">
  <table  class="table" align="center" border="1" width="100%" id="example">                               
  <tr class="danger">
                                   <th>ACTION</th>
								   <th>EMAIL ADDRESS</th>
                                   <th>MESSAGE</th>
                                   <th>TIME</th>
  </tr>
  <?php
	  $i =1;
  while(@$row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>&nbsp";
  ?>
  <a href='inboxregistrar.php?slid=<?php echo @$row[FID]; ?>&view=delete'><img src='../images/delete.png'  onclick="return confirm('Are you sure??')"/></a>
  <?php
          echo  $i . " </td>";
		  echo "<td>&nbsp;" . $row['Email'] . "</td>";
		  echo "<td>&nbsp;" . $row['Comment'] . "</td>";
          echo "<td>&nbsp;" . $row['date'] . "</td>";
		  echo "</tr>&nbsp;";
  $i++;
  }
  
?>
</table>
</form>
 </div>
 </div>
 </div>                
 </div> 
</div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

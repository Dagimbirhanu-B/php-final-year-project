<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Debre Tabor University Student's Online  Clearance System</title>
<meta http-equiv='refresh' content='60'>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Script-Type" content="text/javascript">

<link rel="shortcut icon"href="image2/dtu1.gif" />
<link rel="stylesheet" href="css/global.css" type="text/css"/>
<link rel="stylesheet"   href="css3/styles.css"  media="screen"/>
<link rel="stylesheet"   href="css33/bootstrap.css"  media="screen"/>
<link rel="stylesheet"   href="css3/bootstrap.min.css"  media="screen"/>
<link rel="stylesheet"   href="css3/bootstrap-datetimepicker.min.css"  media="screen"/>
<link rel="stylesheet"   href="css3/formstyles.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css3/font-awesome.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css3/google-code-prettify/prettify.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css2/topheadernavigation.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css3/font-awesomeicon.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css3/icon.css" media="screen"type="text/css"/>
<link rel="stylesheet"   href="css/birthcalanderstyle.css" media="screen"type="text/css"/>

    <script src="js/tpcrn_scripts.js" language="javascript" type="text/javascript"></script>
    <script src="js2/imageslideshow.js" language="javascript" type="text/javascript"></script>
    <script src="js2/jquery.hoverdir.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap.min.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap.js" language="javascript" type="text/javascript"></script>
    <script src="js2/google-code-prettify/prettify.js" language="javascript" type="text/javascript"></script>
    <script src="js2/holder/holder.js" language="javascript" type="text/javascript"></script>
    <script src="js/hidetopnavigation.js" charset="utf-8" language="javascript" type="text/javascript" ></script>
    <script src="js/jquery.js" language="javascript" type="text/javascript" ></script>
    <script src="js2/slideShow.dataTables.js" language="javascript" type="text/javascript"></script>
    <script src="js2/jquery.dataTables.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap-popover.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap-collapse.js" language="javascript" type="text/javascript"></script>
    <script src="js2/va.js" language="javascript" type="text/javascript"></script>
    <script src="js2/bootstrap-datetimepicker.min.js" language="javascript" type="text/javascript"></script>
<script src="date/calendar.js" type="text/javascript" language="javascript"></script> 
<script src="date/calendar-en.js"type="text/javascript" language="javascript"></script> 
<script src="date/calendar-setup.js"type="text/javascript" language="javascript"></script> 
<script src="date/monthpicker.js"type="text/javascript" language="javascript"></script> 

<style type="text/css">
#marqueecontainer {
position: relative;width:100%;
height:180px;overflow: hidden;padding: 2px;padding-left: 4px;
}
#vmarquee {position: absolute; width: 95%; font-size:14px;}
#vmarquee h3 {
text-align: center; color:#000000; font-size:110%;
 font-style:normal; font-weight:700;padding-top:6px;}
#vmarquee p {color:#3F3F3F; font-weight:normal;font-style:normal;text-align:left;}
#vmarquee p a {color:#6F2222;}
#vmarqueesmall {text-align: center;color:#666666;font-size:85%;
}
</style>
<?php 
include('db_config/dbcon.php');
 ?>
</head>
<body></br>
<div class="logo">
<img src="../images/capture7.jpg" alt="Debre Tabor University Logo" width="1147" height="115"style="margin-top:18px; margin-left:-5px;">
<img src="../images/ribbon.png" alt="Debre Tabor University Logo" width="100" height="115"style="margin-top:20px; margin-left:-10px</div>

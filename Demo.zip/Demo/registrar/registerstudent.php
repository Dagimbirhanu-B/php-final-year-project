<?php
include_once("headeroffices.php");
include_once("header2.php"); 
?>
<link rel="stylesheet" type="text/css" href="../time2/jquery.datetimepicker.css"/>
<style type="text/css">
.custom-date-style {
	background-color: red !important;
}
</style>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home"  ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Post Comments"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="registerstudent.php" title="Register Student"class="active1">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="../help.php" title="help"><i class="glyphicon glyphicon-book" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div class="container">
<div class="panel">
<div class="panel panel-primary">
                  <!--<div class="panel-heiading">
                        <h3 class="panel-title">User Registration Form</h3>  
                  </div>-->
               <div class="panel-body">
              <center><h3><font color="black">Debre Tabor University Student Registration Form</font></h3></center>
                <form class="form-horizontal" role="form" action="#"  method="post">
                 <table cellpadding='5' style=" margin: auto; margin-top: -150px;">
                 <tr>
                       <div class="form-group">
                     <td>
                            <label class=" control-label">First Name:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="Fname" placeholder="First name" required=""/>
                    </td>
                          </div>
                 </tr>
                 <tr>
                          <div class="form-group">
                     <td>
                            <label class=" control-label">Middle Name:</label>
                     </td>
                     <td>
                              <input type="text" class="form-control" name="Mname" placeholder="Middle name" required=""/>
                     </td>
                          </div>
                 </tr>
                 <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">Last Name:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="Lname" placeholder="Last name" required=""/>
                    </td>
                          </div>
                        </tr>
                    
         <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">User Name:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="username" id="username" placeholder="User Name" required=""/>
                    </td>
                          </div>
              <td>
                   <div class="username_avail_result" id="username_avail_result">&nbsp;</div>
              </td>
                 </tr>
         <tr>
                <div class="form-group">
                <td>
                  <label class="control-label" >Password</label>
                </td>
                <td>
                <div class="controls">
                    <input type="password" name="PASSWORD2" id="pwd1" class="form-control" style="height: 30px;" placeholder="Password" required="" required x-moz-errormessage='input must contain at least one digit/lowercase/uppercase letter and be at least 6 character long' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}'  onchange='form.pwd2.pattern = this.value;'>
                  </div>
                </td>
                <td>
                    <div class="password_strength" id="password_strength">&nbsp;</div>
                </td>
                </div>
              </tr>
                   <tr>
                   <div class="form-group">
                      <td>
                            <label class="control-label">Confirm Password</label>
                      </td>
                      <td>
                              <input type="password" class="form-control" name="pass2"  id="pwd2" placeholder="Confirm Password"required x-moz-errormessage="The password should be match" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required="" />
                       </td>
                   </div>
                  
                   </tr>
                 
				 <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">Security:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="security" placeholder="Enter security" required=""/>
                    </td>
                          </div>
                 </tr>
				 <!--
				 <tr>
                          <div class="form-group">
                    <td>
                            <label class="control-label">User Name:</label>
                    </td>
                    <td>
                              <input type="text" class="form-control" name="username" id="username" placeholder="User Name" required=""/>
                    </td>
                          </div>
						  <td>
									 <div class="username_avail_result" id="username_avail_result">&nbsp;</div>
						  </td>
                 </tr>
				 <tr>
							  <div class="form-group">
								<td>
									<label class="control-label" >Password</label>
								</td>
								<td>
								<div class="controls">
									  <input type="password" name="pass1" id="pwd1" class="form-control" style="height: 30px;" placeholder="Password" required="" required x-moz-errormessage='input must contain at least one digit/lowercase/uppercase letter and be at least 6 character long' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}'  onchange='form.pwd2.pattern = this.value;'>
									</div>
								</td>
								<td>
									  <div class="password_strength" id="password_strength">&nbsp;</div>
								</td>
								</div>
							</tr>
                   <tr>
                   <div class="form-group">
                      <td>
                            <label class="control-label">Confirm Password</label>
                      </td>
                      <td>
                              <input type="password" class="form-control" name="pass2"  id="pwd2" placeholder="Confirm Password"required x-moz-errormessage="The password should be match" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required="" />
                       </td>
                   </div>
                  
                   </tr>
              !-->				   
                 <tr>
                     <div class="form-group">
                    <td>             
                            <label class="control-label">Sex:</label>
                    </td>
                            
                            <td>
                               <div class="radio">
                                  <label>
                                    <input type="radio" name="Sex" id="optionsRadios1" value="male" required=""/>
                                    Male
                                  </label>
                                </div>
                            </td>
                 </tr>
                 <tr>
                 <td></td>
                 <td>
                                <div class="radio">
                                  <label>
                                    <input type="radio" name="Sex" id="optionsRadios2" value="female" required=""/>
                                    Female
                                  </label>
                                </div>
                       </td>       
                   </tr>           
                          </div>
			<tr>
			<div class="form-group">
				  <td class="_label"><label class="control-label">Birth Date:</label></td>
	             <td><input type="text" class="form-control" name="bday" id="datetimepicker11" size="30" />
                  </td>
	               </div>
				</tr>
<script src="../time2/jquery.js"></script>				
<script src="../time2/jquery.datetimepicker.js"></script>
<script>/*
window.onerror = function(errorMsg) {
	$('#console').html($('#console').html()+'<br>'+errorMsg)
}*/
$('#datetimepicker').datetimepicker({
dayOfWeekStart : 1,
lang:'en',
disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
startDate:	'1986/01/05'
});
$('#datetimepicker').datetimepicker({value:'2015/04/15 05:03',step:10});

$('.some_class').datetimepicker();

$('#default_datetimepicker').datetimepicker({
	formatTime:'H:i',
	formatDate:'d.m.Y',
	defaultDate:'8.12.1986', // it's my birthday
	defaultTime:'10:00',
	timepickerScrollbar:false
});

$('#datetimepicker10').datetimepicker({
	step:5,
	inline:true
});
$('#datetimepicker_mask').datetimepicker({
	mask:'9999/19/39 29:59'
});

$('#datetimepicker1').datetimepicker({
	datepicker:false,
	format:'H:i',
	step:5
});
$('#datetimepicker2').datetimepicker({
	yearOffset:222,
	lang:'ch',
	timepicker:false,
	format:'d/m/Y',
	formatDate:'Y/m/d',
	minDate:'-1970/01/02', // yesterday is minimum date
	maxDate:'+1970/01/02' // and tommorow is maximum date calendar
});
$('#datetimepicker3').datetimepicker({
	inline:true
});
$('#datetimepicker4').datetimepicker();
$('#open').click(function(){
	$('#datetimepicker4').datetimepicker('show');
});
$('#close').click(function(){
	$('#datetimepicker4').datetimepicker('hide');
});
$('#reset').click(function(){
	$('#datetimepicker4').datetimepicker('reset');
});
$('#datetimepicker5').datetimepicker({
	datepicker:false,
	allowTimes:['12:00','13:00','15:00','17:00','17:05','17:20','19:00','20:00'],
	step:5
});
$('#datetimepicker6').datetimepicker();
$('#destroy').click(function(){
	if( $('#datetimepicker6').data('xdsoft_datetimepicker') ){
		$('#datetimepicker6').datetimepicker('destroy');
		this.value = 'create';
	}else{
		$('#datetimepicker6').datetimepicker();
		this.value = 'destroy';
	}
});
var logic = function( currentDateTime ){
	if( currentDateTime.getDay()==6 ){
		this.setOptions({
			minTime:'11:00'
		});
	}else
		this.setOptions({
			minTime:'8:00'
		});
};
$('#datetimepicker7').datetimepicker({
	onChangeDateTime:logic,
	onShow:logic
});
$('#datetimepicker8').datetimepicker({
	onGenerate:function( ct ){
		$(this).find('.xdsoft_date')
			.toggleClass('xdsoft_disabled');
	},
	minDate:'-1970/01/2',
	maxDate:'+1970/01/2',
	timepicker:false
});
$('#datetimepicker9').datetimepicker({
	onGenerate:function( ct ){
		$(this).find('.xdsoft_date.xdsoft_weekend')
			.addClass('xdsoft_disabled');
	},
	weekends:['01.01.2014','02.01.2014','03.01.2014','04.01.2014','05.01.2014','06.01.2014'],
	timepicker:false
});
var dateToDisable = new Date();
	dateToDisable.setDate(dateToDisable.getDate() + 2);
$('#datetimepicker11').datetimepicker({
	beforeShowDay: function(date) {
		if (date.getMonth() == dateToDisable.getMonth() && date.getDate() == dateToDisable.getDate()) {
			return [false, ""]
		}

		return [true, ""];
	}
});
$('#datetimepicker12').datetimepicker({
	beforeShowDay: function(date) {
		if (date.getMonth() == dateToDisable.getMonth() && date.getDate() == dateToDisable.getDate()) {
			return [true, "custom-date-style"];
		}

		return [true, ""];
	}
});
$('#datetimepicker_dark').datetimepicker({theme:'dark'})
</script>
                   <tr>
                      <div class="form-group">
                      <td>
                            <label class="control-label">Age:</label>
                      </td>
                      <td>
                            
                           <input type="text" class="form-control" name="Age" placeholder="Age" pattern="[0-9][0-9]" required=""/>
                         
                         
                      </td>
                          </div>
                   </tr>
				    <tr>
	            <div class="form-group">
                <td>
                <label class=" control-label">Phone:</label>
                </td>
                <td>
			    <input type="text" name="Phone" class="form-control" name="email" placeholder="Your Phone Number(0924782517)" required x-moz-errormessage="input must contain 10 digit Number from 0-9 "  pattern="[0-9][0-9].{8,}"required="">
                </td>
			    </div>
			    </tr>
                  <tr>
	            <div class="form-group">
                <td>
                <label class=" control-label">Email:</label>
                </td>
                <td>
			    <input type="text" name="email" class="form-control"  placeholder="email@gmail.com" required="" required="required" required x-moz-errormessage="input must contain email validation " required="">
                </td>
			    </div>
			    </tr>
                   <tr>
                      <div class="form-group">
                      <td>
                            <label class="control-label">ID No:</label>
                      </td>
                      <td>
                            
                              <input type="text" class="form-control" name="IDNO" id="IDNO" placeholder="IDNo" required=""/>
                            
                      </td>
                          </div>
                   </tr>
                  <!--
                   <tr>
                      <div class="form-group">
                      <td>
                            <label class="control-label">Image:</label>
                      </td>
                      <td>
                  <form action="#"  method='post' name="upload_excel" enctype="multipart/form-data" style="width: 200px;" role="form">
                   <div class="form-group">
                    	<input type='file' name='file' id='file' class="form-control" required=""/>
                  
				  </div>
				
                  <div class="form-group">
                    	<input type='submit' name='Import' value='upload' class="btn btn-success"/>
                  </div>
				
                    </form>
                    </td>
                          </div>
                   </tr>!-->
                    <tr>
                    <div class="form-group">
                    <td>
                    <label class=" control-label">Select Faculty:</label>
                    </td>
                    <td>
                    <div id="show_sub_categories">
                              <select  class="form-control" required='' name="Fac">
                              <option value="">--select one--</option>
                              <?php
											$sql=mysqli_query($conn,"select * from faculty");
											while($row=mysqli_fetch_array($sql))
											{
											$faculty=$row['FName'];
											@$id=$row['id'];
											 echo '<option value="'.$faculty.'">'.$faculty.'</option>';
											} 
                              ?>
                            </select>
                    </div>
                   </td>
                   </div>
                 </tr>
                   <tr>
                   <div class="form-group">
                      <td>
                      <label class="control-label">Department</label>
                      </td>
                      <td>
                          
                           <select  class="form-control" required='' name="Dept" id="Dept">
                              <option value="">--select one--</option>
                        <?php
											$sql=mysqli_query($conn,"select * from departments");
											while($row=mysqli_fetch_array($sql))
											{
											$department=$row['DName'];
											 echo '<option value="'.$department.'">'.$department.'</option>';
											} 
                              ?>
                              
                            </select>
                           
                       </td>
                   </div>
                   </tr> 
                   <tr>
                       <div class="form-group">
                     <td>
                            <label class=" control-label">Select Year</label>
                    </td>
                    <td>
                                <select class="form-control" required='' name="Year">
                              <option value="">--select one--</option>
                              <?php
											$sql=mysqli_query($conn,"select * from departments");
											while($row=mysqli_fetch_array($sql))
											{
											      $py1=8;
											      $py=$row['PYear'];
                                            } 
                                            for($i=1;$i<=$py1;$i++)
                                            {
                                                echo '<option value="'.$i.'">'.$i.'</option>';
                                            }
                              ?>
                              
                            </select>
                    </td>
                          </div>
                 </tr>
                   <tr>
				   <td></td> 
                          <div class="form-group">
                          <td>
                            <div class="col-lg-offset-6">
                              <button class="submit" type="submit" class="btn btn-primary"  name="register"><i class="glyphicon glyphicon-save" ></i>&nbsp;Register</button>
							  <button class="submit" type="reset">Reset</button>
                            </div>
                          </td>
                          <td></td>
                          </div>
                   </tr>
              </table>
      </form>
      <?php
       include_once('controller/registration_controller.php');
      ?>
 </div>
</div>    	
</div>
</div> 
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
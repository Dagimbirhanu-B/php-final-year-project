<?php
if(isset($_POST['submit']))
{
$comment=$_POST["Comment"];
$time = date("l, d/M/Y, h:i:sa");
if(is_numeric($comment))

{ 
?>
<script type="text/javascript">
alert('All information must be character strings');
history.back();
</script>
<?php
}
else{
$query="INSERT INTO notice(Notice,Date) VALUES('$comment',NOW())";
mysqli_query($CONN,$query);
?>

<script type="text/javascript">
alert('YOUR POST NOTICE HAVE BEEN SUCCESSFULLY POST!!!!.');
window.location="postnotice.php";
</script>

}
}


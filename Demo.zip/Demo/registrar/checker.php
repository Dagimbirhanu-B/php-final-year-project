<?php 
include('../db_config/dbcon.php');
if(isset($_POST['action']) && $_POST['action'] == 'username_availability'){ 
	$username 		= htmlentities($_POST['username']); 
	$check_query	= mysqli_query($conn,'SELECT Username FROM account WHERE Username = "'.$username.'" '); 
	echo mysqli_num_rows($check_query); 
}
?>
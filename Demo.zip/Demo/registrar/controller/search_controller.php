<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clearance";


$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

include 'model/Search_model.php';
if (isset($_POST['search_R'])) {
    $stud_ID = $_POST['stud_ID'];
    $search_STR = new Search();
    $Reg_res = $search_STR->Search_R($stud_ID);
    $Reg_res1 = $search_STR->Search_C($stud_ID);
    $responce['Fname'] = $Reg_res['Fname'];
    $responce['Mname'] = $Reg_res['Mname'];
    $responce['Lname'] = $Reg_res['Lname'];
    $responce['Sex'] = $Reg_res['Sex'];
    $responce['Idno'] = $Reg_res['Idno'];
    $responce['Year'] = $Reg_res['Year'];
    $secu=$responce['security'] = $Reg_res['security'];
    $responce['Department'] = $Reg_res['Department'];
    $facClr = $responce['faculty'] = $Reg_res1['faculty'];
    $deptClr = $responce['department'] = $Reg_res1['department'];
    $libClr = $responce['library'] = $Reg_res1['library'];
    $bokClr = $responce['bookstore'] = $Reg_res1['bookstore'];
    $caftClr = $responce['cafeteria'] = $Reg_res1['cafeteria'];
    $dormClr = $responce['dormitory'] = $Reg_res1['dormitory'];
    $sptClr = $responce['sport'] = $Reg_res1['sport'];
    $statu=$responce['status'] = $Reg_res['status'];
     if($statu=='0')
    {
        echo '<div style="color:red;"> This Student is not active!</div>';
    }
        if($Reg_res=='0' and $Reg_res1=='0')
        {
            echo "<label style='color:red;'>Couldn't Find Student Detail with this ID</label>";
        }
    
}
if (isset($_GET['res'])) {
    $stud_ID = $_GET['res'];
    $search_STR = new Search();
    $Reg_res = $search_STR->Search_R($stud_ID);
    $Reg_res1 = $search_STR->Search_C($stud_ID);
    $responce['Fname'] = $Reg_res['Fname'];
    $responce['Mname'] = $Reg_res['Mname'];
    $responce['Lname'] = $Reg_res['Lname'];
    $responce['Sex'] = $Reg_res['Sex'];
    $responce['Idno'] = $Reg_res['Idno'];
    $responce['Year'] = $Reg_res['Year'];
    $responce['Department'] = $Reg_res['Department'];
    $facClr = $responce['faculty'] = $Reg_res1['faculty'];
    $deptClr = $responce['department'] = $Reg_res1['department'];
    $libClr = $responce['library'] = $Reg_res1['library'];
    $bokClr = $responce['bookstore'] = $Reg_res1['bookstore'];
    $caftClr = $responce['cafeteria'] = $Reg_res1['cafeteria'];
    $dormClr = $responce['dormitory'] = $Reg_res1['dormitory'];
    $sptClr = $responce['sport'] = $Reg_res1['sport'];
    $clrnce= $responce['Clearance'] = $Reg_res1['Clearance'];
    $statu=$responce['status'] = $Reg_res['status'];
    if($statu=='0')
    {
        echo '<div style="color:red;"> This Student is not active</div>';
    }
        if($Reg_res=='0' and $Reg_res1=='0')
        {
             echo "<label style='color:red;'> Couldn't Find Student Detail with this ID</label>";
        }
    
}
if (isset($_POST['Search_user'])) {
    $usname = $_POST['usn'];
    $search_usr = new Search();
    $Reg_res = $search_usr->Search_U($usname);

    $fn = $responce['Fname'] = $Reg_res['Fname'];
    $mn = $responce['Mname'] = $Reg_res['Mname'];
    $ln = $responce['Lname'] = $Reg_res['Lname'];
    $s = $responce['Sex'] = $Reg_res['Sex'];
    $rol = $responce['Role'] = $Reg_res['Role'];
	$statu=$responce['status'] = $Reg_res['status'];
	 if($statu=='1')
    {
        echo '<div style="color:red;"> This User is not active!</div>';
    }
    if($Reg_res=='0')
    {
        echo '<div style="color:red;"> Couldnt Find</div>';
    }
}
?>

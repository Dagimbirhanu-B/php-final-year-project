<?php
include "model/registration_model.php";

    // register students

    if(isset($_POST['Import']))
    {
        
        	
        $string = randomString(rand(7,7));
        if(isset($_POST["Import"])){
		

		$filename=$_FILES["file"]["tmp_name"];
		

		 if($_FILES["file"]["size"] > 0)
		 {
            
		  	$file = fopen($filename, "r");
	         while (($import = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
	           $string = randomString(rand(7,7));
              
	           $register=mysqli_query($conn,"INSERT INTO student(Fname,Mname,Lname,Sex,Age,Idno,Year,Department,security,password,status) values('$import[0]','$import[1]','$import[2]','$import[3]','$import[4]','$import[5]','$import[6]','$import[7]','$string','$import[5]','')");
               
               $clear=  mysqli_query($conn,"INSERT INTO clearance(stud_id,faculty,department,library,bookstore,cafeteria,dormitory,sport,Clearance) VALUES('$import[5]','','','','','','','','')");
              
               
               }
                if($register and $clear)
                    {
                        echo "Successfully Registered";
                    }
                    else
                    {
                        echo"<div style='color:red'>Invalid File:Please Upload CSV File.</div>";
                    }
               fclose($file);
          }
               

        
        }
        
        
    }
    if(isset($_POST['register']))
    {   	
        $string = randomString(rand(7,7));
        $fname=$_POST['Fname'];
        $mname=$_POST['Mname'];
        $lname=$_POST['Lname'];
        $username=$_POST['username'];
         $password=$_POST['PASSWORD2'];
        $sex=$_POST['Sex'];
		$date=$_POST['bday'];
        $age=$_POST['Age'];
		$phone=$_POST['Phone'];
		$email=$_POST['email'];
        $idno=$_POST['IDNO'];
		$facality=$_POST['Fac'];
        $year=$_POST['Year'];
        $department=$_POST['Dept'];
		$security2=$_POST['security'];
		//$photo=$_POST['Photo'];
        $query="SELECT * FROM student WHERE Idno='$idno'";
        $sqlm=mysqli_query($conn,"select * from departments where DName='$department'");
        $sec="SELECT * FROM student WHERE security='$security2'";
        
			$rowm=mysqli_fetch_array($sqlm);
            $yrr=$rowm['PYear'];
            $res=mysqli_query($conn,$query);
			$secres=mysqli_query($conn,$sec);
			$row1=mysqli_fetch_array($res);
			$id1=$row1['Idno'];
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This Student is Already Registered');</script>";
            
            }
			elseif(mysqli_num_rows($secres)>0)
            {
                echo "<script lang='javascript'> alert('This Security is assigned by another student');</script>";
            
			}
            elseif($year>$yrr)
            {
                echo "<script lang='javascript'> alert('This Year is not available in this department');</script>";
            
			}
			else
			{
                    $register=mysqli_query($conn,"INSERT INTO student(Fname,Mname,Lname,username,PASSWORD2,Sex,birth_date,Age,Idno,Phone,Email,Faculity,Year,Department,security,status,Photo) VALUES('$fname','$mname','$lname','$username','$password','$sex','$date','$age','$idno','$phone','$email','$facality','$year','$department','$security2','','$photo')");
                    $clear=  mysqli_query($conn,"INSERT INTO clearance(stud_id,faculty,department,library,bookstore,cafeteria,dormitory,sport,Clearance) VALUES('$idno','','','','','','','','')");
                $result=mysqli_query($conn,$register);
                if(!$result and !$clear){
                    echo ("<script lang='javascript'>alert('You are Not registered sucssesfully!!!')</script>".mysqli_error());
                 
				   }
                else{
                   echo ("<script lang='javascript'>alert('You are registered sucssesfully!!!')</script>".mysqli_error());
                 }
            }    
    }
// register user
    if(isset($_POST['AddAccount']))
    {
        $fname=$_POST['Fname'];
        $mname=$_POST['Mname'];
        $lname=$_POST['Lname'];
        $sex=$_POST['Sex'];
		$email=$_POST['email'];
        $username=$_POST['username'];
        $password=$_POST['pass1'];
        $role=$_POST['role'];
        $query="SELECT * FROM account WHERE username='$username'";
            $res=mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This User Name is Already Registered');</script>";
            
            }
            else{
                    $register=mysqli_query($conn,"INSERT INTO account(Fname,Mname,Lname,Username,Email,Password,Sex,Role) VALUES('$fname','$mname','$lname','$username','$email','$password','$sex','$role')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('The User is Successfully Registered');</script>";
                    }
               }
    }
// send message
    if(isset($_POST['sendmessage']))
    {
        $fname=$_POST['Name'];
        $mname=$_POST['IDNo'];
        $lname=$_POST['Email'];
        $sex=$_POST['phone'];
        $username=$_POST['Offices'];
        $password=$_POST['messagess'];
        $role2=date("l, d/M/Y, h:i:sa");
        $query="SELECT * FROM account WHERE Username='$username'";
            $res=mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This User is Already Registered');</script>";
            
            }
            else{
                    $register=mysqli_query($conn,"INSERT INTO messages(Name,IDNo,Email,phone,Offices,messagess,Time) VALUES('$fname','$mname','$lname','$username','$password','$sex','$role2')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('The User is Successfully Registered');</script>";
                    }
               }
    }      
function randomString($length){
                $chars = "abcdefghijkmnopqrstuvwxyz0123456789";
                srand((double)microtime()*1000000);
                $str = "";
                $i=0;

                        while($i <= $length){
                                $num = rand() % 33;
                                $tmp = substr($chars, $num, 1);
                                $str = $str . $tmp;
                                $i++;
                        }
                return $str;
        }
     if(isset($_POST["secu"]))
     {
         $string = randomString(rand(7,7));
     }
	 //addcase for library
	 if(isset($_POST['caselibrary']))
    {
        $fname=$_POST['security'];
        $mname=$_POST['description'];
        $lname=$_POST['stud_ID'];
        $date=date("l, d/M/Y, h:i:sa");
        $query="SELECT * FROM account WHERE Username='$username'";
            $res=mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                 echo "<script lang='javascript'> alert('This User is Already Registered');</script>";
            
            }
            else{
                    $register=mysqli_query($conn,"INSERT INTO cases(Idno,description,staff,by_user,Dateadded,Datereturned) VALUES('$fname','$mname','$lname','$role','$username','$date','$date')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('The User is Successfully Registered');</script>";
                    }
               }
    }
     if(isset($_POST["Add_dep"])){
	   $fac= $_POST['fac'];
	   $yr= $_POST['yr'];
	   $dname= $_POST['Dname'];
        $query="SELECT * FROM departments WHERE Dname='$dname'";
        $res=mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
			  {
                echo "<script lang='javascript'> alert('This Department is Already Registered');</script>";
              }
                else{
            	   $register=mysqli_query($conn,"INSERT INTO departments(Fname,DName,PYear) VALUES('$fac','$dname','$yr')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('Successfully Add Department');</script>";
                    }
	               }
	}
    	 if(isset($_POST["Add_fac"]))
     {
	   $fname= $_POST['Fname'];
        $query="SELECT * FROM faculty WHERE Fname='$fname'";
         $res=mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
                echo "<script lang='javascript'> alert('This Faculty is Already Registered');</script>";
            }
                else{
            	   $register=mysqli_query($conn,"INSERT INTO faculty(Fname) VALUES('$fname')");
                    if($register)
                    {
                        echo "<script lang='javascript'> alert('Successfully Add Faculty');</script>";
                    }
	               }
	}

?>

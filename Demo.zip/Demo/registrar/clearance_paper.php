<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home" class="active" ><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Post Comments"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="deletepost.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="../help.php" title="help"><i class="glyphicon glyphicon-book" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<?php
    if(isset($_POST['preview']))
    {
        $idnn=$_POST['idn'];
		$name=$_POST['name'];
		$dept=$_POST['Department'];
		$year=$_POST['Year'];
        $reson=$_POST['reason'];
        $query    ="SELECT * FROM report WHERE stud_id='$idnn'";
            $res    =mysqli_query($conn,$query);
            if(mysqli_num_rows($res)>0)
            {
            }
            else
            {
                $sqll=mysqli_query($conn,"INSERT INTO report(stud_id,Name,Department,Year,clearance_date,clearance_reason,print_status) VALUES ('$idnn','$name','$dept','$year',now(),'$reson','0')");
            }
    }
if(isset($_POST['sendclearance']))
        {
	        $idno=$_POST['idn'];
            $query1="SELECT * FROM report WHERE stud_id='$idno'";
            $res1=mysqli_query($conn,$query1);
			$rec0=mysqli_fetch_array($res1);
			$userid=$rec0[0];
			if($userid!=$idno)
            {
             echo "<script lang='javascript'> alert('Sending clearance to the student is succefully.');</script>";   
            }
            else
            {
			echo "<script lang='javascript'> alert('This Student is take the clearance before.');</script>";    
			}
	    }
    if(isset($_POST['report']))
    {
        $idnn=$_POST['idn'];
        $sqlq=mysqli_query($conn,"update report set print_status='1' WHERE stud_id='$idnn'");
    }
	?>
<div class="container">   
<div class="panel panel-default" >
<div class="container12">
<form action="#" method="post">
        	<input type="hidden" value="<?php  echo @$_POST["idn"];  ?>" name="idn"/>
         <a href='registrar.php#'class="btn btn-info btn pull-right" style="float: right; margin-right: -70px; margin-top:13px;"><span class="glyphicon glyphicon-hand-left"></span> Back</a>  
		 <button onclick="PrintDiv()" class="btn btn-info btn pull-right" name="report" type="submit" title="Print"style="margin-top:13px;"><span class="glyphicon glyphicon-print "></span> Print</button> 
         <button  class="btn btn-info btn pull-right" name="sendclearance" type="submit" title="Send"style="margin-top:13px;"><span class="glyphicon glyphicon-send "></span> Send </button> 		 
</form>
</div>
  <div class="panel-heading">
    <h3 class="panel-title">Print View Status of the Student</h3>
  </div>
<div class="panel-body" style="font-family: times new roman;" >
  <div id="divToPrint" style=" width: 600px; margin-left: 300px;">
  <div style="border: dashed;background: silver;">
    <center>****************************************************<br />
    <img src="../image2/dtu1.jpg" title="Debre Tabor University Logo"width="200" height="200" class="img-circle"/><br /><br />
<div class="sizeprint">
<font color="white"> DATE:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<div class="sizeprint2">
       <h3><font color="green"><b><p>Debre Tabor UNIVERSITY</p></b></font></h3>
        <h4><font color="yellow"><b><p>Student Termination Clearance/Withdrawal Forms/</p></b></font></h4>
        <h4><font color="red"><b><p>For Regular Undergraduate Only</p></b></font></h4>****************************************************<br />
        <u>This student is sertified from university property.</u>
        </center>
        <table cellpadding='7' style="margin-left: 30px;" >
                                            <tr>
                                            	<td> Student Name: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['preview']))
                                                             {
                                                                echo "<div class='res'>". $_POST['name']. "</div>";
                                                                }
                                                    ?></td>
                                            </tr>
                                            <tr>
                                            	<td>IDNo:</td>
                                            	<td><?php                        
                                                              if(isset($_POST['preview']))
                                                             {
                                                                echo "<div class='res'>". $_POST['idn'] . "</div>";
                                                           }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Year: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['preview']))
                                                             {
                                                                echo "<div class='res'>". $_POST['Year'] . "</div>";
                                                           }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Department: </td>
                                            	<td><?php                        
                                                             if(isset($_POST['preview']))
                                                             {
                                                                echo "<div class='res'>". $_POST['Department'] . "</div>";
                                                           }
                                                    ?>
												</td>
                                            </tr>
                                            <tr>
                                            	<td>Clearance Date: </td>
                                            	<td><?php 
                                                 if(isset($_POST['preview']))
                                                             {
                                                echo date("Y-m-d") ;   
												     } 
													 ?>
											   </td>
                                            </tr>
                                            <tr>
                                            	<td>Clearance Reason: </td>
                                            	<td><?php 
                                                      if(isset($_POST['preview']))
                                                             {
                                                                echo "<div class='res'>". $_POST['reason'] . "</div>";
                                                                }
                                                            ?>
													</td>
                                            </tr>

                                   </table> 
                                   
                                   <br />
        
    
  <center>****************************************************<br /></center> 
    
    </div>
    </div>
   </div>
   
    <script type="text/javascript">     
                                                function PrintDiv() {    
                                                   var divToPrint = document.getElementById('divToPrint');
                                                   var popupWin = window.open('', '_blank', 'width=600,height=1200');
                                                   popupWin.document.open();
                                                   popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
                                                    popupWin.document.close();
                                                  }
   </script>
    
  </div>
</div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>
<?php
class Update {

    function update_Sec($secu,$Sidno)
    {
        $sql=  mysqli_query($conn,"Update student set security='$secu' where Idno='$Sidno'");
        if($sql)
        {
            return 1;
        }
        else {
             return 0;
        }
    }
    function update_Pass($oldp,$pas,$id)
    {
        $sqlp=  mysqli_query($conn,"Select * from student where Idno='$id'");
        while($rowp=  mysqli_fetch_array($sqlp))
        {
            $oldpass=$rowp["password"];
        }
        if($oldp!=$oldpass)
        {
            echo '<img src="images/invalid.png" > Invalid Current Password';
        }
        else {
            $sql=  mysqli_query($conn,"Update student set password='$pas',status='1' where Idno='$id'");
                if($sql)
                {
                    return 1;
                }
                else {
                     return 0;
                }
        }
    }
}
    /*
    <!--
    function settingu($fna,$una)
    {

		$sql_up=mysqli_query($conn,"update account set Mname='$fna ' where Username='$una'");
		if($sql_up)
		{
			return 1;
		}
		else
		{
			return 0;
		}
    }
	 function settingf($fna,$una)
    {

		$sql_up=mysqli_query($conn,"update account set Fname='$fna ' where Username='$una'");
		if($sql_up)
		{
			return 1;
		}
		else
		{
			
			return 0;
		}
    }
	function settingl($fna,$una)
    {

		$sql_up=mysqli_query($conn,"update account set Lname='$fna ' where Username='$una'");
		if($sql_up)
		{
			return 1;
		}
		else
		{
			return 0;
		}
    }
   	function settingp($fna,$una)
    {

		$sql_up=mysqli_query($conn,"update account set Password='$fna ' where Username='$una'");
		if($sql_up)
		{
			return 1;
		}
		else
		{
			return 0;
		}
    }
       	function settingsp($fna,$una)
    {

		$sql_up=mysqli_query($conn,"update student set password='$fna ' where Idno='$una'");
		if($sql_up)
		{
			return 1;
		}
		else
		{
			return 0;
		}
    }
}--->*/

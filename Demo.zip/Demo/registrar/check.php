<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message" class="active" ><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Post Comments"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="deletepost.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student">Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="../help.php" title="help"><i class="glyphicon glyphicon-book" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div> 
<!--Library menu bar -->
<div class="container">
<div class="panel">
          <div class="panel panel-default">          
            <div class="panel-group">	
			   <div class="alert alert-info">
                        <form action="#" class="navbar-search form-inline" method="POST">
                         <table border="0">
						 <tr>
						 <?php
						 @$id3=$_GET[slid];
						 ?>
						 <div class="required">
						 <td> Enter Your IDNO:</td>
    		             <td><input type="text"  name="stud_ID"/></td>
						 <td><button class="btn btn-warning" style="height:38px;" name="search_R">&nbsp;&nbsp;<i class="glyphicon glyphicon-search" ></i>&nbsp;Search</button></td>	
                         <?php  
						   include("controller/search_controller.php") ;  
                           ?>
						 </div>
						</tr>
						</table>
						<a href='inboxregistrar.php#'class="btn btn-info btn pull-right" style="float: right; margin-right: -13px; margin-top:-25px;"><span class="glyphicon glyphicon-hand-left"></span> Back</a>  			
                </form> 
				</div>
               <div class="panel-body">
        <?php  
                      if(isset($_POST["search_R"])and $Reg_res!='0')
                    { 
                        if($statu=='1')
                       {
         ?>
        <div class="pbody">
             <div class="row">
             
                <div class="col-md-5">
                    <table cellpadding='10' cellpadding="0" cellspacing="0" border="0" class="table  table-bordered" id="example">
                            <tr>
                            <?php  $idno= $responce['Idno']; ?>
                            	<td> Full name: </td>
                            	<td>    <?php
                             
                                    echo "<div class='res'>". $responce['Fname'] ." ". $responce['Mname']. " ". $responce['Lname']. "</div>";
                               
                            ?></td>
                            </tr>
                            <tr>
                            	<td>IDNo:</td>
                            	<td>  
                             <?php
                            	
                                    echo  "<div class='res'>". $responce['Idno']."</div>";
                               
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Sex:</td>
                            	<td><?php
                            	
                                    echo   "<div class='res'>".$responce['Sex']."</div>";
                               
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Department:</td>
                            	<td><?php
                            	
                                    echo   "<div class='res'>".$responce['Department']. "</div>";
                               
                            ?></td>
                            </tr>
                            <tr>
                            	<td>Year: </td>
                            	<td><?php
                            	 
                                    echo   "<div class='res'>". $responce['Year']. "</div>";
                               
                            ?></td>
                            </tr>
                     </table>
                   </div>
                        <div class='col-md-3r' >
                                      <h3>Calendar</h3>
                                   <script src="../js2/calander.js" language="javascript" type="text/javascript"></script> 
                        </div>
                     </div>
                
                    </div>
                <?php
                
                
                    $id=$responce['Idno'];
                
                  echo ' <a href="clearance.php?res='.$id.'"><button class="btn btn-primary" style="margin-top: 10px;" name="check_clearance"> Check Clearance</button></a>';
                 
                }     
				}
                ?>
              </div>
                </div>
             </div>
          </div>
        </div>
      </div>
     </div>
   </div>
  </div>
</div>
<?php
	include_once("footeroffices.php");
?> 
</body>
</html>

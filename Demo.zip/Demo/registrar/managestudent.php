<?php
include_once("headeroffices.php");
 ?>
 <!-- #topnavigation above logo -->
<div id="outer-wrap">  
<nav class="fixedtop" id="magatopnav" role="navigation">
<div class="limit  clearfix "> 	
<div id="topnav" class="tpcrn_slide_menubar-container clearfix ">	
<ul id="topmenu" class="topnav megabar clearfix">
<li class="current-menu-item"><a href="aboutus.php"title="About Clearance"><i class="glyphicon glyphicon-info-sign" ></i>&nbsp;About Clearance</a></li>
<li class="current-menu-item"><a href="calander.php"title="Calendar"><i class="glyphicon glyphicon-calendar" ></i>&nbsp;Calendar</a></li>
<li class="current-menu-item"><a href="newpost.php" title="View New Posts"><i class="glyphicon glyphicon-folder-open" ></i>&nbsp;View New Posts</a></li>
</ul>		
</div>
</div> <!-- /.limit -->
</nav> 
</div>
<div id="navigation">
<div class="section clearfix">
<ul class="sf-menu clearfix">
<li class="first leaf"><a href="registrar.php" title="Home"><i class="glyphicon glyphicon-home" ></i>&nbsp;Home</a></li>
<li class="leaf"><a href="aboutus.php"><i class="glyphicon glyphicon-user" ></i>&nbsp;About Us</a></li>
                                       <?php
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM messages WHERE Offices='registrar'");
                                            $number = mysqli_num_rows($nomessages);
                                           ?>
<li class="leaf"><a href="inboxregistrar.php" title="Inbox Message"><i class="glyphicon glyphicon-envelope" ></i>&nbsp;Inbox Message&nbsp;<span><font color="red"><sup><?php echo $number; ?></sup></font></span></a></li>
<li class="expanded"><a href="#"><i class="glyphicon glyphicon-comment" ></i>&nbsp;Post Comment</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Post Comments"><i class="glyphicon glyphicon-upload" ></i>Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="postcomment.php" title="Post Comment" ><i class="glyphicon glyphicon-upload"></i>&nbsp;Post Comment</a></a></li>
<li class="leaf"><a href="postnotice.php" title="Post Student Notice"><i class="glyphicon glyphicon-upload"></i>&nbsp;Student Notice</a></li>
</ul>
</li>
<li class="expanded"><a href="" title="Delete Old Post Comment"><i class="glyphicon glyphicon-trash"></i>&nbsp;Delete Old &nbsp;&nbsp;&nbsp;&nbsp;Post Comment<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="deletepost.php" title="Delete Old Comment Post"><i class="glyphicon glyphicon-trash"></i>Del Old Coment</a></a></li>
<li class="leaf"><a href="deletereport.php" title="Delete Old Report"><i class="glyphicon glyphicon-trash"></i>Del Old Report</a></li>
</ul>
</li>
</ul>
</li>
<li class="expanded"><a href=""><i class="glyphicon glyphicon-tasks" ></i>&nbsp;Operations</a>
<ul class="menu" id="nav nav-pills">
<li class="expanded"><a href="" title="Add Offices"><i class="glyphicon glyphicon-plus" ></i>&nbsp;Add Offices&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="add_department.php" title="Add Department">Add Department</a></li>
<li class="leaf"><a href="add_faculty.php" title="Add Faculty">Add Faculty</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Register Users"><i class="glyphicon glyphicon-save" ></i>Register User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="registeruser.php" title="Register Offices">Register Offices</a></li>
<li class="leaf"><a href="registerstudent.php" title="Register Student">Register Student</a></li>
</ul>
</li>
<li class="leaf"><a href="" title="Manage Users"><i class="glyphicon glyphicon-list-alt" ></i>&nbsp;Manage User&nbsp;&nbsp;<font color="red">></font></a>
<ul class="menu" id="nav nav-pills">
<li class="leaf"><a href="manageuser.php" title="Manege User">Manage Offices</a></li>
<li class="leaf"><a href="managestudent.php" title="Manage Student"  class="active1" >Manage Student</a></li>
</ul>
</li>
<li class="leaf"><a href="setting.php" title="Profile Setting"><i class="glyphicon glyphicon-wrench" ></i>&nbsp;Setting</a></li>
</ul>
</li>
<li class="leaf"><a href="../help.php" title="help"><i class="glyphicon glyphicon-book" ></i>&nbsp;Help</a></li>
<li class="leaf"><a href="logout.php" title="logout"><i class="glyphicon glyphicon-log-out" ></i>&nbsp;Log Out</a></li>
</ul>           
</div>
</div>
<div class="size">
<font color="white"> TIME:</font>
<font color="orange">
<?php
$Today=date('y:m:d');
$new=date('l, F d, Y',strtotime($Today));
echo $new; ?>
</font> 
</div>
<div class="container">
 <div class="panel">
              <div class="panel panel-default">
                  <div class="panel-heading">
                        <h3 class="panel-title">
                                <form action="#" class="navbar-search form-inline" style="margin-top:6px" method="POST">
                                 <div class="required"> Enter Student IDno: &nbsp; &nbsp;
            		                  <input type="text" placeholder="Search" required x-moz-errormessage="Please Enter Student ID" name="stud_ID"/><button class="btn btn-warning" style="height: 27px;" name="search_R"><i class="glyphicon glyphicon-search" ></i>&nbsp;Search</button>	
                                  <?php   include "controller/search_controller.php";                        ?>
                                   </div>
                   	</form>  
                        
                        </h3>
                  </div>
                  <div class="panel-body">
                  <div class="del">
				  <form class="form-horizontal" role="form" action="" method="post" >
                   <table cellpadding='10' style=" margin: auto; margin-top: -20px;" >
                         
                  <?php    
                  
                        if(isset($_POST["search_R"]))
                        {
						?>
						<tr>
                                       <div class="form-group">
                                     <td>
                                            <label class=" control-label">IDNO: </label>
                                    </td>
                                    <td>
                                                <input type="hidden" value="<?php   echo $responce['Idno'];   ?>" name="usname"/>
                                              <div class="output"><?php    echo $responce['Idno'];?></div>
                                    </td>
                                          </div>
                                 </tr>
								 <tr>
                                          <div class="form-group">
                                    <td>
                                            <label class="control-label">FNAME:</label>
                                    </td>
                                    <td>
                                             <div class="output"><?php     echo  $responce['Fname'] ;?> </div>
                                    </td>
                                          </div>
                                 </tr>
								 <tr>
                                          <div class="form-group">
                                    <td>
                                            <label class="control-label">MNAME:</label>
                                    </td>
                                    <td>
                                             <div class="output"><?php     echo $responce['Mname']; ?> </div>
                                    </td>
                                          </div>
                                 </tr>
                                  <tr>
                                          <div class="form-group">
                                    <td>
                                            <label class="control-label">LNAME:</label>
                                    </td>
                                    <td>
                                             <div class="output"> <?php     echo $responce['Lname'] ; ?> </div>
                                    </td>
                                          </div>
                                 </tr>
                                 <tr>
                                          <div class="form-group">
                                    <td>
                                            <label class="control-label">DEPARTMENT:</label>
                                    </td>
                                    <td>
                                             <div class="output"><?php     echo $responce['Department'];?> </div>
                                    </td>
                                          </div>
                                 </tr>
								 <?php
								           $ID=$_POST['stud_ID'];
                                        	$nomessages=mysqli_query($conn,"SELECT * FROM images WHERE Idno='$ID'");
                                            if(mysqli_num_rows($nomessages)){
											while($row=mysqli_fetch_array($nomessages))
											{
											$image2="<img src='../student/uploads/$row[imagepath]' width=400 height=400";
											}
											}
											else
											{
											$image2="<img src='../student/images/profilepic.jpg' width=40 height=40";																						}
											?>
								 <tr>
                                          <div class="form-group">
                                    <td>
                                            <label class="control-label">IMAGE:</label>
                                    </td>
                                    <td>
                                             <div class="output"><?php     echo $image2;?> </div>
                                    </td>
                                          </div>
                                 </tr>
                        <tr>
                        <div class="form-group">
						<td>
                            <input type="hidden" value="<?php if(isset($_POST["search_R"])){  echo $stud_ID;   } ?>" name="Stid"/>
                        </td>
						<td>
                         OPERATIONS
                        </td>
                       <td>
                      <select class="form-control" required='' name="op">
                     <option value="">--select one--</option>
                    <?php  if($statu=='0'){  ?>            <option value="enable" >Enable Student</option><?php   } ?>
                    <?php  if(!$statu=='0'){  ?>            <option value="enable" disabled="" style="color: red;"> Enable Student </option><?php   } ?>
                    <?php  if($statu=='0'){  ?>  <option value="disable" disabled="" style="color: red;"> Disable Student </option><?php   } ?>
                    <?php  if(!$statu=='0'){  ?>  <option value="disable" >Disable Student</option><?php   } ?>
                     <option value="delete">Delete Student</option>
                     </select>
                             </td>
                              <td>                
							  <button class="btn btn-default" name="delete_S"><span class="glyphicon glyphicon-ok-circle"></span> Apply</button>
                               </td>
                        </div>
                                 </tr>
                               <?php   
							   } 
							   ?>
                               </table>
                       </form>  
                      <?php 
                         include_once('controller/delete_controller.php'); 
                        ?>
              </div>
         
      <?php
            include_once('controller/registration_controller.php');
     
      ?>
                  </div>
             </div>
			 </div>
  </div>
<?php
  	include_once("footeroffices.php"); 
?>
</body>
</html>

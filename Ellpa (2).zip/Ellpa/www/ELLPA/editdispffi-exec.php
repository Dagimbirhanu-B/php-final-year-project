<?php
session_start();
 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$member_type=$_POST['member_type'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$chname=$_POST['chname'];
if(mysql_query("UPDATE disoflogin SET uname='$uname', pass='$pass',member_type='$member_type',fname='$fname', lname='$lname',
chname='$chname' WHERE fname='$fname'"))
header("location: disoffimanagerupdate.php");
else
echo "error update news"."".mysql_error();
?> 
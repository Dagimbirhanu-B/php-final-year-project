<?php
$chollname=$_POST['chonamee'];
$namee=$_POST['unamee'];
$oldpss=$_POST['olpass'];
$fnamee=$_POST['fnamee'];
$lnamee=$_POST['lnamee'];
$nchnamee=$_POST['chnnamee'];
$npassw=$_POST['npsswrd'];
$neunamee=$_POST['nunamee'];
$actype=$_POST['actype'];
$len = strlen($npassw);
if(($len)>=6 && ($len)<=20)
{
if($actype=='doff')
{
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO1');
	$results = mysql_query("SELECT * from dislogin where uname='$namee'");
	while($rows=mysql_fetch_array($results))
	{
	$dbuname=$rows['uname'];
	$dbpass=$rows['pass'];
	$dbchname=$rows['chname'];
	
	}
	$dec=base64_decode($dbpass);
		if(($dbuname==$namee)&&($oldpss==$dec)&&($chollname==$dbchname))
		{
		$enc = base64_encode($npassw);
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO');
		    $result = mysql_query("UPDATE dislogin SET uname='$neunamee',pass='$enc',fname='$fnamee',lname='$lnamee',chname='$nchnamee' WHERE uname='$namee'");
			if($result)
			{
			$url="Location:updatesucc.php";
			header($url);
			}
			else
			{
			$url="Location:updateerror.php";
			header($url);
			}
		}
		else
	    {
			$url="Location:updateunfound.php";
			header($url);
	    }
}
else if($actype=='roff')
{
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO1');
	$results = mysql_query("SELECT * from reglogin where uname='$namee'");
	while($rows=mysql_fetch_array($results))
	{
	$dbuname=$rows['uname'];
	$dbpass=$rows['pass'];
	$dbchname=$rows['chname'];
	
	}
	$dec=base64_decode($dbpass);
		if(($dbuname==$namee)&&($oldpss==$dec)&&($chollname==$dbchname))
		{
		$enc = base64_encode($npassw);
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO');
		    $result = mysql_query("UPDATE reglogin SET uname='$neunamee',pass='$enc',fname='$fnamee',lname='$lnamee',chname='$nchnamee' WHERE uname='$namee'");
			if($result)
			{
			$url="Location:updatesucc.php";
			header($url);
			}
			else
			{
			$url="Location:updateerror.php";
			header($url);
			}
		}
		else
	    {
			$url="Location:updateunfound.php";
			header($url);
	    }
}
else if($actype=='admin')
{
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO');
	$results = mysql_query("SELECT * from login where uname='$namee'");
	while($rows=mysql_fetch_array($results))
	{
	$dbuname=$rows['uname'];
	$dbpass=$rows['pass'];
	$dbchname=$rows['chname'];
	
	}
	$dec=base64_decode($dbpass);
		if(($dbuname==$namee)&&($oldpss==$dec)&&($chollname==$dbchname))
		{
		$enc = base64_encode($npassw);
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO');
		    $result = mysql_query("UPDATE login SET uname='$neunamee',pass='$enc',fname='$fnamee',lname='$lnamee',chname='$nchnamee' WHERE uname='$namee'");
			if($result)
			{
			$url="Location:updatesucc.php";
			header($url);
			}
			else
			{
			$url="Location:updateerror.php";
			header($url);
			}
		}
		else
	    {
			$url="Location:updateunfound.php";
			header($url);
	    }
}
}
else
{
			$url="Location:updateerror1.php";
			header($url);
}
?>
﻿<?php
$a=mysql_connect("localhost","root","");
if(mysql_query("create database EEPCOO1",$a))
mysql_select_db("EEPCOO1",$a);
$bb="CREATE TABLE request(
  request_id int(10) NOT NULL AUTO_INCREMENT,
  name VARCHAR(30) NOT NULL,
  address VARCHAR(40) NOT NULL,
  service_type VARCHAR(30) NOT NULL,
  request_date VARCHAR(30) NOT NULL,
  PRIMARY KEY (request_id)
)";
mysql_query("$bb",$a);
$mm="CREATE TABLE disoflogin (
  uname VARCHAR(15) NOT NULL,
  pass VARCHAR(15) NOT NULL,
  member_type VARCHAR(30) NOT NULL,
  fname VARCHAR(30) NOT NULL,
  lname VARCHAR(30) NOT NULL,
  chname VARCHAR(30) NOT NULL,
  PRIMARY KEY (uname)
)";
mysql_query("$mm",$a);
$b="CREATE TABLE bill(
  fnamee VARCHAR(30) NOT NULL,
  mnamee VARCHAR(30) NOT NULL,
  lnamee VARCHAR(30) NOT NULL,
  cntrctnoo VARCHAR(30) NOT NULL,
  tarffcatgry VARCHAR(30) NOT NULL,
  billnoo VARCHAR(30) NOT NULL,
  metnum VARCHAR(40) NOT NULL,
  bookinum VARCHAR(30) NOT NULL,
  PRIMARY KEY (billnoo)
)";
mysql_query("$b",$a);
$c="CREATE TABLE comment (
  name VARCHAR(50) NOT NULL,
  date DATETIME NOT NULL,
  comment VARCHAR(3000) NOT NULL
)";
mysql_query("$c",$a);
$d="CREATE TABLE complain (
  billnom VARCHAR(30) NOT NULL,
  complain VARCHAR(3000) NOT NULL
)";
mysql_query("$d",$a);
$e="CREATE TABLE count (
  subject VARCHAR(50) NOT NULL,
  content VARCHAR(800) NOT NULL,
  date DATETIME NOT NULL,
  id INT(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (id)
)";
mysql_query("$e",$a);
$f="CREATE TABLE cuslogin (
  uname VARCHAR(10) NOT NULL,
  pass VARCHAR(10) NOT NULL,
  member_type VARCHAR(30) NOT NULL,
  secquest VARCHAR(30) NOT NULL,
  PRIMARY KEY (uname)
)";
mysql_query("$f",$a);
$g="CREATE TABLE deenroll (
  NO VARCHAR(20) NOT NULL,
  `service number` VARCHAR(20) NOT NULL,
  `Customer Name` VARCHAR(50) NOT NULL,
  Active VARCHAR(50) NOT NULL,
  Reactive VARCHAR(50) NOT NULL,
  Demmand VARCHAR(50) NOT NULL,
  `Balance Fee` VARCHAR(50) NOT NULL,
  `Receipt No` VARCHAR(50) NOT NULL,
  `Reason for De-enrollment` VARCHAR(200) NOT NULL,
  PRIMARY KEY (NO)
)";
mysql_query("$g",$a);
$h="CREATE TABLE dfile (
  title VARCHAR(100) NOT NULL,
  code VARCHAR(50) NOT NULL,
  decription VARCHAR(2000) NOT NULL,
  file VARCHAR(100) NOT NULL,
  date DATETIME NOT NULL,
  PRIMARY KEY (title)
)";
mysql_query("$h",$a);
$i="CREATE TABLE dislogin (
  uname VARCHAR(15) NOT NULL,
  pass VARCHAR(15) NOT NULL,
  member_type VARCHAR(30) NOT NULL,
  fname VARCHAR(30) NOT NULL,
  lname VARCHAR(30) NOT NULL,
  chname VARCHAR(30) NOT NULL,
  PRIMARY KEY (member_type)
)";
mysql_query("$i",$a);
$j="CREATE TABLE dmessage (
  subject VARCHAR(30) NOT NULL,
  content VARCHAR(3000) NOT NULL,
  date DATETIME NOT NULL,
  id INT(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (id)
)";
mysql_query("$j",$a);
$k="CREATE TABLE event (
  Poster VARCHAR(50) NOT NULL,
  Event VARCHAR(2000) NOT NULL,
  date DATE NOT NULL
)";
mysql_query("$k",$a);
$l="CREATE TABLE file (
  title VARCHAR(100) NOT NULL,
  code VARCHAR(50) NOT NULL,
  decription VARCHAR(2000) NOT NULL,
  file VARCHAR(100) NOT NULL,
  date DATETIME NOT NULL,
  PRIMARY KEY (title)
)";

mysql_query("$l",$a);
$m="CREATE TABLE login (
  uname VARCHAR(15) NOT NULL,
  pass VARCHAR(15) NOT NULL,
  member_type VARCHAR(30) NOT NULL,
  fname VARCHAR(30) NOT NULL,
  lname VARCHAR(30) NOT NULL,
  chname VARCHAR(30) NOT NULL,
  PRIMARY KEY (uname)
)";
mysql_query("$m",$a);
$n="CREATE TABLE meterchange (
  NO VARCHAR(20) NOT NULL,
  `Customer Name` VARCHAR(50) NOT NULL,
  `Old Acc` VARCHAR(20) NOT NULL,
  `Service No` VARCHAR(20) NOT NULL,
  `Removed Property No` VARCHAR(20) NOT NULL,
  `Removed last reading` VARCHAR(20) NOT NULL,
  `Property NO` VARCHAR(20) NOT NULL,
  `Serial No` VARCHAR(20) NOT NULL,
  Make VARCHAR(20) NOT NULL,
  Material VARCHAR(50) NOT NULL,
  Model VARCHAR(30) NOT NULL,
  Dial VARCHAR(50) NOT NULL,
  Const VARCHAR(50) NOT NULL,
  `Intial Reading` VARCHAR(50) NOT NULL,
  `AR/MD` VARCHAR(50) NOT NULL
)";
mysql_query("$n",$a);
$o="CREATE TABLE nametransfer (
  `RemovedcuOld Acc` VARCHAR(20) NOT NULL,
  `Service No.` VARCHAR(20) NOT NULL,
  `Customer's Name` VARCHAR(50) NOT NULL,
  `New Active` VARCHAR(20) NOT NULL,
  Reactive VARCHAR(20) NOT NULL,
  MD VARCHAR(20) NOT NULL,
  `Removed Tariff` VARCHAR(50) NOT NULL,
  `Balance fee` VARCHAR(50) NOT NULL,
  `Removed Receipt No.` VARCHAR(50) NOT NULL,
  `Removed Remark` VARCHAR(200) NOT NULL,
  `App No.` VARCHAR(50) NOT NULL,
  `New Old Acc.` VARCHAR(50) NOT NULL,
  `New customer full name` VARCHAR(50) NOT NULL,
  `Ep.For staff` VARCHAR(50) NOT NULL,
  `New Tariff` VARCHAR(50) NOT NULL,
  Deposit VARCHAR(50) NOT NULL,
  `New Receipt No.` VARCHAR(50) NOT NULL,
  `New Remark` VARCHAR(200) NOT NULL
)";
mysql_query("$o",$a);
$p="CREATE TABLE newconn (
  No VARCHAR(5) NOT NULL,
  book VARCHAR(20) NOT NULL,
  acount VARCHAR(25) NOT NULL,
  contrano VARCHAR(25) NOT NULL,
  appno VARCHAR(25) NOT NULL,
  fname VARCHAR(30) NOT NULL,
  fathname VARCHAR(30) NOT NULL,
  gfname VARCHAR(30) NOT NULL,
  region VARCHAR(30) NOT NULL,
  city VARCHAR(30) NOT NULL,
  kketema VARCHAR(30) NOT NULL,
  kebele VARCHAR(30) NOT NULL,
  houseno VARCHAR(30) NOT NULL,
  floorno VARCHAR(30) NOT NULL,
  landm VARCHAR(30) NOT NULL,
  appsign VARCHAR(30) NOT NULL,
  supdeta VARCHAR(30) NOT NULL,
  perortemp VARCHAR(30) NOT NULL,
  propertno VARCHAR(30) NOT NULL,
  serialno VARCHAR(30) NOT NULL,
  manufact VARCHAR(25) NOT NULL,
  material VARCHAR(30) NOT NULL,
  model VARCHAR(30) NOT NULL,
  voltage VARCHAR(30) NOT NULL,
  ampere VARCHAR(30) NOT NULL,
  phase VARCHAR(30) NOT NULL,
  dails VARCHAR(30) NOT NULL,
  constant VARCHAR(30) NOT NULL,
  intialread VARCHAR(30) NOT NULL,
  depost VARCHAR(30) NOT NULL,
  connfee VARCHAR(30) NOT NULL,
  onlyconn VARCHAR(30) NOT NULL,
  firstpay VARCHAR(30) NOT NULL,
  remainamount VARCHAR(30) NOT NULL,
  noofmonth VARCHAR(30) NOT NULL,
  monthpay VARCHAR(30) NOT NULL,
  recpno VARCHAR(30) NOT NULL,
  PRIMARY KEY (No)
)";
mysql_query("$p",$a);
$q="CREATE TABLE news (
  poster VARCHAR(25) NOT NULL,
  date DATETIME NOT NULL,
  news VARCHAR(10000) DEFAULT NULL,
  id INT(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (id)
)";

mysql_query("$q",$a);
$r="CREATE TABLE powerimpr (
  book VARCHAR(50) NOT NULL,
  acount VARCHAR(50) NOT NULL,
  contNO VARCHAR(50) NOT NULL,
  AppNo VARCHAR(50) NOT NULL,
  `Customer name` VARCHAR(50) NOT NULL,
  `Service No` VARCHAR(50) NOT NULL,
  `property No` VARCHAR(50) NOT NULL,
  `serial No` VARCHAR(50) NOT NULL,
  Manufacture VARCHAR(50) NOT NULL,
  Material VARCHAR(50) NOT NULL,
  Model VARCHAR(50) NOT NULL,
  Voltage VARCHAR(50) NOT NULL,
  Ampere VARCHAR(50) NOT NULL,
  Phase VARCHAR(50) NOT NULL,
  Dails VARCHAR(50) NOT NULL,
  Constant VARCHAR(50) NOT NULL,
  `new meter intial reading` VARCHAR(50) NOT NULL,
  `Removed Amper` VARCHAR(50) NOT NULL,
  `Removed Property No` VARCHAR(50) NOT NULL,
  `Removed Meter last reading` VARCHAR(50) NOT NULL,
  Deposit VARCHAR(50) NOT NULL,
  `connection fee` VARCHAR(50) NOT NULL,
  `Only connection(TA)` VARCHAR(50) NOT NULL,
  `First payment` VARCHAR(50) NOT NULL,
  `Remaining amount` VARCHAR(50) NOT NULL,
  `No of Month` VARCHAR(50) NOT NULL,
  `Monthly Payment` VARCHAR(50) NOT NULL,
  `Receipt No` VARCHAR(50) NOT NULL,
  addpower VARCHAR(20) NOT NULL
)";
mysql_query("$r",$a);
$s="CREATE TABLE rcount (
  subject VARCHAR(50) NOT NULL,
  content VARCHAR(8000) NOT NULL,
  date DATETIME NOT NULL,
  id INT(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (id)
)";
mysql_query("$s",$a);
$t="CREATE TABLE reconnction (
  No VARCHAR(20) NOT NULL,
  `Serial No` VARCHAR(20) NOT NULL,
  `Book No` VARCHAR(20) NOT NULL,
  Acount VARCHAR(20) NOT NULL,
  `Contract No` VARCHAR(20) NOT NULL,
  `Customer Full Name` VARCHAR(50) NOT NULL,
  `D/C Reading` VARCHAR(50) NOT NULL,
  `R/C Reading` VARCHAR(50) NOT NULL,
  Remark VARCHAR(200) NOT NULL
)";
mysql_query("$t",$a);
$u="CREATE TABLE reglogin (
  uname VARCHAR(15) NOT NULL,
  pass VARCHAR(15) NOT NULL,
  member_type VARCHAR(30) NOT NULL,
  fname VARCHAR(30) NOT NULL,
  lname VARCHAR(30) NOT NULL,
  chname VARCHAR(30) NOT NULL,
  PRIMARY KEY (uname)
)";
mysql_query($u,$a);
$v="CREATE TABLE reprocess (
  Cusname VARCHAR(30) NOT NULL,
  billno VARCHAR(30) NOT NULL,
  servicetype VARCHAR(30) NOT NULL,
  servdetail VARCHAR(3000) NOT NULL
)";
mysql_query("$v",$a);
$w="CREATE TABLE rmessage (
  subject VARCHAR(50) NOT NULL,
  content VARCHAR(8000) NOT NULL,
  date DATETIME NOT NULL,
  id INT(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (id)
)";
mysql_query("$w",$a);
$x="CREATE TABLE tariffchang (
  No VARCHAR(20) NOT NULL,
  `Old Acc.` VARCHAR(25) NOT NULL,
  `Service No` VARCHAR(25) NOT NULL,
  `Customer Name` VARCHAR(200) NOT NULL,
  `Old Tariff` VARCHAR(100) NOT NULL,
  `New Tariff` VARCHAR(100) NOT NULL,
  `Additional Deposit` VARCHAR(100) NOT NULL,
  `Receipt No` VARCHAR(50) NOT NULL,
  Remark VARCHAR(200) NOT NULL,
  `New Service No` VARCHAR(100) NOT NULL
)";
mysql_query("$x",$a);
$y="INSERT INTO bill VALUES
('ende', 'gg', 'rr', '677', '34', '111', '234', '45'),
('mule', 'ergete', 'ayete', '122', '333', '122', '22', '123'),
('meski', 'qwer', 'qaser', '12', '20', '2', '80', '23'),
('teka', 'kader', 'erma', '345', '987', '20', '345', '89900'),
('abe', 'hail', 'hogos', '29', '32', '22', '45', '34'
)";
mysql_query("$y",$a);
$z="INSERT INTO comment VALUES
('ende', '2014-06-01 00:00:00', 'best site'),
('abe', '2014-06-02 00:00:00', 'I have no word about.......'),
('mule', '2014-06-05 00:00:00', 'It is realy cool........'),
('teka', '2014-06-05 00:00:00', 'Awsome...........'),
('meski', '2014-06-06 00:00:00', 'we are proud Africa, which is independent country known in every part of world.'),
('atoll', '2014-06-06 00:00:00', 'good......'),
('alex', '2014-06-07 00:00:00', 'wow I can't .......')";
mysql_query("$z",$a);
$aa="INSERT INTO complain VALUES
('111', 'asd df dfdf'),
('122', 'nwetr'),
('2', 'dffdf d fdfdf fddgd'),
('22', 'hjghjgb fghutu tyuugj fhf fhh')";
mysql_query("$aa",$a);
$ab="INSERT INTO cuslogin(uname,pass,member_type,secquest) VALUES
('ende', 'endalke','Customer', 'long'),
('meski', 'meskerem','Customer', 'chachi'),
('abe', 'abebe2','Customer', 'ab'),
('mule', 'mulugeta','Customer', 'mamo')";
mysql_query($ab,$a);
$ac="INSERT INTO deenroll VALUES
('1', 'css22', 'ende', 'Active  ', 'Reactive', ' Demmand ', 'Balance Fee', '23', 'none.'),
('2', 'f44', 'abebe', 'Active', 'Reactive', 'Demmand  ', '   Balance Fe', 'Receipt N', 'Reason for De-enrollment'),
('3', '12', 'ende', '12e', 'f4', 'bdr', '90', '77', 'none')";
mysql_query("$ac",$a);
$addd="INSERT INTO dislogin VALUES
('districtm', 'districtm','District manager', 'Setegn', 'beyene', 'sia')";
mysql_query($addd,$a);
$ae="INSERT INTO dmessage VALUES
('jer', 'Understandability Of The Code Is Too Important Especially During The Testing Phase. Each Variable And Method Must Be Readable', '2014-06-06 16:13:35', 1),
('italy', 'System design is the transformation of the analysis model into a system design model. It is a process of defining the architecture, components, modules, interfaces, and data for a system to satisfy specified requirements. We use system design to reduce the complexity of the system by decomposing the system into subsystems.', '2014-07-26 22:19:11', 2),
('hey', 'Sub-system decomposing Results into a set of loosely dependent parts which make up the system. The goal of the system decomposition is to reduce the com', '2014-07-31 00:28:33', 3)";
mysql_query("ae",$a);
$af="INSERT INTO event VALUES
('abela', ''),
('132', 'Worldwide, it is estimated that sand, gravel, limestone, clay, sulfur, salt, and phosphate make up 90% of the total tonnage of all industrial minerals and rocks produced and 60% of total value. The widespread use  of industrial minerals and rocks is in large part due to the following two characteristics  of these materials Firstly  the use of a single mineral in one production process often involves the use of several others', '2013-07-18'),
('ermi', 'cardsystem', '2013-07-18'),
('rty', 'dfhghh', '2013-07-19'),
('we', 'System design is the transformation of the analysis model into a system design model. It is a process of defining the architecture, components, modules, interfaces, and data for a system to satisfy specified requirements. We use system design to reduce the complexity of the system by decomposing the system into subsystems.', '2013-07-19'),
('34', 'There are higher deposit industrial rocks and other resource in the area and their reserve amount calculated by taking; average thickness, area and density of each rocks', '2013-07-19'),
('dodo', 'Industrial minerals and rocks are group of naturally occurring materials excluding gemstones, metallic ores, ground water, and mineral fuels', '2013-07-19'),
('rtyy', 'power change', '2013-07-19')";

mysql_query($af,$a);
$ag="INSERT INTO login VALUES
('admin', 'admin10','Administrator', 'endalke','mengist', 'long')";
mysql_query($ag,$a);
$agg="INSERT INTO disoflogin VALUES
('districto', 'districto','District officer', 'endalke','mengist', 'long')";
mysql_query($agg,$a);
$ah="INSERT INTO meterchange VALUES
('1', 'ende', 'Old Acc', 'Service No', 'Removed Property No', 'Removed last reading', 'Property NO', 'Serial No', 'Make', 'Material', 'Model', 'Dial', 'Const', 'Intial Reading', 'AR/MD')";
mysql_query($ah,$a);
$ai="INSERT INTO nametransfer VALUES
('acc122', 'css133', 'ende', 'active', 'reactive', 'MD', 'Tariff', 'Balance Fee', 'receipt', 'Remark', 'AppNo', 'OldAcc', 'endalke mengist', 'Ep.For Staff', 'tariff', 'Deposit', 'Receipt No', 'Remark')";
mysql_query($ai,$a);
$aj="INSERT INTO newconn VALUES
('', 'abebe', 'ase12', '1234', 'viva23', 'endalke', 'mengist', 'mera', 'south', 'kombolcha', 'abishager', '08', 's12', 'se22', '--', '--', '--', '---', 'w1', 'd12', '', 'viva', 'ss', 'ssffds', '60', 'der', 'ddsg', 'kkjk', 'fggfdgf', '', '', '', '', '', '', '', ''),
('1', '122', '233', '34', '233', 'abc', 'ser', 'bbc', 'snnpr', 'wollo', 'kocha', 'sesa', '12', '3', '32', 'checked', 'no', 'permanent', '11', '232', '222', '33', '555', '34', '11', '55', '77', '78', '22333', '34', '90', '9000', '50', '500', '67', '89', '9000'),
('12', '33', '12', '34', '12', 'EEPCO', 'asagid', 'h/mesgek', 'wollo', 'kocha', 'shishaber', '09', '99', '--', '--', '#', 'serial', 'err', '12', '34', 'del', 'sel', 'w33', '89', '23', '2', '12', '4', '700', '200', '30', '30', '2', '12', '2', '900', '12')";
mysql_query("$aj",$a);
$ak="INSERT INTO news VALUES
('abel', '2013-07-19 02:38:41', 'System design is the transformation of the analysis model into a system design model. It is a process of defining the architecture, components, modules, interfaces, and data for a system to satisfy specified requirements. We use system design to reduce the complexity of the system by decomposing the system into subsystems.', 1),
('bbc', '2013-07-19 02:39:33', 'A design goal Describes and prioritizes the qualities that are important for the system .Defines the value system against which options are evaluated. These goals are derived from the non-functional requirements of the system.', 2),
('cctv', '2013-07-19 02:41:04', '   Sub-system decomposing Results into a set of loosely dependent parts which make up the system. The goal of the system decomposition is to reduce the complexity of design model and to distribute the class of the system in to large scale and cohesive components. Our system is decomposing into the following subsystem.\r\nFrom above listed database management systems our team selects relational database management system to store data. This is because of A relational database provides an abstraction of data that is higher than flat files. Data are stored in tables that comply with a predefined type called schema. Each column in the table represents an attribute. Each row represents a data item as a tuple of attribute values. Several tuples in different tables are used to represent the attributes of an individual object. Relational databases have been used for awhile and are a mature technology. The use of a relational database introduces a high cost and, often, a\r\nPerformance bottleneck.\r\n', 3),
('supersport', '2013-07-19 02:41:39', '  Understandability of the code is too important especially during the testing phase. Each variable and method must be readable, so number of methods increase in the system and functions must be implemented in a clear way. To increase the understandability of the code adds comments into source code. This causes an additional cost in the developing phase. ', 4),
('cerr', '2013-07-19 02:42:07', '\t   The purpose of the corporation is to engage in the business of producing, transmitting, distributing and selling electrical energy(in accordance with economic and social development policies and priorities of the government) and to carry on any other related activities that would enables it achieve its purpose. At the time of establishment, the authorized capital of the corporation was 6.1 billion Birr of which 2.67 Billion Birr was paid up in cash and kind. \r\n\t   It was determined by the establishment regulation that the corporation shall have its Head Office in Addis Ababa and may have branch offices else where, as may be necessary. Currently,the annual electricity production capacity of the corporation is about 4980 GWH and the number of customers is about 1.1million.Although the corporation has been increasing the number of customers by more than 15% annually, \r\n', 5),
('uo', '2013-07-19 10:15:42', 'The system can operate on personal computers or laptop having more than70GB hard disk, minimum 1 GB RAM, network interface card, Intel Pentium 2.5 GHz processor on server side and operate on personal computer or laptop having more than 500MB RAM, Intel Pentium 2.5 GHz processor, network interface card, and more than 40GB hard disk in client slide and Hub or switch and Cat5e utp cable is needed in both sides', 6),
('ermi', '2013-07-31 00:28:17', 'Sub-system decomposing Results into a set of loosely dependent parts which make up the system. The goal of the system decomposition is to reduce the com\r\nSub-system decomposing Results into a set of loosely dependent parts which make up the system. The goal of the system decomposition is to reduce the com', 7)";

mysql_query("$ak",$a);
$al="INSERT INTO powerimpr VALUES
('a12', 'n23', 'm33', 'css33', 'ende', 'adu122', 'we222', '123', 'dell', 'dell', 'dell', 'dell', 'dell', 'dell', 'dell', 'dell', '', 'dell', 'dell', 'dell', '', 'dell', '', '', '', '', '', '', ''),
('b33', 'n4n44', 'mm77', 'moom33', 'endalke', 'ende1233', 'ser33', '444', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', 'acer', '', '', '', '', '', '', '', '', '')";
mysql_query("$al",$a);
$am="INSERT INTO reconnction VALUES
('123', 'ac23', 'bib66', 'acer3', 'fivi', 'endalke mengist', '200kw', '100kw', 'best thing everr')";
mysql_query("$am",$a);
$an="INSERT INTO reglogin(uname,pass,member_type,fname,lname,chname) VALUES
('region12', 'region12', 'Region manager', 'officcer','abebe', 'baby2')";
mysql_query($an,$a);
$ao="INSERT INTO reprocess VALUES
('kedir', '23', 'nametrans', 'hfsfhfhk')";
mysql_query("$ao",$a);
$ap="INSERT INTO rmessage VALUES
('hello', 'r u fine.The System Can Operate On Personal Computers Or Laptop Having More Than70GB Hard Disk, Minimum 1 GB RAM, Network Interface Card, Intel Pentium 2.5 GHz', '2013-07-25 15:38:29', 1),
('bbyer', 'The Purpose Of The Corporation Is To Engage In The Business Of Producing, Transmitting, Distributing And Selling Electrical Energy(In Accordance With Economic And Social.', '2013-07-25 15:39:45', 2),
('netst', 'text-decoration:none;', '2013-07-25 15:51:20', 3),
('hyyyy', 'Understandability Of The Code Is Too Important Especially During The Testing Pha.', '2013-07-25 15:52:33', 4),
('district hy', 'Understandability Of The Code Is Too Important Especially During The Testing Phase. Each Variable And Method Must Be Readable.', '2013-07-25 16:10:04', 5),
('ddd', 'The System Can Operate On Personal Computers Or Laptop Having More Than70GB Hard Disk, Minimum 1 GB RAM', '2013-07-25 20:45:04', 6)";
mysql_query($ap,$a);
$aq="INSERT INTO tariffchang VALUES
('1', 'css12', 'comp23', 'adugna', '200', '400', '23', 'de33', 'good', 'w2'),
('2', 'dd3', 'r4', 'wolde', '455', '444', '400', 'e3', 'not bad', 'ser'),
('a', 'sd', 'fggg', 'hhh', 'rrrrrr', 'ddddddddd', 'ttttttttttt', 'yyyyyyyyyyyyy', 'uuuuuuuuu', 'iiiiiiiiii')";
mysql_query($aq,$a);
?>












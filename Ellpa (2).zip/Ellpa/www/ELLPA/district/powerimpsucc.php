<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<?php
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
// SQL query to interact with info from our database
$sql = mysql_query("SELECT * FROM powerimpr"); 
// Establish the output variable
$dyn_table = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table .= '<tr><td><b>' . "Contract No" .'</b></td>';
$dyn_table .= '<td><b>' ."Customer Name".'</b></td>';
$dyn_table .= '<td><b>' . "Serial Number".'</b></td>';
$dyn_table .= '<td><b>' . "Voltage".'</b></td>';
$dyn_table .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$Noo=$row["contractno"];
$cuname=$row["custname"];
$serial=$row["serialno"];
$voltage=$row["voltage"]; 
	$dyn_table .= '<tr><td>' . $Noo . '</td>';
	$dyn_table .= '<td>' . $cuname . '</td>';
	$dyn_table .= '<td>' . $serial . '</td>';
	$dyn_table .= '<td>' . $voltage . '</td>';
}
$dyn_table .= '</tr></table>';
//table twoo
$sql = mysql_query("SELECT * FROM powerimpr"); 
// Establish the output variable
$dyn_table1 = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table1 .= '<tr><td>' . "Model" .'</th>';
$dyn_table1 .= '<th>' . "Manufucturer" .'</th>';
$dyn_table1 .= '<th>' . "Removed Voltage" .'</th>';
$dyn_table1 .= '<th>' . "Removed Serial Number" .'</th>';
$dyn_table1 .= '<th>' . "Removed Model" .'</th>';
$dyn_table1 .= '<th>' . "Removed Manufacturer" .'</th>';
$dyn_table1 .= '<th>' . "Added Power" .'</th>';
$dyn_table1 .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$Noo=$row["model"];
$manufac=$row["manufacturer"];
$voltage=$row["removedVoltage"];
$servno=$row["removedserialno"];
$model=$row["removedmodel"];
$manu=$row["removedmanufacturer"];
$power=$row["additionalpower"]; 
	$dyn_table1 .= '<tr><td>' . $Noo . '</td>';
	$dyn_table1 .= '<td>' . $manufac . '</td>';
	$dyn_table1 .= '<td>' . $voltage . '</td>';
	$dyn_table1 .= '<td>' . $servno . '</td>';
	$dyn_table1 .= '<td>' . $model . '</td>';
	$dyn_table1 .= '<td>' . $manu . '</td>';
	$dyn_table1 .= '<td>' . $power . '</td>';
}
$dyn_table1 .= '</tr></table>';
//table four
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/discss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Power improvment success
</title>
<script type="text/javascript">
      function check()
	{
	    var Book=document.powim.book.value;
		var Contract=document.powim.ContNO.value;
		var account=document.powim.Account.value;
		var Appno=document.powim.AppNO.value;
		var cusname=document.powim.cuname.value;
		var servno=document.powim.servno.value;
		var propno=document.powim.Propertyno.value;
		var serno=document.powim.Serialno.value;
		var manufa=document.powim.manufac.value;
		var materi=document.powim.Material.value;
		var model=document.powim.Model.value;
		var voltage=document.powim.Voltage.value;
		var ampere=document.powim.Ampere.value;
		var phase=document.powim.Phase.value;
		var dail=document.powim.Dials.value;
		var consta=document.powim.Constant.value;
		var newinread=document.powim.Intialreading.value;
		var str="Fill All the Necessarly information";
		if(Book==""||Contract==""||account==""||Appno==""||cusname==""||servno==""||propno==""||serno==""||manufa==""||materi==""||model==""||voltage==""||ampere==""||phase==""||dail==""||consta==""||newinread=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	  <div id="maina"><!--left body code area inside main body begins here -->
	     <p style="text-align:center;color:red"><u>Success in submitting</u></p><br>
	        <?php echo $dyn_table; ?>
				<br>
				<?php echo $dyn_table1; ?>
				<br>
	  </div>	<!--left body code area inside main body ends here -->
 
  
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Disservice.php">Home</a></li>
			<li><a href="#">Services</a>
				<ul>	
			<li><a href="powerimp.php">Power improvement</a></li>
			<li><a href="reconnect.php">Re-connection information</a></li>
			<li><a href="nametrans.php">Name transfer information</a></li>
			<li><a href="deenroll.php">De-enrolment information</a></li>
			<li><a href="Tariffchng.php">Tariff change information</a></li>
			<li><a href="meterchng.php">Metter change information</a></li>
			<li><a href="#">Re-processing information</a>
					<ul>
			<li><a href="Re-proccess.php">Provide Information</a></li>	
			<li><a href="Removereprcssinfo.php">Remove Information</a></li>

				</ul>
			</li>

				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="inbox.php">Inbox(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from rcount");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="cmessage.php">Compose Message</a></li>
				</ul>
			</li>	
			</li>
			<li><a href="billregistration.php">Bill registration</a></li>
			<li><a href="view_request.php">View Request</a></li>
			<li><a href="power_improvment.php">View Report</a>
			</li>
	</ul>			
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Disservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCo kombolcha district 2014.
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
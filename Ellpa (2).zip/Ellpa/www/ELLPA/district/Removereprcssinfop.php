<?php
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO1');
	$query=mysql_query("Delete from reprocess");
		if($query)
		{
			$url="Location:Removereprcssinfosuc.php";
			header($url);
		}
		else
	    {
			$url="Location:Removereprcssinfoerr.php";
			header($url);
	    }
?>
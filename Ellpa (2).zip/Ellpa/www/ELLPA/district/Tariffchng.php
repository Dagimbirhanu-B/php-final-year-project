<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/discss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Tariff Change
</title>
<script type="text/javascript">
    function check()
	{
	    var Noo=document.tarffcng.no.value;
		var OldAcc=document.tarffcng.oldacc.value;
		var servnoo=document.tarffcng.Serviceno.value;
		var cuname=document.tarffcng.cufname.value;
		var oldtrrf=document.tarffcng.oldtarr.value;
		var newtrff=document.tarffcng.newtrf.value;
		var adddep=document.tarffcng.adddepo.value;
		var recieptno=document.tarffcng.recno.value;
		var remrkk=document.tarffcng.remark.value;
		var newsernobc=document.tarffcng.newsrvno.value;
		var str="Fill All the Necessarly information";
		if(Noo==""||OldAcc==""||servnoo==""||cuname==""||oldtrrf==""||newtrff==""||adddep==""||recieptno==""||remrkk==""||newsernobc=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	  <div id="maina"><!--left body code area inside main body begins here -->
	      <p style="text-align:center;font-size:20px;font-weight:bold;"><u>TARIFF CHANGE</u></p>
	        <form action="Tariffchngp.php" method="POST" onSubmit="return check();" name="tarffcng">
			<fieldset style="background:#4681bd">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			NO.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Old Acc.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Service No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;
			Customer&#39;s Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;
			Old tariff
			</br>
			<input type="text" name="no">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="oldacc">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="Serviceno">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="cufname">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="oldtarr">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			New Tariff&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Additional Deposit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;
			Receipt No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			Remark&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			New service No. by CIPC
			</br>
			<input type="text" name="newtrf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="adddepo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="recno">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="remark">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="text" name="newsrvno">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</fieldset>
			<div id="error" style="color:red;text-align:center"></div>
			<p style="text-align:center;font-size:20px;font-weight:bold;"><input type="submit">&nbsp;&nbsp;&nbsp;&nbsp;<input type="Reset"></p>
			
			</form>
	  </div>	<!--left body code area inside main body ends here -->
 
  
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
<ul id="menu">
			<li><a href="Disservice.php">Home</a></li>
			<li><a href="#">Services</a>
				<ul>	
			<li><a href="powerimp.php">Power improvement</a></li>
			<li><a href="reconnect.php">Re-connection information</a></li>
			<li><a href="nametrans.php">Name transfer information</a></li>
			<li><a href="deenroll.php">De-enrolment information</a></li>
			<li><a href="Tariffchng.php">Tariff change information</a></li>
			<li><a href="meterchng.php">Metter change information</a></li>
			<li><a href="#">Re-processing information</a>
					<ul>
			<li><a href="Re-proccess.php">Provide Information</a></li>	
			<li><a href="Removereprcssinfo.php">Remove Information</a></li>

				</ul>
			</li>

				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="inbox.php">Inbox(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from rcount");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="cmessage.php">Compose Message</a></li>
				</ul>
			</li>	
			</li>
			<li><a href="billregistration.php">Bill registration</a></li>
			<li><a href="view_request.php">View Request</a></li>
			<li><a href="power_improvment.php">View Report</a>
			</li>
	</ul>				
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Disservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCo kombolcha district 2014.
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
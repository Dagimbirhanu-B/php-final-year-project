<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<?php
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
// SQL query to interact with info from our database
$sql = mysql_query("SELECT * FROM newcust"); 
// Establish the output variable
$dyn_table = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table .= '<tr><td><b>' . "Contract No" .'</b></td>';
$dyn_table .= '<td><b>' ."Customer Name".'</b></td>';
$dyn_table .= '<td><b>' . "Address".'</b></td>';
$dyn_table .= '<td><b>' . "Purpose for w/c electricity is to be supplied".'</b></td>';
$dyn_table .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$Noo=$row["contractno"];
$cuname=$row["custname"];
$address=$row["address"];
$purpose=$row["purpose"]; 
	$dyn_table .= '<tr><td>' . $Noo . '</td>';
	$dyn_table .= '<td>' . $cuname . '</td>';
	$dyn_table .= '<td>' . $address . '</td>';
	$dyn_table .= '<td>' . $purpose . '</td>';
}
$dyn_table .= '</tr></table>';
//table twoo
$sql = mysql_query("SELECT * FROM newcust"); 
// Establish the output variable
$dyn_table1 = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table1 .= '<tr><td>' . "Tariff" .'</th>';
$dyn_table1 .= '<th>' . "Date" .'</th>';
$dyn_table1 .= '<th>' . "Connection Fee" .'</th>';
$dyn_table1 .= '<th>' . "Total" .'</th>';
$dyn_table1 .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$Noo=$row["tariff"];
$date=$row["date"];
$oldacc=$row["connectionfee"];
$servno=$row["total"]; 
	$dyn_table1 .= '<tr><td>' . $Noo . '</td>';
	$dyn_table1 .= '<td>' . $date . '</td>';
	$dyn_table1 .= '<td>' . $oldacc . '</td>';
	$dyn_table1 .= '<td>' . $servno . '</td>';
}
$dyn_table1 .= '</tr></table>';
//table four
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/discss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
New customer registration success
</title>
<script type="text/javascript">
    function check()
	{
	    var Book=document.newcus.cusname.value;
		var Contract=document.newcus.address.value;
		var account=document.newcus.pupose.value;
		var Appno=document.newcus.lightno.value;
		var Frstn=document.newcus.lighttotalw.value;
		var Fathname=document.newcus.motorno.value;
		var Gfathname=document.newcus.motortotw.value;
		var region=document.newcus.socketoutno.value;
		var city=document.newcus.socketouttotw.value;
		var kketem=document.newcus.mesllno.value;
		var Kebel=document.newcus.meslltw.value;
		var Housen=document.newcus.whacno.value;
		var Floorn=document.newcus.whactotw.value;
		var powp=document.newcus.powapp.value;
		var powv=document.newcus.powvolt.value;
		var apptrff=document.newcus.apptarriff.value;
		var datt=document.newcus.datte.value;
		var depth=document.newcus.depeth.value;
		var confeeth=document.newcus.confeeeth.value;
		var totethh=document.newcus.toteth.value;
		var str="Fill All the Necessarly information";
		if(Book==""||Contract==""||account==""||Appno==""||Frstn==""||Fathname==""||Gfathname==""||region==""||city==""||kketem==""
		||Kebel==""||Housen==""||Floorn==""||powp==""||powv==""||apptrff==""||datt==""||depth==""||confeeth==""||totethh=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	  <div id="maina"><!--left body code area inside main body begins here -->
	            <p style="text-align:center;color:red">Success in submitting</p><br>
	            <?php echo $dyn_table; ?>
				<br>
				<?php echo $dyn_table1; ?>
				<br>
	  </div>	<!--left body code area inside main body ends here -->
 
  
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Disserviceof.php">Home</a></li>
			<li><a href="#">Services</a>
				<ul>
			<li><a href="newcust.php">New customer registration</a></li>	
			</li>

				</ul>
				<li><a href="#">File</a>
				<ul>
			<li><a href="uploadfilee.php">Upload File</a></li>
			<li><a href="download.php">Download File</a></li>
			<li><a href="removefile.php">Remove Files</a></li>
				</ul>
			</li>
			</li>
			</li>
			<li><a href="#">Information</a>
				<ul>
			<li><a href="event.php">Post New Event</a></li>	
			<li><a href="news.php">post news</a></li>
			<li><a href="advert.php">Advertisment</a></li>
				</ul>
			</li>
	</ul>	
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Disservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCo kombolcha district 2014.
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
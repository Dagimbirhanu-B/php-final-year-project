<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<?php
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
// SQL query to interact with info from our database
$sql = mysql_query("SELECT * FROM complain"); 
// Establish the output variable
$dyn_table = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table .= '<tr><td><b>' . "Bill NO" .'</b></td>';
$dyn_table .= '<td><b>' ."Complain".'</b></td>';
$dyn_table .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$Noo=$row["billnom"];
$cuname=$row["complain"];
	$dyn_table .= '<tr><td>' . $Noo . '</td>';
	$dyn_table .= '<td>' . $cuname . '</td>';
}
$dyn_table .= '</tr></table>';

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/discss1.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Re-processing information
</title>
<script type="text/javascript">
    function check()
	{
	    var nam=document.reprocess.nam.value;
		var billnom=document.reprocess.billnom.value;
		var servtype=document.reprocess.servtype.value;
		var str="Fill the information";
		if(nam==""||billnom==""||servtype=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	  <div id="penality"><!--left body code area inside main body begins here -->
	  <center><b>Customer Complain Information:</b></center><br>
		<?php echo $dyn_table;?><br><br><br>
		<form action="Re-proccessp.php" method="POST" name="reprocess" onSubmit="return check();">
		  <fieldset>
		   <legend>Re-processing information</legend>
		    Customer Name: <input type="text" name="nam">
			Bill No: <input type="text" name="billnom"><br><br>
			Service Type:<select name="servtype">
						    <option value="" disabled="disabled" selected="selected" >--Select--</option>
							<option value="powerimp">power improvement</option>
							<option value="reconnect">reconnection</option>
							<option value="nametrans">name transfer</option>
							<option value="deenroll">de-enrolment</option>
							<option value="Tariffchng">Tariff change</option>
							<option value="meterchng">meter change</option>
						</select><br><br>
			<textarea name="servdetail" placeholder="Service Detail.."></textarea><br><br>
			<div id="error" style="color:red"></div>
			<input class="groovybutton" type="submit" value="submit"> <input class="groovybutton" type="reset">
			</fieldset>
		 </form>
      </div>	<!--left body code area inside main body ends here -->
 
    <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
	<div id="adverta">
	   
		    	
		  <img src="get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=Dnews.php?val=$newid>Read more</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="get.php?id=2" alt="Advertisments">
		 
	</div>
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Disservice.php">Home</a></li>
			<li><a href="#">Services</a>
				<ul>	
			<li><a href="powerimp.php">Power improvement</a></li>
			<li><a href="reconnect.php">Re-connection information</a></li>
			<li><a href="nametrans.php">Name transfer information</a></li>
			<li><a href="deenroll.php">De-enrolment information</a></li>
			<li><a href="Tariffchng.php">Tariff change information</a></li>
			<li><a href="meterchng.php">Metter change information</a></li>
			<li><a href="#">Re-processing information</a>
					<ul>
			<li><a href="Re-proccess.php">Provide Information</a></li>	
			<li><a href="Removereprcssinfo.php">Remove Information</a></li>

				</ul>
			</li>

				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="inbox.php">Inbox(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from rcount");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="cmessage.php">Compose Message</a></li>
				</ul>
			</li>	
			</li>
			<li><a href="billregistration.php">Bill registration</a></li>
			<li><a href="view_request.php">View Request</a></li>
			<li><a href="power_improvment.php">View Report</a>
			
			</li>
	</ul>			
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Disservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCo kombolcha district 2014.
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
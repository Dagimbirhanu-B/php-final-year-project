<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/discss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
New customer registration
</title>
<script type="text/javascript">
    function check()
	{
	    var contn=document.newcus.contnoo.value;
		var Book=document.newcus.cusname.value;
		var Contract=document.newcus.address.value;
		var account=document.newcus.pupose.value;
		var Appno=document.newcus.lightno.value;
		var Frstn=document.newcus.lighttotalw.value;
		var Fathname=document.newcus.motorno.value;
		var Gfathname=document.newcus.motortotw.value;
		var region=document.newcus.socketoutno.value;
		var city=document.newcus.socketouttotw.value;
		var kketem=document.newcus.mesllno.value;
		var Kebel=document.newcus.meslltw.value;
		var Housen=document.newcus.whacno.value;
		var Floorn=document.newcus.whactotw.value;
		var powp=document.newcus.powapp.value;
		var powv=document.newcus.powvolt.value;
		var apptrff=document.newcus.apptarriff.value;
		var datt=document.newcus.datte.value;
		var depth=document.newcus.depeth.value;
		var confeeth=document.newcus.confeeeth.value;
		var totethh=document.newcus.toteth.value;
		var str="Fill All the Necessarly information";
		if(contn==""||Book==""||Contract==""||account==""||Appno==""||Frstn==""||Fathname==""||Gfathname==""||region==""||city==""||kketem==""
		||Kebel==""||Housen==""||Floorn==""||powp==""||powv==""||apptrff==""||datt==""||depth==""||confeeth==""||totethh=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	  <div id="maina"><!--left body code area inside main body begins here -->
	      <p style="text-align:center;font-size:20px;font-weight:bold;"><u>New Customer Registration</u></p>
	        <form action="newcustp.php" method="POST" onSubmit="return check();" name="newcus">
			<center>
			Contract No:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="contnoo" required="required"><br/>
				Customer name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="custname" required="required"><br/>
				Address:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" name="address" required="required"><br><br>
				Purpose for w/c electricity is to be supplied:<input type="text" name="purpose" required="required"><br><br>
				Applicable Tariff:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" name="tariff" required="required"><br/>
				Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" name="datte" value="<?php echo date('d-m-y');?>"><br/>
				connection fee Eth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="confeeeth" required="required"><br><br>
				Total Eth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="text" name="toteth" required="required"><br>
				<div id="error" style="color:red;text-align:center"></div><br>
				<input class="groovybutton" type="submit" value="Create">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="groovybutton" type="reset" value="Clear">
				</center>
			</form>
	  </div>	<!--left body code area inside main body ends here -->
 
  
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Disserviceof.php">Home</a></li>
			<li><a href="#">Services</a>
				<ul>
			<li><a href="newcust.php">New customer registration</a></li>	
			</li>

				</ul>
				<li><a href="#">File</a>
				<ul>
			<li><a href="uploadfilee.php">Upload File</a></li>
			<li><a href="download.php">Download File</a></li>
			<li><a href="removefile.php">Remove Files</a></li>
				</ul>
			</li>
			</li>
			</li>
			<li><a href="#">Information</a>
				<ul>
			<li><a href="event.php">Post New Event</a></li>	
			<li><a href="news.php">post news</a></li>
			<li><a href="advert.php">Advertisment</a></li>
				</ul>
			</li>
	</ul>	
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Disserviceof.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCo kombolcha district 2014.
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
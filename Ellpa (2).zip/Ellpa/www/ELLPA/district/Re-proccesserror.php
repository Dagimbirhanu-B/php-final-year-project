<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/discss1.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Re-processing information Error
</title>
<script type="text/javascript">
    function check()
	{
	    var nam=document.reprocess.nam.value;
		var billnom=document.reprocess.billnom.value;
		var servtype=document.reprocess.servtype.value;
		var str="Fill the information";
		if(nam==""||billnom==""||servtype=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	  <div id="maina"><!--left body code area inside main body begins here -->
		Error in Re-processing information submitting.
      </div>	<!--left body code area inside main body ends here -->
 
    <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
	<div id="adverta">
	   
		    	
		  <img src="get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=Dnews.php?val=$newid>Read more</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="get.php?id=2" alt="Advertisments">
		 
	</div>
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
<ul id="menu">
			<li><a href="Disservice.php">Home</a></li>
			<li><a href="#">Services</a>
				<ul>	
			<li><a href="powerimp.php">Power improvement</a></li>
			<li><a href="reconnect.php">Re-connection information</a></li>
			<li><a href="nametrans.php">Name transfer information</a></li>
			<li><a href="deenroll.php">De-enrolment information</a></li>
			<li><a href="Tariffchng.php">Tariff change information</a></li>
			<li><a href="meterchng.php">Metter change information</a></li>
			<li><a href="#">Re-processing information</a>
					<ul>
			<li><a href="Re-proccess.php">Provide Information</a></li>	
			<li><a href="Removereprcssinfo.php">Remove Information</a></li>

				</ul>
			</li>

				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="inbox.php">Inbox(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from rcount");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="cmessage.php">Compose Message</a></li>
				</ul>
			</li>	
			</li>
			<li><a href="billregistration.php">Bill registration</a></li>
			<li><a href="view_request.php">View Request</a></li>
			<li><a href="#">View Report</a>
			<ul>
			<li><a href="power_improvment.php">Power Improvment Report</a></li>	
			<li><a href="name_transfer.php">Name Transfer Report</a></li>
            <li><a href="deenrolment.php">De-enrolment Report</a></li>
				</ul>
			</li>
	</ul>				
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Disservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCo kombolcha district 2014.
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
<?php
$idd=$_POST['namee'];
$entte=$_POST['entt'];
$date = date('Y-m-d H:i:s');
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$query=mysql_query("insert into Event values('$idd','$entte','$date')");
		if($query)
		{
			$url="Location:eventsucc.php";
			header($url);
		}
		else
	    {
			$url="Location:eventerror.php";
			header($url);
	    }

?>
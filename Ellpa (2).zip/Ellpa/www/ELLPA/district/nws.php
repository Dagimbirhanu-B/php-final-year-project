<?php
			$pname=$_POST['pn'];
			$date = date('Y-m-d H:i:s');
			$news=$_POST['new'];
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO1');
			$query=mysql_query("insert into news values('$pname','$date','$news','')");
			if($query)
			{
				$url="Location:newss.php";
				header($url);
			}
			else
			{
				$url="Location:newse.php";
				header($url);
			}
?>		 
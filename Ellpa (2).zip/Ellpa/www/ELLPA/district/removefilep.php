<?php
	  $titlee=$_POST['title'];
	  mysql_connect('localhost','root','');
	  mysql_select_db('EEPCOO1');
	  $query=mysql_query("select * from dfile where title='$titlee'");
	  $dbtitle="";
		while($row=mysql_fetch_array($query))
		{
			$dbtitle=$row['title'];
		}
		if($titlee==$dbtitle)
		{
            $query=mysql_query("Delete from dfile where title='$titlee'");
			$url="Location:removefilesucc.php";
			header($url);
		}
		else
	    {
			$url="Location:removefilerror.php";
			header($url);
	    }
?>
<?php
		    mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO1');
			  $id=$_POST['ide'];
				$insert=mysql_query("DELETE FROM imaget WHERE id='$id'");
				if($insert)
				{
					$url="Location:avrtimgrms.php";
					header($url);
					
				}
				else
				{
				    $url="Location:avrtimgrme.php";
					header($url);
				}
?>
<?php
$namme=$_POST['nam'];
$billnomb=$_POST['billnom'];
$servtypee=$_POST['servtype'];
$servdetaill=$_POST['servdetail'];
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$query=mysql_query("insert into reprocess values('$namme','$billnomb','$servtypee','$servdetaill')");
		if($query)
		{
			mysql_query("delete from complain where billnom='$billnomb'");
			$url="Location:Re-proccessucc.php";
			header($url);
		}
		else
	    {
			$url="Location:Re-proccesserror.php";
			header($url);
	    }
?>
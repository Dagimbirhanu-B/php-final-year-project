<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style3.css">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<title>
Bill Not Found
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill all the neccessary information";
		var str="Fill all the neccessary information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
	function check1()
	{
		var cubilno=document.forgot.cubilno.value;
	    var uname=document.forgot.nam.value;
		var str="Fill all the neccessary information";
		if(uname==""||cubilno=="")
		{
		  document.getElementById("error1").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo">

   
</div>
<div id="main"><!--main box code area begins here -->
 <div id="mainaa"><!--main body code area begins here -->
  <div id="maina"><!--left body code area inside main body begins here -->
	    <form action="#" method="POST" name="forgot" onSubmit="return check1();">
		 <fieldset style="width:500px; height:300px;">
		  <legend>Password Reset</legend>
		  Bill Information Not Found.<a href="forgot.php">Back</a>
		  </fieldset>	
		 </form>
		
  </div>	<!--left body code area inside main body ends here -->
    <div id="mainb"><!--right body code area inside main body begins here -->
	<form action="login.php" method="POST" onSubmit="return check();" name="login">
            <fieldset id="fieldsetle">
			   <legend>Member Login</legend>
                   <br>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style="height: 32px;"class="box11" type="text" name="uname" size="30" placeholder="Enter your user name here"><br><br>
                                &nbsp;&nbsp; &nbsp;  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<input type="password" style="height: 30px;"class="box11" name="psswrd" size="30" placeholder="Enter your pasword here"><br><br>
                         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 <input class="groovybutton" type="submit" name="pass" value="Login">
                             <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 <a href="forgot.php">Forgot password?</a></p>
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 
							 <div id="error" style="color:red"></div>
                    
                
            </fieldset>
        </form>
	</div>	<!--right body code area inside main body ends here -->
	<div id="adverta">
	   
		    	
		  <img src="adv/get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=news.php?val=$newid>Read more</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="adv/ge.php?id=2" alt="Advertisments">
		 
	</div>
  </div>	<!--main body code area ends here -->
	<div id="lnbar"><!--link bar code area begins here -->
		<ul id="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="#">About Us</a>
				<ul>
					<li><a href="organstructure.php">Organizational structure</a></li>
				</ul>		
			</li>
			<li>
			<a href="#">More Links</a>
		<ul>
			<li><a href="emergecy.php">Emergency Call</a></li>
			<li><a href="photo.php">Photo Gallery</a></li>
		</ul>
			</li>
		</ul>		
</div><!--link bar code area ends here -->
  </div><!--main box code area ends here -->
<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="index.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerr"><!--right footer code area begins here -->
	<a href="contact.php">contact us</a></pre><br>
</div> <!--center footer code area ends here -->
<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/regcss1.css">
<link rel="stylesheet" href="css/style2.css" type="text/css" media="screen">
<title>
Create Account
</title>
<script type="text/javascript">
    function create()
	{
		var ffname=document.create1.fnamee.value;
		var llname=document.create1.lnamee.value;
		var chhname=document.create1.chnamee.value;
	    var uname=document.create1.unamee.value;
		var pass=document.create1.psswrd.value;
		var cpass=document.create1.cpsswrd.value;
		var str="Fill all the information";
		if(ffname==""||llname==""||chhname==""||uname==""||pass==""||cpass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		if(pass!=cpass){
		alert("The entered password dosn't match");
		document.create1.cpsswrd.value="";
		document.create1.cpsswrd.focus();
		return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--link bar code area begins here-->

</div><!--link bar code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main box code area begins here -->
 <div id="mainaa"><!--main body code area begins here -->
  <div id="maina"><!--left body code area inside main body begins here -->
   <div id="mainbb">
	 <form action="createe.php" method="POST" onSubmit="return create();" name="create1">
            <fieldset style="width:400px;">
			<legend>Create Account:</legend>
			<br>
			              First name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  <input style="height: 32px;"class="box11" type="text" name="fnamee" size="30"><br><br>
			              Last name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  <input style="height: 32px;"class="box11" type="text" name="lnamee" size="30"><br><br>
				          Your Child name:&nbsp;
						  <input style="height: 32px;"class="box11" type="text" name="chnamee" size="30"><br><br>				  
                          User name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  <input style="height: 32px;"class="box11" type="text" name="unamee" size="30"><br><br>
                          Password:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  <input type="password" style="height: 30px;"class="box11" name="psswrd" id="password" size="30"><br><br>				
								Confirm password:&nbsp;<input type="password" style="height: 30px;"class="box11" name="cpsswrd" id="cpsswrd" size="30"><br><br>
								Member Type:&nbsp;<input type="text" style="height: 30px;"class="box11" name="member_type" size="30" value="Administrator"><br><br>
                       <br><br>
						 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 <input class="groovybutton" type="submit" name="cre" value="Create">
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 <input class="groovybutton" type="Reset" name="cre" value="Reset"><br>
                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div id="error" style="color:red"></div>
            </fieldset>
        </form>
   </div>
  </div>	<!--left body code area inside main body ends here -->
     <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
	<div id="adverta">
	   
		    	
		  <img src="adv/get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=Dnews.php?val=$newid>Read more</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="adv/ge.php?id=2" alt="Advertisments">
		 
	</div>
  </div>	<!--main body code area ends here -->
	<div id="lnbar"><!--link bar code area begins here -->
		<ul id="menu">
			<li><a href="Admin.php">Home</a></li>
			<li><a href="#">Create Acount</a>
					<ul>
			<li><a href="create.php">Admin Account</a></li>	
			<li><a href="dismanager.php">District manager Account</a></li>
            <li><a href="disoffimanager.php">District officer Account</a></li>
			<li><a href="regsmanager.php">Region manager Account</a></li>
			<li><a href="customeraccount.php">Customer Account</a></li>
				</ul>
			</li>
			<li><a href="#">Update Acount</a>
			<ul>
			<li><a href="adminupdate.php">Admin Account</a></li>	
			<li><a href="dismanagerupdate.php">District manager Account</a></li>
            <li><a href="disoffimanagerupdate.php">District officer Account</a></li>
			<li><a href="regsmanagerupdate.php">Region manager Account</a></li>
			<li><a href="customeraccountupdate.php">Customer Account</a></li>
				</ul>
			</li>
			<li><a href="#">Delete Acount</a>
			<ul>
			<li><a href="admindelete.php">Admin Account</a></li>	
			<li><a href="dismanagerdelete.php">District manager Account</a></li>
            <li><a href="disoffimanagerdelete.php">District officer Account</a></li>
			<li><a href="regsmanagerdelete.php">Region manager Account</a></li>
			<li><a href="customeraccountdelete.php">Customer Account</a></li>
				</ul>
			</li>
		</ul>		
	</div>
  </div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="admin.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district 2014
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
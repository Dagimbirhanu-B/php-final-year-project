<?php
$namee=$_GET['name1'];
$npassw=$_GET['pass1'];
$actype=$_GET['actyp1'];
if($actype=='doff')
{
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO1');
	$result = mysql_query("SELECT * from dislogin where uname='$namee'");
	while($rows=mysql_fetch_array($result))
	{
	$dbuname=$rows['uname'];
	$dbpass=$rows['pass'];
	
	}
	$dec = base64_decode($dbpass);
	if(($dbuname==$namee) && ($dec==$npassw))
	{
	        $results = mysql_query("Delete from dislogin where uname='$namee'");
			if($results)
			{
			$url="Location:deletesucc.php";
			header($url);
			}
			else
			{
			$url="Location:deleteerror.php";
			header($url);
			}
	}
	else
	{
		$url="Location:deleteerror.php";
		header($url);
	}
}
else if($actype=='roff')
{
$dbuname="";
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO');
		$result = mysql_query("SELECT * from reglogin where uname='$namee'");
	while($rows=mysql_fetch_array($result))
	{
	$dbuname=$rows['uname'];
	$dbpass=$rows['pass'];
	
	}
	$dec = base64_decode($dbpass);
	if(($dbuname==$namee) && ($dec==$npassw))
	{
	        $results = mysql_query("Delete from reglogin where uname='$namee'");
			if($results)
			{
			$url="Location:deletesucc.php";
			header($url);
			}
			else
			{
			$url="Location:deleteerror.php";
			header($url);
			}
	}
	else
	{
		$url="Location:deleteerror.php";
		header($url);
	}
}
else if($actype=='admin')
{
$dbuname="";
	mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO');
		$result = mysql_query("SELECT * from login where uname='$namee'");
	while($rows=mysql_fetch_array($result))
	{
	$dbuname=$rows['uname'];
	$dbpass=$rows['pass'];
	
	}
	$dec = base64_decode($dbpass);
	if(($dbuname==$namee) && ($dec==$npassw))
	{
	        $results = mysql_query("Delete from login where uname='$namee'");
			if($results)
			{
			$url="Location:deletesucc.php";
			header($url);
			}
			else
			{
			$url="Location:deleteerror.php";
			header($url);
			}
	}
	else
	{
		$url="Location:deleteerror.php";
		header($url);
	}
}
?>
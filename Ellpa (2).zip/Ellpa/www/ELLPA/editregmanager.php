<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/regcss1.css">
<link rel="stylesheet" href="css/style2.css" type="text/css" media="screen">
<title>
Create Account
</title>
<script type="text/javascript">
    function create()
	{
		var ffname=document.create1.fnamee.value;
		var llname=document.create1.lnamee.value;
		var chhname=document.create1.chnamee.value;
	    var uname=document.create1.unamee.value;
		var pass=document.create1.psswrd.value;
		var cpass=document.create1.cpsswrd.value;
		var str="Fill all the information";
		if(ffname==""||llname==""||chhname==""||uname==""||pass==""||cpass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--link bar code area begins here-->

</div><!--link bar code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main box code area begins here -->
 <div id="mainaa"><!--main body code area begins here -->
  <div id="maina"><!--left body code area inside main body begins here -->
   <div id="mainbb">
	   <form id="form1" name="abc" method="post" action="editregmanager-exec.php" onSubmit="return validateForm1()">

<div style="float:center;"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<u>Update District officer</u></strong></div>
  <table width="368" align="center">
  <tr>
  <td>
<?php
//include('allmembers.php');
				  if (isset($_GET['fname']))
	{
	
 echo '<form action="editregmanager-exec.php" method="post" name="abc" onsubmit="return validateForm1()">';
	//echo "<img width=200 height=180 alt='Unable to View' src='" . $row1["image"] . "'>"
			 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
			$id=$_GET['fname'];
			$result = mysql_query("SELECT * FROM reglogin WHERE fname = '$id'");

			while($row = mysql_fetch_array($result))
  			{
			echo 'User Name:'.'<input type="text" name="uname" value="'. $row['uname'] .'">'; 
			echo '<br>';
  			echo 'Password: '.'<input type="text" name="pass" value="'. $row['pass'] .'">'; 
			   echo '<br>';
			   echo 'Member Type: '.'<input type="text" name="member_type" value="'. $row['member_type'] .'">'; 
			   echo '<br>';
			    echo 'First Name: '.'<input type="text" name="fname" value="'. $row['fname'] .'">';
			   echo '<br>';
			  echo 'Last Name: '.'<input type="text" name="lname" value="'. $row['lname'] .'">';
			   echo '<br>';
			    echo 'Chiled Name: '.'<input type="text" name="chname" value="'. $row['chname'] .'">';
			   echo '<br>';
			  echo '<input name="" type="submit" value="Update" />';
  			}
	echo '</form>';
			}
			?>
			</td></tr></table></form></center>
   </div>
  </div>	<!--left body code area inside main body ends here -->
     <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
	<div id="adverta">
	   
		    	
		  <img src="get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=Dnews.php?val=$newid>Read more</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="get.php?id=2" alt="Advertisments">
		 
	</div>
  </div>	<!--main body code area ends here -->
	<div id="lnbar"><!--link bar code area begins here -->
		<ul id="menu">
			<li><a href="Admin.php">Home</a></li>
			<li><a href="#">Create Acount</a>
					<ul>
			<li><a href="create.php">Admin Account</a></li>	
			<li><a href="dismanager.php">District manager Account</a></li>
            <li><a href="disoffimanager.php">District officer Account</a></li>
			<li><a href="regsmanager.php">Region manager Account</a></li>
			<li><a href="customeraccount.php">Customer Account</a></li>
				</ul>
			</li>
			<li><a href="#">Update Acount</a>
			<ul>
			<li><a href="adminupdate.php">Admin Account</a></li>	
			<li><a href="dismanagerupdate.php">District manager Account</a></li>
            <li><a href="disoffimanagerupdate.php">District officer Account</a></li>
			<li><a href="regsmanagerupdate.php">Region manager Account</a></li>
			<li><a href="customeraccountupdate.php">Customer Account</a></li>
				</ul>
			</li>
			<li><a href="#">Delete Acount</a>
			<ul>
			<li><a href="admindelete.php">Admin Account</a></li>	
			<li><a href="dismanagerdelete.php">District manager Account</a></li>
            <li><a href="disoffimanagerdelete.php">District officer Account</a></li>
			<li><a href="regsmanagerdelete.php">Region manager Account</a></li>
			<li><a href="customeraccountdelete.php">Customer Account</a></li>
				</ul>
			</li>
		</ul>		
	</div>
  </div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="admin.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district 2014
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
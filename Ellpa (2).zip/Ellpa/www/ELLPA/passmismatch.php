<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/regcss1.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Create Acount
</title>
<script type="text/javascript">
    function create()
	{
	    var uname=document.create1.unamee.value;
		var pass=document.create1.psswrd.value;
		var cpass=document.create1.cpsswrd.value;
		var str="Fill all the information";
		if(uname==""||pass==""||cpass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--link bar code area begins here-->

</div><!--link bar code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main box code area begins here -->
 <div id="mainaa"><!--main body code area begins here -->
  <div id="maina"><!--left body code area inside main body begins here -->
   <div id="mainbb">
	 <form action="createe.php" method="POST" onSubmit="return create();" name="create1">
            <fieldset>
			<br>
                 
				 <h3>Create Acount:</h3>
                          User name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  <input style="height: 32px;"class="box11" type="text" name="unamee" size="30"><br><br>
                               Password:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<input type="password" style="height: 30px;"class="box11" name="psswrd" size="30"><br><br>
								Confrim password:&nbsp;<input type="password" style="height: 30px;"class="box11" name="cpsswrd" size="30"><br><br>
                       Select acount type:&nbsp;&nbsp;<select name="actype" id="actype" style="width:170px">
						    <option value="" disabled="disabled" selected="selected">Acount will be created for</option>
							<option value="doff">District officer</option>
							<option value="roff">Region Officer</option>
						</select><br><br>
						 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="groovybutton" type="submit" name="cre" value="Create"><br>
                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div id="error" style="color:red"></div>
							 <p style="color:red">Password Missmatch</p>
            </fieldset>
        </form>
   </div>
  </div>	<!--left body code area inside main body ends here -->
     <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
  </div>	<!--main body code area ends here -->
	<div id="lnbar"><!--link bar code area begins here -->
		<ul id="menu">
			<li><a href="Admin.php">Home</a></li>
			<li><a href="create.php">Create Acount</a></li>
			<li><a href="update.php">Update Acount</a></li>
			<li><a href="delete.php">Delete Acount</a></li>
		</ul>		
	</div>
  </div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="admin.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district 2014
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
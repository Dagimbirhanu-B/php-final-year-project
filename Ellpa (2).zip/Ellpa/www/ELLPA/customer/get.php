<?php
		    mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO1');
			$id=addslashes($_REQUEST['id']);
			$image=mysql_query("SELECT * FROM imaget WHERE id=$id");
			$image=mysql_fetch_assoc($image);
			$image=$image['image'];
			header("Content-type:/image/jpeg");
			echo $image;
?>
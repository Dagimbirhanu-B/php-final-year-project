<?php
$bllnoo=$_POST['blnum'];
$complnn=$_POST['compln'];
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$results = mysql_query("SELECT * from bill where billnoo='$bllnoo'");
		while($row=mysql_fetch_array($results))
		{
			$billnom=$row['billnoo'];
			
		}
		    if($bllnoo==$billnom)
			{
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO1');
			$result = mysql_query("insert into complain values('$bllnoo','$complnn')");
			  if($result)
			  {
			   	$url="Location:complainsucc.php";
			    header($url);
			  }
			
			}
	       else
		   {
		     	$url="Location:complainerror.php";
			    header($url);
		   }	

		
		
?>
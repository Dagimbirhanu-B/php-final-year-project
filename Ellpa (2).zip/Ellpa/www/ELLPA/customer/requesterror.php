<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/customer.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Customer
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill the information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
      <form action="sercha.php"  onkeypress="return event.keyCode = 13;" method="POST"> <input style="height: 30px;"class="box10"type="text"size="19" name="billnm" placeholder="Check Bill....">
	 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a></form>
	
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	<div id="mainas"><!--left body code area inside main body begins here -->
	 <p style="text-align:center;font-size:20px;font-weight:bold;"><u>Customer Request</u></p>
	        <form action="request-exec.php" method="POST" onSubmit="return check();" name="newcus">
			    <div align="center">Customer Name:<input type="text" name="name"></div><br/>
				<div align="center">Address:<input type="text" name="address"></div><br/>
				<div align="center">Service Type:<input type="text" name="service_type"></div><br>
				<div align="center">Request Date:<input type="text" name="request_date"></div><br>
			     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#FF0000">Please Fill Correct Information</font>
				<div align="center"><input class="groovybutton" type="submit" value="Send">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="groovybutton" type="reset" value="Clear"></div>
				</form>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,65,0"id="aa" width="610" height="400">
<param name="movie" value="aa.swf">
<param name="bgcolor" value="#FFFFFF">
<embed name="FSB" src="aa.swf"
quality="high" bgcolor="#FFFFFF" swLiveConnect="true"
width="610"
height="400"
type="application/x-shockwave-flash"
pluginspage="http://www.macromedia.com/go/getflashplayer"></embed>
</object><br><br>
		<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">Purpose of the Organization</p>
		<p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">The organization Propose to engage in the business of producing ,transmitting ,distributing and selling electrical energy in accordance with economic and social development policies and priories of the government and to carry out any other 
		related activates that would enable it achieve its purpose.</p>
		<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">History of the organization</p>
		<p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">Electric Power was introduced to Ethiopian in the late 19th Century,................ the government.
	<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">Vision of the organization</p>
	<p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">To be a center of excellence in providing quality electirc service at every ones door and being competitive 
	export industry.</p>
	<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">Mision of the organization</p>
	<p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">To porvide adequet and qulatity electricity generation, 
	tranismission, distribution and sales services, through continuous improvment of utility mangment practices responsive to the socio- economic 
	development and environmental protection need of the public.</p>
  </div>	<!--left body code area inside main body ends here -->
  <div id="mainab"><!--articles head code inside main body begins here -->
		<p style="font-size:20px;font-family:Times New Roman;">Articles</p>
	</div><!--articles head code ends here -->
    <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
  </div>	<!--main body code area ends here -->
  <div id="advertab">
	   
		    	
		  <img src="get.php?id=1" alt="Advertisments">
		
  </div>
  <div id="newss">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=News.php?val=$newid>Read More</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>	
	<div id="advertb">
			    	
		  <img src="get.php?id=2" alt="Advertisments">
		 
	</div>
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Customer.php">Home</a></li>
			<li><a href="Event.php">New Event</a></li>
			<li><a href="complain.php">complain</a></li>
			<li><a href="request.php">Send Request</a></li>
		
	</ul>		
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Customer.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district 2014
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/customer.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Search Result
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill the information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
      <form action="sercha.php"  onkeypress="return event.keyCode = 13;" method="POST"> <input style="height: 30px;"class="box10"type="text"size="19" name="billnm" placeholder="Check Bill....">
	 logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a></form>
	
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
  <div id="mainas"><!--left body code area inside main body begins here -->
		<fieldset>
		<?php
		$fname="";
		$mname="";
		$bllnoo=$_GET['val1'];
		mysql_connect('localhost','root','');
		mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from bill where billnoo='$bllnoo'");
		while($row=mysql_fetch_array($results))
		{
			$fname=$row['fnamee'];
			$mname=$row['mnamee'];
			$lname=$row['lnamee'];
			$contrctno=$row['cntrctnoo'];
			$tarffct=$row['tarffcatgry'];
			$billno=$row['billnoo'];
			$metrno=$row['metnum'];
			$bkiinfo=$row['bookinum'];
		}
		?>
		<table border="0">
		<tr>
		<td><b>First Name:</b>&nbsp;&nbsp;<?php echo $fname?></td>
		<td></td>
		<td><b>Middle Name:</b>&nbsp;&nbsp;<?php echo $mname?></td>
		</tr>
		<tr>
		<td><b>Last Name:</b>&nbsp;&nbsp;<?php echo $lname?></td>
		<td></td>
		<td><b>Contract No:</b>&nbsp;&nbsp;<?php echo $contrctno?></td>
		</tr>	
		<tr>
		<td><b>Tariff Cat:</b>&nbsp;&nbsp;<?php echo $tarffct?></td>
		<td></td>
		<td><b>Bill No:</b>&nbsp;&nbsp;<?php echo $billno?></td>
		</tr>
		<tr>
		<td><b>Meter No:</b>&nbsp;&nbsp;<?php echo $metrno?></td>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td><b>Book IT No:</b>&nbsp;&nbsp;<?php echo $bkiinfo?></td>
		</tr>	
		</table>		
		<?php
		
		
?>
		</fieldset>
  </div>	<!--left body code area inside main body ends here -->
    <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
  </div>	<!--main body code area ends here -->
  <div id="advertab">
	   
		    	
		  <img src="get.php?id=1" alt="Advertisments">
		
  </div>
  <div id="newss">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=News.php?val=$newid>Read More</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>	
	<div id="advertb">
			    	
		  <img src="get.php?id=2" alt="Advertisments">
		 
	</div>
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Customer.php">Home</a></li>
			<li><a href="Event.php">New Event</a></li>
			<li><a href="complain.php">complain</a></li>
			<li><a href="request.php">Send Request</a></li>
		
	</ul>	
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Customer.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
All Right Reserved@EEPCO kombolchas district 2014
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
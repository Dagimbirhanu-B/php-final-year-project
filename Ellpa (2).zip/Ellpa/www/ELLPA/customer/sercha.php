<?php
$cubiln=$_POST['billnm'];
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$results = mysql_query("SELECT * from bill where billnoo='$cubiln'");
while($rows=mysql_fetch_array($results))
{
	$bbillno=$rows['billnoo'];
}
    if($bbillno==$cubiln)
	{
		    $url="Location:serch.php?val1=$cubiln";
			header($url);
	}
    else
	{
	        $url="Location:serchnotfound.php";
			header($url);
	}

?>
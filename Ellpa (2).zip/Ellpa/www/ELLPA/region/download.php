<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/regcss1.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Download File
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill the information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
	}
	function check1()
	{
		var titlee=document.form.title.value;
	    var uname=document.form.detail.value;
		var pass=document.form.filee.value;
		var str="Fill the information";
		if(uname==""||pass==""||titlee=="")
		{
		  document.getElementById("error1").innerHTML=str;
		   return false;
		}
		return true;
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	 <div id="maina"><!--left body code area inside main body begins here -->
	  	<fieldset id="fieldsetle">
		<legend>Download File</legend>
			   	 <?php
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO1');
			$query=mysql_query("select * from dfile order by date DESC LIMIT 1");
			$row=mysql_fetch_array($query);
			$code=$row['code'];
			if($code)
			{
				$query = mysql_query("SELECT * from dfile where code='$code'");
				$numrows=mysql_num_rows($query);
				if($numrows==1)
				{
				$row=mysql_fetch_assoc($query);
				$title=$row['title'];
				$file=$row['file'];
				$discription=$row['decription'];
				$date=$row['date'];
				echo "<br><br>
				<table>
				<tr><th>$title</th></tr>
				<tr><td>$discription</td></tr>
				<tr><td><center><a href='../district/upload/$code/$file'>download file</a></center></td></tr>
				</table>";
				}
			}
			else
			{
			  $url="Location:nodownload.php";
			  header($url);
			}
		?>
		</fieldset>
     </div>	<!--left body code area inside main body ends here -->
    <div id="mainb"><!--right body code area inside main body begins here -->
   
	</div>	<!--right body code area inside main body ends here -->
    <div id="adverta">
	   
		    	
		  <img src="get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=news.php?val=$newid>Read More</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="get.php?id=2" alt="Advertisments">
		 
	</div>  
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Regservice.php">Home</a></li>
			<li><a href="#">Services Information</a>
				<ul>
			<li><a href="newconinfo.php">New connection Information</a></li>
			<li><a href="powerimpinfo.php">Power improvement</a></li>
			<li><a href="re-conninfo.php">Re-connection information</a></li>
			<li><a href="nametransinfo.php">Name transfer information</a></li>
			<li><a href="de-enrol.php">De-enrolment information</a></li>
			<li><a href="tariffchangeinfo.php">Tariff change information</a></li>
			<li><a href="metterchnginfo.php">Metter change information</a></li>
			<li><a href="Re-process.php">Re-processing information</a></li>
				</ul>
			</li>
			<li><a href="#">File</a>
				<ul>
			<li><a href="uploadfile.php">Upload File</a></li>
			<li><a href="download.php">Download File</a></li>
			<li><a href="Removefile.php">Remove Files</a></li>
				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="dmessage.php">Inbox
			(<?php
			   mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from count");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="message.php">Compose Message</a></li>
				</ul>
			</li>	
		</ul>			
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Regservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
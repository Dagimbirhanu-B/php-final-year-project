<?php
    $titlee=$_POST['title'];
	$detaill=$_POST['detail'];
	$name=$_FILES['filee']['name'];
	$type=$_FILES['filee']['type'];
	$size=$_FILES['filee']['size'];
	$tempnam=$_FILES['filee']['tmp_name'];
	$date=date('Y-m-d H:i:s');
	$code="";
	if($name)
	{
	  mysql_connect('localhost','root','');
	  mysql_select_db('EEPCOO1');
	  $charset="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	  $length=15;
	  for($i=0;$i<=$length;$i++)
	  {
	        $rand=rand()%strlen($charset);
			$tmp=substr($charset,$rand,1);
			$code.=$tmp;
	  }
		  //$query = mysql_query("SELECT code from file where code='$code'");
		  //$numnows=mysql_num_rows($query);
	  
	  //while($numnows != 0)
	  //{
		  // for($i=0;$i<=$length;$i++)
		  //{
			//$rand=rand()%strlen($charset);
			$tmp=substr($charset,$rand,1);
			//$code.=$tmp;
		 // }
		  //$query = mysql_query("SELECT code from file where code='$code'");
		  //$numnows=mysql_num_rows($query);
	  //}
	  mkdir("upload/$code");
	  move_uploaded_file($tempnam,"upload/$code/"."$name");
	  $query=mysql_query("insert into file values('$titlee','$code','$detaill','$name','$date')");
	  if($query)
	  {
	  $url="Location:uploadfilesucc.php";
	  header($url);
	  }
	  else
	  {
	  $url="Location:uploadfileerror.php";
	  header($url);
	  }
	}
	else
	{
	  $url="Location:uploadfileerror.php";
	  header($url);
	}
?>
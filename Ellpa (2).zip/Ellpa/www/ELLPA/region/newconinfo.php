<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<?php
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
// SQL query to interact with info from our database
$sql = mysql_query("SELECT * FROM newconn"); 
// Establish the output variable
$dyn_table = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table .= '<tr><td><b>' . "No" .'</b></td>';
$dyn_table .= '<td><b>' ."Book".'</b></td>';
$dyn_table .= '<td><b>' ."Acount".'</b></td>';
$dyn_table .= '<td><b>' . "Contract No".'</b></td>';
$dyn_table .= '<td><b>' . "App.No".'</b></td>';
$dyn_table .= '<td><b>' . "First name/company name".'</b></td>';
$dyn_table .= '<td><b>' . "Father name".'</b></td>';
$dyn_table .= '<td><b>' . "Grand father name".'</b></td>';
$dyn_table .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$nnoo=$row["No"];
$book=$row["book"];
$acc=$row["acount"];
$contrno=$row["contrano"];
$appn=$row["appno"];
$fnamm=$row["fname"];
$fathhnm=$row["fathname"];
$gfnamee=$row["gfname"]; 
	$dyn_table .= '<tr><td>' . $nnoo . '</td>';
	$dyn_table .= '<td>' . $book . '</td>';
	$dyn_table .= '<td>' . $acc . '</td>';
	$dyn_table .= '<td>' . $contrno . '</td>';
	$dyn_table .= '<td>' . $appn . '</td>';
	$dyn_table .= '<td>' . $fnamm . '</td>';
	$dyn_table .= '<td>' . $fathhnm . '</td>';
	$dyn_table .= '<td>' . $gfnamee . '</td>';
}
$dyn_table .= '</tr></table>';
//table twoo
$sql = mysql_query("SELECT * FROM newconn"); 
// Establish the output variable
$dyn_table2 = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table2 .= '<tr><td><b>' . "No" .'</b></td>';
$dyn_table2 .= '<td><b>' ."Region".'</b></td>';
$dyn_table2 .= '<td><b>' ."City".'</b></td>';
$dyn_table2 .= '<td><b>' . "k/ketema".'</b></td>';
$dyn_table2 .= '<td><b>' . "kebele".'</b></td>';
$dyn_table2 .= '<td><b>' . "House No".'</b></td>';
$dyn_table2 .= '<td><b>' . "Floor No".'</b></td>';
$dyn_table2 .= '<td><b>' . "Land Mark ".'</b></td>';
$dyn_table2 .= '<td><b>' . "Applicant sign ".'</b></td>';
$dyn_table2 .= '<td><b>' . "Supply Details".'</b></td>';
$dyn_table2 .= '<td><b>' . "Permanent/Temporary ".'</b></td>';
$dyn_table2 .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$nnoo=$row["No"];
$regiion=$row["region"];
$citty=$row["city"];
$kktnma=$row["kketema"];
$kebell=$row["kebele"];
$housnoo=$row["houseno"];
$floorno=$row["floorno"];
$landm=$row["landm"];
$appsignn=$row["appsign"];
$supldata=$row["supdeta"];
$perotemp=$row["perortemp"];
    
	$dyn_table2 .= '<tr><td>' . $nnoo . '</td>';
	$dyn_table2 .= '<td>' . $regiion . '</td>';
	$dyn_table2 .= '<td>' . $citty . '</td>';
	$dyn_table2 .= '<td>' . $kktnma . '</td>';
	$dyn_table2 .= '<td>' . $kebell . '</td>';
	$dyn_table2 .= '<td>' . $housnoo . '</td>';
	$dyn_table2 .= '<td>' . $floorno . '</td>';
	$dyn_table2 .= '<td>' . $landm . '</td>';
	$dyn_table2 .= '<td>' . $appsignn . '</td>';
	$dyn_table2 .= '<td>' . $supldata . '</td>';
	$dyn_table2 .= '<td>' . $perotemp . '</td>';
	
}
$dyn_table2 .= '</tr></table>';
//table three
$sql = mysql_query("SELECT * FROM newconn"); 
// Establish the output variable
$dyn_table3 = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table3 .= '<tr><td><b>' . "NO" .'</b></td>';
$dyn_table3 .= '<td><b>' ."Property NO".'</b></td>';
$dyn_table3 .= '<td><b>' ."Serial NO".'</b></td>';
$dyn_table3 .= '<td><b>' . "Manufacture".'</b></td>';
$dyn_table3 .= '<td><b>' . "Material".'</b></td>';
$dyn_table3 .= '<td><b>' . "Model".'</b></td>';
$dyn_table3 .= '<td><b>' . "Voltage".'</b></td>';
$dyn_table3 .= '<td><b>' . "Ampere ".'</b></td>';
$dyn_table3 .= '<td><b>' . "Phase".'</b></td>';
$dyn_table3 .= '<td><b>' . "Dails".'</b></td>';
$dyn_table3 .= '<td><b>' . "Constant".'</b></td>';
$dyn_table3 .= '<td><b>' . "Intial reading".'</b></td>';
$dyn_table3 .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$nnoo=$row["No"];
$propno=$row["propertno"];
$serlno=$row["serialno"];
$manufact=$row["manufact"];
$materrl=$row["material"];
$mddl=$row["model"];
$voltgee=$row["voltage"];
$amphree=$row["ampere"];
$phse=$row["phase"];
$dalils=$row["dails"];
$const=$row["constant"];
$intlread=$row["intialread"];    
	$dyn_table3 .= '<tr><td>' . $nnoo . '</td>';
	$dyn_table3 .= '<td>' . $propno . '</td>';
	$dyn_table3 .= '<td>' . $serlno . '</td>';
	$dyn_table3 .= '<td>' . $manufact . '</td>';
	$dyn_table3 .= '<td>' . $materrl . '</td>';
	$dyn_table3 .= '<td>' . $mddl . '</td>';
	$dyn_table3 .= '<td>' . $voltgee . '</td>';
	$dyn_table3 .= '<td>' . $amphree . '</td>';
	$dyn_table3 .= '<td>' . $phse . '</td>';
	$dyn_table3 .= '<td>' . $dalils . '</td>';
	$dyn_table3 .= '<td>' . $const . '</td>';
	$dyn_table3 .= '<td>' . $intlread . '</td>';
	
}
$dyn_table3 .= '</tr></table>';
//table four
$sql = mysql_query("SELECT * FROM newconn"); 
// Establish the output variable
$dyn_table4 = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table4 .= '<tr><td><b>' . "No" .'</b></td>';
$dyn_table4 .= '<td><b>' ."Deposit".'</b></td>';
$dyn_table4 .= '<td><b>' ."Connection Fee".'</b></td>';
$dyn_table4 .= '<td><b>' . "Only connection(TA)".'</b></td>';
$dyn_table4 .= '<td><b>' . "First Payment".'</b></td>';
$dyn_table4 .= '<td><b>' . "Remaining amount".'</b></td>';
$dyn_table4 .= '<td><b>' . "No.of month".'</b></td>';
$dyn_table4 .= '<td><b>' . "Monthly pmt. ".'</b></td>';
$dyn_table4 .= '<td><b>' . "Receipt No.".'</b></td>';
$dyn_table4 .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$nnoo=$row["No"];
$depostt=$row["depost"];
$confee=$row["connfee"];
$onlycnn=$row["onlyconn"];
$frstpay=$row["firstpay"];
$rmnamount=$row["remainamount"];
$noofmonth=$row["noofmonth"];
$monthlypay=$row["monthpay"];
$reccpno=$row["recpno"];  
	$dyn_table4 .= '<tr><td>' . $nnoo . '</td>';
	$dyn_table4 .= '<td>' . $depostt . '</td>';
	$dyn_table4 .= '<td>' . $confee . '</td>';
	$dyn_table4 .= '<td>' . $onlycnn . '</td>';
	$dyn_table4 .= '<td>' . $frstpay . '</td>';
	$dyn_table4 .= '<td>' . $rmnamount . '</td>';
	$dyn_table4 .= '<td>' . $noofmonth . '</td>';
	$dyn_table4 .= '<td>' . $monthlypay . '</td>';
	$dyn_table4 .= '<td>' . $reccpno . '</td>';
	
}
$dyn_table4 .= '</tr></table>';
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/regcss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
New connection information
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill the information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
		
	}
	
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
       <input style="height: 30px;"class="box10"type="text"size="19" placeholder="Search...."> logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	 <div id="maina"><!--left body code area inside main body begins here -->
	      <p style="text-align:center;font-size:20px;font-weight:bold;"><u>New connection information</u></p>
	      <?php echo $dyn_table; ?>
		  <br>
		  <?php echo $dyn_table2; ?>
		  <p style="text-align:center;font-size:20px;font-weight:bold;"><u>METER FEATURE</u></p>
		  <?php echo $dyn_table3; ?>
		  <p style="text-align:center;font-size:20px;font-weight:bold;"><u>PAYMENTS</u></p>
		  <?php echo $dyn_table4; ?>
	  </div>	<!--left body code area inside main body ends here -->
     
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Regservice.php">Home</a></li>
			<li><a href="#">Services Information</a>
				<ul>
			<li><a href="newconinfo.php">New connection Information</a></li>
			<li><a href="powerimpinfo.php">Power improvement</a></li>
			<li><a href="re-conninfo.php">Re-connection information</a></li>
			<li><a href="nametransinfo.php">Name transfer information</a></li>
			<li><a href="de-enrol.php">De-enrolment information</a></li>
			<li><a href="tariffchangeinfo.php">Tariff change information</a></li>
			<li><a href="metterchnginfo.php">Metter change information</a></li>
			<li><a href="Re-process.php">Re-processing information</a></li>
				</ul>
			</li>
			<li><a href="#">File</a>
				<ul>
			<li><a href="uploadfile.php">Upload File</a></li>
			<li><a href="download.php">Download File</a></li>
			<li><a href="Removefile.php">Remove Files</a></li>
				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="dmessage.php">Inbox
			(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from count");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="message.php">Compose Message</a></li>
				</ul>
			</li>	
		</ul>			
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Regservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district 
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
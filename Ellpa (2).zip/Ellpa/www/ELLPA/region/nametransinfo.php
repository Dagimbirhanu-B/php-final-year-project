<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<?php
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
// SQL query to interact with info from our database
$sql = mysql_query("SELECT * FROM nametransfer"); 
// Establish the output variable
$dyn_table = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table .= '<tr><td><b>' . "Old Acc." .'</b></td>';
$dyn_table .= '<td><b>' ."Service No.".'</b></td>';
$dyn_table .= '<td><b>' . "Customer's Name".'</b></td>';
$dyn_table .= '<td><b>' . "Active".'</b></td>';
$dyn_table .= '<td><b>' . "Reactive".'</b></td>';
$dyn_table .= '<td><b>' . "M.D".'</b></td>';
$dyn_table .= '<td><b>' . "Tariff".'</b></td>';
$dyn_table .= '<td><b>' . "Balance fee".'</b></td>';
$dyn_table .= '<td><b>' . "Receipt No".'</b></td>';
$dyn_table .= '<td><b>' . "Remark".'</b></td>';
$dyn_table .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$book=$row["RemovedcuOld Acc"];
$acc=$row["Service No."];
$appn=$row["Customer's Name"];
$fnamm=$row["New Active"];
$fathhnm=$row["Reactive"];
$gfnamee=$row["MD"]; 
$rmtrff=$row["Removed Tariff"]; 
$balnfee=$row["Balance fee"]; 
$recpno=$row["Removed Receipt No."]; 
$rmrk=$row["Removed Remark"]; 

	$dyn_table .= '<tr><td>' . $book . '</td>';
	$dyn_table .= '<td>' . $acc . '</td>';
	$dyn_table .= '<td>' . $appn . '</td>';
	$dyn_table .= '<td>' . $fnamm . '</td>';
	$dyn_table .= '<td>' . $fathhnm . '</td>';
	$dyn_table .= '<td>' . $gfnamee . '</td>';
	$dyn_table .= '<td>' . $rmtrff . '</td>';
	$dyn_table .= '<td>' . $balnfee . '</td>';
	$dyn_table .= '<td>' . $recpno . '</td>';
	$dyn_table .= '<td>' . $rmrk . '</td>';
}
$dyn_table .= '</tr></table>';
//table twoo
$sql = mysql_query("SELECT * FROM nametransfer"); 
// Establish the output variable
$dyn_table2 = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table2 .= '<tr><td><b>' . "App.No." .'</b></td>';
$dyn_table2 .= '<td><b>' ."Old Acc.".'</b></td>';
$dyn_table2 .= '<td><b>' . "Customer's full name".'</b></td>';
$dyn_table2 .= '<td><b>' . "Ep.For Staff".'</b></td>';
$dyn_table2 .= '<td><b>' . "Tariff".'</b></td>';
$dyn_table2 .= '<td><b>' . "Deposit".'</b></td>';
$dyn_table2 .= '<td><b>' . "Receipt No.".'</b></td>';
$dyn_table2 .= '<td><b>' . "Remark".'</b></td>';
$dyn_table2 .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$regiion=$row["App No."];
$citty=$row["New Old Acc."];
$kktnma=$row["New customer full name"];
$kebell=$row["Ep.For staff"];
$housnoo=$row["New Tariff"];
$floorno=$row["Deposit"];
$landm=$row["New Receipt No."];
$appsignn=$row["New Remark"];  
	$dyn_table2 .= '<tr><td>' . $regiion . '</td>';
	$dyn_table2 .= '<td>' . $citty . '</td>';
	$dyn_table2 .= '<td>' . $kktnma . '</td>';
	$dyn_table2 .= '<td>' . $kebell . '</td>';
	$dyn_table2 .= '<td>' . $housnoo . '</td>';
	$dyn_table2 .= '<td>' . $floorno . '</td>';
	$dyn_table2 .= '<td>' . $landm . '</td>';
	$dyn_table2 .= '<td>' . $appsignn . '</td>';
	
}
$dyn_table2 .= '</tr></table>';

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/regcss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Name transfer information
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill the information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
		
	}
	
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	   logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	 <div id="maina"><!--left body code area inside main body begins here -->
	      <p style="text-align:center;font-size:20px;font-weight:bold;">Name transfer information</p>
		  <p style="text-align:center;font-size:18px;font-weight:bold;"><u>REMOVED/DENROLLED/CUSTOMER DATA</u></p>
	      <?php echo $dyn_table; ?> 
		  <p style="text-align:center;font-size:20px;font-weight:bold;">NEW CUSTOMER DATA</p>
	       <?php echo $dyn_table2; ?>
	  </div>	<!--left body code area inside main body ends here -->
     
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Regservice.php">Home</a></li>
			<li><a href="#">Services Information</a>
				<ul>
			<li><a href="newconinfo.php">New connection Information</a></li>
			<li><a href="powerimpinfo.php">Power improvement</a></li>
			<li><a href="re-conninfo.php">Re-connection information</a></li>
			<li><a href="nametransinfo.php">Name transfer information</a></li>
			<li><a href="de-enrol.php">De-enrolment information</a></li>
			<li><a href="tariffchangeinfo.php">Tariff change information</a></li>
			<li><a href="metterchnginfo.php">Metter change information</a></li>
			<li><a href="Re-process.php">Re-processing information</a></li>
				</ul>
			</li>
			<li><a href="#">File</a>
				<ul>
			<li><a href="uploadfile.php">Upload File</a></li>
			<li><a href="download.php">Download File</a></li>
			<li><a href="Removefile.php">Remove Files</a></li>
				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="dmessage.php">Inbox
			(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from count");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="message.php">Compose Message</a></li>
				</ul>
			</li>	
		</ul>		
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Regservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
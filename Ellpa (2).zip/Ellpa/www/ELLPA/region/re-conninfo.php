<?php
session_start();
if(($_SESSION['uname']))
{
   $usname=$_SESSION['uname'];
}
else
{
   header("Location:../index.php");
}
?>
<?php
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
// SQL query to interact with info from our database
$sql = mysql_query("SELECT * FROM reconnction"); 
// Establish the output variable
$dyn_table = '<table border="1" cellpadding="10" id="myTable" align="center">';
$dyn_table .= '<tr><td><b>' . "NO" .'</b></td>';
$dyn_table .= '<td><b>' ."Serial No".'</b></td>';
$dyn_table .= '<td><b>' . "Book No".'</b></td>';
$dyn_table .= '<td><b>' . "Acount".'</b></td>';
$dyn_table .= '<td><b>' . "Contract No".'</b></td>';
$dyn_table .= '<td><b>' . "Customer Full Name".'</b></td>';
$dyn_table .= '<td><b>' . "D/C Reading".'</b></td>';
$dyn_table .= '<td><b>' . "R/C Reading". '</b></td>';
$dyn_table .= '<td><b>' . "Remark". '</b></td>';
$dyn_table .= '</tr>';
while($row = mysql_fetch_array($sql))
{  
$Noo=$row["No"];
$cuname=$row["Serial No"];
$oldacc=$row["Book No"];
$servno=$row["Acount"];
$rempno=$row["Contract No"];
$remlare=$row["Customer Full Name"];
$prono=$row["D/C Reading"];
$serno=$row["R/C Reading"];
$rem=$row["Remark"];    
	$dyn_table .= '<tr><td>' . $Noo . '</td>';
	$dyn_table .= '<td>' . $cuname . '</td>';
	$dyn_table .= '<td>' . $oldacc . '</td>';
	$dyn_table .= '<td>' . $servno . '</td>';
	$dyn_table .= '<td>' . $rempno . '</td>';
	$dyn_table .= '<td>' . $remlare . '</td>';
	$dyn_table .= '<td>' . $prono . '</td>';
	$dyn_table .= '<td>' . $serno . '</td>';
	$dyn_table .= '<td>' . $rem . '</td>';
}
$dyn_table .= '</tr></table>';

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../css/regcss.css">
<link rel="stylesheet" href="../css/style2.css" type="text/css" media="screen">
<title>
Re-connection information
</title>
<script type="text/javascript">
    function check()
	{
	    var uname=document.login.uname.value;
		var pass=document.login.pass.value;
		var str="Fill the information";
		if(uname==""||pass=="")
		{
		  document.getElementById("error").innerHTML=str;
		   return false;
		}
		return true;
		
	}
</script>
</head>
<body>
<div id="logo"><!--logo code area begins here-->

   
</div><!--logo code area ends here-->
<div id="lnbar"><!--logo code area begins here-->

</div><!--logo code area ends here-->
<div id="lnbara"><!--top link bar code area begins here-->
       <input style="height: 30px;"class="box10"type="text"size="19" placeholder="Search...."> logged as <?php print($usname); ?>  || <a href="../logout.php">Logout</a>
</div><!--top link bar code area ends here-->
<div id="main"><!--main body code area begins here -->
  <div id="mainaa" style="background: white"><!--main body code area begins here -->
	 <div id="maina"><!--left body code area inside main body begins here -->
	      <p style="text-align:center;font-size:20px;font-weight:bold;"><u>Re-connection information</u></p>
	      <?php echo $dyn_table; ?>
	  </div>	<!--left body code area inside main body ends here -->
     
  </div>	<!--main body code area ends here -->
  
  <div id="lnbar"><!--link bar code area begins here -->
	<ul id="menu">
			<li><a href="Regservice.php">Home</a></li>
			<li><a href="#">Services Information</a>
				<ul>
			<li><a href="newconinfo.php">New connection Information</a></li>
			<li><a href="powerimpinfo.php">Power improvement</a></li>
			<li><a href="re-conninfo.php">Re-connection information</a></li>
			<li><a href="nametransinfo.php">Name transfer information</a></li>
			<li><a href="de-enrol.php">De-enrolment information</a></li>
			<li><a href="tariffchangeinfo.php">Tariff change information</a></li>
			<li><a href="metterchnginfo.php">Metter change information</a></li>
			<li><a href="Re-process.php">Re-processing information</a></li>
				</ul>
			</li>
			<li><a href="#">File</a>
				<ul>
			<li><a href="uploadfile.php">Upload File</a></li>
			<li><a href="download.php">Download File</a></li>
			<li><a href="Removefile.php">Remove Files</a></li>
				</ul>
			</li>
			<li><a href="#">Message</a>
				<ul>
			<li><a href="dmessage.php">Inbox
			(<?php
			    mysql_connect('localhost','root','');
		        mysql_select_db('EEPCOO1');
		  		$result11= mysql_query("SELECT * from count");
				$num_rows = mysql_num_rows($result11);
				echo "$num_rows";
		?>)</a></li>	
			<li><a href="message.php">Compose Message</a></li>
				</ul>
			</li>	
		</ul>			
</div><!--link bar code area ends here -->
</div><!--main body code area ends here -->

<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="Regservice.php">Home</a>
</div> <!--left footer code area ends here -->

<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
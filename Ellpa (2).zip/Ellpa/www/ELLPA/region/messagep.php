<?php
$subject=$_POST['subj'];
$massege=$_POST['mssge'];
$date = date('Y-m-d H:i:s');
    mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO1');
	$query=mysql_query("insert into rmessage values('$subject','$massege','$date','')");
	$query1=mysql_query("insert into rcount values('$subject','$massege','$date','')");
		if(($query)&&($query1))
		{
			$url="Location:messagesucc.php";
			header($url);
		}
		else
	    {
			$url="Location:messageerror.php";
			header($url);
	    }
?>
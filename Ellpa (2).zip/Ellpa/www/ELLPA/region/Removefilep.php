<?php
	  $titlee=$_POST['title'];
	  mysql_connect('localhost','root','');
	  mysql_select_db('EEPCOO1');
	  $query=mysql_query("select * from file where title='$titlee'");
	  $dbtitle="";
		while($row=mysql_fetch_array($query))
		{
			$dbtitle=$row['title'];
		}
		if($titlee==$dbtitle)
		{
            $query=mysql_query("Delete from file where title='$titlee'");
			$url="Location:Removefilesucc.php";
			header($url);
		}
		else
	    {
			$url="Location:Removefileerr.php";
			header($url);
	    }
?>
<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$uname=$_POST['unamee'];
$pass=$_POST['psswrd'];
$member_type=$_POST['member_type'];
$secque=$_POST['secqu'];
if(mysql_query("INSERT INTO cuslogin(uname,pass,member_type,secquest) 
VALUES('$uname', '$pass', '$member_type', '$secque')")){
header("location: add_success.php");
}
else 
header("location: customererror.php");
?>
<?php
$unamee=$_POST['nam'];
$chunamee=$_POST['chnnnamm'];
$newpass=$_POST['newpass'];
$confpass=$_POST['confpass'];
$unaame="";
$securquest="";
$len = strlen($newpass);
if(($len)>=6 && ($len)<=20)
{
if($newpass==$confpass)
{
		mysql_connect('localhost','root','');
		mysql_select_db('EEPCOO1');
    	$result1 = mysql_query("SELECT * from cuslogin where uname='$unamee'");
		while($row1=mysql_fetch_array($result1))
		{
			$unaame=$row1['uname'];
			$securquest=$row1['secquest'];
		}
		if(($unamee==$unaame)&&($chunamee==$securquest))
		{
		$enc = base64_encode($newpass);
			mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO');
			$results = mysql_query("UPDATE cuslogin SET pass='$enc' WHERE uname='$unamee'");
			if($results)
			{
				$url="Location:forgotupdasucc.php";
				header($url);
			}
		}
		
		else
	    {
			$url="Location:forgotusnotfound.php";
			header($url);
	    }
}
else
{
	$url="Location:forgotpassmism.php";
	header($url);
}
}
else
{
	$url="Location:updateerror1.php";
	header($url);
}
?>
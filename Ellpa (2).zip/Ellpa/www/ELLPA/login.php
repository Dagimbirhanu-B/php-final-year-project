<?php
session_start();
$usname=$_POST['uname'];
$pas=$_POST['psswrd'];
$pos=$_POST['position'];
$dbadmnuname="";
$dbadmnpass="";
$dbadmnpos="";
$dbdisuname="";
$dbdispass="";
$dbdispos="";
$dbreguname="";
$dbregpass="";
$dbregpos="";
$dbcusuname="";
$dbcuspass="";
$dbcuspos="";
$dbofuname="";
$dbofpass="";
$dbofpos="";
    mysql_connect('localhost','root','');
	mysql_select_db('EEPCOO1');
	$query=mysql_query("select * from login where uname='$usname'");
		while($row=mysql_fetch_array($query))
		{
			$dbadmnuname=$row['uname'];
			$dbadmnpass=$row['pass'];
			$dbadmnpos=$row['member_type'];
		}
		$dec = $dbadmnpass;
		if($usname==$dbadmnuname&&$pas==$dec&&$dbadmnpos==$pos)
		{
            $_SESSION["uname"] = $dbadmnuname;
			$url="Location:Admin.php";
			header($url);
		}
		else
		{
		    mysql_connect('localhost','root','');
			mysql_select_db('EEPCOO1');
		    $query1=mysql_query("select * from dislogin where member_type='$pos'");
			while($row1=mysql_fetch_array($query1))
			{
			$dbdisuname=$row1['uname'];
			$dbdispass=$row1['pass'];
			$dbdispos=$row1['member_type'];
			}
			$dec1 = $dbdispass;
			if($usname==$dbdisuname&&$pas==$dec1&&$dbdispos==$pos)
			{
			$_SESSION["uname"] = $dbdisuname;
			$_SESSION["pass"] = $dbdispass;
			$_SESSION["position"] = $dbdispos;
			$url="Location:district/Disservice.php";
			header($url);
			}
			else
			{
			    mysql_connect('localhost','root','');
				mysql_select_db('EEPCOO1');
				$query2=mysql_query("select * from reglogin where uname='$usname'");
				while($row2=mysql_fetch_array($query2))
				{
				$dbreguname=$row2['uname'];
				$dbregpass=$row2['pass'];
				$dbregpos=$row2['member_type'];
				}
				$dec2 = $dbregpass;
			    if($usname==$dbreguname&&$pas==$dec2&&$dbregpos==$pos)
				{
					$_SESSION["uname"] = $dbreguname;
					$_SESSION["pass"] = $dbreguname;
					$_SESSION["member_type"] = $dbregpos;
					$url="Location:region/Regservice.php";
					header($url);
				}
				else
				{
					mysql_connect('localhost','root','');
					mysql_select_db('EEPCOO1');
					$query3=mysql_query("select * from cuslogin where uname='$usname'");
					while($row3=mysql_fetch_array($query3))
					{
					$dbcusuname=$row3['uname'];
					$dbcuspass=$row3['pass'];
					$dbcuspos=$row3['member_type'];
					}
					$dec3 = $dbcuspass;
					if($usname==$dbcusuname&&$pas==$dec3&&$dbcuspos==$pos)
					{
						$_SESSION["uname"] = $dbcusuname;
						$_SESSION["pass"] = $dbcuspos;
						$_SESSION["member_type"] = $dbcuspos;
						$url="Location:customer/Customer.php";
						header($url);
					}
					else
				{
					mysql_connect('localhost','root','');
					mysql_select_db('EEPCOO1');
					$query3=mysql_query("select * from disoflogin where uname='$usname'");
					while($row2=mysql_fetch_array($query3))
					{
					$dbofuname=$row2['uname'];
					$dbofpass=$row2['pass'];
					$dbofpos=$row2['member_type'];
					}
					$dec3 = $dbofpass;
					if($usname==$dbofuname&&$pas==$dec3&&$pos==$dbofpos)
					{
						$_SESSION["uname"] = $dbofuname;
						$_SESSION["pass"] = $dbofpass;
						$_SESSION["member_type"] = $dbofpos;
						$url="Location:district/Disserviceof.php";
						header($url);
					}
					else
					{
						include('loginerror.php');
					}
				}
			}
			
		}}
?>
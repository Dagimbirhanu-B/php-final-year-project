<?php
$namee=$_POST['unamee'];
$npassw=$_POST['passwrd'];
$actype=$_POST['actype'];
			$url="Location:deletewarrning.php?nme=$namee&npssw=$npassw&acty=$actype";
			header($url);
?>
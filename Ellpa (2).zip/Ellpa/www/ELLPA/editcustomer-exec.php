<?php
session_start();
 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$member_type=$_POST['member_type'];
$secquest=$_POST['secquest'];
if(mysql_query("UPDATE cuslogin SET uname='$uname', pass='$pass',member_type='$member_type',secquest='$secquest' WHERE uname='$uname'"))
header("location: customeraccountupdate.php");
else
echo "error update news"."".mysql_error();
?> 
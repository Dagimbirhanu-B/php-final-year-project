<?php
$namme=$_POST['nam'];
$commntt=$_POST['commnt'];
$date = date('Y-m-d H:i:s');
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$query=mysql_query("insert into comment values('$namme','$date','$commntt')");
		if($query)
		{
			$url="Location:feedback.php";
			header($url);
		}
		else
	    {
			$url="Location:feedbacke.php";
			header($url);
	    }
?>
﻿<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href= "css/style3.css">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<title>
Home Page 
</title>
<script type="text/javascript">
	function check()
	{
	    var uname=document.logi.uname.value;
		var pass=document.logi.psswrd.value;
		var str="Fill all the neccessary information";
		 if( document.logi.position.value == "-1" )
   {
     alert( "Please select your account type!" );
     document.logi.position.focus() ;
     return false;
   }
    if( document.logi.uname.value == "" )
   {
     alert( "User's name is empty!" );
     document.logi.uname.focus() ;
     return false;
   }
    
   //validate user password
    if( document.logi.psswrd.value == "" )
   {
     alert( "Empty password. Please enter your password" );
     document.logi.psswrd.focus() ;
     return false;
   }
		return true;
	}
</script>
</head>
<body>
<!--logo code begins here -->
<div id="logo"> </div>
<div id="main"><!--main box code area begins here -->
 <div id="mainaa"><!--main body code area begins here -->
     <div id="maina"><!--left body code area inside main body begins here -->
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			codebase="">
			<param name="image" value="images/2.jpg">
			<param name="bgcolor" value="#FFFFFF">
			<embed name="" src="images/2.jpg"
			quality="high" bgcolor="#FFFFFF" swLiveConnect="true"
			width="610"
			height="400"
			type=""
			pluginspage=""></embed>
		</object>
        <br><br>
		<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">Purpose of the Organization</p>
		<p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">The organization Propose to engage in the business of producing ,transmitting ,distributing and selling electrical energy in accordance with economic and social development policies and priories of the government and to carry out any other 
		related activates that would enable it achieve its purpose.</p>
		<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">History of the organization</p>
		<p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">Electric Power was introduced to Ethiopian in the late 19th Century, during the regime of Minilik. The first......                                                                      ......its purpose.

	  </p>
		<p style="font-size:15px;font-family:Times New Roman;color:4169E1;">Vision of the organization</p>
	  <p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">To be a center of excellence in providing quality electirc service at every ones door and being competitive 
	  export industry.</p>
	  <p style="font-size:15px;font-family:Times New Roman;color:4169E1;">Mision of the organization</p>
	  <p style="font-size:normal;font-family:Times New Roman;text-Align:justify;">To porvide adequet and qulatity electricity generation, 
	  tranismission, distribution and sales services, through continuous improvment of utility mangment practices responsive to the socio- economic 
	  development and environmental protection need of the public.</p>
    </div>	<!--left body code area inside main body ends here -->
	   <div id="mainab"><!--articles head code inside main body begins here -->
		<p style="font-size:20px;font-family:Times New Roman;">Articles</p>
	   </div><!--articles head code ends here -->
	  <div id="mainb"><!--right body code area inside main body begins here -->
        <form name="logi"  onSubmit="return check()" method="POST" action="login.php">
            <fieldset id="fieldsetle">
			   <legend>Member Login</legend>
                   <br>
				    <select name="position" id="position">
		<option value="-1">--Select position--</option>
			<option>Administrator</option>
			<option>District manager</option>
			<option>District officer</option>
			<option>Region manager</option>
			<option>Customer</option>
			</select><br/><br/>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input style="height: 32px;"class="box11" type="text" name="uname" size="30" id="uname" placeholder="Enter your user name here"><br><br>
                                &nbsp;&nbsp; &nbsp;  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
			<input type="password" style="height: 30px;"class="box11" name="psswrd" size="30" placeholder="Enter your pasword here" id="psswrd"><br><br>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 &nbsp;&nbsp;
						<br>		
                         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						 <input class="groovybutton" type="submit" name="login" value="Login"> <input class="groovybutton" type="reset" name="clear" value="Clear">
                             <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 <a href="forgot.php">Forgot password?</a></p>
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 <a href="cust.php"></a>
							 <div id="error" style="color:red"></div>
                    
                
            </fieldset>
        </form>
	</div>	<!--right body code area inside main body ends here -->
	<div id="adverta">
	   
		    	
		  <img src="adv/get.php?id=1" alt="Advertisments">
		
	</div>
	<div id="news">
	<b>News:</b>
	 <table border="0">
		<?php
		 $pname="";
		 $nws="";
		 $datee="";
		 $newid="";
include_once('eepcodb.php');
		 mysql_connect('localhost','root','');
		 mysql_select_db('EEPCOO1');
		$results = mysql_query("SELECT * from news order by date DESC LIMIT 5");
		while($row=mysql_fetch_array($results))
		{
			$pname=$row['poster'];
			$nws=$row['news'];
			$newstring = substr($nws,0,200);
			$datee=$row['date'];
			$newid=$row['id'];
			echo "<tr>
			  <td>{$newstring}.....<a href=news.php?val=$newid>Read more</a></td>
			     </tr>";
		}
		
		?>
	</table>
	</div>
	<div id="advertb">
			    	
		  <img src="adv/ge.php?id=2" alt="Advertisments">
		 
	</div>
  </div>	<!--main body code area ends here -->
	<div id="lnbar"><!--link bar code area begins here -->
		<ul id="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="feedback.php">Feedback</a></li>
                       
			<li><a href="contact.php">Contact</a></li>
			<li><a href="#">About Us</a>
				<ul>
					<li><a href="organstructure.php">Organizational structure</a></li>
				</ul>		
			</li>
			<li>
			<a href="#">More Links</a>
		<ul>
			<li><a href="emergecy.php">Emergency Call</a></li>
			<li><a href="photo.php">Photo Gallery</a></li>
		</ul>
			</li>
		</ul>		
	</div>
</div><!--main box code area ends here -->
<div id="footer"><!--main footer code area begins here -->
                                                                           
                                                   
</div><!--main foter code area ends here -->
<div id="footerl"><!--left footer code area begins here -->
	<a href="index.php">Home</a>
</div> <!--left footer code area ends here -->
<div id="footerr"><!--right footer code area begins here -->
	<a href="contact.php">contact us</a></pre><br>
</div> <!--center footer code area ends here -->
<div id="footerb"><!--bottom footer code area begins here -->
	All Right Reserved@EEPCO kombolcha district 
</div> <!--bottom footer code area ens here -->
<div id="under"><!--under code area begins here -->

</div><!--under code area ends here -->
</body>
</html>
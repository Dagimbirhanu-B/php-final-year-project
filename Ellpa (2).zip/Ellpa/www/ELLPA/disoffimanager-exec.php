<?php
session_start();
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$uname=$_POST['unamee'];
$pass=$_POST['psswrd'];
$member_type=$_POST['member_type'];
$fname=$_POST['fnamee'];
$lname=$_POST['lnamee'];
$chname=$_POST['chnamee'];
if(mysql_query("INSERT INTO disoflogin(uname,pass,member_type,fname,lname,chname) 
VALUES('$uname', '$pass', '$member_type', '$fname','$lname','$chname')")){
header("location: add_success.php");
}
else 
echo "error in insertion".mysql_error();
?>
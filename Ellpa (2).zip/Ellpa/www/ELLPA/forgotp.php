<?php
$cubiln=$_POST['cubilno'];
mysql_connect('localhost','root','');
mysql_select_db('EEPCOO1');
$results = mysql_query("SELECT * from bill where billnoo='$cubiln'");
while($rows=mysql_fetch_array($results))
{
	$bbillno=$rows['billnoo'];
}
    if($bbillno==$cubiln)
	{
		    $url="Location:forgotnewpass.php";
			header($url);
	}
    else
	{
	        $url="Location:forgotbnotfound.php";
			header($url);
	}

?>
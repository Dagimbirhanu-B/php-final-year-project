<?php
if (!isset($_SESSION['user']))
die('you need to be logged in to use this feature.<br />please login <a href="login.php">here</a>');
?>
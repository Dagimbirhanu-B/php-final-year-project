<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>php project</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>

<body>

<?php
include("table.php");
?>

</body>
</html>

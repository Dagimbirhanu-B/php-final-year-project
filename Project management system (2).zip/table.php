<?php
echo '<table border="1" cellspacing="0" cellpadding="4" bordercolor="#999999">
	<tr>	<td width="10%"><a href="projects.php">projects</a></td>
		<td width="10%"><a href="users.php">users</a></td>
		<td width="10%"><a href="cat.php">categories</a></td>
		<td width="10%"><a href="status.php">status</a></td>		
		<td width="10%"><a href="logout.php">logout</a></td>
	</tr>
</table>';
?>
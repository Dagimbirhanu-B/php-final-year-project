<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
 <table border='0'>
                <h3>Kombolcha Institute Of Technology</h3>
            	<h3>Arefaine Mebrahtu</h3>
				<tr><td width="250">
					   <img src='elfora pict/ar.jpg' width='100%'height="400px" />
					    <font size="3"color="#333300">
						
<P>FULL NAME :Arefaine Mebrahtu<br>
INSTITUTE : <acronym title="Kombolcha Institute Of Technology">KIOT</acronym><br>
FACULTY   : INFORMATICS<br>
ID NUMBER : ITR/1478/04<br>
DEPARTMENT: INFORMATION TECHNOLOGY<br>
YEAR      : 4<sup>th</sup><br>
PHONE     : +2510914193873<br>
STATUS    : in a RLATIONSHIP <br>
HOBBY     : PROGRAMING<br>
HOME TOWN : Abissiniya</P>
                       </td>
					
				<td width="250">
				<h3>Ashenafi Ali</h3>
					   <img src='elfora pict/asss.jpg' width='100%' height="400px" />
					    <font size="3"color="#333300">
						
<P>FULL NAME :Ashenafi Ali<br>
INSTITUTE : <acronym title="Kombolcha Institute Of Technology">KIOT</acronym><br>
FACULTY   : INFORMATICS<br>
ID NUMBER : ITR/1481/04<br>
DEPARTMENT: INFORMATION TECHNOLOGY<br>
YEAR      : 4<sup>th</sup><br>
PHONE     : +251921695807<br>
STATUS    : singel<br>
HOBBY     : PROGRAMING<br>
HOME TOWN : Diredawa</P>
                      </td>
					
						
				<td width="250">
				<h3>Asamnew Abebe</h3>
					   <img src='elfora pict/wa.jpg' width='100%' height="400px" />
					    <font size="3"color="#333300">
						
<P>FULL NAME :Asamnew Abebe<br>
INSTITUTE : <acronym title="Kombolcha Institute Of Technology">KIOT</acronym><br>
FACULTY   : INFORMATICS<br>
ID NUMBER : ITR/1479/04<br>
DEPARTMENT: INFORMATION TECHNOLOGY<br>
YEAR      : 4<sup>th</sup><br>
PHONE     : +2510914193873<br>
STATUS    : complicated<br>
HOBBY     : PROGRAMING<br>
HOME TOWN : Welayta Sodo</P>
                    </tr>   </td>
                    
			 </table>
</body>
</html>

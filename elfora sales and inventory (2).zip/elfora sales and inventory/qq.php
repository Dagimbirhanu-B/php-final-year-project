#wapper{
width:1024px;
height:800px;
background-color:#AAFFFF;
}
#banner{width:1335px;
background-image:url(elfora%20pict/33.jpg);
height:120px;
background-color:#7F9FFF;
}
#menuTop{width:1335px;
height:35px;
background-color:#00FF00;
}
a {
font-family:Geneva, Arial, Helvetica, sans-serif
font-size: 12px;
color:#0000FF;
background:#00FF00;
}
a:link {
text-decoration: none;
}
a:visited {
text-decoration: none;
}
a:hover {
text-decoration: underline;
color:#D47FFF;
background:#FF3F00;
}
a:active {
text-decoration: none;
}
#columnLeft{
background-image:url(elfora%20pict/12.jpg);
width:220px;
height:600px;
background-color:#7F9F55;
float:left;
}
#columnRight{
background-image:url(elfora%20pict/44.jpg);
width:220px;
height:600px;
background-color:#D49F00;
float:right;
}
#content{
width:900px;
height:600px;
background-color:#D49FAA;
margin-left:215px;
}
#footer{
width:1335px;
height:50px;
background-color:#2A5F00;
}
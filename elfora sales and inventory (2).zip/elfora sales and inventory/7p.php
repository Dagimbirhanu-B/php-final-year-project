<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>KIOT Online property management system</title>
</head>
<body>
<div id="wrapper">
  
  <div id="content">
    <h2><center><span style="color:#003300"> Account Players</span></center></h2>
   <center> <table width="40%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td height="20" bgcolor="#3399FF"><span class="style5"><strong>List of account users</strong></span></td>
      </tr>
      <?php
// Establish Connection with Database
$con = mysql_connect("localhost","root","");
// Select Database
mysql_select_db("OSI", $con);
$id=$_GET['id'];
// Specify the query to execute
$sql = "select * from makeorder where id='$id'";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$name=$row['name'];
$id=$row['id'];
$age=$row['age'];
$gender=$row['gender'];
$address=$row['address'];
$phone_no=$row['phone_no'];
$email=$row['email'];
$order_type=$row['order_type'];
$quantity=$row['quantity'];
$status=$row['status'];
}
?>
    <tr>  
        <td height="15"><br><br>
        <form action="8p.php" method="post"onSubmit="return validate(this);" ><br />
              
               &nbsp;&nbsp; Name<input type="text" name="name" value="<?php echo $name;?>" border="pink"><br><br>
                ID <input type="text" name="id" value="<?php echo $id;?>"><br><br>
                           &nbsp;&nbsp;&nbsp;&nbsp; Age <input type="text" name="age" value="<?php echo $age;?>">  <br> <br>  
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Gender <input type="text" name="gender" value="<?php echo $gender;?>"><br><br>
              &nbsp;&nbsp;Address<input type="text" name="address" value="<?php echo $address;?>"><br><br>
             &nbsp;&nbsp;&nbsp;&nbsp; Phone_no <input type="text" name="phone_no" value="<?php echo $phone_no;?>">  <br> <br>  
             &nbsp;&nbsp;Email<input type="text" name="email" value="<?php echo $email;?>"><br><br>
             &nbsp;&nbsp;Order_type<input type="text" name="order_type" value="<?php echo $order_type;?>"><br><br>
               &nbsp;&nbsp;Quantity<input type="text" name="quantity" value="<?php echo $quantity;?>"><br><br>
                     &nbsp;&nbsp;Status<input type="text" name="status" value="<?php echo $status;?>"><br><br>
 <input type="submit"name="submit"value="update" /> <input type="reset"name="reset"vaelue="Reset" />
        </form></td></tr></table>
</center>
</div>
</div>
</body>
</html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Online property management system</title>

</head>
<body bgcolor="#CCCCCC">
<div id="wrapper">
  
  <div id="content">
    <h2><center><span style="color:#003300">ordered item</span></center></h2>
   <center> <table width="60%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td height="20" bgcolor="#3399FF"><span class="style10"><strong>List of ordered items</strong></span></td>
      </tr>
      <tr>
        <td height="18" bgcolor="3399FF"><span class="style10"><strong>Item List</strong></span></td>
      </tr>
      <tr>
        <td><table width="100%" border="1" bordercolor="#FF6600" >
            <tr>
              <th height="32" bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>Name</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>ID</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Age</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Gender</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Address</div></th>
                 <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">phone number</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Email</div></th>
                 <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Order type</div></th>
                  <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Quantity</div></th>
                   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Status</div></th>
                     <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Termination</div></th>

              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Agreement</div></th>
            </tr>
           
  
		    <?php
// Establish Connection with Database
$con = mysql_connect("localhost","root","");
// Select Database
mysql_select_db("OSI", $con);
// Specify the query to execute
$sql = "select * from makeorder where status='Approved'";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$name=$row['name'];
$id=$row['id'];
$age=$row['age'];
$gender=$row['gender'];
$address=$row['address'];
$ph=$row['phone_no'];
$email=$row['email'];
$ot=$row['order_type'];
$quantity=$row['quantity'];
$status=$row['status'];
$termination=$row['termination'];
?>
            <tr>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $name;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $id;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $age;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $gender;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $address;?></strong></div></td>
                <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $ph;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $email;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $ot;?></strong></div></td>
                <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $quantity;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $status;?></strong></div></td>
                <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $termination;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><a href="sagree.php?id=<?php echo $id;?>">{Agreement}</a></strong></div></td>
            </tr>
            <?php
}
// Retrieve Number of records returned
$records = mysql_num_rows($result);
?>
            <tr>
              <td colspan="4" class="style3"><div align="left" class="style12"><?php echo "Total ".$records." Records"; ?> </div></td>
            </tr>
			
            <?php
// Close the connection

?>

        </table></td>
      </tr>
     
    </table>
    <p>&nbsp;</p>
  </div>
   <div style="clear:both;"></div>
</div>
</body>
</html>

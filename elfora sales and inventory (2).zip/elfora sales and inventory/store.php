<?php
$a=mysql_connect("localhost","root","");
 if(!$a)
 {die('could not connect' . mysql_error());}
else
//echo "connection established";
/* if(mysql_query("create database OPMS",$a))
echo "database created";
else
echo "database not created" . mysql_error();*/
mysql_select_db("OSI",$a);
if(isset($_POST['submit'])){
$date=date('y/m/d');
$s="INSERT INTO storeinfo(itemname,date,quantity) VALUES('$_POST[itemname]','$date','$_POST[quantity]')";
$result=mysql_query($s);
if($result){
 echo '<script type="text/javascript">alert(" successfully inserted!!");window.location=\'store.php\';</script>';
 echo "data is inserted";
    }
    else 
	echo '<script type="text/javascript">alert(" fail data not inserted!!");window.location=\'store.php\';</script>';
   echo "fail  data not inserted".mysql_error();
}
mysql_close($a)
?>
<title>make order</title>
</head>

<body bgcolor="#CCCCCC">
<center>Store Items<br>
<form action="store.php" method="POST" name="store">
<tr><td> item name: </td><td><select name="itemname"><option>menchet abesh</option><option>tomato paste</option><option>meat</option>option>bone</option><option>tallow</option>
<option>horn</option></select></td></tr><br><br>
<label>quantity</label><input type="text"name="quantity" /><br><br>
<input type="submit" name="submit" value="store"  /> <input type="reset" name="reset" value="Reset"  />
</form></center>
</body>
</html>

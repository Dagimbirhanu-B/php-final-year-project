<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title></title>
<script type="text/javascript">
function validate(form)
{
var usertype=form.usertype.value;
var username=form.username.value;
var userid=form.userid.value;
var email=form.email.value;
var password=form.password.value;
var gender=form.gender.value;
var check = /^[a-zA-Z\ \']+$/;
 var isNumeric = /^[0-9]+$/;
 var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

if(usertype=="")
{
alert("please enter usertype?");
account1.usertype.value="";
account1.usertype.focus();
return false;
}
if(!check.test(username))
{
alert("please enter letter only for username?");
account1.username.value="";
account1.username.focus();
return false;
}
if(userid=="")
{
alert("please enter userid?");
account1.userid.value="";
account1.userid.focus();
return false;
}
var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
if(!emailExp.test(email))
{
alert("please enter valid email ID?");
account1.email.value="";
account1.email.focus();
return false;
}
if(password=="")
{
alert("please enter yourpassword?");
account1.password.value="";
account1.password.focus();
return false;
}
if(gender=="")
{
alert("please select your gender?");
account1.gender.value="";
account1.gender.focus();
return false;
}
 return true;
}
</script>
</head>
<body bgcolor="#CCCCCC">
  
 
     <div style="width:790px; height:500px; margin:0 auto; position:relative; border:2px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:25px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">
	 <tr><td>
 <strong><font color="white" size="2px">List of account users</font></strong>
 <div style="background-color:#666666;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;">
      </td></tr>   
        
            
 <div style="float:right; margin-right:20px; background-color:#cccccc; width:25px;  text-align:center; border-radius:10px; height:12px;"></a></div>
   <center> <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
      
       
     
      <tr>
        <td height="26"><form id="account" name="account" method="POST" action="account.php" onSubmit="return validate(this) ;">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
			 </tr>
              <tr>
                <td height="30" >usertype</td>
                <td><span id="sprytextfield2">
                  <label>
                 <select name="usertype"id="usertype"><option>G.Manager</option><option>Customer</option><option>Admin</option><option>Sales and Inventory</option></select>
                  </label>
                  <span class="textfieldRequiredMsg">please select.</span></span></td>
              </tr>
			   </tr>
              <tr>
                <td height="32" >username</td>
                <td><span id="sprytextfield3">
                  <label>
                  <input type="text" name="username" id="username" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
			   </tr>
              <tr>
                <td height="20" >userid</td>
                <td><span id="sprytextfield2">
                  <label>
                  <input type="text" name="userid" id="userid" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
			   </tr>
              <tr>
                <td height="32" >email</td>
                <td><span id="sprytextfield2">
                  <label>
                  <input type="text" name="email" id="email" />
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
              <tr>
              <tr>
              <tr>
              <tr>
			 <tr>
                <td height="34">password</td>
                <td><span id="sprytextfield1">
                  <label>
                  <input type="password"name="password" />
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
			  <tr>
                <td height="34">gender</td>
                <td><span id="sprytextfield1">
                  <label>
                  <select name="gender" id="gender">
				  <option>M</option>
                <option>F</option>
            </select>
                  </label>
                  <span class="textfieldRequiredMsg">A value is required.</span></span></td>
              </tr>
 <td height="35" align="center"> <input type="submit"name="submit"value="Create Account"/></td><td height="40" align="justify"> <input type="reset"name="reset"vaelue="Reset" /></td>
</table>

        </form></td>
      </tr>
      <tr>
        <td height="25" bgcolor="3399FF"><span class="style10"><strong>User List</strong></span></td>
      </tr>
      <tr>
        <td><table width="100%" border="1" bordercolor="#D49F00" >
            <tr>
              <th height="32" bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>usertype</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>username</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">userid</div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">email</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">password</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">gender</div></th>
			   <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style9 style5"><strong>Edit</strong></div></th>
              <th bgcolor="#BDE0A8" class="style3"><div align="left" class="style12">Delete</div></th>
            </tr>
           
  
		    <?php
// Establish Connection with Database
$con = mysql_connect("localhost","root","");
// Select Database
mysql_select_db("OSI",$con);
// Specify the query to execute
$sql = "select * from account";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$usertype=$row['usertype'];
$username=$row['username'];
$userid=$row['userid'];
$email=$row['email'];
$password=$row['password'];
$gender=$row['gender'];

?>
            <tr>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $usertype;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $username;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $userid;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $email;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $password;?></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $gender;?></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><a href="ed.php?$userid=<?php echo '$_POST[userid]';?>">Edit</a></strong></div></td>
              <td class="style3"><div align="left" class="style9 style5"><strong><a href="de.php?userid=<?php echo $userid;?>">Delete</a></strong></div></td>
            </tr>
            <?php
}
// Retrieve Number of records returned
$records = mysql_num_rows($result);
?>
            <tr>
              <td colspan="4" class="style3"><div align="left" class="style12"><?php echo "Total ".$records." Records"; ?> </div></td>
            </tr>
            <?php
// Close the connection

?>

        </table></td>
      </tr>
     
    </table>
	</div>
    <p>&nbsp;</p>
</body>
</html>

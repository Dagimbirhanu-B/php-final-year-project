<HTML>
<body bgcolor="#CCCCCC">
<br>
<h2><center>Generate Admin Report:</center></h2>
<br>
<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("OSI",$a);
$result = mysql_query("SELECT * FROM account",$a);
echo '<center><table bgcolor="#cccccc">';
echo'<TR><TD bgcolor="pink"  width="60"><B>usertype</B><TD bgcolor="pink"  width="60"><B>username</B><TD bgcolor="pink"  width="120"><B>userid</B><TD  bgcolor="pink" width="60"><B>email</B><TD bgcolor="pink"  width="60"><B>password</B><TD bgcolor="pink"  width="60"><B>gender</B></TR>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60">';
echo $row["usertype"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["username"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["userid"];
echo '</td>';
echo '<td bgcolor="white" width="60">';
echo $row["email"];
echo '</td>';
echo '<td bgcolor="white" width="120">';
echo $row["password"];
echo '</td>';
echo '<td bgcolor="white" width="70">';
echo $row["gender"];
echo '</td>';
echo'</tr>';
}
echo '</TABLE>';
?>
</body>
</HTML>
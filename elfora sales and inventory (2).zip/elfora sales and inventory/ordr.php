
<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("OSI",$con);
if (isset($_POST['make_order'])) {
$date=date('y/m/d');
$sql="INSERT INTO makeorder VALUES('$_POST[name]','$_POST[id]','$_POST[age]','$_POST[gender]','$_POST[address]','$_POST[phone_no]','$_POST[email]','$_POST[order_type]','$_POST[quantity]','unapprove','$_POST[termination]','$date')";
$result=mysql_query($sql);
if($result){
 echo 
 '<script type="text/javascript">alert(" successfully make ordered!");window.location=\'ordr.php\';</script>';
    }
    else 
  echo mysql_error(); 
 echo '<script type="text/javascript">alert(" fail  data not inserted!");window.location=\'ordr.php\';</script>'.mysql_error();
}
?>

<HTML>
<HEAD>
</form> 
<script type="text/javascript"> 
function validate() 
{
 if( document.form1.name.value =="" ) 
{ 
alert( "Please provide your name!" );return false;
 } 
if( document.form1.id.value =="" ) 
{ 
alert( "Please insert id!" );return false;
 } 
if( document.form1.age.value == "" ) 
{ alert( "Please insert age!" );return false;
 } 
 if( document.form1.gender.value == "" ) 
{ alert( "Please insert gender!" );return false;
 } 
if( document.form1.address.value == "" ) 
{ alert( "Please insert your address!" ); return false;
} 
if( document.form1.phone_no.value == "" ) 
{ alert( "Please insert phone_no!" );  return false;}
if( document.form1.email.value == "" ) 
{ alert( "Please insert email!" );  return false;}
if( document.form1.order_type.value == "" ) 
{ alert( "Please insert year of graduate!" );  return false;}
if( document.form1.quantity.value == "" ) 
{ alert( "Please insert quantity!" );  return false;}
if( document.form1.termination.value == "" ) 
{ alert( "Please provide termination!" );  
return false; }
}
 </script> 
<TITLE></TITLE>
</HEAD>
<BODY>
<table width=100% bgcolor="#CCCCCC" align="center">
    <td height="382">
        <table width border='0'>
        <form method="post" action="ordr.php" name="form1" onsubmit="return validate()";>
         <tr><td>  name:</td><td><input type="text" name="name"/></td></tr>
            <tr><td>  id:</td><td><input type="text" COLSPAN=10 name="id"/></td></tr>
            
	    <tr><td> Gender:</td><td><select name="gender"><option>    </option><option>M</option><option>F</option></select></td></tr>
     
	    <tr><td> Age:</td> <td><input type="text"     name="age"/></td><tr>
            <tr><td> ADRESS:</td>    <td><input type="text"     name="address"/></td></tr>
            <tr><td> phone_no:</td>            <td><input type="text"    name="phone_no"/></td></tr>
               
            <tr><td> email:</td> <td><input type="text"       name="email"/></td></tr>
             <tr><td> order type: </td><td><select name="order type"><option>menchet abesh</option><option>tomato paste</option><option>meat</option>option>bone</option><option>tallow</option>
<option>horn</option></select></td></tr>
            <tr><td> quantity :</td>    <td><input type="text"     name="quantity"/></td></tr>
             <tr><td> termination:</td>  <td><input type="text"     name="termination"/></td></tr>
            
            <tr><td> make order</td><td><input type="submit" name="make_order" value="make_order"/><td></tr>
           
        </table>    
</table>
</form>
</BODY>
</HTML>
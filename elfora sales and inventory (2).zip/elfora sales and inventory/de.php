<html>
<body>
<?php
//if(isset($_POST['userid'])){
//$userid=$_POST['userid'];
$a=mysql_connect("localhost","root","");
if(!$a){die('not connet'.mysql_error());}
mysql_select_db("OSI",$a);
if(isset($_GET['userid'])){
$userid=$_GET['userid'];
$query="DELETE FROM account WHERE userid='$userid'";
mysql_query($query,$a);
if(!$query)
{
echo ('not deleted'.mysql_error());
//header 'window:location\update1.php';
}
else
echo '<script type="text/javascript">alert("delete Successfully");window.location=\'up.php\';</script>';
//include("search.php");
}
?>
<?php
$a=mysql_connect("localhost","root","");
 if(!$a)
 {die('could not connect' . mysql_error());}
else
//echo "connection established";
/* if(mysql_query("create database OPMS",$a))
echo "database created";
else
echo "database not created" . mysql_error();*/
mysql_select_db("OSI",$a);
if(isset($_POST['submit'])){
$date=date('y/m/d');
$s="INSERT INTO addprice(itemname,date,quantity,price) VALUES('$_POST[itemname]','$date','$_POST[quantity]','$_POST[price]')";
$result=mysql_query($s);
if($result){
 echo '<script type="text/javascript">alert(" successfully cost submited!!");window.location=\'cost.php\';</script>';
 echo "data is inserted";
    }
    else 
	echo '<script type="text/javascript">alert(" Date not inserted!!");window.location=\'cost.php\';</script>';
   echo "fail  data not inserted".mysql_error();
}
mysql_close($a)
?>
<html>
</head>

<body bgcolor="#CCCCCC">
<center><h3>Fill Cost<br>
<form action="cost.php" method="POST" name="cost" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>item name</label><input type="text" name="itemname"/><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<label>quantity</label><input type="text"name="quantity" /><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<label>price</label><input type="text"name="price" /><br><br><br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="give cost" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input type="reset" name="reset" value="Reset"  />
</form></center>
</body>
</html>
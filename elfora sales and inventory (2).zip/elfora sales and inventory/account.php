<?php
$a = mysql_connect("localhost","root","");
if(!$a){
die('not connected'.mysql_error());}
else
//echo"connected";
 mysql_select_db("OSI",$a);
 if(isset($_POST['submit'])){
$c="INSERT INTO account(usertype,username,userid,email,password,gender) VALUES('$_POST[usertype]','$_POST[username]','$_POST[userid]','$_POST[email]','$_POST[password]','$_POST[gender]')";
$result=mysql_query($c);
if($result){
 echo '<script type="text/javascript">alert(" successfully account created!!");window.location=\'up.php\';</script>';
 echo "data is inserted";
    }
    else 
	
   echo "fail  data not inserted".mysql_error();
mysql_close($a);
}
?>
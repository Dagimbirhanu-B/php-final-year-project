
<html>
<head>
<title>
</title>
</head>
<body>
<?php
$con=mysql_connect("localhost","root","") or die('not connected');
mysql_select_db("OSI",$con) or die("can not select the database");
$id=$_GET['id'];
$query="UPDATE makeorder SET termination='yes' WHERE id='".$id."' ";
$a=mysql_query($query,$con);
if(!$a)
{
die('data can not be Update' . mysql_error());
}
else
{
echo '<script type="text/javascript">alert(" successfully Agree!!");window.location=\'siA.php\';</script>';
}
?>
</body>
</html>
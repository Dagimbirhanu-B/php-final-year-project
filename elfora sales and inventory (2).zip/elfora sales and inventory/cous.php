<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
 <table border='0'>
				<tr><td width="250" valign="top">
					   <img src='elfora pict/22.jpg' width='80%'height="150px" align="top"/>
					    <font size="4"color="#333300">
ELFORA Agro-Industries PLC is organized under the Office of the Chief Executive Officer of MIDROC Ethiopia and is led by a General Manager, directly reporting to the CEO. The company has four Operations & Service Units: Corporate Management Services, Foreign Marketing & Sales Services, Production Operations, and Local Marketing & Sales Services, all of which are managed by qualified managers endowed with rich experience, and geared up for company future growth.                       </td>
				<td width="250">
		
					   <img src='elfora pict/232.jpg' width='80%' height="200px" />
					    <font size="4"color="#333300">
						
To satisfy the ever increasing demands and the stringent requirement of its clients for quality and safe products, ELFORA is constantly engaged in developing and upgrading abattoir facilities and procedures of slaughtering and processing of chilled/frozen carcasses of beef, mutton and goat meat. Cold truck fleet of vehicles is available to transport the carcasses to the pre-shipment waiting and loading point, at Bole International Airport in Addis Ababa, or Djibouti Port for export to the Middle East countries. 
<img src='elfora pict/232.jpg' width='80%' height="200px" />
                      </td>
					 
				<td width="250"valign="top">
				
					    <font size="3"color="#333300">
						<h4>Our Mission</h4>

A multi-sector organization with second-to-none leadership positions in each of our products and services there by exceeding the expectations of our customers, employees, shareholders and the community.
Since its establishment in 1997, the Company�s profitability and return on investment has been very low and even declining. For a company with total investment of over Birr 400 million, the rate of return on total investment (ROI) has averaged only 2.3 percent during its ten years of operation. The low level of return on investment (ROI) is the result of a combination of various factors. Among the problems are: high fluctuation in demand for some products and difficulty in planning production; underutilization of existing capacity; gap between time of production and demand volume resulting in supply inconsistency, loss of sales, and stocks piling up; higher selling prices than competitors�; inadequacy of promotional activities; escalation of air freight charges, making selling prices too high to be competitive in the international market; and high administrative and general expenses.
<img src='elfora pict/33.jpg' width='80%' height="200px" />
                    </tr>   </td>
                    
			 </table>
</body>
</html>

<HTML>
<body bgcolor="#CCCCCC">
<br>
<h2><center>Generate store information:</center></h2>
<br>
<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("OSI",$a);
$result = mysql_query("SELECT * FROM storeinfo",$a);
echo '<center><table bgcolor="black">';
echo'<TR><TD bgcolor="#9999FF"  width="70"><B>itemid</B><TD bgcolor="#9999FF"  width="160"><B>item name</B><TD bgcolor="#9999FF"  width="70"><B>date</B><TD  bgcolor="#9999FF" width="70"><B>quantity</B></TR>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="#9999FF" width="70">';
echo $row["postid"];
echo '</td>';
echo '<td bgcolor="#9999FF" width="70">';
echo $row["itemname"];
echo '</td>';
echo '<td bgcolor="#9999FF" width="70">';
echo $row["date"];
echo '</td>';
echo '<td bgcolor="#9999FF" width="70">';
echo $row["quantity"];
echo '</td>';

echo'</tr>';
}
echo '</TABLE>';
?>
</body>
</HTML>
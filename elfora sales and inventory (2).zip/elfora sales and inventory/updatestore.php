<?php
$con= mysql_connect("localhost", "root", "");
mysql_select_db("OSI",$con);	
$date= date('y/m/d');
$update="update addprice set date='$date',quantity='$_POST[quantity]',price='$_POST[price]' where itemname='$_POST[itemname]'";
$quer=mysql_query($update,$con);
echo '<script type="text/javascript">alert(" Succesfully update");window.location=\'updates.php\';</script>';
?>
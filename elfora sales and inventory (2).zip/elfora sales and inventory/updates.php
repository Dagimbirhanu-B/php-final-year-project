<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>online sales and inventory </title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

</head>
<div style="width:900px; height:700px; margin:0 auto; position:relative; border:2px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:25px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">
    <h2><center><span style="color:#9999FF">Fill Cost</span></center></h2>

<?php
$a=mysql_connect("localhost","root","");
 if(!$a)
 {die('could not connect' . mysql_error());}
else
//echo "connection established";
/* if(mysql_query("create database OPMS",$a))
echo "database created";
else
echo "database not created" . mysql_error();*/
mysql_select_db("OSI",$a);
if(isset($_POST['submit'])){
$date=date('y/m/d');
$s="INSERT INTO addprice(itemname,date,quantity,price) VALUES('$_POST[itemname]','$date','$_POST[quantity]','$_POST[price]')";
$result=mysql_query($s);
if($result){
 echo '<script type="text/javascript">alert(" successfully cost submited!!");window.location=\'cost.php\';</script>';
 echo "data is inserted";
    }
    else 
	echo '<script type="text/javascript">alert(" Date not inserted!!");window.location=\'cost.php\';</script>';
   echo "fail  data not inserted".mysql_error();
}
mysql_close($a)
?>
<html>
</head>


<center><h3><br>
<form action="cost.php" method="POST" name="cost" >
 <tr>
                  <td height="36"><span class="color:#9999FF">item name:</span></td>
                  <td><span id="sprytextfield3">
                    <label>
                  <select name="itemname" id="itemname">
				  <option>meat</option>
				  <option>tallow</option>
				  <option>tomato paste</option>
				  <option>menchet abesh</option>
                <option>bone</option>
                    <span class="textfieldRequiredMsg">A value is required.</span></span></td>
                </tr>
              <tr>
                <td>&nbsp;</td>
                <td><label><b> select</b>
                  <input type="submit" name="view" id="button" value="select" />
                </label></td>
              </tr><br><br>
<label>quantity</label><input type="text"name="quantity" /><br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<label>price</label><input type="text"name="price" /><br><br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="give cost" />
 <input type="reset" name="reset" value="Reset"  />
</form></center>
</body>
</html>
  
   
    <h2 align="center"><span style="color:#"> update store information </span></h2>
    <table width="70%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td height="27" bgcolor="#CCCCCC"><span class="color:#9999FF"><strong><h3>search item name</strong></span></td>
      </tr>
      <tr>
        <td height="26"><form id="form1" name="form1" method="post" action="updates.php">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
			 </tr>
             <tr>
                  <td height="36"><span class="color:#9999FF">item name:</span></td>
                  <td><span id="sprytextfield3">
                    <label>
                  <select name="itemname" id="itemname">
				  <option>meat</option>
				  <option>tallow</option>
				  <option>tomato paste</option>
				  <option>menchet abesh</option>
                <option>bone</option>
                    <span class="textfieldRequiredMsg">A value is required.</span></span></td>
                </tr>
              <tr>
                <td>&nbsp;</td>
                <td><label><b> select</b>
                  <input type="submit" name="view" id="button" value="select" />
                </label></td>
              </tr>
</table>
        </form></td>
      </tr>
      <tr>
        <td height="25" bgcolor="#9999FF"><span class="color:#9999FF"><strong>item List</strong></span></td>
      </tr>
      <tr>
        <td><table width="100%" border="1" bordercolor="black" >
		<tr>
	
            <tr>
              <th height="32" bgcolor="#9999FF" class="style3"><div align="left" class="style9 style5"><strong>item name</strong></div></th>
              <th bgcolor="#9999FF" class="style3"><div align="left" class="style9 style5"><strong>date</strong></div></th>
              <th bgcolor="#9999FF" class="style3"><div align="left" class="style12">quantity</div></th>
             <th bgcolor="#9999FF" class="style3"><div align="left" class="style12">price</div></th>
			   <th bgcolor="#9999FF" class="style3"><div align="left" class="style9 style5"><strong>update</strong></div></th>
              
            </tr>
           
		   
		    <?php
// Establish Connection with Database
$con = mysql_connect("localhost","root");
// Select Database
mysql_select_db("osi", $con);
if (isset($_POST['view'])) {
$itemname=$_POST['itemname'];
// Specify the query to execute
$sql = "select * from addprice where itemname='".$itemname."'";
// Execute query
$result = mysql_query($sql,$con);
// Loop through each records 
while($row = mysql_fetch_array($result))
{
$itemname=$row['itemname'];
$date=$row['date'];
$quantity=$row['quantity'];
$price=$row['price'];
?>

            <tr>
<td class="style3"><div align="left" class="style9 style5"><strong><form action="updatestore.php" method="post"><input name="itemname" type="text" id="itemname" readonly value="<?php echo $itemname;?>" /></strong></div></td>
<td class="style3"><div align="left" class="style9 style5"><strong><input name="date" type="text" id="date" readonly value="<?php echo $date;?>" /></strong></div></td>
			  <td class="style3"><div align="left" class="style9 style5"><strong><input name="quantity" type="text" id="quantity" value="<?php echo $quantity;?>" /></strong></div></td>
             <td class="style3"><div align="left" class="style9 style5"><strong><input name="price" type="text" id="price" value="<?php echo $price;?>" /></strong></div></td>
			  
              <td class="style3"><div align="left" class="style9 style5"><strong><input name="submit" type="submit" id="button" value="update" /></form></strong></div></td>
             
            </tr>
            <?php
	}		
// Retrieve Number of records returned
$records = mysql_num_rows($result);


?>
            <tr>
              <td colspan="4" class="style3"><div align="left" class="style12"><?php echo " ".$records." found"; ?> </div></td>
              
            </tr>
            <?php
			}
// Close the connection
mysql_close($con);
?>

        </table></td>
      </tr>
     
    </table>
    <p align="justify">&nbsp;</p>
    <table width="100%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
    </table>
    <p>&nbsp;</p>
  </div>
 

</body>
</html>



 <div style="width:720px; height:600px; margin:0 auto; position:relative; border:2px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:25px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">

 <div style="background-color:#666666;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;">
        
        
            <div style="float:left;" ><strong><font color="white" size="2px">view Advertisment</font></strong></div>
 <div style="float:right; margin-right:20px; background-color:#cccccc; width:25px;  text-align:center; border-radius:10px; height:12px;"></a></div>
<br>
<br>
<HTML>
<body>
<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("OSI",$a);
$result = mysql_query("SELECT * FROM advertise",$a);
echo '<center><table bgcolor="#999999" width="700" height="550">';

while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="60" height="20">';
echo $row["Gmanager"];
echo '</td>';
echo '<td bgcolor="white" width="200">';
echo $row["Advertise"];
echo '</td>';
echo'</tr>';
}
echo '</TABLE>';
?>
</body>
</div></div>
</HTML>
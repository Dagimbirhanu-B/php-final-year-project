
<html>
<head>
<title>
</title>
</head>
<body>
<?php
$con=mysql_connect("localhost","root","") or die('not connected');
$usertype=$_REQUEST['usertype'];
$username=$_REQUEST['username'];
$userid=$_REQUEST['userid'];
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$gender=$_REQUEST['gender'];
mysql_select_db("OSI",$con) or die("can not select the database");
$query="UPDATE account SET usertype='".$usertype."',username='".$username."',
 email='".$email."',password='".$password."',gender='".$gender."' WHERE userid='".$userid."' ";
$a=mysql_query($query,$con);
if(!$a)
{
die('data can not be Update' . mysql_error());
}
else
{
echo '<script type="text/javascript">alert(" successfully updated!!");window.location=\'up.php\';</script>';
}
?>
</body>
</html>
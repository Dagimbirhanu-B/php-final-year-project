<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <title>feedback</title>
<link rel="stylesheet" type="text/css" href="f.css" media="screen" />
</style>
<script type="text/javascript">
function validate(form)
{
var A=form.name.value;
var B=form.email.value;
var C=form.country.value;
var D=form.phone_number.value;
var E=form.comment.value;

 var check = /^[a-zA-Z\ \']+$/;
 var isNumeric = /^[0-9]+$/;
 var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;

if(!check.test(A))
{
alert("please enter only letter for name");
form.name.focus();
form.name.value="";
return false;
}
var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
if(!emailExp.test(B))
{
 alert("Please Enter Valid Email Address ");
 form.email.value="";
 form.email.focus();
 return false;  
}

if(!check.test(C))
{
alert("please enter only letter for country.");
form.country.focus();
form.country.value="";
return false;
}
if(!isNumeric.test(D))
{
alert("please enter only number for phone.");
form.phone_number.focus();
form.phone_number.value="";
return false;
}
$a=form.phone_number.length;
if($a<10||$a>10)
{
alert("please enter only 10 digit for phone number.");
form.phone_number.focus();
//form.phone.value="";
return false;
}

if(E=="")
{
alert("please enter your comment.");
form.comment.focus();
form.comment.value="";
return false;
}

 return true;
}
</script>
</head>
<body>
 <div id="container">
  <div id="wrapper">
   <div id="banner">
	<!--<img src="aa.jpg" alt="logo" style="max-height:100%; max-width:100%;">-->
   </div>
   <div id="nav">
	  <ul>
	   <li><a href="Home.php">Home<!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lt IE 7]><table><tr><td><![endif]-->
	     
		<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	    </li>
	   <li><a href="">About US<!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lt IE 7]><table><tr><td><![endif]-->
	     
		<!--[if lte IE 6]></td></tr></table></a><![endif]-->
	    </li>
  
	<div id="leftcol">
	
		

   </div>
   <div>We hope that this new developed system can help organization very well by:<br />
   1.reducing budget fluctuation<br />
   2.icreasing performance of work related to it<br />
   3.realy 70% it reduce lose of property.......</div>

   <div id="rightcol">
	  
   </div>

   <div id="content">
	 <center> <h2> <h2>
<hr color="#0000FF">
<form action="comment.php" method="post" onSubmit="return validate(this);" >
<table>
<tr>
<td>

<font color="#FF0000"><b>Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font> <input type="text" name="name" id="name"><br><br>
<font color="#FF0000"><b>Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font> <input type="text" name="email" id="email"><br><br>
<font color="#FF0000"><b>Country:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font> <input type="text" name="country" id="country"><br><br>
<font color="#FF0000"><b>Phone Number:&nbsp;</b></font> <input type="text" name="phone_number" id="phone_number"><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td>
<td rowspan="2" width="61">
</td>
</tr>
<tr>
<td align="right">
<textarea cols="50" rows="10" name="comment" style="color:#FF0000"></textarea>
</td>
<td>
<input type="submit" value="send" onclick="return valid(this.form);" />
</td>
</tr>
</table>
</form>	
   </div>
   
</body>
</html>

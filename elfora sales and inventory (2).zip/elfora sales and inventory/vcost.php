<HTML>
<div id="templatemo_content"> <div id="content_top"></div><div id="content_middle"><h1><center><font color="black">Generate Item and cost</font></center></h1>
 <div style="width:700px; height:350px; margin:0 auto; position:relative; border:2px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:25px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">

<?php
$a = mysql_connect("localhost", "root", "");
mysql_select_db("OSI",$a);
$result = mysql_query("SELECT * FROM addprice",$a);
echo '<center><table bgcolor="#cccccc">';
echo'<TR><TD bgcolor="pink"  width="150"><B>item name</B><TD bgcolor="pink"  width="150"><B>date</B><TD bgcolor="pink"  width="150"><B>quantity</B><TD  bgcolor="pink" width="150"><B>price</B></TR>';
while ($row = mysql_fetch_array($result))
{
echo '<tr>';
echo '<td bgcolor="white" width="150">';
echo $row["itemname"];
echo '</td>';
echo '<td bgcolor="white" width="150">';
echo $row["date"];
echo '</td>';
echo '<td bgcolor="white" width="150">';
echo $row["quantity"];
echo '</td>';
echo '<td bgcolor="white" width="150">';
echo $row["price"];
echo '</td>';
echo'</tr>';
}
echo '</TABLE>';
?>

</div>
</body>
</HTML>
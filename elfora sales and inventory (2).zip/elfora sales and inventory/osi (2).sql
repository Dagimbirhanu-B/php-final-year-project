-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 24, 2015 at 02:01 PM
-- Server version: 5.5.28
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `osi`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `usertype` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` char(1) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`usertype`, `username`, `userid`, `email`, `password`, `gender`) VALUES
('Customer', 'wawi', '44', 'wawi@yahoo.com', '44', 'M'),
('Admin', 'ashu', '33', 'ashu@gmail.com', '33', 'M'),
('Sales and Inventory', 'arif', '22', 'arif@yahoo.com', '22', 'M'),
('G.Manager', 'edom', '11', 'edi@gmail.com', '11', 'F');

-- --------------------------------------------------------

--
-- Table structure for table `addprice`
--

CREATE TABLE IF NOT EXISTS `addprice` (
  `itemname` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addprice`
--

INSERT INTO `addprice` (`itemname`, `date`, `quantity`, `price`) VALUES
('meat', '2015-06-23', '12', '12'),
('meat', '2015-06-23', '12', '12'),
('meat', '2015-06-23', '12', '12'),
('', '2015-06-23', '', ''),
('tallow', '2015-06-23', '100kg', '100'),
('meat', '2015-06-23', '12', '12');

-- --------------------------------------------------------

--
-- Table structure for table `advertise`
--

CREATE TABLE IF NOT EXISTS `advertise` (
  `Gmanager` varchar(30) NOT NULL,
  `Advertise` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advertise`
--

INSERT INTO `advertise` (`Gmanager`, `Advertise`) VALUES
('ashenafi', 'adsdffffffffgffffffffffffffffffffffgggggggggggggghhhhhhhhhhhhhhhhhh'),
('Ashu', 'wooooooooooooooooooooo\r\nwoooooooooooooooooooooo\r\nNoooooooooooooooooooooo\r\nNoooooooooooooooooooooo'),
('gggg', 'eeeeeee');

-- --------------------------------------------------------

--
-- Table structure for table `comment1`
--

CREATE TABLE IF NOT EXISTS `comment1` (
  `name` varchar(30) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment1`
--

INSERT INTO `comment1` (`name`, `comment`, `date`) VALUES
('Ashu', 'tow---tow---tow\r\naltowm----kkkk', '2015-06-01'),
('wawi', 'i am the best student', '2015-06-24');

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE IF NOT EXISTS `cost` (
  `ma` varchar(30) NOT NULL,
  `tomatopaste` varchar(30) NOT NULL,
  `boneandmeat` varchar(30) NOT NULL,
  `tallow` varchar(30) NOT NULL,
  `horn` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`ma`, `tomatopaste`, `boneandmeat`, `tallow`, `horn`) VALUES
('600 Br', '1000Br', '800Br', '111Br', '89Br'),
('600br', '123br', '90br', '12br', '50br'),
('', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `makeorder`
--

CREATE TABLE IF NOT EXISTS `makeorder` (
  `name` varchar(30) NOT NULL,
  `id` varchar(20) NOT NULL,
  `age` int(15) NOT NULL,
  `gender` char(1) NOT NULL,
  `address` varchar(15) NOT NULL,
  `phone_no` int(15) NOT NULL,
  `email` varchar(20) NOT NULL,
  `order_type` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `termination` varchar(30) NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `makeorder`
--

INSERT INTO `makeorder` (`name`, `id`, `age`, `gender`, `address`, `phone_no`, `email`, `order_type`, `quantity`, `status`, `termination`, `date`) VALUES
('ashu', '989', 0, 'm', 'dire', 9865432, 'ty@gmail.com', 'bone and meat', '55', 'Approved', 'yes', NULL),
('abd', '7865', 0, 'm', 'dire', 978654343, 'ty@gmail.com', 'tallow', '12', 'Approved', 'yes', NULL),
('ab', '234', 0, 'm', 'kocha', 9865432, 'ty@gmail.com', 'tallow', '12', 'Approved', 'yes', NULL),
('jirma', '8990', 0, 'm', 'Adamaa', 9865432, 'ty@gmail.com', 'horn', '11', 'Approved', 'yes', NULL),
('ab', '22', 23, 'M', 'dire', 9865432, 'ashu@gmail.com', 'tomato paste', '55k', 'Approved', 'yes', NULL),
('kb', '123', 23, 'M', 'wollo', 921695807, 'kb@yahoo.com', 'menchet abesh', '20kg', 'Approved', 'yes', '2015-04-10'),
('ashuuu', '12', 21, 'M', 'wollo', 921695807, 'ashu@gmail.com', 'tallow', '20kg', 'Approved', 'yes', '2015-06-23');

-- --------------------------------------------------------

--
-- Table structure for table `storeinfo`
--

CREATE TABLE IF NOT EXISTS `storeinfo` (
  `postid` int(20) NOT NULL AUTO_INCREMENT,
  `itemname` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `quantity` varchar(20) NOT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `storeinfo`
--

INSERT INTO `storeinfo` (`postid`, `itemname`, `date`, `quantity`) VALUES
(1, 'meat', '2015-04-10', '200g'),
(2, 'bone', '2015-04-10', '300kg'),
(3, 'tallow', '2015-04-10', '100kg'),
(4, 'menchet abesh', '2015-06-23', '25kg'),
(5, 'tomato paste', '2015-06-23', '30kg'),
(6, 'tallow', '2015-06-23', '100kg'),
(7, 'horn', '2015-06-23', '40kg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

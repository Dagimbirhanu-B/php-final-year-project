<html>
<head>
   <title>best home</title>
   <link rel="stylesheet"href="cas.css">
      <link rel="stylesheet"href="ee.css">
	  <link rel="stylesheet"href="MOHA_style.css">
	  
	  <script language="JavaScript">
function setVisibility(id, visibility) {
document.getElementById(id).style.display = visibility;
}

</script>  

</head>
<body>
<div id="wrapper">

<div id="moha_header>
<div id="moha_header">
<table  border="0" align="center" width="750px">
<!--Header-->
<tr>
<td width="700px" colspan="3" height="120px">
<p><img style="border-radius:20px;box-shadow:10px 5px 5px #3399CC" src="elfora pict/images11.JPG" align="left" width="200px" height="120px"><img style="border-radius:55px;box-shadow:10px 5px 5px #3399CC" src="elfora pict/arif.png" align="right" width="470px" height="120px"></p>
</td>
</tr>
</table> 
 <div id="shopping_cart_box">
            </div>
        


<div id="menu"><center>
<li><a href="homee.php" target="iframe1">Home</a></li>
���
<li><a href="RETA.php" target="iframe1">View Advertisment</a></li>�

<li><a href="#" >contact as</a>
<ul>
<li><a href="abus.php" target="iframe1">About us</a></li>
<li><a href=""="iframe1">contact as</a></li>�
<li><a href="feedback.php" target="iframe1">Feedback</a></li>��
</ul>
<li><a href="#" >social media center</a>
<ul>
<li><a href="http://www.google.com/" target="_parent">Google</a></li>
<li><a href="http://www.Facebook.com/" target="_parent">Facebook</a></li>
<li><a href="http://www.twitter.com/" target="_parent">Twitter</a></li></ul></li>
</ul>
<li><a href="vcost.php" target="iframe1">view item and price</a></li>�
<li><a href="log.html" target="_parent">Login</a></li>
</div>




 <div class="templatemo_sidebar_wrapper float_l">
                <div class="templatemo_sidebar_top"></div>
                <div class="templatemo_sidebar">
               
                    <div class="sidebar_box">
               
                        <h2>Elfora Agro-Industries Plc</h2>
                        <div class="sidebar_box_content">
                          <ul class="categories_list">
						  <li>
                       <h4>
					   Good Performance
					   </h4>
					     </li>
                              
                               
                            </ul>
							
							<div class="news_box">
                                       <img src="elfora pict/images16.jpg" height="120px" width="100%" alt="" />  
                                        
                            </div>
							
                             <div class="news_box">
                                         <img src="elfora pict/images11.jpg" height="120px" width="100%" alt="Elfora Agro-Industries Plc" />  
                                        <p>Elfora<span>Agro-Industries Plc</span>Is the Newst and leaates technology usable </p>
                            </div>
                            <div class="news_box">
                                         <img src="elfora pict/images.jpg"height="120px" width="100%" alt="" />  
                                       <p>Elfora<span>Agro-Industries Plc</span>�To provide quality products and sustained services to every customer and user� </p>
                            </div>
                         </div>
    
                    </div>
                
                      <br><br><br><br>
                
                </div> <div class="templatemo_sidebar_bottom"></div> <!-- end of sidebar -->
            </div> <!-- end of templatemo_sidebar_wrapper --> 
                <div id="templatemo_content">
                <div id="content_top"></div>
                <div id="content_middle">
                <iframe src=""name="iframe1"height="900"width="900"></iframe></div>
                </div>
                <div id="content_bottom"></div>
            </div> 
 <div class="templatemo_sidebar_wrapper float_r">
                <div class="templatemo_sidebar_top"></div>
                <div class="templatemo_sidebar">
                	
                    <div class="sidebar_box">
                
                   	<h2>1,108 employees in Ethiopia</h2>
                    
                    	<div class="sidebar_box_content">
            
                         	<div class="news_box">
                                       <img src="elfora pict/33.jpg" height="120px" width="100%" alt="Elfora Agro-Industries Plc" />  
                                        
                            </div>
                            <div class="news_box">
                                         <img src="elfora pict/images13.jpg" height="120px" width="100%" alt="Elfora Agro-Industries Plc" />  
                                        <p>Elfora<span>Elfora Agro-Industries Plc</span>satisfying the ever increasing demands and the stringent requirement of its clients. </p>
                            </div>
                            <div class="news_box">
                                         <img src="elfora pict/images12.jpg" height="120px" width="100%" alt="Elfora Agro-Industries Plc" />  
                                       <p>Elfora<span>Agro-Industries Plc</span> 	Produce and market high quality livestock and meat products both to the domestic and export markets. </p>
                            </div>
                            <br><br><br><br><br>
                            
                        </div> <!-- end of sidebar_box_content -->
                    </div> <!-- end of sidebar_box ( news ) -->
                    
                    <div class="sidebar_box">
                    
                    	
                        
                        
                        
                            
                            
                        
                    
                    </div> <!-- end of sidebar_box ( newsletter ) -->

                </div> <div class="templatemo_sidebar_bottom"></div> <!-- end of sidebar -->
            </div> <!-- end of templatemo_sidebar_wrapper --> 
            
            
          <div class="cleaner"></div>

      </div> <!-- end of templatemo_content_wrapper -->
        









<div id="footer"><center><font color="white">Developed by:Information Technology 4TH Year<br>Copy Right&copy;3A2007 All Rights Reserved</font></center></div>

</div>




</body>
</html>
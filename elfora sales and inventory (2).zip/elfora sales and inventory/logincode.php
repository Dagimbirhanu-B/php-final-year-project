<?php
session_start();
$usertype=$_POST['usertype'];
$userid=$_POST['userid'];
$password=$_POST['password'];
if($usertype=="Admin")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("OSI", $con);
$sql = "select * from account where userid='".$userid."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'log.html\';</script>'.mysql_error();
}
else
{
header("location:Admin.html");
} 
mysql_close($con);
}
else if($usertype=="G.manager")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("OSI",$con);
$sql = "select * from account where userid='".$userid."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'log.html\';</script>'.mysql_error();
}
else
{
header("location:gm.html");
$_SESSION['usertype']=$row['usertype'];
} 
mysql_close($con);
}
else if($usertype=="customer")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("OSI", $con);
$sql = "select * from account where userid='".$userid."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'log.html\';</script>'.mysql_error();
}
else
{
header("location:customer.html");
} 
mysql_close($con);
}
else if($usertype=="sales and inventory")
{
$con = mysql_connect("localhost","root","");
mysql_select_db("OSI", $con);
$sql = "select * from account where userid='".$userid."' and password='".$password."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
echo '<script type="text/javascript">alert("Wrong UserID or Password");window.location=\'log.html\';</script>'.mysql_error();
}
else
{
header("location:SI.html");
} 
mysql_close($con);
}
?>